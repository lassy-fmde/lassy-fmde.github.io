package generated.Library;

public class Book extends lu.uni.democles.runtime.Instance {
	private lu.uni.democles.runtime.Property _p_authors = new lu.uni.democles.runtime.Property(this, "authors", "Book", "Local", false, false, null, "set");
	private lu.uni.democles.runtime.Event _e_setCopies = new lu.uni.democles.runtime.Event(this, "setCopies", "Book", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Property _p_bookId = new lu.uni.democles.runtime.Property(this, "bookId", "Book", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_isbn = new lu.uni.democles.runtime.Property(this, "isbn", "Book", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_copies = new lu.uni.democles.runtime.Property(this, "copies", "Book", "Local", false, false, null, "set");
	private lu.uni.democles.runtime.Property _p_title = new lu.uni.democles.runtime.Property(this, "title", "Book", "Local", false, false, null, "single");
	private java.lang.Object __isbn_eval() {
		try {
	return null;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Library::Book/Property/isbn");
	throw _error;
}

	}
	private java.lang.Object __bookId_eval() {
		try {
	return null;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Library::Book/Property/bookId");
	throw _error;
}

	}
	protected boolean guard_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse) {
		
		return true;

	}
	protected void attachProperties(lu.uni.democles.runtime.Event e) {
		// Set Attached Properties:


	}
	private java.lang.Object eval_ep(final lu.uni.democles.runtime.Event e, final lu.uni.democles.runtime.Property p) {
		if (p.entityName.equals(this._p_copies.entityName) && e.entityName.equals(this._e_setCopies.entityName)) {
	return _setCopies_copies_eval(e);
}
		return null;

	}
	public Book() {
		super("generated.Library.Book", new java.lang.String[] {  });

	}
	protected java.lang.Object evalQuery(lu.uni.democles.runtime.Property p) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) return p.newVal;

if (p.isEvaluating()) throw new lu.uni.democles.runtime.ModificationCycleException();

p.setEvaluating(true);
java.lang.Object o = null;


		if ("title".equals(p.entityName)) {
	o = __title_eval();
	set(p, o);
}

		if ("copies".equals(p.entityName)) {
	o = __copies_eval();
	set(p, o);
}

		if ("bookId".equals(p.entityName)) {
	o = __bookId_eval();
	set(p, o);
}

		if ("isbn".equals(p.entityName)) {
	o = __isbn_eval();
	set(p, o);
}

		if ("authors".equals(p.entityName)) {
	o = __authors_eval();
	set(p, o);
}

		if (o instanceof lu.uni.democles.runtime.Instance) {
	((lu.uni.democles.runtime.Instance)o).initProps();
} else if (o instanceof lu.uni.democles.runtime.OCLCollection) {
	for (java.util.Iterator iter = ((lu.uni.democles.runtime.OCLCollection)o).getValues().iterator(); iter.hasNext();) {
		java.lang.Object entry = iter.next();
		if (entry instanceof lu.uni.democles.runtime.Instance) {
			((lu.uni.democles.runtime.Instance)entry).initProps();
		}
	}
}
p.setEvaluating(false);
return o;


	}
	public static void main(String[] args) {
	}
	private java.lang.Object __copies_eval() {
		try {
	return new lu.uni.democles.runtime.OCLSet(new Object[] {});

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Library::Book/Property/copies");
	throw _error;
}

	}
	private java.lang.Object _setCopies_copies_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return ((lu.uni.democles.runtime.OCLSet)_event.getParameter("copies"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|Library::Book/Event/setCopies-impacts-Library::Book/Property/copies");
	try {
		_error.addVariable("copies", _event.getParameter("copies"));
	} catch (Throwable _t) {
		_error.addVariable("copies", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	protected java.lang.Object eval_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse, final java.lang.String _paramName) {
		
		return null;

	}
	protected void resetNewVal() {
		this._p_title.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_copies.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_bookId.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_isbn.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_authors.newVal = lu.uni.democles.runtime.Entity.nullObject;
	}
	private void handleImpact(lu.uni.democles.runtime.Event e, lu.uni.democles.runtime.Property p) {
		set(p, eval_ep(e, p));
	}
	private java.lang.Object __authors_eval() {
		try {
	return new lu.uni.democles.runtime.OCLSet(new Object[] {});

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Library::Book/Property/authors");
	throw _error;
}

	}
	public static Book newWithValues(java.util.HashMap values) {
		Book res = new Book();
res.initialValues = new java.util.HashMap(values);
res.initProps();
return res;
	}
	private java.lang.Object __title_eval() {
		try {
	return null;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Library::Book/Property/title");
	throw _error;
}

	}
	protected boolean guard_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final lu.uni.democles.runtime.Instance linkedInstance, final int _link) {
		
		return true;

	}
	protected void doModify(lu.uni.democles.runtime.Event event) {
		if ("setCopies".equals(event.entityName)) {
	handleImpact(event, this._p_copies);
}

	}
	protected boolean guard(final lu.uni.democles.runtime.Event e1) {
		
		return true;

	}
	protected void set(lu.uni.democles.runtime.Property p, java.lang.Object v) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) {
	throw new lu.uni.democles.runtime.MultipleModificationException(p.toString());
}
p.newVal = v;
		super.set(p, v);
	}
	protected java.lang.Object eval_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final java.lang.String paramName, final int _link) {
		
		return null;

	}
	public void initProps() {
		if (this.isInitialized()) return;

		this._p_title.oldVal = this.initialValues.containsKey("title") ? this.initialValues.get("title") : eval_p(this._p_title).getValues().iterator().next();
this._p_title.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_title, this._p_title.oldVal);

		this._p_copies.oldVal = this.initialValues.containsKey("copies") ? this.initialValues.get("copies") : eval_p(this._p_copies);
this._p_copies.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_copies, this._p_copies.oldVal);

		this._p_bookId.oldVal = this.initialValues.containsKey("bookId") ? this.initialValues.get("bookId") : eval_p(this._p_bookId).getValues().iterator().next();
this._p_bookId.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_bookId, this._p_bookId.oldVal);

		this._p_isbn.oldVal = this.initialValues.containsKey("isbn") ? this.initialValues.get("isbn") : eval_p(this._p_isbn).getValues().iterator().next();
this._p_isbn.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_isbn, this._p_isbn.oldVal);

		this._p_authors.oldVal = this.initialValues.containsKey("authors") ? this.initialValues.get("authors") : eval_p(this._p_authors);
this._p_authors.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_authors, this._p_authors.oldVal);

		this.setInitialized();
this.initialValues = new java.util.HashMap();


	}
}
