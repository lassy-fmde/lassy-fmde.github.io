package generated.Library;

public class Library extends lu.uni.democles.runtime.Instance {
	private lu.uni.democles.runtime.Event _e_sessionOpened = new lu.uni.democles.runtime.Event(this, "sessionOpened", "Library", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_booksFound = new lu.uni.democles.runtime.Event(this, "booksFound", "Library", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_loginFailed = new lu.uni.democles.runtime.Event(this, "loginFailed", "Library", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Property _p_findBooks = new lu.uni.democles.runtime.Property(this, "findBooks", "Library", "Query", false, false, null, "set");
	private lu.uni.democles.runtime.Property _p_copies = new lu.uni.democles.runtime.Property(this, "copies", "Library", "Query", false, false, null, "set");
	private lu.uni.democles.runtime.Event _e_authenticateMember = new lu.uni.democles.runtime.Event(this, "authenticateMember", "Library", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.Library.Library", "sessionOpened", new java.lang.String[] {"member"}), new lu.uni.democles.runtime.ChildLink(true, "", "generated.Library.Library", "loginFailed", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Property _p_catalogue = new lu.uni.democles.runtime.Property(this, "catalogue", "Library", "Local", false, false, null, "set");
	private lu.uni.democles.runtime.Property _p_members = new lu.uni.democles.runtime.Property(this, "members", "Library", "Local", false, false, null, "set");
	private lu.uni.democles.runtime.Property _p_findMember = new lu.uni.democles.runtime.Property(this, "findMember", "Library", "Query", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_existsMember = new lu.uni.democles.runtime.Property(this, "existsMember", "Library", "Query", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_searchBook = new lu.uni.democles.runtime.Event(this, "searchBook", "Library", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.Library.Library", "booksFound", new java.lang.String[] {"foundBooks"}) });
	protected boolean guard_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse) {
		
		return true;

	}
	protected void attachProperties(lu.uni.democles.runtime.Event e) {
		// Set Attached Properties:
if ("searchBook".equals(e.entityName)) {
	e.attachProperty("Library_catalogue", this._p_catalogue.evalInContainer());
	e.attachProperty("Library_findBooks", this._p_findBooks.evalInContainer());
}


		// Set Attached Properties:


	}
	protected java.lang.Object evalQuery(lu.uni.democles.runtime.Property p) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) return p.newVal;

if (p.isEvaluating()) throw new lu.uni.democles.runtime.ModificationCycleException();

p.setEvaluating(true);
java.lang.Object o = null;


		if ("members".equals(p.entityName)) {
	o = __members_eval();
	set(p, o);
}

		if ("catalogue".equals(p.entityName)) {
	o = __catalogue_eval();
	set(p, o);
}

		if ("copies".equals(p.entityName)) {
	o = __copies_eval();
	set(p, o);
}

		if (o instanceof lu.uni.democles.runtime.Instance) {
	((lu.uni.democles.runtime.Instance)o).initProps();
} else if (o instanceof lu.uni.democles.runtime.OCLCollection) {
	for (java.util.Iterator iter = ((lu.uni.democles.runtime.OCLCollection)o).getValues().iterator(); iter.hasNext();) {
		java.lang.Object entry = iter.next();
		if (entry instanceof lu.uni.democles.runtime.Instance) {
			((lu.uni.democles.runtime.Instance)entry).initProps();
		}
	}
}
p.setEvaluating(false);
return o;


	}
	public static void main(String[] args) {
	}
	private java.lang.Object __copies_eval() {
		try {
	return (((lu.uni.democles.runtime.OCLBag)((lu.uni.democles.runtime.OCLSet)((lu.uni.democles.runtime.Property)generated.Library.Library.this.getEntity("catalogue")).evalInContainer()).collect(new lu.uni.democles.runtime.Function() {
	public Object _iteration(Object _value) {
final generated.Library.Book v_temp1 = ((generated.Library.Book)_value);
return _asObject(((lu.uni.democles.runtime.OCLSet)((lu.uni.democles.runtime.Property)v_temp1.getEntity("copies")).evalInContainer()));
	}
})).asSet());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Library::Library/Property/copies");
	throw _error;
}

	}
	protected java.lang.Object eval_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse, final java.lang.String _paramName) {
		
		return null;

	}
	public Library() {
		super("generated.Library.Library", new java.lang.String[] {  });

	}
	public generated.Library.Member __pq_findMember(final java.lang.String v_libNo) {
		try {
	return ((generated.Library.Member)((lu.uni.democles.runtime.OCLSet)((lu.uni.democles.runtime.Property)generated.Library.Library.this.getEntity("members")).evalInContainer()).any(new lu.uni.democles.runtime.Function() {
	public Object _iteration(Object _value) {
final generated.Library.Member v_m = ((generated.Library.Member)_value);
return _asObject((lu.uni.democles.runtime.Function._equals(((java.lang.String)((lu.uni.democles.runtime.Property)v_m.getEntity("libraryNo")).evalInContainer().getValues().iterator().next()), v_libNo)));
	}
}));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Library::Library/Property/findMember");
	_error.addVariable("libNo", v_libNo);
	throw _error;
}



	}
	protected void resetNewVal() {
		this._p_findMember.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_members.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_existsMember.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_findBooks.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_catalogue.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_copies.newVal = lu.uni.democles.runtime.Entity.nullObject;
	}
	protected boolean guard_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final lu.uni.democles.runtime.Instance linkedInstance, final int _link) {
		if (e1.entityName.equals("searchBook") && e2.entityName.equals("booksFound") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Library::Library/Event/searchBook$eventChildLink,Local,booksFound");
	try {
		_error.addVariable("catalogue", e1.getAttachedProperty("Library_catalogue"));
	} catch (Throwable _t) {
		_error.addVariable("catalogue", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("term", e1.getParameter("term"));
	} catch (Throwable _t) {
		_error.addVariable("term", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("category", e1.getParameter("category"));
	} catch (Throwable _t) {
		_error.addVariable("category", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		
		if (e1.entityName.equals("authenticateMember") && e2.entityName.equals("sessionOpened") && linkProperty == null) {
try {
	return (((boolean)((java.lang.Boolean)linkedInstance.evalQueryWithParameters("existsMember", new Object[] { ((java.lang.String)e1.getParameter("libNo")), ((java.lang.String)e1.getParameter("pw")) })).booleanValue()));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Library::Library/Event/authenticateMember$eventChildLink,Local,sessionOpened");
	try {
		_error.addVariable("libNo", e1.getParameter("libNo"));
	} catch (Throwable _t) {
		_error.addVariable("libNo", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("pw", e1.getParameter("pw"));
	} catch (Throwable _t) {
		_error.addVariable("pw", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}
if (e1.entityName.equals("authenticateMember") && e2.entityName.equals("loginFailed") && linkProperty == null) {
try {
	return (!(((boolean)((java.lang.Boolean)linkedInstance.evalQueryWithParameters("existsMember", new Object[] { ((java.lang.String)e1.getParameter("libNo")), ((java.lang.String)e1.getParameter("pw")) })).booleanValue())));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Library::Library/Event/authenticateMember$eventChildLink,Local,loginFailed");
	try {
		_error.addVariable("libNo", e1.getParameter("libNo"));
	} catch (Throwable _t) {
		_error.addVariable("libNo", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("pw", e1.getParameter("pw"));
	} catch (Throwable _t) {
		_error.addVariable("pw", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		return true;

	}
	public static Library newWithValues(java.util.HashMap values) {
		Library res = new Library();
res.initialValues = new java.util.HashMap(values);
res.initProps();
return res;
	}
	public lu.uni.democles.runtime.OCLSet __pq_findBooks(final java.lang.String v_term, final java.lang.String v_category) {
		try {
	return ((lu.uni.democles.runtime.OCLSet)((lu.uni.democles.runtime.Property)generated.Library.Library.this.getEntity("catalogue")).evalInContainer()).select(new lu.uni.democles.runtime.Function() {
	public Object _iteration(Object _value) {
final generated.Library.Book v_b = ((generated.Library.Book)_value);
return _asObject(((((lu.uni.democles.runtime.Function._equals(v_category, "Title")) && (lu.uni.democles.runtime.Function._equals(((java.lang.String)((lu.uni.democles.runtime.Property)v_b.getEntity("title")).evalInContainer().getValues().iterator().next()), v_term))) || ((lu.uni.democles.runtime.Function._equals(v_category, "ISBN")) && (lu.uni.democles.runtime.Function._equals(((java.lang.String)((lu.uni.democles.runtime.Property)v_b.getEntity("isbn")).evalInContainer().getValues().iterator().next()), v_term)))) || ((lu.uni.democles.runtime.Function._equals(v_category, "Author")) && ((lu.uni.democles.runtime.OCLSet)((lu.uni.democles.runtime.Property)v_b.getEntity("authors")).evalInContainer()).exists(new lu.uni.democles.runtime.Function() {
	public Object _iteration(Object _value) {
final generated.Library.Author v_a = ((generated.Library.Author)_value);
return _asObject((lu.uni.democles.runtime.Function._equals(((java.lang.String)((lu.uni.democles.runtime.Property)v_a.getEntity("name")).evalInContainer().getValues().iterator().next()), v_term)));
	}
}))));
	}
});

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Library::Library/Property/findBooks");
	_error.addVariable("term", v_term);
	_error.addVariable("category", v_category);
	throw _error;
}



	}
	protected boolean guard(final lu.uni.democles.runtime.Event e1) {
		
		return true;

	}
	private java.lang.Object __catalogue_eval() {
		try {
	return new lu.uni.democles.runtime.OCLSet(new Object[] {});

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Library::Library/Property/catalogue");
	throw _error;
}

	}
	private java.lang.Object __members_eval() {
		try {
	return new lu.uni.democles.runtime.OCLSet(new Object[] {});

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Library::Library/Property/members");
	throw _error;
}

	}
	protected void set(lu.uni.democles.runtime.Property p, java.lang.Object v) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) {
	throw new lu.uni.democles.runtime.MultipleModificationException(p.toString());
}
p.newVal = v;
		super.set(p, v);
	}
	protected java.lang.Object eval_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final java.lang.String paramName, final int _link) {
		if (e1.entityName.equals("searchBook") && e2.entityName.equals("booksFound") && linkProperty == null && paramName.equals("foundBooks")) {
try {
	return ((lu.uni.democles.runtime.OCLSet)((lu.uni.democles.runtime.Instance)e1.container).evalQueryWithParameters("findBooks", new Object[] { ((java.lang.String)e1.getParameter("term")), ((java.lang.String)e1.getParameter("category")) }));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|Library::Library/Event/searchBook$eventChildLink,Local,booksFound$foundBooks");
	try {
		_error.addVariable("catalogue", e1.getAttachedProperty("Library_catalogue"));
	} catch (Throwable _t) {
		_error.addVariable("catalogue", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("term", e1.getParameter("term"));
	} catch (Throwable _t) {
		_error.addVariable("term", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("category", e1.getParameter("category"));
	} catch (Throwable _t) {
		_error.addVariable("category", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		
		if (e1.entityName.equals("authenticateMember") && e2.entityName.equals("sessionOpened") && linkProperty == null && paramName.equals("member")) {
try {
	return (((generated.Library.Member)generated.Library.Library.this.evalQueryWithParameters("findMember", new Object[] { ((java.lang.String)e1.getParameter("libNo")) })));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|Library::Library/Event/authenticateMember$eventChildLink,Local,sessionOpened$member");
	try {
		_error.addVariable("libNo", e1.getParameter("libNo"));
	} catch (Throwable _t) {
		_error.addVariable("libNo", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("pw", e1.getParameter("pw"));
	} catch (Throwable _t) {
		_error.addVariable("pw", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		return null;

	}
	public void initProps() {
		if (this.isInitialized()) return;

		this._p_members.oldVal = this.initialValues.containsKey("members") ? this.initialValues.get("members") : eval_p(this._p_members);
this._p_members.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_members, this._p_members.oldVal);

		this._p_catalogue.oldVal = this.initialValues.containsKey("catalogue") ? this.initialValues.get("catalogue") : eval_p(this._p_catalogue);
this._p_catalogue.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_catalogue, this._p_catalogue.oldVal);

		this.setInitialized();
this.initialValues = new java.util.HashMap();


	}
	public boolean __pq_existsMember(final java.lang.String v_libNo, final java.lang.String v_pw) {
		try {
	return ((lu.uni.democles.runtime.OCLSet)((lu.uni.democles.runtime.Property)generated.Library.Library.this.getEntity("members")).evalInContainer()).exists(new lu.uni.democles.runtime.Function() {
	public Object _iteration(Object _value) {
final generated.Library.Member v_m = ((generated.Library.Member)_value);
return _asObject(((lu.uni.democles.runtime.Function._equals(((java.lang.String)((lu.uni.democles.runtime.Property)v_m.getEntity("libraryNo")).evalInContainer().getValues().iterator().next()), v_libNo)) && (lu.uni.democles.runtime.Function._equals(((java.lang.String)((lu.uni.democles.runtime.Property)v_m.getEntity("password")).evalInContainer().getValues().iterator().next()), v_pw))));
	}
});

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Library::Library/Property/existsMember");
	_error.addVariable("libNo", v_libNo);
	_error.addVariable("pw", v_pw);
	throw _error;
}



	}
}
