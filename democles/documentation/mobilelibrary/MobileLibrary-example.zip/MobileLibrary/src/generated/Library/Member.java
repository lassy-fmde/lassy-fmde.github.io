package generated.Library;

public class Member extends lu.uni.democles.runtime.Instance {
	private lu.uni.democles.runtime.Property _p_borrows = new lu.uni.democles.runtime.Property(this, "borrows", "Member", "Local", false, false, null, "set");
	private lu.uni.democles.runtime.Property _p_libraryNo = new lu.uni.democles.runtime.Property(this, "libraryNo", "Member", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_setToCollect = new lu.uni.democles.runtime.Event(this, "setToCollect", "Member", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Property _p_password = new lu.uni.democles.runtime.Property(this, "password", "Member", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_name = new lu.uni.democles.runtime.Property(this, "name", "Member", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_addCopyToCollect = new lu.uni.democles.runtime.Event(this, "addCopyToCollect", "Member", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Property _p_toCollect = new lu.uni.democles.runtime.Property(this, "toCollect", "Member", "Local", false, false, null, "set");
	private lu.uni.democles.runtime.Event _e_setBorrows = new lu.uni.democles.runtime.Event(this, "setBorrows", "Member", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private java.lang.Object _setToCollect_toCollect_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return ((lu.uni.democles.runtime.OCLSet)_event.getParameter("toCollect"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|Library::Member/Event/setToCollect-impacts-Library::Member/Property/toCollect");
	try {
		_error.addVariable("toCollect", _event.getParameter("toCollect"));
	} catch (Throwable _t) {
		_error.addVariable("toCollect", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	private java.lang.Object __name_eval() {
		try {
	return null;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Library::Member/Property/name");
	throw _error;
}

	}
	protected boolean guard_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse) {
		
		return true;

	}
	private java.lang.Object eval_ep(final lu.uni.democles.runtime.Event e, final lu.uni.democles.runtime.Property p) {
		if (p.entityName.equals(this._p_toCollect.entityName) && e.entityName.equals(this._e_addCopyToCollect.entityName)) {
	return _addCopyToCollect_toCollect_eval(e);
}
		if (p.entityName.equals(this._p_toCollect.entityName) && e.entityName.equals(this._e_setToCollect.entityName)) {
	return _setToCollect_toCollect_eval(e);
}
		if (p.entityName.equals(this._p_borrows.entityName) && e.entityName.equals(this._e_setBorrows.entityName)) {
	return _setBorrows_borrows_eval(e);
}
		return null;

	}
	protected void attachProperties(lu.uni.democles.runtime.Event e) {
		// Set Attached Properties:


	}
	protected java.lang.Object evalQuery(lu.uni.democles.runtime.Property p) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) return p.newVal;

if (p.isEvaluating()) throw new lu.uni.democles.runtime.ModificationCycleException();

p.setEvaluating(true);
java.lang.Object o = null;


		if ("password".equals(p.entityName)) {
	o = __password_eval();
	set(p, o);
}

		if ("toCollect".equals(p.entityName)) {
	o = __toCollect_eval();
	set(p, o);
}

		if ("libraryNo".equals(p.entityName)) {
	o = __libraryNo_eval();
	set(p, o);
}

		if ("borrows".equals(p.entityName)) {
	o = __borrows_eval();
	set(p, o);
}

		if ("name".equals(p.entityName)) {
	o = __name_eval();
	set(p, o);
}

		if (o instanceof lu.uni.democles.runtime.Instance) {
	((lu.uni.democles.runtime.Instance)o).initProps();
} else if (o instanceof lu.uni.democles.runtime.OCLCollection) {
	for (java.util.Iterator iter = ((lu.uni.democles.runtime.OCLCollection)o).getValues().iterator(); iter.hasNext();) {
		java.lang.Object entry = iter.next();
		if (entry instanceof lu.uni.democles.runtime.Instance) {
			((lu.uni.democles.runtime.Instance)entry).initProps();
		}
	}
}
p.setEvaluating(false);
return o;


	}
	public static void main(String[] args) {
	}
	protected java.lang.Object eval_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse, final java.lang.String _paramName) {
		
		return null;

	}
	protected void resetNewVal() {
		this._p_password.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_toCollect.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_libraryNo.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_borrows.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_name.newVal = lu.uni.democles.runtime.Entity.nullObject;
	}
	private void handleImpact(lu.uni.democles.runtime.Event e, lu.uni.democles.runtime.Property p) {
		set(p, eval_ep(e, p));
	}
	private java.lang.Object __password_eval() {
		try {
	return null;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Library::Member/Property/password");
	throw _error;
}

	}
	private java.lang.Object _addCopyToCollect_toCollect_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return (((lu.uni.democles.runtime.OCLSet)((lu.uni.democles.runtime.Property)generated.Library.Member.this.getEntity("toCollect")).evalInContainer()).union(new lu.uni.democles.runtime.OCLSet(new Object[] {((generated.Library.Copy)_event.getParameter("copy"))})));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|Library::Member/Event/addCopyToCollect-impacts-Library::Member/Property/toCollect");
	try {
		_error.addVariable("copy", _event.getParameter("copy"));
	} catch (Throwable _t) {
		_error.addVariable("copy", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	protected boolean guard_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final lu.uni.democles.runtime.Instance linkedInstance, final int _link) {
		
		return true;

	}
	private java.lang.Object _setBorrows_borrows_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return ((lu.uni.democles.runtime.OCLSet)_event.getParameter("borrows"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|Library::Member/Event/setBorrows-impacts-Library::Member/Property/borrows");
	try {
		_error.addVariable("borrows", _event.getParameter("borrows"));
	} catch (Throwable _t) {
		_error.addVariable("borrows", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	protected void doModify(lu.uni.democles.runtime.Event event) {
		if ("setBorrows".equals(event.entityName)) {
	handleImpact(event, this._p_borrows);
}
if ("setToCollect".equals(event.entityName)) {
	handleImpact(event, this._p_toCollect);
}
if ("addCopyToCollect".equals(event.entityName)) {
	handleImpact(event, this._p_toCollect);
}

	}
	private java.lang.Object __borrows_eval() {
		try {
	return new lu.uni.democles.runtime.OCLSet(new Object[] {});

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Library::Member/Property/borrows");
	throw _error;
}

	}
	protected boolean guard(final lu.uni.democles.runtime.Event e1) {
		
		return true;

	}
	private java.lang.Object __toCollect_eval() {
		try {
	return new lu.uni.democles.runtime.OCLSet(new Object[] {});

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Library::Member/Property/toCollect");
	throw _error;
}

	}
	protected void set(lu.uni.democles.runtime.Property p, java.lang.Object v) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) {
	throw new lu.uni.democles.runtime.MultipleModificationException(p.toString());
}
p.newVal = v;
		super.set(p, v);
	}
	public static Member newWithValues(java.util.HashMap values) {
		Member res = new Member();
res.initialValues = new java.util.HashMap(values);
res.initProps();
return res;
	}
	protected java.lang.Object eval_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final java.lang.String paramName, final int _link) {
		
		return null;

	}
	public Member() {
		super("generated.Library.Member", new java.lang.String[] {  });

	}
	public void initProps() {
		if (this.isInitialized()) return;

		this._p_password.oldVal = this.initialValues.containsKey("password") ? this.initialValues.get("password") : eval_p(this._p_password).getValues().iterator().next();
this._p_password.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_password, this._p_password.oldVal);

		this._p_toCollect.oldVal = this.initialValues.containsKey("toCollect") ? this.initialValues.get("toCollect") : eval_p(this._p_toCollect);
this._p_toCollect.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_toCollect, this._p_toCollect.oldVal);

		this._p_libraryNo.oldVal = this.initialValues.containsKey("libraryNo") ? this.initialValues.get("libraryNo") : eval_p(this._p_libraryNo).getValues().iterator().next();
this._p_libraryNo.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_libraryNo, this._p_libraryNo.oldVal);

		this._p_borrows.oldVal = this.initialValues.containsKey("borrows") ? this.initialValues.get("borrows") : eval_p(this._p_borrows);
this._p_borrows.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_borrows, this._p_borrows.oldVal);

		this._p_name.oldVal = this.initialValues.containsKey("name") ? this.initialValues.get("name") : eval_p(this._p_name).getValues().iterator().next();
this._p_name.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_name, this._p_name.oldVal);

		this.setInitialized();
this.initialValues = new java.util.HashMap();


	}
	private java.lang.Object __libraryNo_eval() {
		try {
	return null;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Library::Member/Property/libraryNo");
	throw _error;
}

	}
}
