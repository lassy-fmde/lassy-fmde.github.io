package generated.Library;

public class Author extends lu.uni.democles.runtime.Instance {
	private lu.uni.democles.runtime.Property _p_name = new lu.uni.democles.runtime.Property(this, "name", "Author", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_authorId = new lu.uni.democles.runtime.Property(this, "authorId", "Author", "Local", false, false, null, "single");
	public static Author newWithValues(java.util.HashMap values) {
		Author res = new Author();
res.initialValues = new java.util.HashMap(values);
res.initProps();
return res;
	}
	public Author() {
		super("generated.Library.Author", new java.lang.String[] {  });

	}
	public void initProps() {
		if (this.isInitialized()) return;

		this._p_authorId.oldVal = this.initialValues.containsKey("authorId") ? this.initialValues.get("authorId") : eval_p(this._p_authorId).getValues().iterator().next();
this._p_authorId.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_authorId, this._p_authorId.oldVal);

		this._p_name.oldVal = this.initialValues.containsKey("name") ? this.initialValues.get("name") : eval_p(this._p_name).getValues().iterator().next();
this._p_name.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_name, this._p_name.oldVal);

		this.setInitialized();
this.initialValues = new java.util.HashMap();


	}
	protected void set(lu.uni.democles.runtime.Property p, java.lang.Object v) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) {
	throw new lu.uni.democles.runtime.MultipleModificationException(p.toString());
}
p.newVal = v;
		super.set(p, v);
	}
	protected java.lang.Object evalQuery(lu.uni.democles.runtime.Property p) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) return p.newVal;

if (p.isEvaluating()) throw new lu.uni.democles.runtime.ModificationCycleException();

p.setEvaluating(true);
java.lang.Object o = null;


		if ("authorId".equals(p.entityName)) {
	o = __authorId_eval();
	set(p, o);
}

		if ("name".equals(p.entityName)) {
	o = __name_eval();
	set(p, o);
}

		if (o instanceof lu.uni.democles.runtime.Instance) {
	((lu.uni.democles.runtime.Instance)o).initProps();
} else if (o instanceof lu.uni.democles.runtime.OCLCollection) {
	for (java.util.Iterator iter = ((lu.uni.democles.runtime.OCLCollection)o).getValues().iterator(); iter.hasNext();) {
		java.lang.Object entry = iter.next();
		if (entry instanceof lu.uni.democles.runtime.Instance) {
			((lu.uni.democles.runtime.Instance)entry).initProps();
		}
	}
}
p.setEvaluating(false);
return o;


	}
	private java.lang.Object __name_eval() {
		try {
	return null;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Library::Author/Property/name");
	throw _error;
}

	}
	private java.lang.Object __authorId_eval() {
		try {
	return null;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Library::Author/Property/authorId");
	throw _error;
}

	}
	protected void resetNewVal() {
		this._p_authorId.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_name.newVal = lu.uni.democles.runtime.Entity.nullObject;
	}
	public static void main(String[] args) {
	}
}
