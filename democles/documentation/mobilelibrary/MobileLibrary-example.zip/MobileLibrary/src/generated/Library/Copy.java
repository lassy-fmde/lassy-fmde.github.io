package generated.Library;

public class Copy extends lu.uni.democles.runtime.Instance {
	private lu.uni.democles.runtime.Property _p_renewals = new lu.uni.democles.runtime.Property(this, "renewals", "Copy", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_renewOk = new lu.uni.democles.runtime.Event(this, "renewOk", "Copy", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_renew = new lu.uni.democles.runtime.Event(this, "renew", "Copy", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.Library.Copy", "renewOk", new java.lang.String[] {"newDueDate"}), new lu.uni.democles.runtime.ChildLink(true, "", "generated.Library.Copy", "renewFailed", new java.lang.String[] {"copy"}) });
	private lu.uni.democles.runtime.Event _e_reserveOk = new lu.uni.democles.runtime.Event(this, "reserveOk", "Copy", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_reserve = new lu.uni.democles.runtime.Event(this, "reserve", "Copy", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.Library.Copy", "reserveOk", new java.lang.String[] {}), new lu.uni.democles.runtime.ChildLink(true, "", "generated.Library.Copy", "reserveFailed", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Property _p_dueDate = new lu.uni.democles.runtime.Property(this, "dueDate", "Copy", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_copyId = new lu.uni.democles.runtime.Property(this, "copyId", "Copy", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_renewFailed = new lu.uni.democles.runtime.Event(this, "renewFailed", "Copy", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Property _p_state = new lu.uni.democles.runtime.Property(this, "state", "Copy", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_reserveFailed = new lu.uni.democles.runtime.Event(this, "reserveFailed", "Copy", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Property _p_book = new lu.uni.democles.runtime.Property(this, "book", "Copy", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_maxRenewals = new lu.uni.democles.runtime.Property(this, "maxRenewals", "Copy", "Query", false, false, null, "single");
	protected boolean guard_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse) {
		
		return true;

	}
	protected void attachProperties(lu.uni.democles.runtime.Event e) {
		// Set Attached Properties:


	}
	private java.lang.Object eval_ep(final lu.uni.democles.runtime.Event e, final lu.uni.democles.runtime.Property p) {
		if (p.entityName.equals(this._p_renewals.entityName) && e.entityName.equals(this._e_renewOk.entityName)) {
	return _renewOk_renewals_eval(e);
}
		if (p.entityName.equals(this._p_state.entityName) && e.entityName.equals(this._e_reserveOk.entityName)) {
	return _reserveOk_state_eval(e);
}
		if (p.entityName.equals(this._p_dueDate.entityName) && e.entityName.equals(this._e_renewOk.entityName)) {
	return _renewOk_dueDate_eval(e);
}
		return null;

	}
	protected java.lang.Object evalQuery(lu.uni.democles.runtime.Property p) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) return p.newVal;

if (p.isEvaluating()) throw new lu.uni.democles.runtime.ModificationCycleException();

p.setEvaluating(true);
java.lang.Object o = null;


		if ("dueDate".equals(p.entityName)) {
	o = __dueDate_eval();
	set(p, o);
}

		if ("renewals".equals(p.entityName)) {
	o = __renewals_eval();
	set(p, o);
}

		if ("book".equals(p.entityName)) {
	o = __book_eval();
	set(p, o);
}

		if ("maxRenewals".equals(p.entityName)) {
	o = __maxRenewals_eval();
	set(p, o);
}

		if ("copyId".equals(p.entityName)) {
	o = __copyId_eval();
	set(p, o);
}

		if ("state".equals(p.entityName)) {
	o = __state_eval();
	set(p, o);
}

		if (o instanceof lu.uni.democles.runtime.Instance) {
	((lu.uni.democles.runtime.Instance)o).initProps();
} else if (o instanceof lu.uni.democles.runtime.OCLCollection) {
	for (java.util.Iterator iter = ((lu.uni.democles.runtime.OCLCollection)o).getValues().iterator(); iter.hasNext();) {
		java.lang.Object entry = iter.next();
		if (entry instanceof lu.uni.democles.runtime.Instance) {
			((lu.uni.democles.runtime.Instance)entry).initProps();
		}
	}
}
p.setEvaluating(false);
return o;


	}
	public static void main(String[] args) {
	}
	private java.lang.Object _renewOk_renewals_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return new java.lang.Integer((((int)((java.lang.Integer)((lu.uni.democles.runtime.Property)generated.Library.Copy.this.getEntity("renewals")).evalInContainer().getValues().iterator().next()).intValue()) + 1));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|Library::Copy/Event/renewOk-impacts-Library::Copy/Property/renewals");
	try {
		_error.addVariable("newDueDate", _event.getParameter("newDueDate"));
	} catch (Throwable _t) {
		_error.addVariable("newDueDate", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	protected java.lang.Object eval_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse, final java.lang.String _paramName) {
		
		return null;

	}
	public Copy() {
		super("generated.Library.Copy", new java.lang.String[] {  });

	}
	protected void resetNewVal() {
		this._p_dueDate.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_renewals.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_book.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_maxRenewals.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_copyId.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_state.newVal = lu.uni.democles.runtime.Entity.nullObject;
	}
	private void handleImpact(lu.uni.democles.runtime.Event e, lu.uni.democles.runtime.Property p) {
		set(p, eval_ep(e, p));
	}
	private java.lang.Object _reserveOk_state_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return "ToCollect";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|Library::Copy/Event/reserveOk-impacts-Library::Copy/Property/state");
	throw _error;
}


	}
	public static Copy newWithValues(java.util.HashMap values) {
		Copy res = new Copy();
res.initialValues = new java.util.HashMap(values);
res.initProps();
return res;
	}
	protected boolean guard_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final lu.uni.democles.runtime.Instance linkedInstance, final int _link) {
		
		if (e1.entityName.equals("renew") && e2.entityName.equals("renewOk") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Library::Copy/Event/renew$eventChildLink,Local,renewOk");
	try {
		_error.addVariable("newDueDate", e1.getParameter("newDueDate"));
	} catch (Throwable _t) {
		_error.addVariable("newDueDate", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}
if (e1.entityName.equals("renew") && e2.entityName.equals("renewFailed") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Library::Copy/Event/renew$eventChildLink,Local,renewFailed");
	try {
		_error.addVariable("newDueDate", e1.getParameter("newDueDate"));
	} catch (Throwable _t) {
		_error.addVariable("newDueDate", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("reserve") && e2.entityName.equals("reserveOk") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Library::Copy/Event/reserve$eventChildLink,Local,reserveOk");
	throw _error;
}
	}
if (e1.entityName.equals("reserve") && e2.entityName.equals("reserveFailed") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Library::Copy/Event/reserve$eventChildLink,Local,reserveFailed");
	throw _error;
}
	}

		return true;

	}
	private java.lang.Object __dueDate_eval() {
		try {
	return null;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Library::Copy/Property/dueDate");
	throw _error;
}

	}
	private java.lang.Object _renewOk_dueDate_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return ((java.lang.String)_event.getParameter("newDueDate"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|Library::Copy/Event/renewOk-impacts-Library::Copy/Property/dueDate");
	try {
		_error.addVariable("newDueDate", _event.getParameter("newDueDate"));
	} catch (Throwable _t) {
		_error.addVariable("newDueDate", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	private java.lang.Object __renewals_eval() {
		try {
	return new java.lang.Integer(0);

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Library::Copy/Property/renewals");
	throw _error;
}

	}
	protected void doModify(lu.uni.democles.runtime.Event event) {
		if ("renewOk".equals(event.entityName)) {
	handleImpact(event, this._p_renewals);
}
if ("renewOk".equals(event.entityName)) {
	handleImpact(event, this._p_dueDate);
}
if ("reserveOk".equals(event.entityName)) {
	handleImpact(event, this._p_state);
}

	}
	private java.lang.Object __copyId_eval() {
		try {
	return null;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Library::Copy/Property/copyId");
	throw _error;
}

	}
	protected boolean guard(final lu.uni.democles.runtime.Event e1) {
			if ("reserveFailed".equals(e1.entityName)) {
try {
	return (!lu.uni.democles.runtime.Function._equals(((java.lang.String)((lu.uni.democles.runtime.Property)generated.Library.Copy.this.getEntity("state")).evalInContainer().getValues().iterator().next()), "Borrowable"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_GUARD|Library::Copy/Event/reserveFailed");
	throw _error;
}
	}

			if ("renewFailed".equals(e1.entityName)) {
try {
	return (((int)((java.lang.Integer)((lu.uni.democles.runtime.Property)generated.Library.Copy.this.getEntity("renewals")).evalInContainer().getValues().iterator().next()).intValue()) >= ((int)((java.lang.Integer)((lu.uni.democles.runtime.Property)generated.Library.Copy.this.getEntity("maxRenewals")).evalInContainer().getValues().iterator().next()).intValue()));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_GUARD|Library::Copy/Event/renewFailed");
	try {
		_error.addVariable("copy", e1.getParameter("copy"));
	} catch (Throwable _t) {
		_error.addVariable("copy", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

			if ("renew".equals(e1.entityName)) {
try {
	return (lu.uni.democles.runtime.Function._equals(((java.lang.String)((lu.uni.democles.runtime.Property)generated.Library.Copy.this.getEntity("state")).evalInContainer().getValues().iterator().next()), "Onloan"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_GUARD|Library::Copy/Event/renew");
	try {
		_error.addVariable("newDueDate", e1.getParameter("newDueDate"));
	} catch (Throwable _t) {
		_error.addVariable("newDueDate", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		
			if ("reserveOk".equals(e1.entityName)) {
try {
	return (lu.uni.democles.runtime.Function._equals(((java.lang.String)((lu.uni.democles.runtime.Property)generated.Library.Copy.this.getEntity("state")).evalInContainer().getValues().iterator().next()), "Borrowable"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_GUARD|Library::Copy/Event/reserveOk");
	throw _error;
}
	}

			if ("renewOk".equals(e1.entityName)) {
try {
	return (((int)((java.lang.Integer)((lu.uni.democles.runtime.Property)generated.Library.Copy.this.getEntity("renewals")).evalInContainer().getValues().iterator().next()).intValue()) < ((int)((java.lang.Integer)((lu.uni.democles.runtime.Property)generated.Library.Copy.this.getEntity("maxRenewals")).evalInContainer().getValues().iterator().next()).intValue()));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_GUARD|Library::Copy/Event/renewOk");
	try {
		_error.addVariable("newDueDate", e1.getParameter("newDueDate"));
	} catch (Throwable _t) {
		_error.addVariable("newDueDate", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		return true;

	}
	protected void set(lu.uni.democles.runtime.Property p, java.lang.Object v) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) {
	throw new lu.uni.democles.runtime.MultipleModificationException(p.toString());
}
p.newVal = v;
		super.set(p, v);
	}
	protected java.lang.Object eval_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final java.lang.String paramName, final int _link) {
		
		if (e1.entityName.equals("renew") && e2.entityName.equals("renewOk") && linkProperty == null && paramName.equals("newDueDate")) {
try {
	return ((java.lang.String)e1.getParameter("newDueDate"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|Library::Copy/Event/renew$eventChildLink,Local,renewOk$newDueDate");
	try {
		_error.addVariable("newDueDate", e1.getParameter("newDueDate"));
	} catch (Throwable _t) {
		_error.addVariable("newDueDate", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}
if (e1.entityName.equals("renew") && e2.entityName.equals("renewFailed") && linkProperty == null && paramName.equals("copy")) {
try {
	return generated.Library.Copy.this;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|Library::Copy/Event/renew$eventChildLink,Local,renewFailed$copy");
	try {
		_error.addVariable("newDueDate", e1.getParameter("newDueDate"));
	} catch (Throwable _t) {
		_error.addVariable("newDueDate", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		return null;

	}
	private java.lang.Object __state_eval() {
		try {
	return "Borrowable";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Library::Copy/Property/state");
	throw _error;
}

	}
	private java.lang.Object __maxRenewals_eval() {
		try {
	return new java.lang.Integer(3);

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Library::Copy/Property/maxRenewals");
	throw _error;
}

	}
	public void initProps() {
		if (this.isInitialized()) return;

		this._p_dueDate.oldVal = this.initialValues.containsKey("dueDate") ? this.initialValues.get("dueDate") : eval_p(this._p_dueDate).getValues().iterator().next();
this._p_dueDate.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_dueDate, this._p_dueDate.oldVal);

		this._p_renewals.oldVal = this.initialValues.containsKey("renewals") ? this.initialValues.get("renewals") : eval_p(this._p_renewals).getValues().iterator().next();
this._p_renewals.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_renewals, this._p_renewals.oldVal);

		this._p_book.oldVal = this.initialValues.containsKey("book") ? this.initialValues.get("book") : eval_p(this._p_book).getValues().iterator().next();
this._p_book.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_book, this._p_book.oldVal);

		this._p_copyId.oldVal = this.initialValues.containsKey("copyId") ? this.initialValues.get("copyId") : eval_p(this._p_copyId).getValues().iterator().next();
this._p_copyId.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_copyId, this._p_copyId.oldVal);

		this._p_state.oldVal = this.initialValues.containsKey("state") ? this.initialValues.get("state") : eval_p(this._p_state).getValues().iterator().next();
this._p_state.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_state, this._p_state.oldVal);

		this.setInitialized();
this.initialValues = new java.util.HashMap();


	}
	private java.lang.Object __book_eval() {
		try {
	return null;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Library::Copy/Property/book");
	throw _error;
}

	}
}
