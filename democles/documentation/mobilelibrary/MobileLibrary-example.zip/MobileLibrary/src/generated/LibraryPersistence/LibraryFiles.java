package generated.LibraryPersistence;

public class LibraryFiles extends lu.uni.democles.runtime.Instance {
	private lu.uni.democles.runtime.Event _e_saveCopies = new lu.uni.democles.runtime.Event(this, "saveCopies", "LibraryFiles", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "saveCopiesFileHandler", "generated.Persistence.FileHandler", "saveString", new java.lang.String[] {"filename", "content"}) });
	private lu.uni.democles.runtime.Event _e_memberLineRead = new lu.uni.democles.runtime.Event(this, "memberLineRead", "LibraryFiles", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.Persistence.FileHandler", "memberFileHandler", "lineread", new java.lang.String[] {"line"}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "memberStringTokenizer", "generated.StringUtils.StringTokenizer", "tokenizeString", new java.lang.String[] {"string", "separator"}) });
	private lu.uni.democles.runtime.Property _p_findCopies = new lu.uni.democles.runtime.Property(this, "findCopies", "LibraryFiles", "Query", false, false, null, "set");
	private lu.uni.democles.runtime.Event _e_toCollectFileClosed = new lu.uni.democles.runtime.Event(this, "toCollectFileClosed", "LibraryFiles", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.Persistence.FileHandler", "toCollectFileHandler", "fileClosed", new java.lang.String[] {}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.LibraryPersistence.LibraryFiles", "libraryLoaded", new java.lang.String[] {"library"}) });
	private lu.uni.democles.runtime.Event _e_memberFileClosed = new lu.uni.democles.runtime.Event(this, "memberFileClosed", "LibraryFiles", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.Persistence.FileHandler", "memberFileHandler", "fileClosed", new java.lang.String[] {}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.LibraryPersistence.LibraryFiles", "loadBorrows", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Event _e_bookFileClosed = new lu.uni.democles.runtime.Event(this, "bookFileClosed", "LibraryFiles", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.Persistence.FileHandler", "bookFileHandler", "fileClosed", new java.lang.String[] {}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.LibraryPersistence.LibraryFiles", "loadCopies", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Event _e_loadBooks = new lu.uni.democles.runtime.Event(this, "loadBooks", "LibraryFiles", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "bookFileHandler", "generated.Persistence.FileHandler", "openFile", new java.lang.String[] {"filename"}) });
	private lu.uni.democles.runtime.Property _p_saveToCollectFileHandler = new lu.uni.democles.runtime.Property(this, "saveToCollectFileHandler", "LibraryFiles", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_load = new lu.uni.democles.runtime.Event(this, "load", "LibraryFiles", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.LibraryPersistence.LibraryFiles", "loadAuthors", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Property _p_authors = new lu.uni.democles.runtime.Property(this, "authors", "LibraryFiles", "Local", false, false, null, "set");
	private lu.uni.democles.runtime.Property _p_borrowsStringTokenizer = new lu.uni.democles.runtime.Property(this, "borrowsStringTokenizer", "LibraryFiles", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_updateBookCopies = new lu.uni.democles.runtime.Event(this, "updateBookCopies", "LibraryFiles", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "books", "generated.Library.Book", "setCopies", new java.lang.String[] {"copies"}), new lu.uni.democles.runtime.ChildLink(true, "", "generated.LibraryPersistence.LibraryFiles", "loadMembers", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Event _e_saveToCollect = new lu.uni.democles.runtime.Event(this, "saveToCollect", "LibraryFiles", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "saveToCollectFileHandler", "generated.Persistence.FileHandler", "saveString", new java.lang.String[] {"filename", "content"}) });
	private lu.uni.democles.runtime.Property _p_copyFileHandler = new lu.uni.democles.runtime.Property(this, "copyFileHandler", "LibraryFiles", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_loadMembers = new lu.uni.democles.runtime.Event(this, "loadMembers", "LibraryFiles", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "memberFileHandler", "generated.Persistence.FileHandler", "openFile", new java.lang.String[] {"filename"}) });
	private lu.uni.democles.runtime.Property _p_findAuthors = new lu.uni.democles.runtime.Property(this, "findAuthors", "LibraryFiles", "Query", false, false, null, "set");
	private lu.uni.democles.runtime.Event _e_authorsLineRead = new lu.uni.democles.runtime.Event(this, "authorsLineRead", "LibraryFiles", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.Persistence.FileHandler", "authorFileHandler", "lineread", new java.lang.String[] {"line"}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "authorStringTokenizer", "generated.StringUtils.StringTokenizer", "tokenizeString", new java.lang.String[] {"string", "separator"}) });
	private lu.uni.democles.runtime.Property _p_bookFileHandler = new lu.uni.democles.runtime.Property(this, "bookFileHandler", "LibraryFiles", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_copyLineTokenized = new lu.uni.democles.runtime.Event(this, "copyLineTokenized", "LibraryFiles", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.StringUtils.StringTokenizer", "copyStringTokenizer", "stringTokenized", new java.lang.String[] {"tokens"}) }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Property _p_authorFileHandler = new lu.uni.democles.runtime.Property(this, "authorFileHandler", "LibraryFiles", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_copyStringTokenizer = new lu.uni.democles.runtime.Property(this, "copyStringTokenizer", "LibraryFiles", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_borrowsLineTokenized = new lu.uni.democles.runtime.Event(this, "borrowsLineTokenized", "LibraryFiles", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.StringUtils.StringTokenizer", "borrowsStringTokenizer", "stringTokenized", new java.lang.String[] {"tokens"}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "members", "generated.Library.Member", "setBorrows", new java.lang.String[] {"borrows"}) });
	private lu.uni.democles.runtime.Event _e_saveLibrary = new lu.uni.democles.runtime.Event(this, "saveLibrary", "LibraryFiles", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.LibraryPersistence.LibraryFiles", "saveCopies", new java.lang.String[] {"copies"}), new lu.uni.democles.runtime.ChildLink(true, "", "generated.LibraryPersistence.LibraryFiles", "saveBorrows", new java.lang.String[] {"members"}), new lu.uni.democles.runtime.ChildLink(true, "", "generated.LibraryPersistence.LibraryFiles", "saveToCollect", new java.lang.String[] {"members"}) });
	private lu.uni.democles.runtime.Event _e_borrowsFileClosed = new lu.uni.democles.runtime.Event(this, "borrowsFileClosed", "LibraryFiles", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.Persistence.FileHandler", "borrowsFileHandler", "fileClosed", new java.lang.String[] {}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.LibraryPersistence.LibraryFiles", "loadToCollect", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Event _e_loadToCollect = new lu.uni.democles.runtime.Event(this, "loadToCollect", "LibraryFiles", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "toCollectFileHandler", "generated.Persistence.FileHandler", "openFile", new java.lang.String[] {"filename"}) });
	private lu.uni.democles.runtime.Event _e_copyFileClosed = new lu.uni.democles.runtime.Event(this, "copyFileClosed", "LibraryFiles", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.Persistence.FileHandler", "copyFileHandler", "fileClosed", new java.lang.String[] {}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.LibraryPersistence.LibraryFiles", "updateBookCopies", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Property _p_borrowsFileHandler = new lu.uni.democles.runtime.Property(this, "borrowsFileHandler", "LibraryFiles", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_toCollectFileHandler = new lu.uni.democles.runtime.Property(this, "toCollectFileHandler", "LibraryFiles", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_books = new lu.uni.democles.runtime.Property(this, "books", "LibraryFiles", "Local", false, false, null, "set");
	private lu.uni.democles.runtime.Event _e_borrowsLineRead = new lu.uni.democles.runtime.Event(this, "borrowsLineRead", "LibraryFiles", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.Persistence.FileHandler", "borrowsFileHandler", "lineread", new java.lang.String[] {"line"}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "borrowsStringTokenizer", "generated.StringUtils.StringTokenizer", "tokenizeString", new java.lang.String[] {"string", "separator"}) });
	private lu.uni.democles.runtime.Property _p_memberStringTokenizer = new lu.uni.democles.runtime.Property(this, "memberStringTokenizer", "LibraryFiles", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_members = new lu.uni.democles.runtime.Property(this, "members", "LibraryFiles", "Local", false, false, null, "set");
	private lu.uni.democles.runtime.Event _e_copyLineRead = new lu.uni.democles.runtime.Event(this, "copyLineRead", "LibraryFiles", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.Persistence.FileHandler", "copyFileHandler", "lineread", new java.lang.String[] {"line"}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "copyStringTokenizer", "generated.StringUtils.StringTokenizer", "tokenizeString", new java.lang.String[] {"string", "separator"}) });
	private lu.uni.democles.runtime.Property _p_bookStringTokenizer = new lu.uni.democles.runtime.Property(this, "bookStringTokenizer", "LibraryFiles", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_toCollectLineTokenized = new lu.uni.democles.runtime.Event(this, "toCollectLineTokenized", "LibraryFiles", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.StringUtils.StringTokenizer", "toCollectStringTokenizer", "stringTokenized", new java.lang.String[] {"tokens"}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "members", "generated.Library.Member", "setToCollect", new java.lang.String[] {"toCollect"}) });
	private lu.uni.democles.runtime.Property _p_saveBorrowsFileHandler = new lu.uni.democles.runtime.Property(this, "saveBorrowsFileHandler", "LibraryFiles", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_findCopy = new lu.uni.democles.runtime.Property(this, "findCopy", "LibraryFiles", "Query", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_intToString = new lu.uni.democles.runtime.Property(this, "intToString", "LibraryFiles", "Query", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_authorsFileClosed = new lu.uni.democles.runtime.Event(this, "authorsFileClosed", "LibraryFiles", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.Persistence.FileHandler", "authorFileHandler", "fileClosed", new java.lang.String[] {}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.LibraryPersistence.LibraryFiles", "loadBooks", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Property _p_authorStringTokenizer = new lu.uni.democles.runtime.Property(this, "authorStringTokenizer", "LibraryFiles", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_libraryLoaded = new lu.uni.democles.runtime.Event(this, "libraryLoaded", "LibraryFiles", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Property _p_findBook = new lu.uni.democles.runtime.Property(this, "findBook", "LibraryFiles", "Query", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_bookLineTokenized = new lu.uni.democles.runtime.Event(this, "bookLineTokenized", "LibraryFiles", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.StringUtils.StringTokenizer", "bookStringTokenizer", "stringTokenized", new java.lang.String[] {"tokens"}) }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_loadBorrows = new lu.uni.democles.runtime.Event(this, "loadBorrows", "LibraryFiles", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "borrowsFileHandler", "generated.Persistence.FileHandler", "openFile", new java.lang.String[] {"filename"}) });
	private lu.uni.democles.runtime.Property _p_memberFileHandler = new lu.uni.democles.runtime.Property(this, "memberFileHandler", "LibraryFiles", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_copies = new lu.uni.democles.runtime.Property(this, "copies", "LibraryFiles", "Local", false, false, null, "set");
	private lu.uni.democles.runtime.Property _p_toCollectStringTokenizer = new lu.uni.democles.runtime.Property(this, "toCollectStringTokenizer", "LibraryFiles", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_loadAuthors = new lu.uni.democles.runtime.Event(this, "loadAuthors", "LibraryFiles", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "authorFileHandler", "generated.Persistence.FileHandler", "openFile", new java.lang.String[] {"filename"}) });
	private lu.uni.democles.runtime.Event _e_bookLineRead = new lu.uni.democles.runtime.Event(this, "bookLineRead", "LibraryFiles", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.Persistence.FileHandler", "bookFileHandler", "lineread", new java.lang.String[] {"line"}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "bookStringTokenizer", "generated.StringUtils.StringTokenizer", "tokenizeString", new java.lang.String[] {"string", "separator"}) });
	private lu.uni.democles.runtime.Event _e_loadCopies = new lu.uni.democles.runtime.Event(this, "loadCopies", "LibraryFiles", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "copyFileHandler", "generated.Persistence.FileHandler", "openFile", new java.lang.String[] {"filename"}) });
	private lu.uni.democles.runtime.Property _p_saveCopiesFileHandler = new lu.uni.democles.runtime.Property(this, "saveCopiesFileHandler", "LibraryFiles", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_authorsLineTokenized = new lu.uni.democles.runtime.Event(this, "authorsLineTokenized", "LibraryFiles", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.StringUtils.StringTokenizer", "authorStringTokenizer", "stringTokenized", new java.lang.String[] {"tokens"}) }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_memberLineTokenized = new lu.uni.democles.runtime.Event(this, "memberLineTokenized", "LibraryFiles", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.StringUtils.StringTokenizer", "memberStringTokenizer", "stringTokenized", new java.lang.String[] {"tokens"}) }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_toCollectLineRead = new lu.uni.democles.runtime.Event(this, "toCollectLineRead", "LibraryFiles", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.Persistence.FileHandler", "toCollectFileHandler", "lineread", new java.lang.String[] {"line"}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "toCollectStringTokenizer", "generated.StringUtils.StringTokenizer", "tokenizeString", new java.lang.String[] {"string", "separator"}) });
	private lu.uni.democles.runtime.Event _e_saveBorrows = new lu.uni.democles.runtime.Event(this, "saveBorrows", "LibraryFiles", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "saveBorrowsFileHandler", "generated.Persistence.FileHandler", "saveString", new java.lang.String[] {"filename", "content"}) });
	private java.lang.Object __authors_eval() {
		try {
	return new lu.uni.democles.runtime.OCLSet(new Object[] {});

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|LibraryPersistence::LibraryFiles/Property/authors");
	throw _error;
}

	}
	private java.lang.Object __memberFileHandler_eval() {
		try {
	return (new generated.Persistence.FileHandler());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|LibraryPersistence::LibraryFiles/Property/memberFileHandler");
	throw _error;
}

	}
	private java.lang.Object __bookFileHandler_eval() {
		try {
	return (new generated.Persistence.FileHandler());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|LibraryPersistence::LibraryFiles/Property/bookFileHandler");
	throw _error;
}

	}
	public LibraryFiles() {
		super("generated.LibraryPersistence.LibraryFiles", new java.lang.String[] {  });

	}
	private java.lang.Object __memberStringTokenizer_eval() {
		try {
	return (new generated.StringUtils.StringTokenizer());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|LibraryPersistence::LibraryFiles/Property/memberStringTokenizer");
	throw _error;
}

	}
	private java.lang.Object __authorFileHandler_eval() {
		try {
	return (new generated.Persistence.FileHandler());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|LibraryPersistence::LibraryFiles/Property/authorFileHandler");
	throw _error;
}

	}
	protected java.lang.Object eval_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse, final java.lang.String _paramName) {
		
		if (_parent.entityName.equals("stringTokenized") && _event.entityName.equals("memberLineTokenized") && _linkProperty.entityName.equals("memberStringTokenizer") && _inverse == false && _paramName.equals("tokens")) {
try {
	return ((lu.uni.democles.runtime.OCLSequence)_parent.getParameter("tokens"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/memberLineTokenized$eventParentLink,Forward,memberStringTokenizer,StringUtils::StringTokenizer,stringTokenized$tokens");
	try {
		_error.addVariable("tokens", _parent.getParameter("tokens"));
	} catch (Throwable _t) {
		_error.addVariable("tokens", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (_parent.entityName.equals("stringTokenized") && _event.entityName.equals("bookLineTokenized") && _linkProperty.entityName.equals("bookStringTokenizer") && _inverse == false && _paramName.equals("tokens")) {
try {
	return ((lu.uni.democles.runtime.OCLSequence)_parent.getParameter("tokens"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/bookLineTokenized$eventParentLink,Forward,bookStringTokenizer,StringUtils::StringTokenizer,stringTokenized$tokens");
	try {
		_error.addVariable("tokens", _parent.getParameter("tokens"));
	} catch (Throwable _t) {
		_error.addVariable("tokens", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (_parent.entityName.equals("stringTokenized") && _event.entityName.equals("toCollectLineTokenized") && _linkProperty.entityName.equals("toCollectStringTokenizer") && _inverse == false && _paramName.equals("tokens")) {
try {
	return ((lu.uni.democles.runtime.OCLSequence)_parent.getParameter("tokens"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/toCollectLineTokenized$eventParentLink,Forward,toCollectStringTokenizer,StringUtils::StringTokenizer,stringTokenized$tokens");
	try {
		_error.addVariable("tokens", _parent.getParameter("tokens"));
	} catch (Throwable _t) {
		_error.addVariable("tokens", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (_parent.entityName.equals("lineread") && _event.entityName.equals("toCollectLineRead") && _linkProperty.entityName.equals("toCollectFileHandler") && _inverse == false && _paramName.equals("line")) {
try {
	return ((java.lang.String)_parent.getParameter("line"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/toCollectLineRead$eventParentLink,Forward,toCollectFileHandler,Persistence::FileHandler,lineread$line");
	try {
		_error.addVariable("line", _parent.getParameter("line"));
	} catch (Throwable _t) {
		_error.addVariable("line", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (_parent.entityName.equals("lineread") && _event.entityName.equals("bookLineRead") && _linkProperty.entityName.equals("bookFileHandler") && _inverse == false && _paramName.equals("line")) {
try {
	return ((java.lang.String)_parent.getParameter("line"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/bookLineRead$eventParentLink,Forward,bookFileHandler,Persistence::FileHandler,lineread$line");
	try {
		_error.addVariable("line", _parent.getParameter("line"));
	} catch (Throwable _t) {
		_error.addVariable("line", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (_parent.entityName.equals("lineread") && _event.entityName.equals("authorsLineRead") && _linkProperty.entityName.equals("authorFileHandler") && _inverse == false && _paramName.equals("line")) {
try {
	return ((java.lang.String)_parent.getParameter("line"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/authorsLineRead$eventParentLink,Forward,authorFileHandler,Persistence::FileHandler,lineread$line");
	try {
		_error.addVariable("line", _parent.getParameter("line"));
	} catch (Throwable _t) {
		_error.addVariable("line", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (_parent.entityName.equals("lineread") && _event.entityName.equals("copyLineRead") && _linkProperty.entityName.equals("copyFileHandler") && _inverse == false && _paramName.equals("line")) {
try {
	return ((java.lang.String)_parent.getParameter("line"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/copyLineRead$eventParentLink,Forward,copyFileHandler,Persistence::FileHandler,lineread$line");
	try {
		_error.addVariable("line", _parent.getParameter("line"));
	} catch (Throwable _t) {
		_error.addVariable("line", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (_parent.entityName.equals("stringTokenized") && _event.entityName.equals("authorsLineTokenized") && _linkProperty.entityName.equals("authorStringTokenizer") && _inverse == false && _paramName.equals("tokens")) {
try {
	return ((lu.uni.democles.runtime.OCLSequence)_parent.getParameter("tokens"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/authorsLineTokenized$eventParentLink,Forward,authorStringTokenizer,StringUtils::StringTokenizer,stringTokenized$tokens");
	try {
		_error.addVariable("tokens", _parent.getParameter("tokens"));
	} catch (Throwable _t) {
		_error.addVariable("tokens", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (_parent.entityName.equals("lineread") && _event.entityName.equals("memberLineRead") && _linkProperty.entityName.equals("memberFileHandler") && _inverse == false && _paramName.equals("line")) {
try {
	return ((java.lang.String)_parent.getParameter("line"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/memberLineRead$eventParentLink,Forward,memberFileHandler,Persistence::FileHandler,lineread$line");
	try {
		_error.addVariable("line", _parent.getParameter("line"));
	} catch (Throwable _t) {
		_error.addVariable("line", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (_parent.entityName.equals("stringTokenized") && _event.entityName.equals("borrowsLineTokenized") && _linkProperty.entityName.equals("borrowsStringTokenizer") && _inverse == false && _paramName.equals("tokens")) {
try {
	return ((lu.uni.democles.runtime.OCLSequence)_parent.getParameter("tokens"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/borrowsLineTokenized$eventParentLink,Forward,borrowsStringTokenizer,StringUtils::StringTokenizer,stringTokenized$tokens");
	try {
		_error.addVariable("tokens", _parent.getParameter("tokens"));
	} catch (Throwable _t) {
		_error.addVariable("tokens", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (_parent.entityName.equals("stringTokenized") && _event.entityName.equals("copyLineTokenized") && _linkProperty.entityName.equals("copyStringTokenizer") && _inverse == false && _paramName.equals("tokens")) {
try {
	return ((lu.uni.democles.runtime.OCLSequence)_parent.getParameter("tokens"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/copyLineTokenized$eventParentLink,Forward,copyStringTokenizer,StringUtils::StringTokenizer,stringTokenized$tokens");
	try {
		_error.addVariable("tokens", _parent.getParameter("tokens"));
	} catch (Throwable _t) {
		_error.addVariable("tokens", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (_parent.entityName.equals("lineread") && _event.entityName.equals("borrowsLineRead") && _linkProperty.entityName.equals("borrowsFileHandler") && _inverse == false && _paramName.equals("line")) {
try {
	return ((java.lang.String)_parent.getParameter("line"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/borrowsLineRead$eventParentLink,Forward,borrowsFileHandler,Persistence::FileHandler,lineread$line");
	try {
		_error.addVariable("line", _parent.getParameter("line"));
	} catch (Throwable _t) {
		_error.addVariable("line", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		return null;

	}
	private java.lang.Object __copies_eval() {
		try {
	return new lu.uni.democles.runtime.OCLSet(new Object[] {});

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|LibraryPersistence::LibraryFiles/Property/copies");
	throw _error;
}

	}
	public generated.Library.Copy __pq_findCopy(final java.lang.String v_copyId) {
		try {
	return ((generated.Library.Copy)((lu.uni.democles.runtime.OCLSet)((lu.uni.democles.runtime.Property)generated.LibraryPersistence.LibraryFiles.this.getEntity("copies")).evalInContainer()).any(new lu.uni.democles.runtime.Function() {
	public Object _iteration(Object _value) {
final generated.Library.Copy v_c = ((generated.Library.Copy)_value);
return _asObject((lu.uni.democles.runtime.Function._equals(v_copyId, ((java.lang.String)((lu.uni.democles.runtime.Property)v_c.getEntity("copyId")).evalInContainer().getValues().iterator().next()))));
	}
}));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|LibraryPersistence::LibraryFiles/Property/findCopy");
	_error.addVariable("copyId", v_copyId);
	throw _error;
}



	}
	private java.lang.Object __toCollectStringTokenizer_eval() {
		try {
	return (new generated.StringUtils.StringTokenizer());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|LibraryPersistence::LibraryFiles/Property/toCollectStringTokenizer");
	throw _error;
}

	}
	protected boolean guard(final lu.uni.democles.runtime.Event e1) {
		
		return true;

	}
	protected java.lang.Object eval_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final java.lang.String paramName, final int _link) {
		if (e1.entityName.equals("saveLibrary") && e2.entityName.equals("saveCopies") && linkProperty == null && paramName.equals("copies")) {
try {
	return (((lu.uni.democles.runtime.OCLSet)((lu.uni.democles.runtime.Property)((generated.Library.Library)e1.getParameter("library")).getEntity("copies")).evalInContainer()).asSequence());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/saveLibrary$eventChildLink,Local,saveCopies$copies");
	try {
		_error.addVariable("library", e1.getParameter("library"));
	} catch (Throwable _t) {
		_error.addVariable("library", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}
if (e1.entityName.equals("saveLibrary") && e2.entityName.equals("saveBorrows") && linkProperty == null && paramName.equals("members")) {
try {
	return (((lu.uni.democles.runtime.OCLSet)((lu.uni.democles.runtime.Property)((generated.Library.Library)e1.getParameter("library")).getEntity("members")).evalInContainer()).asSequence());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/saveLibrary$eventChildLink,Local,saveBorrows$members");
	try {
		_error.addVariable("library", e1.getParameter("library"));
	} catch (Throwable _t) {
		_error.addVariable("library", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}
if (e1.entityName.equals("saveLibrary") && e2.entityName.equals("saveToCollect") && linkProperty == null && paramName.equals("members")) {
try {
	return (((lu.uni.democles.runtime.OCLSet)((lu.uni.democles.runtime.Property)((generated.Library.Library)e1.getParameter("library")).getEntity("members")).evalInContainer()).asSequence());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/saveLibrary$eventChildLink,Local,saveToCollect$members");
	try {
		_error.addVariable("library", e1.getParameter("library"));
	} catch (Throwable _t) {
		_error.addVariable("library", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		
		if (e1.entityName.equals("toCollectLineTokenized") && e2.entityName.equals("setToCollect") && linkProperty.entityName.equals("members") && paramName.equals("toCollect")) {
try {
	return (((lu.uni.democles.runtime.OCLSet)((lu.uni.democles.runtime.Property)this.getEntity("toCollect")).evalInContainer()).including((((generated.Library.Copy)generated.LibraryPersistence.LibraryFiles.this.evalQueryWithParameters("findCopy", new Object[] { (((java.lang.String)((lu.uni.democles.runtime.OCLSequence)e1.getParameter("tokens")).at((int)2))) })))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/toCollectLineTokenized$eventChildLink,Forward,members,Library::Member,setToCollect$toCollect");
	try {
		_error.addVariable("tokens", e1.getParameter("tokens"));
	} catch (Throwable _t) {
		_error.addVariable("tokens", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("toCollectLineRead") && e2.entityName.equals("tokenizeString") && linkProperty.entityName.equals("toCollectStringTokenizer") && paramName.equals("string")) {
try {
	return ((java.lang.String)e1.getParameter("line"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/toCollectLineRead$eventChildLink,Forward,toCollectStringTokenizer,StringUtils::StringTokenizer,tokenizeString$string");
	try {
		_error.addVariable("line", e1.getParameter("line"));
	} catch (Throwable _t) {
		_error.addVariable("line", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}
if (e1.entityName.equals("toCollectLineRead") && e2.entityName.equals("tokenizeString") && linkProperty.entityName.equals("toCollectStringTokenizer") && paramName.equals("separator")) {
try {
	return ";";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/toCollectLineRead$eventChildLink,Forward,toCollectStringTokenizer,StringUtils::StringTokenizer,tokenizeString$separator");
	try {
		_error.addVariable("line", e1.getParameter("line"));
	} catch (Throwable _t) {
		_error.addVariable("line", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("bookLineRead") && e2.entityName.equals("tokenizeString") && linkProperty.entityName.equals("bookStringTokenizer") && paramName.equals("string")) {
try {
	return ((java.lang.String)e1.getParameter("line"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/bookLineRead$eventChildLink,Forward,bookStringTokenizer,StringUtils::StringTokenizer,tokenizeString$string");
	try {
		_error.addVariable("line", e1.getParameter("line"));
	} catch (Throwable _t) {
		_error.addVariable("line", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}
if (e1.entityName.equals("bookLineRead") && e2.entityName.equals("tokenizeString") && linkProperty.entityName.equals("bookStringTokenizer") && paramName.equals("separator")) {
try {
	return ";";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/bookLineRead$eventChildLink,Forward,bookStringTokenizer,StringUtils::StringTokenizer,tokenizeString$separator");
	try {
		_error.addVariable("line", e1.getParameter("line"));
	} catch (Throwable _t) {
		_error.addVariable("line", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("loadBooks") && e2.entityName.equals("openFile") && linkProperty.entityName.equals("bookFileHandler") && paramName.equals("filename")) {
try {
	return "BookData.dat";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/loadBooks$eventChildLink,Forward,bookFileHandler,Persistence::FileHandler,openFile$filename");
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("authorsLineRead") && e2.entityName.equals("tokenizeString") && linkProperty.entityName.equals("authorStringTokenizer") && paramName.equals("string")) {
try {
	return ((java.lang.String)e1.getParameter("line"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/authorsLineRead$eventChildLink,Forward,authorStringTokenizer,StringUtils::StringTokenizer,tokenizeString$string");
	try {
		_error.addVariable("line", e1.getParameter("line"));
	} catch (Throwable _t) {
		_error.addVariable("line", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}
if (e1.entityName.equals("authorsLineRead") && e2.entityName.equals("tokenizeString") && linkProperty.entityName.equals("authorStringTokenizer") && paramName.equals("separator")) {
try {
	return ";";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/authorsLineRead$eventChildLink,Forward,authorStringTokenizer,StringUtils::StringTokenizer,tokenizeString$separator");
	try {
		_error.addVariable("line", e1.getParameter("line"));
	} catch (Throwable _t) {
		_error.addVariable("line", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("saveCopies") && e2.entityName.equals("saveString") && linkProperty.entityName.equals("saveCopiesFileHandler") && paramName.equals("filename")) {
try {
	return "CopyData.dat";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/saveCopies$eventChildLink,Forward,saveCopiesFileHandler,Persistence::FileHandler,saveString$filename");
	try {
		_error.addVariable("copies", e1.getParameter("copies"));
	} catch (Throwable _t) {
		_error.addVariable("copies", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}
if (e1.entityName.equals("saveCopies") && e2.entityName.equals("saveString") && linkProperty.entityName.equals("saveCopiesFileHandler") && paramName.equals("content")) {
try {
	return ((java.lang.String)new lu.uni.democles.runtime.Function() {
	public Object _result() {
		final lu.uni.democles.runtime.OCLSequence v_copyStrings = ((lu.uni.democles.runtime.OCLSequence)((lu.uni.democles.runtime.OCLSequence)e1.getParameter("copies")).collect(new lu.uni.democles.runtime.Function() {
	public Object _iteration(Object _value) {
final generated.Library.Copy v_temp1 = ((generated.Library.Copy)_value);
return _asObject(((((((((((java.lang.String)((lu.uni.democles.runtime.Property)v_temp1.getEntity("copyId")).evalInContainer().getValues().iterator().next()) + ";") + ((java.lang.String)((lu.uni.democles.runtime.Property)v_temp1.getEntity("state")).evalInContainer().getValues().iterator().next())) + ";") + ((java.lang.String)((lu.uni.democles.runtime.Property)v_temp1.getEntity("dueDate")).evalInContainer().getValues().iterator().next())) + ";") + (((java.lang.String)generated.LibraryPersistence.LibraryFiles.this.evalQueryWithParameters("intToString", new Object[] { new java.lang.Integer(((int)((java.lang.Integer)((lu.uni.democles.runtime.Property)v_temp1.getEntity("renewals")).evalInContainer().getValues().iterator().next()).intValue())) })))) + ";") + ((java.lang.String)((lu.uni.democles.runtime.Property)((generated.Library.Book)((lu.uni.democles.runtime.Property)v_temp1.getEntity("book")).evalInContainer().getValues().iterator().next()).getEntity("bookId")).evalInContainer().getValues().iterator().next())));
	}
}));
		return _asObject(((java.lang.String)v_copyStrings.iterate(new lu.uni.democles.runtime.Function() {
	public Object _iterate(Object _value, Object _acc) {
final java.lang.String v_output = ((java.lang.String)_acc);
final java.lang.String v_line = ((java.lang.String)_value);
return _asObject(((v_output + v_line) + "\n"));
	}
}, "")));
	}
}._result());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/saveCopies$eventChildLink,Forward,saveCopiesFileHandler,Persistence::FileHandler,saveString$content");
	try {
		_error.addVariable("copies", e1.getParameter("copies"));
	} catch (Throwable _t) {
		_error.addVariable("copies", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("copyLineRead") && e2.entityName.equals("tokenizeString") && linkProperty.entityName.equals("copyStringTokenizer") && paramName.equals("string")) {
try {
	return ((java.lang.String)e1.getParameter("line"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/copyLineRead$eventChildLink,Forward,copyStringTokenizer,StringUtils::StringTokenizer,tokenizeString$string");
	try {
		_error.addVariable("line", e1.getParameter("line"));
	} catch (Throwable _t) {
		_error.addVariable("line", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}
if (e1.entityName.equals("copyLineRead") && e2.entityName.equals("tokenizeString") && linkProperty.entityName.equals("copyStringTokenizer") && paramName.equals("separator")) {
try {
	return ";";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/copyLineRead$eventChildLink,Forward,copyStringTokenizer,StringUtils::StringTokenizer,tokenizeString$separator");
	try {
		_error.addVariable("line", e1.getParameter("line"));
	} catch (Throwable _t) {
		_error.addVariable("line", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("saveBorrows") && e2.entityName.equals("saveString") && linkProperty.entityName.equals("saveBorrowsFileHandler") && paramName.equals("filename")) {
try {
	return "BorrowsData.dat";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/saveBorrows$eventChildLink,Forward,saveBorrowsFileHandler,Persistence::FileHandler,saveString$filename");
	try {
		_error.addVariable("members", e1.getParameter("members"));
	} catch (Throwable _t) {
		_error.addVariable("members", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}
if (e1.entityName.equals("saveBorrows") && e2.entityName.equals("saveString") && linkProperty.entityName.equals("saveBorrowsFileHandler") && paramName.equals("content")) {
try {
	return ((java.lang.String)((lu.uni.democles.runtime.OCLSequence)((lu.uni.democles.runtime.OCLSequence)e1.getParameter("members")).collect(new lu.uni.democles.runtime.Function() {
	public Object _iteration(Object _value) {
final generated.Library.Member v_m = ((generated.Library.Member)_value);
return _asObject(((lu.uni.democles.runtime.OCLBag)((lu.uni.democles.runtime.OCLSet)((lu.uni.democles.runtime.Property)v_m.getEntity("borrows")).evalInContainer()).collect(new lu.uni.democles.runtime.Function() {
	public Object _iteration(Object _value) {
final generated.Library.Copy v_c = ((generated.Library.Copy)_value);
return _asObject(((((java.lang.String)((lu.uni.democles.runtime.Property)v_m.getEntity("libraryNo")).evalInContainer().getValues().iterator().next()) + ";") + ((java.lang.String)((lu.uni.democles.runtime.Property)v_c.getEntity("copyId")).evalInContainer().getValues().iterator().next())));
	}
})));
	}
})).iterate(new lu.uni.democles.runtime.Function() {
	public Object _iterate(Object _value, Object _acc) {
final java.lang.String v_result = ((java.lang.String)_acc);
final java.lang.String v_line = ((java.lang.String)_value);
return _asObject(((v_result + v_line) + "\n"));
	}
}, ""));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/saveBorrows$eventChildLink,Forward,saveBorrowsFileHandler,Persistence::FileHandler,saveString$content");
	try {
		_error.addVariable("members", e1.getParameter("members"));
	} catch (Throwable _t) {
		_error.addVariable("members", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("memberLineRead") && e2.entityName.equals("tokenizeString") && linkProperty.entityName.equals("memberStringTokenizer") && paramName.equals("string")) {
try {
	return ((java.lang.String)e1.getParameter("line"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/memberLineRead$eventChildLink,Forward,memberStringTokenizer,StringUtils::StringTokenizer,tokenizeString$string");
	try {
		_error.addVariable("line", e1.getParameter("line"));
	} catch (Throwable _t) {
		_error.addVariable("line", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}
if (e1.entityName.equals("memberLineRead") && e2.entityName.equals("tokenizeString") && linkProperty.entityName.equals("memberStringTokenizer") && paramName.equals("separator")) {
try {
	return ";";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/memberLineRead$eventChildLink,Forward,memberStringTokenizer,StringUtils::StringTokenizer,tokenizeString$separator");
	try {
		_error.addVariable("line", e1.getParameter("line"));
	} catch (Throwable _t) {
		_error.addVariable("line", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("loadToCollect") && e2.entityName.equals("openFile") && linkProperty.entityName.equals("toCollectFileHandler") && paramName.equals("filename")) {
try {
	return "ToCollectData.dat";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/loadToCollect$eventChildLink,Forward,toCollectFileHandler,Persistence::FileHandler,openFile$filename");
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("borrowsLineTokenized") && e2.entityName.equals("setBorrows") && linkProperty.entityName.equals("members") && paramName.equals("borrows")) {
try {
	return (((lu.uni.democles.runtime.OCLSet)((lu.uni.democles.runtime.Property)this.getEntity("borrows")).evalInContainer()).including((((generated.Library.Copy)generated.LibraryPersistence.LibraryFiles.this.evalQueryWithParameters("findCopy", new Object[] { (((java.lang.String)((lu.uni.democles.runtime.OCLSequence)e1.getParameter("tokens")).at((int)2))) })))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/borrowsLineTokenized$eventChildLink,Forward,members,Library::Member,setBorrows$borrows");
	try {
		_error.addVariable("tokens", e1.getParameter("tokens"));
	} catch (Throwable _t) {
		_error.addVariable("tokens", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("loadAuthors") && e2.entityName.equals("openFile") && linkProperty.entityName.equals("authorFileHandler") && paramName.equals("filename")) {
try {
	return "AuthorData.dat";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/loadAuthors$eventChildLink,Forward,authorFileHandler,Persistence::FileHandler,openFile$filename");
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("loadCopies") && e2.entityName.equals("openFile") && linkProperty.entityName.equals("copyFileHandler") && paramName.equals("filename")) {
try {
	return "CopyData.dat";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/loadCopies$eventChildLink,Forward,copyFileHandler,Persistence::FileHandler,openFile$filename");
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("saveToCollect") && e2.entityName.equals("saveString") && linkProperty.entityName.equals("saveToCollectFileHandler") && paramName.equals("filename")) {
try {
	return "ToCollectData.dat";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/saveToCollect$eventChildLink,Forward,saveToCollectFileHandler,Persistence::FileHandler,saveString$filename");
	try {
		_error.addVariable("members", e1.getParameter("members"));
	} catch (Throwable _t) {
		_error.addVariable("members", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}
if (e1.entityName.equals("saveToCollect") && e2.entityName.equals("saveString") && linkProperty.entityName.equals("saveToCollectFileHandler") && paramName.equals("content")) {
try {
	return ((java.lang.String)((lu.uni.democles.runtime.OCLSequence)((lu.uni.democles.runtime.OCLSequence)e1.getParameter("members")).collect(new lu.uni.democles.runtime.Function() {
	public Object _iteration(Object _value) {
final generated.Library.Member v_m = ((generated.Library.Member)_value);
return _asObject(((lu.uni.democles.runtime.OCLBag)((lu.uni.democles.runtime.OCLSet)((lu.uni.democles.runtime.Property)v_m.getEntity("toCollect")).evalInContainer()).collect(new lu.uni.democles.runtime.Function() {
	public Object _iteration(Object _value) {
final generated.Library.Copy v_c = ((generated.Library.Copy)_value);
return _asObject(((((java.lang.String)((lu.uni.democles.runtime.Property)v_m.getEntity("libraryNo")).evalInContainer().getValues().iterator().next()) + ";") + ((java.lang.String)((lu.uni.democles.runtime.Property)v_c.getEntity("copyId")).evalInContainer().getValues().iterator().next())));
	}
})));
	}
})).iterate(new lu.uni.democles.runtime.Function() {
	public Object _iterate(Object _value, Object _acc) {
final java.lang.String v_result = ((java.lang.String)_acc);
final java.lang.String v_line = ((java.lang.String)_value);
return _asObject(((v_result + v_line) + "\n"));
	}
}, ""));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/saveToCollect$eventChildLink,Forward,saveToCollectFileHandler,Persistence::FileHandler,saveString$content");
	try {
		_error.addVariable("members", e1.getParameter("members"));
	} catch (Throwable _t) {
		_error.addVariable("members", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("updateBookCopies") && e2.entityName.equals("setCopies") && linkProperty.entityName.equals("books") && paramName.equals("copies")) {
try {
	return ((lu.uni.democles.runtime.OCLSet)e1.getAttachedProperty("LibraryFiles_copies")).select(new lu.uni.democles.runtime.Function() {
	public Object _iteration(Object _value) {
final generated.Library.Copy v_temp1 = ((generated.Library.Copy)_value);
return _asObject((lu.uni.democles.runtime.Function._equals(((generated.Library.Book)((lu.uni.democles.runtime.Property)v_temp1.getEntity("book")).evalInContainer().getValues().iterator().next()), this)));
	}
});

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/updateBookCopies$eventChildLink,Forward,books,Library::Book,setCopies$copies");
	try {
		_error.addVariable("copies", e1.getAttachedProperty("LibraryFiles_copies"));
	} catch (Throwable _t) {
		_error.addVariable("copies", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("books", e1.getAttachedProperty("LibraryFiles_books"));
	} catch (Throwable _t) {
		_error.addVariable("books", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("borrowsLineRead") && e2.entityName.equals("tokenizeString") && linkProperty.entityName.equals("borrowsStringTokenizer") && paramName.equals("string")) {
try {
	return ((java.lang.String)e1.getParameter("line"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/borrowsLineRead$eventChildLink,Forward,borrowsStringTokenizer,StringUtils::StringTokenizer,tokenizeString$string");
	try {
		_error.addVariable("line", e1.getParameter("line"));
	} catch (Throwable _t) {
		_error.addVariable("line", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}
if (e1.entityName.equals("borrowsLineRead") && e2.entityName.equals("tokenizeString") && linkProperty.entityName.equals("borrowsStringTokenizer") && paramName.equals("separator")) {
try {
	return ";";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/borrowsLineRead$eventChildLink,Forward,borrowsStringTokenizer,StringUtils::StringTokenizer,tokenizeString$separator");
	try {
		_error.addVariable("line", e1.getParameter("line"));
	} catch (Throwable _t) {
		_error.addVariable("line", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("toCollectFileClosed") && e2.entityName.equals("libraryLoaded") && linkProperty == null && paramName.equals("library")) {
try {
	return (generated.Library.Library.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "catalogue", ((lu.uni.democles.runtime.OCLSet)e1.getAttachedProperty("LibraryFiles_books")), "members", ((lu.uni.democles.runtime.OCLSet)e1.getAttachedProperty("LibraryFiles_members")) }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/toCollectFileClosed$eventChildLink,Local,libraryLoaded$library");
	try {
		_error.addVariable("books", e1.getAttachedProperty("LibraryFiles_books"));
	} catch (Throwable _t) {
		_error.addVariable("books", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("members", e1.getAttachedProperty("LibraryFiles_members"));
	} catch (Throwable _t) {
		_error.addVariable("members", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("loadBorrows") && e2.entityName.equals("openFile") && linkProperty.entityName.equals("borrowsFileHandler") && paramName.equals("filename")) {
try {
	return "BorrowsData.dat";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/loadBorrows$eventChildLink,Forward,borrowsFileHandler,Persistence::FileHandler,openFile$filename");
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("loadMembers") && e2.entityName.equals("openFile") && linkProperty.entityName.equals("memberFileHandler") && paramName.equals("filename")) {
try {
	return "MemberData.dat";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|LibraryPersistence::LibraryFiles/Event/loadMembers$eventChildLink,Forward,memberFileHandler,Persistence::FileHandler,openFile$filename");
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		return null;

	}
	protected boolean guard_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse) {
		
		if (_event.entityName.equals("memberLineTokenized") && _parent.entityName.equals("stringTokenized") && _linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && _linkProperty.entityName.equals("memberStringTokenizer") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/memberLineTokenized$eventParentLink,Forward,memberStringTokenizer,StringUtils::StringTokenizer,stringTokenized");
	try {
		_error.addVariable("tokens", _parent.getParameter("tokens"));
	} catch (Throwable _t) {
		_error.addVariable("tokens", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("authorsFileClosed") && _parent.entityName.equals("fileClosed") && _linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && _linkProperty.entityName.equals("authorFileHandler") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/authorsFileClosed$eventParentLink,Forward,authorFileHandler,Persistence::FileHandler,fileClosed");
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("bookLineTokenized") && _parent.entityName.equals("stringTokenized") && _linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && _linkProperty.entityName.equals("bookStringTokenizer") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/bookLineTokenized$eventParentLink,Forward,bookStringTokenizer,StringUtils::StringTokenizer,stringTokenized");
	try {
		_error.addVariable("tokens", _parent.getParameter("tokens"));
	} catch (Throwable _t) {
		_error.addVariable("tokens", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("toCollectLineTokenized") && _parent.entityName.equals("stringTokenized") && _linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && _linkProperty.entityName.equals("toCollectStringTokenizer") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/toCollectLineTokenized$eventParentLink,Forward,toCollectStringTokenizer,StringUtils::StringTokenizer,stringTokenized");
	try {
		_error.addVariable("tokens", _parent.getParameter("tokens"));
	} catch (Throwable _t) {
		_error.addVariable("tokens", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("toCollectLineRead") && _parent.entityName.equals("lineread") && _linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && _linkProperty.entityName.equals("toCollectFileHandler") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/toCollectLineRead$eventParentLink,Forward,toCollectFileHandler,Persistence::FileHandler,lineread");
	try {
		_error.addVariable("line", _parent.getParameter("line"));
	} catch (Throwable _t) {
		_error.addVariable("line", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("bookLineRead") && _parent.entityName.equals("lineread") && _linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && _linkProperty.entityName.equals("bookFileHandler") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/bookLineRead$eventParentLink,Forward,bookFileHandler,Persistence::FileHandler,lineread");
	try {
		_error.addVariable("line", _parent.getParameter("line"));
	} catch (Throwable _t) {
		_error.addVariable("line", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("authorsLineRead") && _parent.entityName.equals("lineread") && _linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && _linkProperty.entityName.equals("authorFileHandler") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/authorsLineRead$eventParentLink,Forward,authorFileHandler,Persistence::FileHandler,lineread");
	try {
		_error.addVariable("line", _parent.getParameter("line"));
	} catch (Throwable _t) {
		_error.addVariable("line", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("copyLineRead") && _parent.entityName.equals("lineread") && _linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && _linkProperty.entityName.equals("copyFileHandler") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/copyLineRead$eventParentLink,Forward,copyFileHandler,Persistence::FileHandler,lineread");
	try {
		_error.addVariable("line", _parent.getParameter("line"));
	} catch (Throwable _t) {
		_error.addVariable("line", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("bookFileClosed") && _parent.entityName.equals("fileClosed") && _linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && _linkProperty.entityName.equals("bookFileHandler") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/bookFileClosed$eventParentLink,Forward,bookFileHandler,Persistence::FileHandler,fileClosed");
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("memberFileClosed") && _parent.entityName.equals("fileClosed") && _linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && _linkProperty.entityName.equals("memberFileHandler") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/memberFileClosed$eventParentLink,Forward,memberFileHandler,Persistence::FileHandler,fileClosed");
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("authorsLineTokenized") && _parent.entityName.equals("stringTokenized") && _linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && _linkProperty.entityName.equals("authorStringTokenizer") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/authorsLineTokenized$eventParentLink,Forward,authorStringTokenizer,StringUtils::StringTokenizer,stringTokenized");
	try {
		_error.addVariable("tokens", _parent.getParameter("tokens"));
	} catch (Throwable _t) {
		_error.addVariable("tokens", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("memberLineRead") && _parent.entityName.equals("lineread") && _linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && _linkProperty.entityName.equals("memberFileHandler") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/memberLineRead$eventParentLink,Forward,memberFileHandler,Persistence::FileHandler,lineread");
	try {
		_error.addVariable("line", _parent.getParameter("line"));
	} catch (Throwable _t) {
		_error.addVariable("line", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("borrowsLineTokenized") && _parent.entityName.equals("stringTokenized") && _linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && _linkProperty.entityName.equals("borrowsStringTokenizer") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/borrowsLineTokenized$eventParentLink,Forward,borrowsStringTokenizer,StringUtils::StringTokenizer,stringTokenized");
	try {
		_error.addVariable("tokens", _parent.getParameter("tokens"));
	} catch (Throwable _t) {
		_error.addVariable("tokens", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("copyLineTokenized") && _parent.entityName.equals("stringTokenized") && _linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && _linkProperty.entityName.equals("copyStringTokenizer") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/copyLineTokenized$eventParentLink,Forward,copyStringTokenizer,StringUtils::StringTokenizer,stringTokenized");
	try {
		_error.addVariable("tokens", _parent.getParameter("tokens"));
	} catch (Throwable _t) {
		_error.addVariable("tokens", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("borrowsFileClosed") && _parent.entityName.equals("fileClosed") && _linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && _linkProperty.entityName.equals("borrowsFileHandler") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/borrowsFileClosed$eventParentLink,Forward,borrowsFileHandler,Persistence::FileHandler,fileClosed");
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("borrowsLineRead") && _parent.entityName.equals("lineread") && _linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && _linkProperty.entityName.equals("borrowsFileHandler") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/borrowsLineRead$eventParentLink,Forward,borrowsFileHandler,Persistence::FileHandler,lineread");
	try {
		_error.addVariable("line", _parent.getParameter("line"));
	} catch (Throwable _t) {
		_error.addVariable("line", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("toCollectFileClosed") && _parent.entityName.equals("fileClosed") && _linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && _linkProperty.entityName.equals("toCollectFileHandler") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/toCollectFileClosed$eventParentLink,Forward,toCollectFileHandler,Persistence::FileHandler,fileClosed");
	try {
		_error.addVariable("books", _parent.getAttachedProperty("LibraryFiles_books"));
	} catch (Throwable _t) {
		_error.addVariable("books", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("members", _parent.getAttachedProperty("LibraryFiles_members"));
	} catch (Throwable _t) {
		_error.addVariable("members", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("copyFileClosed") && _parent.entityName.equals("fileClosed") && _linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && _linkProperty.entityName.equals("copyFileHandler") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/copyFileClosed$eventParentLink,Forward,copyFileHandler,Persistence::FileHandler,fileClosed");
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		return true;

	}
	protected void resetNewVal() {
		this._p_saveBorrowsFileHandler.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_findCopy.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_borrowsFileHandler.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_saveToCollectFileHandler.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_findBook.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_books.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_copyStringTokenizer.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_bookFileHandler.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_intToString.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_findCopies.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_findAuthors.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_members.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_borrowsStringTokenizer.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_toCollectStringTokenizer.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_authorStringTokenizer.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_bookStringTokenizer.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_copies.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_memberStringTokenizer.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_copyFileHandler.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_toCollectFileHandler.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_saveCopiesFileHandler.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_authorFileHandler.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_authors.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_memberFileHandler.newVal = lu.uni.democles.runtime.Entity.nullObject;
	}
	private java.lang.Object __copyStringTokenizer_eval() {
		try {
	return (new generated.StringUtils.StringTokenizer());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|LibraryPersistence::LibraryFiles/Property/copyStringTokenizer");
	throw _error;
}

	}
	private java.lang.Object __bookStringTokenizer_eval() {
		try {
	return (new generated.StringUtils.StringTokenizer());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|LibraryPersistence::LibraryFiles/Property/bookStringTokenizer");
	throw _error;
}

	}
	public generated.Library.Book __pq_findBook(final java.lang.String v_bookId) {
		try {
	return ((generated.Library.Book)((lu.uni.democles.runtime.OCLSet)((lu.uni.democles.runtime.Property)generated.LibraryPersistence.LibraryFiles.this.getEntity("books")).evalInContainer()).any(new lu.uni.democles.runtime.Function() {
	public Object _iteration(Object _value) {
final generated.Library.Book v_b = ((generated.Library.Book)_value);
return _asObject((lu.uni.democles.runtime.Function._equals(((java.lang.String)((lu.uni.democles.runtime.Property)v_b.getEntity("bookId")).evalInContainer().getValues().iterator().next()), v_bookId)));
	}
}));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|LibraryPersistence::LibraryFiles/Property/findBook");
	_error.addVariable("bookId", v_bookId);
	throw _error;
}



	}
	public lu.uni.democles.runtime.OCLSet __pq_findCopies(final lu.uni.democles.runtime.OCLSet v_copyIds) {
		try {
	return ((lu.uni.democles.runtime.OCLSet)((lu.uni.democles.runtime.Property)generated.LibraryPersistence.LibraryFiles.this.getEntity("copies")).evalInContainer()).select(new lu.uni.democles.runtime.Function() {
	public Object _iteration(Object _value) {
final generated.Library.Copy v_c = ((generated.Library.Copy)_value);
return _asObject((v_copyIds.includes(((java.lang.String)((lu.uni.democles.runtime.Property)v_c.getEntity("copyId")).evalInContainer().getValues().iterator().next()))));
	}
});

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|LibraryPersistence::LibraryFiles/Property/findCopies");
	_error.addVariable("copyIds", v_copyIds);
	throw _error;
}



	}
	protected boolean guard_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final lu.uni.democles.runtime.Instance linkedInstance, final int _link) {
		if (e1.entityName.equals("saveLibrary") && e2.entityName.equals("saveCopies") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/saveLibrary$eventChildLink,Local,saveCopies");
	try {
		_error.addVariable("library", e1.getParameter("library"));
	} catch (Throwable _t) {
		_error.addVariable("library", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}
if (e1.entityName.equals("saveLibrary") && e2.entityName.equals("saveBorrows") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/saveLibrary$eventChildLink,Local,saveBorrows");
	try {
		_error.addVariable("library", e1.getParameter("library"));
	} catch (Throwable _t) {
		_error.addVariable("library", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}
if (e1.entityName.equals("saveLibrary") && e2.entityName.equals("saveToCollect") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/saveLibrary$eventChildLink,Local,saveToCollect");
	try {
		_error.addVariable("library", e1.getParameter("library"));
	} catch (Throwable _t) {
		_error.addVariable("library", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		
		if (e1.entityName.equals("authorsFileClosed") && e2.entityName.equals("loadBooks") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/authorsFileClosed$eventChildLink,Local,loadBooks");
	throw _error;
}
	}

		if (e1.entityName.equals("toCollectLineTokenized") && e2.entityName.equals("setToCollect") && linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && linkProperty.entityName.equals("members")) {
try {
	return (lu.uni.democles.runtime.Function._equals(((java.lang.String)((lu.uni.democles.runtime.Property)linkedInstance.getEntity("libraryNo")).evalInContainer().getValues().iterator().next()), (((java.lang.String)((lu.uni.democles.runtime.OCLSequence)e1.getParameter("tokens")).at((int)1)))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/toCollectLineTokenized$eventChildLink,Forward,members,Library::Member,setToCollect");
	try {
		_error.addVariable("tokens", e1.getParameter("tokens"));
	} catch (Throwable _t) {
		_error.addVariable("tokens", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("load") && e2.entityName.equals("loadAuthors") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/load$eventChildLink,Local,loadAuthors");
	throw _error;
}
	}

		if (e1.entityName.equals("toCollectLineRead") && e2.entityName.equals("tokenizeString") && linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && linkProperty.entityName.equals("toCollectStringTokenizer")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/toCollectLineRead$eventChildLink,Forward,toCollectStringTokenizer,StringUtils::StringTokenizer,tokenizeString");
	try {
		_error.addVariable("line", e1.getParameter("line"));
	} catch (Throwable _t) {
		_error.addVariable("line", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("bookLineRead") && e2.entityName.equals("tokenizeString") && linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && linkProperty.entityName.equals("bookStringTokenizer")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/bookLineRead$eventChildLink,Forward,bookStringTokenizer,StringUtils::StringTokenizer,tokenizeString");
	try {
		_error.addVariable("line", e1.getParameter("line"));
	} catch (Throwable _t) {
		_error.addVariable("line", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("loadBooks") && e2.entityName.equals("openFile") && linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && linkProperty.entityName.equals("bookFileHandler")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/loadBooks$eventChildLink,Forward,bookFileHandler,Persistence::FileHandler,openFile");
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("authorsLineRead") && e2.entityName.equals("tokenizeString") && linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && linkProperty.entityName.equals("authorStringTokenizer")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/authorsLineRead$eventChildLink,Forward,authorStringTokenizer,StringUtils::StringTokenizer,tokenizeString");
	try {
		_error.addVariable("line", e1.getParameter("line"));
	} catch (Throwable _t) {
		_error.addVariable("line", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("saveCopies") && e2.entityName.equals("saveString") && linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && linkProperty.entityName.equals("saveCopiesFileHandler")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/saveCopies$eventChildLink,Forward,saveCopiesFileHandler,Persistence::FileHandler,saveString");
	try {
		_error.addVariable("copies", e1.getParameter("copies"));
	} catch (Throwable _t) {
		_error.addVariable("copies", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("copyLineRead") && e2.entityName.equals("tokenizeString") && linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && linkProperty.entityName.equals("copyStringTokenizer")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/copyLineRead$eventChildLink,Forward,copyStringTokenizer,StringUtils::StringTokenizer,tokenizeString");
	try {
		_error.addVariable("line", e1.getParameter("line"));
	} catch (Throwable _t) {
		_error.addVariable("line", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("bookFileClosed") && e2.entityName.equals("loadCopies") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/bookFileClosed$eventChildLink,Local,loadCopies");
	throw _error;
}
	}

		if (e1.entityName.equals("saveBorrows") && e2.entityName.equals("saveString") && linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && linkProperty.entityName.equals("saveBorrowsFileHandler")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/saveBorrows$eventChildLink,Forward,saveBorrowsFileHandler,Persistence::FileHandler,saveString");
	try {
		_error.addVariable("members", e1.getParameter("members"));
	} catch (Throwable _t) {
		_error.addVariable("members", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("memberFileClosed") && e2.entityName.equals("loadBorrows") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/memberFileClosed$eventChildLink,Local,loadBorrows");
	throw _error;
}
	}

		if (e1.entityName.equals("memberLineRead") && e2.entityName.equals("tokenizeString") && linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && linkProperty.entityName.equals("memberStringTokenizer")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/memberLineRead$eventChildLink,Forward,memberStringTokenizer,StringUtils::StringTokenizer,tokenizeString");
	try {
		_error.addVariable("line", e1.getParameter("line"));
	} catch (Throwable _t) {
		_error.addVariable("line", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("loadToCollect") && e2.entityName.equals("openFile") && linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && linkProperty.entityName.equals("toCollectFileHandler")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/loadToCollect$eventChildLink,Forward,toCollectFileHandler,Persistence::FileHandler,openFile");
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("borrowsLineTokenized") && e2.entityName.equals("setBorrows") && linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && linkProperty.entityName.equals("members")) {
try {
	return (lu.uni.democles.runtime.Function._equals(((java.lang.String)((lu.uni.democles.runtime.Property)linkedInstance.getEntity("libraryNo")).evalInContainer().getValues().iterator().next()), (((java.lang.String)((lu.uni.democles.runtime.OCLSequence)e1.getParameter("tokens")).at((int)1)))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/borrowsLineTokenized$eventChildLink,Forward,members,Library::Member,setBorrows");
	try {
		_error.addVariable("tokens", e1.getParameter("tokens"));
	} catch (Throwable _t) {
		_error.addVariable("tokens", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("loadAuthors") && e2.entityName.equals("openFile") && linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && linkProperty.entityName.equals("authorFileHandler")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/loadAuthors$eventChildLink,Forward,authorFileHandler,Persistence::FileHandler,openFile");
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("borrowsFileClosed") && e2.entityName.equals("loadToCollect") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/borrowsFileClosed$eventChildLink,Local,loadToCollect");
	throw _error;
}
	}

		if (e1.entityName.equals("loadCopies") && e2.entityName.equals("openFile") && linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && linkProperty.entityName.equals("copyFileHandler")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/loadCopies$eventChildLink,Forward,copyFileHandler,Persistence::FileHandler,openFile");
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("saveToCollect") && e2.entityName.equals("saveString") && linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && linkProperty.entityName.equals("saveToCollectFileHandler")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/saveToCollect$eventChildLink,Forward,saveToCollectFileHandler,Persistence::FileHandler,saveString");
	try {
		_error.addVariable("members", e1.getParameter("members"));
	} catch (Throwable _t) {
		_error.addVariable("members", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("updateBookCopies") && e2.entityName.equals("setCopies") && linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && linkProperty.entityName.equals("books")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/updateBookCopies$eventChildLink,Forward,books,Library::Book,setCopies");
	try {
		_error.addVariable("copies", e1.getAttachedProperty("LibraryFiles_copies"));
	} catch (Throwable _t) {
		_error.addVariable("copies", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("books", e1.getAttachedProperty("LibraryFiles_books"));
	} catch (Throwable _t) {
		_error.addVariable("books", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}
if (e1.entityName.equals("updateBookCopies") && e2.entityName.equals("loadMembers") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/updateBookCopies$eventChildLink,Local,loadMembers");
	try {
		_error.addVariable("copies", e1.getAttachedProperty("LibraryFiles_copies"));
	} catch (Throwable _t) {
		_error.addVariable("copies", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("books", e1.getAttachedProperty("LibraryFiles_books"));
	} catch (Throwable _t) {
		_error.addVariable("books", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("borrowsLineRead") && e2.entityName.equals("tokenizeString") && linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && linkProperty.entityName.equals("borrowsStringTokenizer")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/borrowsLineRead$eventChildLink,Forward,borrowsStringTokenizer,StringUtils::StringTokenizer,tokenizeString");
	try {
		_error.addVariable("line", e1.getParameter("line"));
	} catch (Throwable _t) {
		_error.addVariable("line", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("toCollectFileClosed") && e2.entityName.equals("libraryLoaded") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/toCollectFileClosed$eventChildLink,Local,libraryLoaded");
	try {
		_error.addVariable("books", e1.getAttachedProperty("LibraryFiles_books"));
	} catch (Throwable _t) {
		_error.addVariable("books", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("members", e1.getAttachedProperty("LibraryFiles_members"));
	} catch (Throwable _t) {
		_error.addVariable("members", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("loadBorrows") && e2.entityName.equals("openFile") && linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && linkProperty.entityName.equals("borrowsFileHandler")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/loadBorrows$eventChildLink,Forward,borrowsFileHandler,Persistence::FileHandler,openFile");
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("loadMembers") && e2.entityName.equals("openFile") && linkProperty.container.modelName.equals("generated.LibraryPersistence.LibraryFiles") && linkProperty.entityName.equals("memberFileHandler")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/loadMembers$eventChildLink,Forward,memberFileHandler,Persistence::FileHandler,openFile");
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("copyFileClosed") && e2.entityName.equals("updateBookCopies") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|LibraryPersistence::LibraryFiles/Event/copyFileClosed$eventChildLink,Local,updateBookCopies");
	throw _error;
}
	}

		return true;

	}
	private java.lang.Object __toCollectFileHandler_eval() {
		try {
	return (new generated.Persistence.FileHandler());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|LibraryPersistence::LibraryFiles/Property/toCollectFileHandler");
	throw _error;
}

	}
	protected void attachProperties(lu.uni.democles.runtime.Event e) {
		// Set Attached Properties:


		// Set Attached Properties:
if ("updateBookCopies".equals(e.entityName)) {
	e.attachProperty("LibraryFiles_copies", this._p_copies.evalInContainer());
	e.attachProperty("LibraryFiles_books", this._p_books.evalInContainer());
}


		// Set Attached Properties:
if ("toCollectFileClosed".equals(e.entityName)) {
	e.attachProperty("LibraryFiles_books", this._p_books.evalInContainer());
	e.attachProperty("LibraryFiles_members", this._p_members.evalInContainer());
}


	}
	private java.lang.Object __copyFileHandler_eval() {
		try {
	return (new generated.Persistence.FileHandler());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|LibraryPersistence::LibraryFiles/Property/copyFileHandler");
	throw _error;
}

	}
	public void initProps() {
		if (this.isInitialized()) return;

		this._p_saveBorrowsFileHandler.oldVal = this.initialValues.containsKey("saveBorrowsFileHandler") ? this.initialValues.get("saveBorrowsFileHandler") : eval_p(this._p_saveBorrowsFileHandler).getValues().iterator().next();
this._p_saveBorrowsFileHandler.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_saveBorrowsFileHandler, this._p_saveBorrowsFileHandler.oldVal);

		this._p_borrowsFileHandler.oldVal = this.initialValues.containsKey("borrowsFileHandler") ? this.initialValues.get("borrowsFileHandler") : eval_p(this._p_borrowsFileHandler).getValues().iterator().next();
this._p_borrowsFileHandler.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_borrowsFileHandler, this._p_borrowsFileHandler.oldVal);

		this._p_saveToCollectFileHandler.oldVal = this.initialValues.containsKey("saveToCollectFileHandler") ? this.initialValues.get("saveToCollectFileHandler") : eval_p(this._p_saveToCollectFileHandler).getValues().iterator().next();
this._p_saveToCollectFileHandler.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_saveToCollectFileHandler, this._p_saveToCollectFileHandler.oldVal);

		this._p_books.oldVal = this.initialValues.containsKey("books") ? this.initialValues.get("books") : eval_p(this._p_books);
this._p_books.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_books, this._p_books.oldVal);

		this._p_copyStringTokenizer.oldVal = this.initialValues.containsKey("copyStringTokenizer") ? this.initialValues.get("copyStringTokenizer") : eval_p(this._p_copyStringTokenizer).getValues().iterator().next();
this._p_copyStringTokenizer.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_copyStringTokenizer, this._p_copyStringTokenizer.oldVal);

		this._p_bookFileHandler.oldVal = this.initialValues.containsKey("bookFileHandler") ? this.initialValues.get("bookFileHandler") : eval_p(this._p_bookFileHandler).getValues().iterator().next();
this._p_bookFileHandler.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_bookFileHandler, this._p_bookFileHandler.oldVal);

		this._p_members.oldVal = this.initialValues.containsKey("members") ? this.initialValues.get("members") : eval_p(this._p_members);
this._p_members.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_members, this._p_members.oldVal);

		this._p_borrowsStringTokenizer.oldVal = this.initialValues.containsKey("borrowsStringTokenizer") ? this.initialValues.get("borrowsStringTokenizer") : eval_p(this._p_borrowsStringTokenizer).getValues().iterator().next();
this._p_borrowsStringTokenizer.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_borrowsStringTokenizer, this._p_borrowsStringTokenizer.oldVal);

		this._p_toCollectStringTokenizer.oldVal = this.initialValues.containsKey("toCollectStringTokenizer") ? this.initialValues.get("toCollectStringTokenizer") : eval_p(this._p_toCollectStringTokenizer).getValues().iterator().next();
this._p_toCollectStringTokenizer.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_toCollectStringTokenizer, this._p_toCollectStringTokenizer.oldVal);

		this._p_authorStringTokenizer.oldVal = this.initialValues.containsKey("authorStringTokenizer") ? this.initialValues.get("authorStringTokenizer") : eval_p(this._p_authorStringTokenizer).getValues().iterator().next();
this._p_authorStringTokenizer.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_authorStringTokenizer, this._p_authorStringTokenizer.oldVal);

		this._p_bookStringTokenizer.oldVal = this.initialValues.containsKey("bookStringTokenizer") ? this.initialValues.get("bookStringTokenizer") : eval_p(this._p_bookStringTokenizer).getValues().iterator().next();
this._p_bookStringTokenizer.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_bookStringTokenizer, this._p_bookStringTokenizer.oldVal);

		this._p_copies.oldVal = this.initialValues.containsKey("copies") ? this.initialValues.get("copies") : eval_p(this._p_copies);
this._p_copies.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_copies, this._p_copies.oldVal);

		this._p_memberStringTokenizer.oldVal = this.initialValues.containsKey("memberStringTokenizer") ? this.initialValues.get("memberStringTokenizer") : eval_p(this._p_memberStringTokenizer).getValues().iterator().next();
this._p_memberStringTokenizer.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_memberStringTokenizer, this._p_memberStringTokenizer.oldVal);

		this._p_copyFileHandler.oldVal = this.initialValues.containsKey("copyFileHandler") ? this.initialValues.get("copyFileHandler") : eval_p(this._p_copyFileHandler).getValues().iterator().next();
this._p_copyFileHandler.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_copyFileHandler, this._p_copyFileHandler.oldVal);

		this._p_toCollectFileHandler.oldVal = this.initialValues.containsKey("toCollectFileHandler") ? this.initialValues.get("toCollectFileHandler") : eval_p(this._p_toCollectFileHandler).getValues().iterator().next();
this._p_toCollectFileHandler.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_toCollectFileHandler, this._p_toCollectFileHandler.oldVal);

		this._p_saveCopiesFileHandler.oldVal = this.initialValues.containsKey("saveCopiesFileHandler") ? this.initialValues.get("saveCopiesFileHandler") : eval_p(this._p_saveCopiesFileHandler).getValues().iterator().next();
this._p_saveCopiesFileHandler.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_saveCopiesFileHandler, this._p_saveCopiesFileHandler.oldVal);

		this._p_authorFileHandler.oldVal = this.initialValues.containsKey("authorFileHandler") ? this.initialValues.get("authorFileHandler") : eval_p(this._p_authorFileHandler).getValues().iterator().next();
this._p_authorFileHandler.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_authorFileHandler, this._p_authorFileHandler.oldVal);

		this._p_authors.oldVal = this.initialValues.containsKey("authors") ? this.initialValues.get("authors") : eval_p(this._p_authors);
this._p_authors.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_authors, this._p_authors.oldVal);

		this._p_memberFileHandler.oldVal = this.initialValues.containsKey("memberFileHandler") ? this.initialValues.get("memberFileHandler") : eval_p(this._p_memberFileHandler).getValues().iterator().next();
this._p_memberFileHandler.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_memberFileHandler, this._p_memberFileHandler.oldVal);

		this.setInitialized();
this.initialValues = new java.util.HashMap();


	}
	private java.lang.Object __authorStringTokenizer_eval() {
		try {
	return (new generated.StringUtils.StringTokenizer());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|LibraryPersistence::LibraryFiles/Property/authorStringTokenizer");
	throw _error;
}

	}
	private java.lang.Object _bookLineTokenized_books_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return (((lu.uni.democles.runtime.OCLSet)((lu.uni.democles.runtime.Property)generated.LibraryPersistence.LibraryFiles.this.getEntity("books")).evalInContainer()).including((generated.Library.Book.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "bookId", (((java.lang.String)((lu.uni.democles.runtime.OCLSequence)_event.getParameter("tokens")).at((int)1))), "title", (((java.lang.String)((lu.uni.democles.runtime.OCLSequence)_event.getParameter("tokens")).at((int)2))), "isbn", (((java.lang.String)((lu.uni.democles.runtime.OCLSequence)_event.getParameter("tokens")).at((int)3))), "authors", (((lu.uni.democles.runtime.OCLSet)generated.LibraryPersistence.LibraryFiles.this.evalQueryWithParameters("findAuthors", new Object[] { ((((lu.uni.democles.runtime.OCLSequence)_event.getParameter("tokens")).subSequence(4, (((lu.uni.democles.runtime.OCLSequence)_event.getParameter("tokens")).size()))).asSet()) }))), "copies", new lu.uni.democles.runtime.OCLSet(new Object[] {}) }))))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|LibraryPersistence::LibraryFiles/Event/bookLineTokenized-impacts-LibraryPersistence::LibraryFiles/Property/books");
	try {
		_error.addVariable("tokens", _event.getParameter("tokens"));
	} catch (Throwable _t) {
		_error.addVariable("tokens", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	public static LibraryFiles newWithValues(java.util.HashMap values) {
		LibraryFiles res = new LibraryFiles();
res.initialValues = new java.util.HashMap(values);
res.initProps();
return res;
	}
	protected void set(lu.uni.democles.runtime.Property p, java.lang.Object v) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) {
	throw new lu.uni.democles.runtime.MultipleModificationException(p.toString());
}
p.newVal = v;
		super.set(p, v);
	}
	private java.lang.Object __books_eval() {
		try {
	return new lu.uni.democles.runtime.OCLSet(new Object[] {});

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|LibraryPersistence::LibraryFiles/Property/books");
	throw _error;
}

	}
	protected java.lang.Object evalQuery(lu.uni.democles.runtime.Property p) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) return p.newVal;

if (p.isEvaluating()) throw new lu.uni.democles.runtime.ModificationCycleException();

p.setEvaluating(true);
java.lang.Object o = null;


		if ("saveBorrowsFileHandler".equals(p.entityName)) {
	o = __saveBorrowsFileHandler_eval();
	set(p, o);
}

		if ("borrowsFileHandler".equals(p.entityName)) {
	o = __borrowsFileHandler_eval();
	set(p, o);
}

		if ("saveToCollectFileHandler".equals(p.entityName)) {
	o = __saveToCollectFileHandler_eval();
	set(p, o);
}

		if ("books".equals(p.entityName)) {
	o = __books_eval();
	set(p, o);
}

		if ("copyStringTokenizer".equals(p.entityName)) {
	o = __copyStringTokenizer_eval();
	set(p, o);
}

		if ("bookFileHandler".equals(p.entityName)) {
	o = __bookFileHandler_eval();
	set(p, o);
}

		if ("members".equals(p.entityName)) {
	o = __members_eval();
	set(p, o);
}

		if ("borrowsStringTokenizer".equals(p.entityName)) {
	o = __borrowsStringTokenizer_eval();
	set(p, o);
}

		if ("toCollectStringTokenizer".equals(p.entityName)) {
	o = __toCollectStringTokenizer_eval();
	set(p, o);
}

		if ("authorStringTokenizer".equals(p.entityName)) {
	o = __authorStringTokenizer_eval();
	set(p, o);
}

		if ("bookStringTokenizer".equals(p.entityName)) {
	o = __bookStringTokenizer_eval();
	set(p, o);
}

		if ("copies".equals(p.entityName)) {
	o = __copies_eval();
	set(p, o);
}

		if ("memberStringTokenizer".equals(p.entityName)) {
	o = __memberStringTokenizer_eval();
	set(p, o);
}

		if ("copyFileHandler".equals(p.entityName)) {
	o = __copyFileHandler_eval();
	set(p, o);
}

		if ("toCollectFileHandler".equals(p.entityName)) {
	o = __toCollectFileHandler_eval();
	set(p, o);
}

		if ("saveCopiesFileHandler".equals(p.entityName)) {
	o = __saveCopiesFileHandler_eval();
	set(p, o);
}

		if ("authorFileHandler".equals(p.entityName)) {
	o = __authorFileHandler_eval();
	set(p, o);
}

		if ("authors".equals(p.entityName)) {
	o = __authors_eval();
	set(p, o);
}

		if ("memberFileHandler".equals(p.entityName)) {
	o = __memberFileHandler_eval();
	set(p, o);
}

		if (o instanceof lu.uni.democles.runtime.Instance) {
	((lu.uni.democles.runtime.Instance)o).initProps();
} else if (o instanceof lu.uni.democles.runtime.OCLCollection) {
	for (java.util.Iterator iter = ((lu.uni.democles.runtime.OCLCollection)o).getValues().iterator(); iter.hasNext();) {
		java.lang.Object entry = iter.next();
		if (entry instanceof lu.uni.democles.runtime.Instance) {
			((lu.uni.democles.runtime.Instance)entry).initProps();
		}
	}
}
p.setEvaluating(false);
return o;


	}
	public lu.uni.democles.runtime.OCLSet __pq_findAuthors(final lu.uni.democles.runtime.OCLSet v_authorIds) {
		try {
	return ((lu.uni.democles.runtime.OCLSet)((lu.uni.democles.runtime.Property)generated.LibraryPersistence.LibraryFiles.this.getEntity("authors")).evalInContainer()).select(new lu.uni.democles.runtime.Function() {
	public Object _iteration(Object _value) {
final generated.Library.Author v_a = ((generated.Library.Author)_value);
return _asObject((v_authorIds.includes(((java.lang.String)((lu.uni.democles.runtime.Property)v_a.getEntity("authorId")).evalInContainer().getValues().iterator().next()))));
	}
});

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|LibraryPersistence::LibraryFiles/Property/findAuthors");
	_error.addVariable("authorIds", v_authorIds);
	throw _error;
}



	}
	private java.lang.Object __saveBorrowsFileHandler_eval() {
		try {
	return (new generated.Persistence.FileHandler());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|LibraryPersistence::LibraryFiles/Property/saveBorrowsFileHandler");
	throw _error;
}

	}
	protected void doModify(lu.uni.democles.runtime.Event event) {
		if ("memberLineTokenized".equals(event.entityName)) {
	handleImpact(event, this._p_members);
}
if ("bookLineTokenized".equals(event.entityName)) {
	handleImpact(event, this._p_books);
}
if ("copyLineTokenized".equals(event.entityName)) {
	handleImpact(event, this._p_copies);
}
if ("authorsLineTokenized".equals(event.entityName)) {
	handleImpact(event, this._p_authors);
}

	}
	private java.lang.Object _memberLineTokenized_members_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return (((lu.uni.democles.runtime.OCLSet)((lu.uni.democles.runtime.Property)generated.LibraryPersistence.LibraryFiles.this.getEntity("members")).evalInContainer()).including((generated.Library.Member.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "libraryNo", (((java.lang.String)((lu.uni.democles.runtime.OCLSequence)_event.getParameter("tokens")).at((int)1))), "password", (((java.lang.String)((lu.uni.democles.runtime.OCLSequence)_event.getParameter("tokens")).at((int)3))), "name", (((java.lang.String)((lu.uni.democles.runtime.OCLSequence)_event.getParameter("tokens")).at((int)2))), "borrows", new lu.uni.democles.runtime.OCLSet(new Object[] {}), "toCollect", new lu.uni.democles.runtime.OCLSet(new Object[] {}) }))))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|LibraryPersistence::LibraryFiles/Event/memberLineTokenized-impacts-LibraryPersistence::LibraryFiles/Property/members");
	try {
		_error.addVariable("tokens", _event.getParameter("tokens"));
	} catch (Throwable _t) {
		_error.addVariable("tokens", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	public static void main(String[] args) {
	}
	private java.lang.Object __borrowsStringTokenizer_eval() {
		try {
	return (new generated.StringUtils.StringTokenizer());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|LibraryPersistence::LibraryFiles/Property/borrowsStringTokenizer");
	throw _error;
}

	}
	private java.lang.Object __members_eval() {
		try {
	return new lu.uni.democles.runtime.OCLSet(new Object[] {});

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|LibraryPersistence::LibraryFiles/Property/members");
	throw _error;
}

	}
	private java.lang.Object __borrowsFileHandler_eval() {
		try {
	return (new generated.Persistence.FileHandler());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|LibraryPersistence::LibraryFiles/Property/borrowsFileHandler");
	throw _error;
}

	}
	private void handleImpact(lu.uni.democles.runtime.Event e, lu.uni.democles.runtime.Property p) {
		set(p, eval_ep(e, p));
	}
	private java.lang.Object eval_ep(final lu.uni.democles.runtime.Event e, final lu.uni.democles.runtime.Property p) {
		if (p.entityName.equals(this._p_copies.entityName) && e.entityName.equals(this._e_copyLineTokenized.entityName)) {
	return _copyLineTokenized_copies_eval(e);
}
		if (p.entityName.equals(this._p_members.entityName) && e.entityName.equals(this._e_memberLineTokenized.entityName)) {
	return _memberLineTokenized_members_eval(e);
}
		if (p.entityName.equals(this._p_authors.entityName) && e.entityName.equals(this._e_authorsLineTokenized.entityName)) {
	return _authorsLineTokenized_authors_eval(e);
}
		if (p.entityName.equals(this._p_books.entityName) && e.entityName.equals(this._e_bookLineTokenized.entityName)) {
	return _bookLineTokenized_books_eval(e);
}
		return null;

	}
	private java.lang.Object _copyLineTokenized_copies_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return (((lu.uni.democles.runtime.OCLSet)((lu.uni.democles.runtime.Property)generated.LibraryPersistence.LibraryFiles.this.getEntity("copies")).evalInContainer()).including((generated.Library.Copy.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "copyId", (((java.lang.String)((lu.uni.democles.runtime.OCLSequence)_event.getParameter("tokens")).at((int)1))), "book", (((generated.Library.Book)generated.LibraryPersistence.LibraryFiles.this.evalQueryWithParameters("findBook", new Object[] { (((java.lang.String)((lu.uni.democles.runtime.OCLSequence)_event.getParameter("tokens")).at((int)5))) }))), "dueDate", (((java.lang.String)((lu.uni.democles.runtime.OCLSequence)_event.getParameter("tokens")).at((int)3))), "renewals", new java.lang.Integer((java.lang.Integer.valueOf((((java.lang.String)((lu.uni.democles.runtime.OCLSequence)_event.getParameter("tokens")).at((int)4)))).intValue())), "state", (((java.lang.String)((lu.uni.democles.runtime.OCLSequence)_event.getParameter("tokens")).at((int)2))) }))))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|LibraryPersistence::LibraryFiles/Event/copyLineTokenized-impacts-LibraryPersistence::LibraryFiles/Property/copies");
	try {
		_error.addVariable("tokens", _event.getParameter("tokens"));
	} catch (Throwable _t) {
		_error.addVariable("tokens", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	public java.lang.String __pq_intToString(final int v_int) {
		try {
	return ((java.lang.String)new lu.uni.democles.runtime.Function() {
	public Object _result() {
if ((v_int > 0)) {
	return _asObject(((java.lang.String)new lu.uni.democles.runtime.OCLOrderedSet(new Object[] {new java.lang.Integer(1000000), new java.lang.Integer(10000), new java.lang.Integer(1000), new java.lang.Integer(100), new java.lang.Integer(10), new java.lang.Integer(1)}).iterate(new lu.uni.democles.runtime.Function() {
	public Object _iterate(Object _value, Object _acc) {
final java.lang.String v_s = ((java.lang.String)_acc);
final int v_denominator = ((int)((java.lang.Integer)_value).intValue());
return _asObject(((java.lang.String)new lu.uni.democles.runtime.Function() {
	public Object _result() {
		final java.lang.String v_numberAsString = (((java.lang.String)new lu.uni.democles.runtime.OCLOrderedSet(new Object[] {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"}).at((int)(((java.lang.Math.round(java.lang.Math.floor(java.lang.Math.abs(v_int / v_denominator)))) % 10) + 1))));
		return _asObject(((java.lang.String)new lu.uni.democles.runtime.Function() {
	public Object _result() {
if (((lu.uni.democles.runtime.Function._equals(v_s, "")) && (lu.uni.democles.runtime.Function._equals(v_numberAsString, "0")))) {
	return _asObject(v_s);
} else {
	return _asObject((v_s + v_numberAsString));
}
}}._result()));
	}
}._result()));
	}
}, "")));
} else {
	return _asObject("0");
}
}}._result());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|LibraryPersistence::LibraryFiles/Property/intToString");
	_error.addVariable("int", new java.lang.Integer(v_int));
	throw _error;
}



	}
	private java.lang.Object __saveCopiesFileHandler_eval() {
		try {
	return (new generated.Persistence.FileHandler());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|LibraryPersistence::LibraryFiles/Property/saveCopiesFileHandler");
	throw _error;
}

	}
	private java.lang.Object __saveToCollectFileHandler_eval() {
		try {
	return (new generated.Persistence.FileHandler());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|LibraryPersistence::LibraryFiles/Property/saveToCollectFileHandler");
	throw _error;
}

	}
	private java.lang.Object _authorsLineTokenized_authors_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return (((lu.uni.democles.runtime.OCLSet)((lu.uni.democles.runtime.Property)generated.LibraryPersistence.LibraryFiles.this.getEntity("authors")).evalInContainer()).including((generated.Library.Author.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "name", (((java.lang.String)((lu.uni.democles.runtime.OCLSequence)_event.getParameter("tokens")).at((int)2))), "authorId", (((java.lang.String)((lu.uni.democles.runtime.OCLSequence)_event.getParameter("tokens")).at((int)1))) }))))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|LibraryPersistence::LibraryFiles/Event/authorsLineTokenized-impacts-LibraryPersistence::LibraryFiles/Property/authors");
	try {
		_error.addVariable("tokens", _event.getParameter("tokens"));
	} catch (Throwable _t) {
		_error.addVariable("tokens", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
}
