package generated.Application;

public class Main extends lu.uni.democles.runtime.Instance {
	private lu.uni.democles.runtime.Property _p_loginControl = new lu.uni.democles.runtime.Property(this, "loginControl", "Main", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_sessionOpened = new lu.uni.democles.runtime.Event(this, "sessionOpened", "Main", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.Library.Library", "library", "sessionOpened", new java.lang.String[] {"m"}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "memberControl", "generated.MobileLibraryGUI.MemberWindowController", "sessionOpened", new java.lang.String[] {"m"}), new lu.uni.democles.runtime.ChildLink(false, "loginControl", "generated.MobileLibraryGUI.LoginWindowController", "sessionOpened", new java.lang.String[] {}), new lu.uni.democles.runtime.ChildLink(false, "searchControl", "generated.MobileLibraryGUI.SearchWindowController", "memberSessionStarted", new java.lang.String[] {"m"}) });
	private lu.uni.democles.runtime.Event _e_init = new lu.uni.democles.runtime.Event(this, "init", "Main", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.Application.Main", "loadLibrary", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Event _e_setCompleteBookCollection = new lu.uni.democles.runtime.Event(this, "setCompleteBookCollection", "Main", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_openSession = new lu.uni.democles.runtime.Event(this, "openSession", "Main", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.MobileLibraryGUI.LoginWindowController", "loginControl", "openSession", new java.lang.String[] {"libNo", "password"}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.Application.Main", "authenticateMember", new java.lang.String[] {"libNo", "pw"}) });
	private lu.uni.democles.runtime.Event _e_searchBook = new lu.uni.democles.runtime.Event(this, "searchBook", "Main", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.MobileLibraryGUI.SearchWindowController", "searchControl", "searchBook", new java.lang.String[] {"term", "category"}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "library", "generated.Library.Library", "searchBook", new java.lang.String[] {"term", "category"}) });
	private lu.uni.democles.runtime.Property _p_library = new lu.uni.democles.runtime.Property(this, "library", "Main", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_startWindowControl = new lu.uni.democles.runtime.Property(this, "startWindowControl", "Main", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_memberViewMode = new lu.uni.democles.runtime.Property(this, "memberViewMode", "Main", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_searchControl = new lu.uni.democles.runtime.Property(this, "searchControl", "Main", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_loginFailed = new lu.uni.democles.runtime.Event(this, "loginFailed", "Main", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.Library.Library", "library", "loginFailed", new java.lang.String[] {}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "loginControl", "generated.MobileLibraryGUI.LoginWindowController", "loginFailed", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Event _e_searchFinished = new lu.uni.democles.runtime.Event(this, "searchFinished", "Main", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.Library.Library", "library", "booksFound", new java.lang.String[] {"booksFound"}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "searchControl", "generated.MobileLibraryGUI.SearchWindowController", "searchFinished", new java.lang.String[] {"booksFound"}) });
	private lu.uni.democles.runtime.Property _p_memberControl = new lu.uni.democles.runtime.Property(this, "memberControl", "Main", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_getSearchFrame = new lu.uni.democles.runtime.Property(this, "getSearchFrame", "Main", "Query", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_viewsControl = new lu.uni.democles.runtime.Property(this, "viewsControl", "Main", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_loginConfirmed = new lu.uni.democles.runtime.Event(this, "loginConfirmed", "Main", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.MobileLibraryGUI.LoginWindowController", "loginControl", "loginConfirmed", new java.lang.String[] {}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.Application.Main", "setToMemberMode", new java.lang.String[] {}), new lu.uni.democles.runtime.ChildLink(true, "", "generated.Application.Main", "refreshMemberWindow", new java.lang.String[] {}), new lu.uni.democles.runtime.ChildLink(false, "viewsControl", "generated.MobileLibraryGUI.ViewsWindowController", "changeFromLoginToMember", new java.lang.String[] {"memberFrame"}) });
	private lu.uni.democles.runtime.Event _e_libraryBooksLoaded = new lu.uni.democles.runtime.Event(this, "libraryBooksLoaded", "Main", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.LibraryPersistence.LibraryFiles", "libraryFileHandler", "libraryLoaded", new java.lang.String[] {"bookCollection"}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.Application.Main", "setCompleteBookCollection", new java.lang.String[] {"completeBookCollection"}), new lu.uni.democles.runtime.ChildLink(false, "viewsControl", "generated.MobileLibraryGUI.ViewsWindowController", "startViewsWindow", new java.lang.String[] {"searchWindow", "loginWindow"}), new lu.uni.democles.runtime.ChildLink(true, "", "generated.Application.Main", "closeStartWindow", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Event _e_saveLibrary = new lu.uni.democles.runtime.Event(this, "saveLibrary", "Main", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.MobileLibraryGUI.MemberWindowController", "memberControl", "saveData", new java.lang.String[] {}), new lu.uni.democles.runtime.ParentLink(false, "generated.MobileLibraryGUI.SearchWindowController", "searchControl", "refreshAndSave", new java.lang.String[] {}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "libraryFileHandler", "generated.LibraryPersistence.LibraryFiles", "saveLibrary", new java.lang.String[] {"library"}) });
	private lu.uni.democles.runtime.Event _e_closeStartWindow = new lu.uni.democles.runtime.Event(this, "closeStartWindow", "Main", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "startWindowControl", "generated.MobileLibraryGUI.StartWindowController", "closeWIndow", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Event _e_authenticateMember = new lu.uni.democles.runtime.Event(this, "authenticateMember", "Main", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "library", "generated.Library.Library", "authenticateMember", new java.lang.String[] {"libNo", "pw"}) });
	private lu.uni.democles.runtime.Property _p_getMemberFrame = new lu.uni.democles.runtime.Property(this, "getMemberFrame", "Main", "Query", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_libraryFileHandler = new lu.uni.democles.runtime.Property(this, "libraryFileHandler", "Main", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_refreshMemberWindow = new lu.uni.democles.runtime.Event(this, "refreshMemberWindow", "Main", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.MobileLibraryGUI.SearchWindowController", "searchControl", "refreshAndSave", new java.lang.String[] {}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "memberControl", "generated.MobileLibraryGUI.MemberWindowController", "refreshData", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Event _e_setToMemberMode = new lu.uni.democles.runtime.Event(this, "setToMemberMode", "Main", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_loadLibrary = new lu.uni.democles.runtime.Event(this, "loadLibrary", "Main", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "libraryFileHandler", "generated.LibraryPersistence.LibraryFiles", "load", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Property _p_getLoginFrame = new lu.uni.democles.runtime.Property(this, "getLoginFrame", "Main", "Query", false, false, null, "single");
	private java.lang.Object __getMemberFrame_eval() {
		try {
	return ((generated.GeneralGUI.Frame)((lu.uni.democles.runtime.Property)((generated.MobileLibraryGUI.MemberWindowController)((lu.uni.democles.runtime.Property)generated.Application.Main.this.getEntity("memberControl")).evalInContainer().getValues().iterator().next()).getEntity("window")).evalInContainer().getValues().iterator().next());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Application::Main/Property/getMemberFrame");
	throw _error;
}

	}
	protected boolean guard_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse) {
		if (_event.entityName.equals("openSession") && _parent.entityName.equals("openSession") && _linkProperty.container.modelName.equals("generated.Application.Main") && _linkProperty.entityName.equals("loginControl") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Application::Main/Event/openSession$eventParentLink,Forward,loginControl,MobileLibraryGUI::LoginWindowController,openSession");
	try {
		_error.addVariable("libNo", _parent.getParameter("libNo"));
	} catch (Throwable _t) {
		_error.addVariable("libNo", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("password", _parent.getParameter("password"));
	} catch (Throwable _t) {
		_error.addVariable("password", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		
		if (_event.entityName.equals("loginFailed") && _parent.entityName.equals("loginFailed") && _linkProperty.container.modelName.equals("generated.Application.Main") && _linkProperty.entityName.equals("library") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Application::Main/Event/loginFailed$eventParentLink,Forward,library,Library::Library,loginFailed");
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("refreshMemberWindow") && _parent.entityName.equals("refreshAndSave") && _linkProperty.container.modelName.equals("generated.Application.Main") && _linkProperty.entityName.equals("searchControl") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Application::Main/Event/refreshMemberWindow$eventParentLink,Forward,searchControl,MobileLibraryGUI::SearchWindowController,refreshAndSave");
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("saveLibrary") && _parent.entityName.equals("saveData") && _linkProperty.container.modelName.equals("generated.Application.Main") && _linkProperty.entityName.equals("memberControl") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Application::Main/Event/saveLibrary$eventParentLink,Forward,memberControl,MobileLibraryGUI::MemberWindowController,saveData");
	try {
		_error.addVariable("library", _parent.getAttachedProperty("Main_library"));
	} catch (Throwable _t) {
		_error.addVariable("library", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}
if (_event.entityName.equals("saveLibrary") && _parent.entityName.equals("refreshAndSave") && _linkProperty.container.modelName.equals("generated.Application.Main") && _linkProperty.entityName.equals("searchControl") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Application::Main/Event/saveLibrary$eventParentLink,Forward,searchControl,MobileLibraryGUI::SearchWindowController,refreshAndSave");
	try {
		_error.addVariable("library", _parent.getAttachedProperty("Main_library"));
	} catch (Throwable _t) {
		_error.addVariable("library", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("searchBook") && _parent.entityName.equals("searchBook") && _linkProperty.container.modelName.equals("generated.Application.Main") && _linkProperty.entityName.equals("searchControl") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Application::Main/Event/searchBook$eventParentLink,Forward,searchControl,MobileLibraryGUI::SearchWindowController,searchBook");
	try {
		_error.addVariable("library", _parent.getAttachedProperty("Main_library"));
	} catch (Throwable _t) {
		_error.addVariable("library", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("term", _parent.getParameter("term"));
	} catch (Throwable _t) {
		_error.addVariable("term", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("category", _parent.getParameter("category"));
	} catch (Throwable _t) {
		_error.addVariable("category", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("searchFinished") && _parent.entityName.equals("booksFound") && _linkProperty.container.modelName.equals("generated.Application.Main") && _linkProperty.entityName.equals("library") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Application::Main/Event/searchFinished$eventParentLink,Forward,library,Library::Library,booksFound");
	try {
		_error.addVariable("booksFound", _parent.getParameter("booksFound"));
	} catch (Throwable _t) {
		_error.addVariable("booksFound", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("sessionOpened") && _parent.entityName.equals("sessionOpened") && _linkProperty.container.modelName.equals("generated.Application.Main") && _linkProperty.entityName.equals("library") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Application::Main/Event/sessionOpened$eventParentLink,Forward,library,Library::Library,sessionOpened");
	try {
		_error.addVariable("library", _parent.getAttachedProperty("Main_library"));
	} catch (Throwable _t) {
		_error.addVariable("library", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("m", _parent.getParameter("m"));
	} catch (Throwable _t) {
		_error.addVariable("m", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("libraryBooksLoaded") && _parent.entityName.equals("libraryLoaded") && _linkProperty.container.modelName.equals("generated.Application.Main") && _linkProperty.entityName.equals("libraryFileHandler") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Application::Main/Event/libraryBooksLoaded$eventParentLink,Forward,libraryFileHandler,LibraryPersistence::LibraryFiles,libraryLoaded");
	try {
		_error.addVariable("libraryFileHandler", _parent.getAttachedProperty("Main_libraryFileHandler"));
	} catch (Throwable _t) {
		_error.addVariable("libraryFileHandler", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("getSearchFrame", _parent.getAttachedProperty("Main_getSearchFrame"));
	} catch (Throwable _t) {
		_error.addVariable("getSearchFrame", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("getLoginFrame", _parent.getAttachedProperty("Main_getLoginFrame"));
	} catch (Throwable _t) {
		_error.addVariable("getLoginFrame", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("bookCollection", _parent.getParameter("bookCollection"));
	} catch (Throwable _t) {
		_error.addVariable("bookCollection", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("loginConfirmed") && _parent.entityName.equals("loginConfirmed") && _linkProperty.container.modelName.equals("generated.Application.Main") && _linkProperty.entityName.equals("loginControl") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Application::Main/Event/loginConfirmed$eventParentLink,Forward,loginControl,MobileLibraryGUI::LoginWindowController,loginConfirmed");
	try {
		_error.addVariable("getMemberFrame", _parent.getAttachedProperty("Main_getMemberFrame"));
	} catch (Throwable _t) {
		_error.addVariable("getMemberFrame", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		return true;

	}
	private java.lang.Object eval_ep(final lu.uni.democles.runtime.Event e, final lu.uni.democles.runtime.Property p) {
		if (p.entityName.equals(this._p_startWindowControl.entityName) && e.entityName.equals(this._e_closeStartWindow.entityName)) {
	return _closeStartWindow_startWindowControl_eval(e);
}
		if (p.entityName.equals(this._p_library.entityName) && e.entityName.equals(this._e_setCompleteBookCollection.entityName)) {
	return _setCompleteBookCollection_library_eval(e);
}
		if (p.entityName.equals(this._p_memberViewMode.entityName) && e.entityName.equals(this._e_setToMemberMode.entityName)) {
	return _setToMemberMode_memberViewMode_eval(e);
}
		return null;

	}
	protected void attachProperties(lu.uni.democles.runtime.Event e) {
		// Set Attached Properties:


		// Set Attached Properties:
if ("saveLibrary".equals(e.entityName)) {
	e.attachProperty("Main_library", this._p_library.evalInContainer().getValues().iterator().next());
}


		// Set Attached Properties:
if ("searchBook".equals(e.entityName)) {
	e.attachProperty("Main_library", this._p_library.evalInContainer().getValues().iterator().next());
}


		// Set Attached Properties:
if ("sessionOpened".equals(e.entityName)) {
	e.attachProperty("Main_library", this._p_library.evalInContainer().getValues().iterator().next());
}


		// Set Attached Properties:
if ("libraryBooksLoaded".equals(e.entityName)) {
	e.attachProperty("Main_libraryFileHandler", this._p_libraryFileHandler.evalInContainer().getValues().iterator().next());
	e.attachProperty("Main_getSearchFrame", this._p_getSearchFrame.evalInContainer().getValues().iterator().next());
	e.attachProperty("Main_getLoginFrame", this._p_getLoginFrame.evalInContainer().getValues().iterator().next());
}


		// Set Attached Properties:
if ("loginConfirmed".equals(e.entityName)) {
	e.attachProperty("Main_getMemberFrame", this._p_getMemberFrame.evalInContainer().getValues().iterator().next());
}


	}
	protected java.lang.Object evalQuery(lu.uni.democles.runtime.Property p) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) return p.newVal;

if (p.isEvaluating()) throw new lu.uni.democles.runtime.ModificationCycleException();

p.setEvaluating(true);
java.lang.Object o = null;


		if ("startWindowControl".equals(p.entityName)) {
	o = __startWindowControl_eval();
	set(p, o);
}

		if ("memberControl".equals(p.entityName)) {
	o = __memberControl_eval();
	set(p, o);
}

		if ("searchControl".equals(p.entityName)) {
	o = __searchControl_eval();
	set(p, o);
}

		if ("viewsControl".equals(p.entityName)) {
	o = __viewsControl_eval();
	set(p, o);
}

		if ("getMemberFrame".equals(p.entityName)) {
	o = __getMemberFrame_eval();
	set(p, o);
}

		if ("libraryFileHandler".equals(p.entityName)) {
	o = __libraryFileHandler_eval();
	set(p, o);
}

		if ("getLoginFrame".equals(p.entityName)) {
	o = __getLoginFrame_eval();
	set(p, o);
}

		if ("library".equals(p.entityName)) {
	o = __library_eval();
	set(p, o);
}

		if ("memberViewMode".equals(p.entityName)) {
	o = __memberViewMode_eval();
	set(p, o);
}

		if ("getSearchFrame".equals(p.entityName)) {
	o = __getSearchFrame_eval();
	set(p, o);
}

		if ("loginControl".equals(p.entityName)) {
	o = __loginControl_eval();
	set(p, o);
}

		if (o instanceof lu.uni.democles.runtime.Instance) {
	((lu.uni.democles.runtime.Instance)o).initProps();
} else if (o instanceof lu.uni.democles.runtime.OCLCollection) {
	for (java.util.Iterator iter = ((lu.uni.democles.runtime.OCLCollection)o).getValues().iterator(); iter.hasNext();) {
		java.lang.Object entry = iter.next();
		if (entry instanceof lu.uni.democles.runtime.Instance) {
			((lu.uni.democles.runtime.Instance)entry).initProps();
		}
	}
}
p.setEvaluating(false);
return o;


	}
	public static void main(String[] args) {
		Main initialMain = new Main();

		initialMain.initProps();
		lu.uni.democles.runtime.EventQueue.queueEvent(initialMain, initialMain._e_init, null);


	}
	private java.lang.Object __memberControl_eval() {
		try {
	return (new generated.MobileLibraryGUI.MemberWindowController());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Application::Main/Property/memberControl");
	throw _error;
}

	}
	private java.lang.Object _setCompleteBookCollection_library_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return ((generated.Library.Library)_event.getParameter("completeBookCollection"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|Application::Main/Event/setCompleteBookCollection-impacts-Application::Main/Property/library");
	try {
		_error.addVariable("completeBookCollection", _event.getParameter("completeBookCollection"));
	} catch (Throwable _t) {
		_error.addVariable("completeBookCollection", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	protected java.lang.Object eval_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse, final java.lang.String _paramName) {
		if (_parent.entityName.equals("openSession") && _event.entityName.equals("openSession") && _linkProperty.entityName.equals("loginControl") && _inverse == false && _paramName.equals("libNo")) {
try {
	return ((java.lang.String)_parent.getParameter("libNo"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|Application::Main/Event/openSession$eventParentLink,Forward,loginControl,MobileLibraryGUI::LoginWindowController,openSession$libNo");
	try {
		_error.addVariable("passwordField", _parent.getAttachedProperty("LoginWindowController_passwordField"));
	} catch (Throwable _t) {
		_error.addVariable("passwordField", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("libraryNoField", _parent.getAttachedProperty("LoginWindowController_libraryNoField"));
	} catch (Throwable _t) {
		_error.addVariable("libraryNoField", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("libNo", _parent.getParameter("libNo"));
	} catch (Throwable _t) {
		_error.addVariable("libNo", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("password", _parent.getParameter("password"));
	} catch (Throwable _t) {
		_error.addVariable("password", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}
if (_parent.entityName.equals("openSession") && _event.entityName.equals("openSession") && _linkProperty.entityName.equals("loginControl") && _inverse == false && _paramName.equals("password")) {
try {
	return ((java.lang.String)_parent.getParameter("password"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|Application::Main/Event/openSession$eventParentLink,Forward,loginControl,MobileLibraryGUI::LoginWindowController,openSession$password");
	try {
		_error.addVariable("passwordField", _parent.getAttachedProperty("LoginWindowController_passwordField"));
	} catch (Throwable _t) {
		_error.addVariable("passwordField", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("libraryNoField", _parent.getAttachedProperty("LoginWindowController_libraryNoField"));
	} catch (Throwable _t) {
		_error.addVariable("libraryNoField", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("libNo", _parent.getParameter("libNo"));
	} catch (Throwable _t) {
		_error.addVariable("libNo", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("password", _parent.getParameter("password"));
	} catch (Throwable _t) {
		_error.addVariable("password", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		
		if (_parent.entityName.equals("searchBook") && _event.entityName.equals("searchBook") && _linkProperty.entityName.equals("searchControl") && _inverse == false && _paramName.equals("term")) {
try {
	return ((java.lang.String)_parent.getParameter("term"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|Application::Main/Event/searchBook$eventParentLink,Forward,searchControl,MobileLibraryGUI::SearchWindowController,searchBook$term");
	try {
		_error.addVariable("term", _parent.getParameter("term"));
	} catch (Throwable _t) {
		_error.addVariable("term", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("category", _parent.getParameter("category"));
	} catch (Throwable _t) {
		_error.addVariable("category", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}
if (_parent.entityName.equals("searchBook") && _event.entityName.equals("searchBook") && _linkProperty.entityName.equals("searchControl") && _inverse == false && _paramName.equals("category")) {
try {
	return ((java.lang.String)_parent.getParameter("category"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|Application::Main/Event/searchBook$eventParentLink,Forward,searchControl,MobileLibraryGUI::SearchWindowController,searchBook$category");
	try {
		_error.addVariable("term", _parent.getParameter("term"));
	} catch (Throwable _t) {
		_error.addVariable("term", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("category", _parent.getParameter("category"));
	} catch (Throwable _t) {
		_error.addVariable("category", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (_parent.entityName.equals("booksFound") && _event.entityName.equals("searchFinished") && _linkProperty.entityName.equals("library") && _inverse == false && _paramName.equals("booksFound")) {
try {
	return ((lu.uni.democles.runtime.OCLSet)_parent.getParameter("foundBooks"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|Application::Main/Event/searchFinished$eventParentLink,Forward,library,Library::Library,booksFound$booksFound");
	try {
		_error.addVariable("foundBooks", _parent.getParameter("foundBooks"));
	} catch (Throwable _t) {
		_error.addVariable("foundBooks", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (_parent.entityName.equals("sessionOpened") && _event.entityName.equals("sessionOpened") && _linkProperty.entityName.equals("library") && _inverse == false && _paramName.equals("m")) {
try {
	return ((generated.Library.Member)_parent.getParameter("member"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|Application::Main/Event/sessionOpened$eventParentLink,Forward,library,Library::Library,sessionOpened$m");
	try {
		_error.addVariable("member", _parent.getParameter("member"));
	} catch (Throwable _t) {
		_error.addVariable("member", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (_parent.entityName.equals("libraryLoaded") && _event.entityName.equals("libraryBooksLoaded") && _linkProperty.entityName.equals("libraryFileHandler") && _inverse == false && _paramName.equals("bookCollection")) {
try {
	return ((generated.Library.Library)_parent.getParameter("library"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|Application::Main/Event/libraryBooksLoaded$eventParentLink,Forward,libraryFileHandler,LibraryPersistence::LibraryFiles,libraryLoaded$bookCollection");
	try {
		_error.addVariable("library", _parent.getParameter("library"));
	} catch (Throwable _t) {
		_error.addVariable("library", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		return null;

	}
	private java.lang.Object __loginControl_eval() {
		try {
	return (new generated.MobileLibraryGUI.LoginWindowController());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Application::Main/Property/loginControl");
	throw _error;
}

	}
	private void handleImpact(lu.uni.democles.runtime.Event e, lu.uni.democles.runtime.Property p) {
		set(p, eval_ep(e, p));
	}
	protected void resetNewVal() {
		this._p_startWindowControl.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_memberControl.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_searchControl.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_viewsControl.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_getMemberFrame.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_libraryFileHandler.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_getLoginFrame.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_library.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_memberViewMode.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_getSearchFrame.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_loginControl.newVal = lu.uni.democles.runtime.Entity.nullObject;
	}
	private java.lang.Object __getLoginFrame_eval() {
		try {
	return ((generated.GeneralGUI.Frame)((lu.uni.democles.runtime.Property)((generated.MobileLibraryGUI.LoginWindowController)((lu.uni.democles.runtime.Property)generated.Application.Main.this.getEntity("loginControl")).evalInContainer().getValues().iterator().next()).getEntity("frame")).evalInContainer().getValues().iterator().next());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Application::Main/Property/getLoginFrame");
	throw _error;
}

	}
	private java.lang.Object _closeStartWindow_startWindowControl_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return null;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|Application::Main/Event/closeStartWindow-impacts-Application::Main/Property/startWindowControl");
	throw _error;
}


	}
	public static Main newWithValues(java.util.HashMap values) {
		Main res = new Main();
res.initialValues = new java.util.HashMap(values);
res.initProps();
return res;
	}
	protected boolean guard_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final lu.uni.democles.runtime.Instance linkedInstance, final int _link) {
		if (e1.entityName.equals("openSession") && e2.entityName.equals("authenticateMember") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Application::Main/Event/openSession$eventChildLink,Local,authenticateMember");
	try {
		_error.addVariable("libNo", e1.getParameter("libNo"));
	} catch (Throwable _t) {
		_error.addVariable("libNo", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("password", e1.getParameter("password"));
	} catch (Throwable _t) {
		_error.addVariable("password", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		
		if (e1.entityName.equals("loginFailed") && e2.entityName.equals("loginFailed") && linkProperty.container.modelName.equals("generated.Application.Main") && linkProperty.entityName.equals("loginControl")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Application::Main/Event/loginFailed$eventChildLink,Forward,loginControl,MobileLibraryGUI::LoginWindowController,loginFailed");
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("refreshMemberWindow") && e2.entityName.equals("refreshData") && linkProperty.container.modelName.equals("generated.Application.Main") && linkProperty.entityName.equals("memberControl")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Application::Main/Event/refreshMemberWindow$eventChildLink,Forward,memberControl,MobileLibraryGUI::MemberWindowController,refreshData");
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("authenticateMember") && e2.entityName.equals("authenticateMember") && linkProperty.container.modelName.equals("generated.Application.Main") && linkProperty.entityName.equals("library")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Application::Main/Event/authenticateMember$eventChildLink,Forward,library,Library::Library,authenticateMember");
	try {
		_error.addVariable("libNo", e1.getParameter("libNo"));
	} catch (Throwable _t) {
		_error.addVariable("libNo", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("pw", e1.getParameter("pw"));
	} catch (Throwable _t) {
		_error.addVariable("pw", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("saveLibrary") && e2.entityName.equals("saveLibrary") && linkProperty.container.modelName.equals("generated.Application.Main") && linkProperty.entityName.equals("libraryFileHandler")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Application::Main/Event/saveLibrary$eventChildLink,Forward,libraryFileHandler,LibraryPersistence::LibraryFiles,saveLibrary");
	try {
		_error.addVariable("library", e1.getAttachedProperty("Main_library"));
	} catch (Throwable _t) {
		_error.addVariable("library", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("searchBook") && e2.entityName.equals("searchBook") && linkProperty.container.modelName.equals("generated.Application.Main") && linkProperty.entityName.equals("library")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Application::Main/Event/searchBook$eventChildLink,Forward,library,Library::Library,searchBook");
	try {
		_error.addVariable("library", e1.getAttachedProperty("Main_library"));
	} catch (Throwable _t) {
		_error.addVariable("library", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("term", e1.getParameter("term"));
	} catch (Throwable _t) {
		_error.addVariable("term", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("category", e1.getParameter("category"));
	} catch (Throwable _t) {
		_error.addVariable("category", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("loadLibrary") && e2.entityName.equals("load") && linkProperty.container.modelName.equals("generated.Application.Main") && linkProperty.entityName.equals("libraryFileHandler")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Application::Main/Event/loadLibrary$eventChildLink,Forward,libraryFileHandler,LibraryPersistence::LibraryFiles,load");
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("searchFinished") && e2.entityName.equals("searchFinished") && linkProperty.container.modelName.equals("generated.Application.Main") && linkProperty.entityName.equals("searchControl")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Application::Main/Event/searchFinished$eventChildLink,Forward,searchControl,MobileLibraryGUI::SearchWindowController,searchFinished");
	try {
		_error.addVariable("booksFound", e1.getParameter("booksFound"));
	} catch (Throwable _t) {
		_error.addVariable("booksFound", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("closeStartWindow") && e2.entityName.equals("closeWIndow") && linkProperty.container.modelName.equals("generated.Application.Main") && linkProperty.entityName.equals("startWindowControl")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Application::Main/Event/closeStartWindow$eventChildLink,Forward,startWindowControl,MobileLibraryGUI::StartWindowController,closeWIndow");
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("sessionOpened") && e2.entityName.equals("sessionOpened") && linkProperty.container.modelName.equals("generated.Application.Main") && linkProperty.entityName.equals("memberControl")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Application::Main/Event/sessionOpened$eventChildLink,Forward,memberControl,MobileLibraryGUI::MemberWindowController,sessionOpened");
	try {
		_error.addVariable("library", e1.getAttachedProperty("Main_library"));
	} catch (Throwable _t) {
		_error.addVariable("library", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("m", e1.getParameter("m"));
	} catch (Throwable _t) {
		_error.addVariable("m", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}
if (e1.entityName.equals("sessionOpened") && e2.entityName.equals("sessionOpened") && linkProperty.container.modelName.equals("generated.Application.Main") && linkProperty.entityName.equals("loginControl")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Application::Main/Event/sessionOpened$eventChildLink,Forward,loginControl,MobileLibraryGUI::LoginWindowController,sessionOpened");
	try {
		_error.addVariable("library", e1.getAttachedProperty("Main_library"));
	} catch (Throwable _t) {
		_error.addVariable("library", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("m", e1.getParameter("m"));
	} catch (Throwable _t) {
		_error.addVariable("m", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}
if (e1.entityName.equals("sessionOpened") && e2.entityName.equals("memberSessionStarted") && linkProperty.container.modelName.equals("generated.Application.Main") && linkProperty.entityName.equals("searchControl")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Application::Main/Event/sessionOpened$eventChildLink,Forward,searchControl,MobileLibraryGUI::SearchWindowController,memberSessionStarted");
	try {
		_error.addVariable("library", e1.getAttachedProperty("Main_library"));
	} catch (Throwable _t) {
		_error.addVariable("library", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("m", e1.getParameter("m"));
	} catch (Throwable _t) {
		_error.addVariable("m", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("libraryBooksLoaded") && e2.entityName.equals("setCompleteBookCollection") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Application::Main/Event/libraryBooksLoaded$eventChildLink,Local,setCompleteBookCollection");
	try {
		_error.addVariable("libraryFileHandler", e1.getAttachedProperty("Main_libraryFileHandler"));
	} catch (Throwable _t) {
		_error.addVariable("libraryFileHandler", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("getSearchFrame", e1.getAttachedProperty("Main_getSearchFrame"));
	} catch (Throwable _t) {
		_error.addVariable("getSearchFrame", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("getLoginFrame", e1.getAttachedProperty("Main_getLoginFrame"));
	} catch (Throwable _t) {
		_error.addVariable("getLoginFrame", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("bookCollection", e1.getParameter("bookCollection"));
	} catch (Throwable _t) {
		_error.addVariable("bookCollection", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}
if (e1.entityName.equals("libraryBooksLoaded") && e2.entityName.equals("startViewsWindow") && linkProperty.container.modelName.equals("generated.Application.Main") && linkProperty.entityName.equals("viewsControl")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Application::Main/Event/libraryBooksLoaded$eventChildLink,Forward,viewsControl,MobileLibraryGUI::ViewsWindowController,startViewsWindow");
	try {
		_error.addVariable("libraryFileHandler", e1.getAttachedProperty("Main_libraryFileHandler"));
	} catch (Throwable _t) {
		_error.addVariable("libraryFileHandler", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("getSearchFrame", e1.getAttachedProperty("Main_getSearchFrame"));
	} catch (Throwable _t) {
		_error.addVariable("getSearchFrame", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("getLoginFrame", e1.getAttachedProperty("Main_getLoginFrame"));
	} catch (Throwable _t) {
		_error.addVariable("getLoginFrame", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("bookCollection", e1.getParameter("bookCollection"));
	} catch (Throwable _t) {
		_error.addVariable("bookCollection", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}
if (e1.entityName.equals("libraryBooksLoaded") && e2.entityName.equals("closeStartWindow") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Application::Main/Event/libraryBooksLoaded$eventChildLink,Local,closeStartWindow");
	try {
		_error.addVariable("libraryFileHandler", e1.getAttachedProperty("Main_libraryFileHandler"));
	} catch (Throwable _t) {
		_error.addVariable("libraryFileHandler", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("getSearchFrame", e1.getAttachedProperty("Main_getSearchFrame"));
	} catch (Throwable _t) {
		_error.addVariable("getSearchFrame", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("getLoginFrame", e1.getAttachedProperty("Main_getLoginFrame"));
	} catch (Throwable _t) {
		_error.addVariable("getLoginFrame", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("bookCollection", e1.getParameter("bookCollection"));
	} catch (Throwable _t) {
		_error.addVariable("bookCollection", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("loginConfirmed") && e2.entityName.equals("setToMemberMode") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Application::Main/Event/loginConfirmed$eventChildLink,Local,setToMemberMode");
	try {
		_error.addVariable("getMemberFrame", e1.getAttachedProperty("Main_getMemberFrame"));
	} catch (Throwable _t) {
		_error.addVariable("getMemberFrame", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}
if (e1.entityName.equals("loginConfirmed") && e2.entityName.equals("refreshMemberWindow") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Application::Main/Event/loginConfirmed$eventChildLink,Local,refreshMemberWindow");
	try {
		_error.addVariable("getMemberFrame", e1.getAttachedProperty("Main_getMemberFrame"));
	} catch (Throwable _t) {
		_error.addVariable("getMemberFrame", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}
if (e1.entityName.equals("loginConfirmed") && e2.entityName.equals("changeFromLoginToMember") && linkProperty.container.modelName.equals("generated.Application.Main") && linkProperty.entityName.equals("viewsControl")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Application::Main/Event/loginConfirmed$eventChildLink,Forward,viewsControl,MobileLibraryGUI::ViewsWindowController,changeFromLoginToMember");
	try {
		_error.addVariable("getMemberFrame", e1.getAttachedProperty("Main_getMemberFrame"));
	} catch (Throwable _t) {
		_error.addVariable("getMemberFrame", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("init") && e2.entityName.equals("loadLibrary") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|Application::Main/Event/init$eventChildLink,Local,loadLibrary");
	throw _error;
}
	}

		return true;

	}
	private java.lang.Object __memberViewMode_eval() {
		try {
	return "Login";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Application::Main/Property/memberViewMode");
	throw _error;
}

	}
	private java.lang.Object __getSearchFrame_eval() {
		try {
	return ((generated.GeneralGUI.Frame)((lu.uni.democles.runtime.Property)((generated.MobileLibraryGUI.SearchWindowController)((lu.uni.democles.runtime.Property)generated.Application.Main.this.getEntity("searchControl")).evalInContainer().getValues().iterator().next()).getEntity("frame")).evalInContainer().getValues().iterator().next());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Application::Main/Property/getSearchFrame");
	throw _error;
}

	}
	protected void doModify(lu.uni.democles.runtime.Event event) {
		if ("setToMemberMode".equals(event.entityName)) {
	handleImpact(event, this._p_memberViewMode);
}
if ("closeStartWindow".equals(event.entityName)) {
	handleImpact(event, this._p_startWindowControl);
}
if ("setCompleteBookCollection".equals(event.entityName)) {
	handleImpact(event, this._p_library);
}

	}
	private java.lang.Object __viewsControl_eval() {
		try {
	return (new generated.MobileLibraryGUI.ViewsWindowController());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Application::Main/Property/viewsControl");
	throw _error;
}

	}
	private java.lang.Object __searchControl_eval() {
		try {
	return (new generated.MobileLibraryGUI.SearchWindowController());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Application::Main/Property/searchControl");
	throw _error;
}

	}
	protected boolean guard(final lu.uni.democles.runtime.Event e1) {
		
		return true;

	}
	private java.lang.Object _setToMemberMode_memberViewMode_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return "Member";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|Application::Main/Event/setToMemberMode-impacts-Application::Main/Property/memberViewMode");
	throw _error;
}


	}
	protected void set(lu.uni.democles.runtime.Property p, java.lang.Object v) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) {
	throw new lu.uni.democles.runtime.MultipleModificationException(p.toString());
}
p.newVal = v;
		super.set(p, v);
	}
	private java.lang.Object __library_eval() {
		try {
	return (generated.Library.Library.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "catalogue", new lu.uni.democles.runtime.OCLSet(new Object[] {(generated.Library.Book.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "title", "Test", "isbn", "1234", "authors", new lu.uni.democles.runtime.OCLSet(new Object[] {(generated.Library.Author.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "name", "John Doe" }))))}) }))))}), "members", new lu.uni.democles.runtime.OCLSet(new Object[] {}) }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Application::Main/Property/library");
	throw _error;
}

	}
	private java.lang.Object __libraryFileHandler_eval() {
		try {
	return (new generated.LibraryPersistence.LibraryFiles());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Application::Main/Property/libraryFileHandler");
	throw _error;
}

	}
	protected java.lang.Object eval_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final java.lang.String paramName, final int _link) {
		if (e1.entityName.equals("openSession") && e2.entityName.equals("authenticateMember") && linkProperty == null && paramName.equals("libNo")) {
try {
	return ((java.lang.String)e1.getParameter("libNo"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|Application::Main/Event/openSession$eventChildLink,Local,authenticateMember$libNo");
	try {
		_error.addVariable("libNo", e1.getParameter("libNo"));
	} catch (Throwable _t) {
		_error.addVariable("libNo", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("password", e1.getParameter("password"));
	} catch (Throwable _t) {
		_error.addVariable("password", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}
if (e1.entityName.equals("openSession") && e2.entityName.equals("authenticateMember") && linkProperty == null && paramName.equals("pw")) {
try {
	return ((java.lang.String)e1.getParameter("password"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|Application::Main/Event/openSession$eventChildLink,Local,authenticateMember$pw");
	try {
		_error.addVariable("libNo", e1.getParameter("libNo"));
	} catch (Throwable _t) {
		_error.addVariable("libNo", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("password", e1.getParameter("password"));
	} catch (Throwable _t) {
		_error.addVariable("password", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		
		if (e1.entityName.equals("authenticateMember") && e2.entityName.equals("authenticateMember") && linkProperty.entityName.equals("library") && paramName.equals("libNo")) {
try {
	return ((java.lang.String)e1.getParameter("libNo"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|Application::Main/Event/authenticateMember$eventChildLink,Forward,library,Library::Library,authenticateMember$libNo");
	try {
		_error.addVariable("libNo", e1.getParameter("libNo"));
	} catch (Throwable _t) {
		_error.addVariable("libNo", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("pw", e1.getParameter("pw"));
	} catch (Throwable _t) {
		_error.addVariable("pw", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}
if (e1.entityName.equals("authenticateMember") && e2.entityName.equals("authenticateMember") && linkProperty.entityName.equals("library") && paramName.equals("pw")) {
try {
	return ((java.lang.String)e1.getParameter("pw"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|Application::Main/Event/authenticateMember$eventChildLink,Forward,library,Library::Library,authenticateMember$pw");
	try {
		_error.addVariable("libNo", e1.getParameter("libNo"));
	} catch (Throwable _t) {
		_error.addVariable("libNo", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("pw", e1.getParameter("pw"));
	} catch (Throwable _t) {
		_error.addVariable("pw", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("saveLibrary") && e2.entityName.equals("saveLibrary") && linkProperty.entityName.equals("libraryFileHandler") && paramName.equals("library")) {
try {
	return ((generated.Library.Library)e1.getAttachedProperty("Main_library"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|Application::Main/Event/saveLibrary$eventChildLink,Forward,libraryFileHandler,LibraryPersistence::LibraryFiles,saveLibrary$library");
	try {
		_error.addVariable("library", e1.getAttachedProperty("Main_library"));
	} catch (Throwable _t) {
		_error.addVariable("library", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("searchBook") && e2.entityName.equals("searchBook") && linkProperty.entityName.equals("library") && paramName.equals("term")) {
try {
	return ((java.lang.String)e1.getParameter("term"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|Application::Main/Event/searchBook$eventChildLink,Forward,library,Library::Library,searchBook$term");
	try {
		_error.addVariable("library", e1.getAttachedProperty("Main_library"));
	} catch (Throwable _t) {
		_error.addVariable("library", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("term", e1.getParameter("term"));
	} catch (Throwable _t) {
		_error.addVariable("term", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("category", e1.getParameter("category"));
	} catch (Throwable _t) {
		_error.addVariable("category", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}
if (e1.entityName.equals("searchBook") && e2.entityName.equals("searchBook") && linkProperty.entityName.equals("library") && paramName.equals("category")) {
try {
	return ((java.lang.String)e1.getParameter("category"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|Application::Main/Event/searchBook$eventChildLink,Forward,library,Library::Library,searchBook$category");
	try {
		_error.addVariable("library", e1.getAttachedProperty("Main_library"));
	} catch (Throwable _t) {
		_error.addVariable("library", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("term", e1.getParameter("term"));
	} catch (Throwable _t) {
		_error.addVariable("term", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("category", e1.getParameter("category"));
	} catch (Throwable _t) {
		_error.addVariable("category", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("searchFinished") && e2.entityName.equals("searchFinished") && linkProperty.entityName.equals("searchControl") && paramName.equals("booksFound")) {
try {
	return ((lu.uni.democles.runtime.OCLSet)e1.getParameter("booksFound"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|Application::Main/Event/searchFinished$eventChildLink,Forward,searchControl,MobileLibraryGUI::SearchWindowController,searchFinished$booksFound");
	try {
		_error.addVariable("booksFound", e1.getParameter("booksFound"));
	} catch (Throwable _t) {
		_error.addVariable("booksFound", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("sessionOpened") && e2.entityName.equals("sessionOpened") && linkProperty.entityName.equals("memberControl") && paramName.equals("m")) {
try {
	return ((generated.Library.Member)e1.getParameter("m"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|Application::Main/Event/sessionOpened$eventChildLink,Forward,memberControl,MobileLibraryGUI::MemberWindowController,sessionOpened$m");
	try {
		_error.addVariable("library", e1.getAttachedProperty("Main_library"));
	} catch (Throwable _t) {
		_error.addVariable("library", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("m", e1.getParameter("m"));
	} catch (Throwable _t) {
		_error.addVariable("m", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}
if (e1.entityName.equals("sessionOpened") && e2.entityName.equals("memberSessionStarted") && linkProperty.entityName.equals("searchControl") && paramName.equals("m")) {
try {
	return ((generated.Library.Member)e1.getParameter("m"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|Application::Main/Event/sessionOpened$eventChildLink,Forward,searchControl,MobileLibraryGUI::SearchWindowController,memberSessionStarted$m");
	try {
		_error.addVariable("library", e1.getAttachedProperty("Main_library"));
	} catch (Throwable _t) {
		_error.addVariable("library", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("m", e1.getParameter("m"));
	} catch (Throwable _t) {
		_error.addVariable("m", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("libraryBooksLoaded") && e2.entityName.equals("setCompleteBookCollection") && linkProperty == null && paramName.equals("completeBookCollection")) {
try {
	return ((generated.Library.Library)e1.getParameter("bookCollection"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|Application::Main/Event/libraryBooksLoaded$eventChildLink,Local,setCompleteBookCollection$completeBookCollection");
	try {
		_error.addVariable("libraryFileHandler", e1.getAttachedProperty("Main_libraryFileHandler"));
	} catch (Throwable _t) {
		_error.addVariable("libraryFileHandler", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("getSearchFrame", e1.getAttachedProperty("Main_getSearchFrame"));
	} catch (Throwable _t) {
		_error.addVariable("getSearchFrame", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("getLoginFrame", e1.getAttachedProperty("Main_getLoginFrame"));
	} catch (Throwable _t) {
		_error.addVariable("getLoginFrame", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("bookCollection", e1.getParameter("bookCollection"));
	} catch (Throwable _t) {
		_error.addVariable("bookCollection", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}
if (e1.entityName.equals("libraryBooksLoaded") && e2.entityName.equals("startViewsWindow") && linkProperty.entityName.equals("viewsControl") && paramName.equals("searchWindow")) {
try {
	return ((java.lang.Object)e1.getAttachedProperty("Main_getSearchFrame"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|Application::Main/Event/libraryBooksLoaded$eventChildLink,Forward,viewsControl,MobileLibraryGUI::ViewsWindowController,startViewsWindow$searchWindow");
	try {
		_error.addVariable("libraryFileHandler", e1.getAttachedProperty("Main_libraryFileHandler"));
	} catch (Throwable _t) {
		_error.addVariable("libraryFileHandler", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("getSearchFrame", e1.getAttachedProperty("Main_getSearchFrame"));
	} catch (Throwable _t) {
		_error.addVariable("getSearchFrame", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("getLoginFrame", e1.getAttachedProperty("Main_getLoginFrame"));
	} catch (Throwable _t) {
		_error.addVariable("getLoginFrame", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("bookCollection", e1.getParameter("bookCollection"));
	} catch (Throwable _t) {
		_error.addVariable("bookCollection", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}
if (e1.entityName.equals("libraryBooksLoaded") && e2.entityName.equals("startViewsWindow") && linkProperty.entityName.equals("viewsControl") && paramName.equals("loginWindow")) {
try {
	return ((java.lang.Object)e1.getAttachedProperty("Main_getLoginFrame"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|Application::Main/Event/libraryBooksLoaded$eventChildLink,Forward,viewsControl,MobileLibraryGUI::ViewsWindowController,startViewsWindow$loginWindow");
	try {
		_error.addVariable("libraryFileHandler", e1.getAttachedProperty("Main_libraryFileHandler"));
	} catch (Throwable _t) {
		_error.addVariable("libraryFileHandler", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("getSearchFrame", e1.getAttachedProperty("Main_getSearchFrame"));
	} catch (Throwable _t) {
		_error.addVariable("getSearchFrame", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("getLoginFrame", e1.getAttachedProperty("Main_getLoginFrame"));
	} catch (Throwable _t) {
		_error.addVariable("getLoginFrame", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("bookCollection", e1.getParameter("bookCollection"));
	} catch (Throwable _t) {
		_error.addVariable("bookCollection", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("loginConfirmed") && e2.entityName.equals("changeFromLoginToMember") && linkProperty.entityName.equals("viewsControl") && paramName.equals("memberFrame")) {
try {
	return ((java.lang.Object)e1.getAttachedProperty("Main_getMemberFrame"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|Application::Main/Event/loginConfirmed$eventChildLink,Forward,viewsControl,MobileLibraryGUI::ViewsWindowController,changeFromLoginToMember$memberFrame");
	try {
		_error.addVariable("getMemberFrame", e1.getAttachedProperty("Main_getMemberFrame"));
	} catch (Throwable _t) {
		_error.addVariable("getMemberFrame", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		return null;

	}
	private java.lang.Object __startWindowControl_eval() {
		try {
	return (new generated.MobileLibraryGUI.StartWindowController());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|Application::Main/Property/startWindowControl");
	throw _error;
}

	}
	public void initProps() {
		if (this.isInitialized()) return;

		this._p_startWindowControl.oldVal = this.initialValues.containsKey("startWindowControl") ? this.initialValues.get("startWindowControl") : eval_p(this._p_startWindowControl).getValues().iterator().next();
this._p_startWindowControl.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_startWindowControl, this._p_startWindowControl.oldVal);

		this._p_memberControl.oldVal = this.initialValues.containsKey("memberControl") ? this.initialValues.get("memberControl") : eval_p(this._p_memberControl).getValues().iterator().next();
this._p_memberControl.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_memberControl, this._p_memberControl.oldVal);

		this._p_searchControl.oldVal = this.initialValues.containsKey("searchControl") ? this.initialValues.get("searchControl") : eval_p(this._p_searchControl).getValues().iterator().next();
this._p_searchControl.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_searchControl, this._p_searchControl.oldVal);

		this._p_viewsControl.oldVal = this.initialValues.containsKey("viewsControl") ? this.initialValues.get("viewsControl") : eval_p(this._p_viewsControl).getValues().iterator().next();
this._p_viewsControl.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_viewsControl, this._p_viewsControl.oldVal);

		this._p_libraryFileHandler.oldVal = this.initialValues.containsKey("libraryFileHandler") ? this.initialValues.get("libraryFileHandler") : eval_p(this._p_libraryFileHandler).getValues().iterator().next();
this._p_libraryFileHandler.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_libraryFileHandler, this._p_libraryFileHandler.oldVal);

		this._p_library.oldVal = this.initialValues.containsKey("library") ? this.initialValues.get("library") : eval_p(this._p_library).getValues().iterator().next();
this._p_library.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_library, this._p_library.oldVal);

		this._p_memberViewMode.oldVal = this.initialValues.containsKey("memberViewMode") ? this.initialValues.get("memberViewMode") : eval_p(this._p_memberViewMode).getValues().iterator().next();
this._p_memberViewMode.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_memberViewMode, this._p_memberViewMode.oldVal);

		this._p_loginControl.oldVal = this.initialValues.containsKey("loginControl") ? this.initialValues.get("loginControl") : eval_p(this._p_loginControl).getValues().iterator().next();
this._p_loginControl.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_loginControl, this._p_loginControl.oldVal);

		this.setInitialized();
this.initialValues = new java.util.HashMap();


	}
	public Main() {
		super("generated.Application.Main", new java.lang.String[] {  });

	}
}
