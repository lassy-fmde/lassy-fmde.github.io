package generated.DateProcessing;

public class DateHandler extends lu.uni.democles.runtime.Instance {
	private lu.uni.democles.runtime.Property _p_calcAfterOneMonth = new lu.uni.democles.runtime.Property(this, "calcAfterOneMonth", "DateHandler", "Query", false, false, null, "single");
	public java.lang.String __pq_calcAfterOneMonth(final java.lang.String v_currDate) {
		try {
	return v_currDate;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|DateProcessing::DateHandler/Property/calcAfterOneMonth");
	_error.addVariable("currDate", v_currDate);
	throw _error;
}



	}
	protected void resetNewVal() {
		this._p_calcAfterOneMonth.newVal = lu.uni.democles.runtime.Entity.nullObject;
	}
	public static void main(String[] args) {
	}
	public DateHandler() {
		super("generated.DateProcessing.DateHandler", new java.lang.String[] {  });

	}
	public static DateHandler newWithValues(java.util.HashMap values) {
		DateHandler res = new DateHandler();
res.initialValues = new java.util.HashMap(values);
res.initProps();
return res;
	}
	protected void set(lu.uni.democles.runtime.Property p, java.lang.Object v) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) {
	throw new lu.uni.democles.runtime.MultipleModificationException(p.toString());
}
p.newVal = v;
		super.set(p, v);
	}
	public void initProps() {
		if (this.isInitialized()) return;

		this.setInitialized();
this.initialValues = new java.util.HashMap();


	}
}
