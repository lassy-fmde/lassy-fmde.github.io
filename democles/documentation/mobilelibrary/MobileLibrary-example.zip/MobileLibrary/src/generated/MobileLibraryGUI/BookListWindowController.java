package generated.MobileLibraryGUI;

public class BookListWindowController extends lu.uni.democles.runtime.Instance {
	private lu.uni.democles.runtime.Property _p_window = new lu.uni.democles.runtime.Property(this, "window", "BookListWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_mode = new lu.uni.democles.runtime.Property(this, "mode", "BookListWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_getAuthorsData = new lu.uni.democles.runtime.Property(this, "getAuthorsData", "BookListWindowController", "Query", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_bookListTable = new lu.uni.democles.runtime.Property(this, "bookListTable", "BookListWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_selectedBook = new lu.uni.democles.runtime.Event(this, "selectedBook", "BookListWindowController", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Property _p_detailsWindow = new lu.uni.democles.runtime.Property(this, "detailsWindow", "BookListWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_title = new lu.uni.democles.runtime.Property(this, "title", "BookListWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_refreshAndSave = new lu.uni.democles.runtime.Event(this, "refreshAndSave", "BookListWindowController", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.MobileLibraryGUI.BookDetailWindowController", "detailsWindow", "refreshAndSave", new java.lang.String[] {}) }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Property _p_currMember = new lu.uni.democles.runtime.Property(this, "currMember", "BookListWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_bookSelected = new lu.uni.democles.runtime.Event(this, "bookSelected", "BookListWindowController", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.GeneralGUI.SelectionList", "bookListTable", "itemSelected", new java.lang.String[] {"index"}) }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Property _p_getBookCopiesData = new lu.uni.democles.runtime.Property(this, "getBookCopiesData", "BookListWindowController", "Query", false, false, null, "sequence");
	private lu.uni.democles.runtime.Event _e_memberSessionStarted = new lu.uni.democles.runtime.Event(this, "memberSessionStarted", "BookListWindowController", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "detailsWindow", "generated.MobileLibraryGUI.BookDetailWindowController", "memberSessionStarted", new java.lang.String[] {"m"}) });
	public BookListWindowController() {
		super("generated.MobileLibraryGUI.BookListWindowController", new java.lang.String[] {  });

	}
	public static BookListWindowController newWithValues(java.util.HashMap values) {
		BookListWindowController res = new BookListWindowController();
res.initialValues = new java.util.HashMap(values);
res.initProps();
return res;
	}
	protected boolean guard_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse) {
		
		if (_event.entityName.equals("bookSelected") && _parent.entityName.equals("itemSelected") && _linkProperty.container.modelName.equals("generated.MobileLibraryGUI.BookListWindowController") && _linkProperty.entityName.equals("bookListTable") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::BookListWindowController/Event/bookSelected$eventParentLink,Forward,bookListTable,GeneralGUI::SelectionList,itemSelected");
	try {
		_error.addVariable("index", _parent.getParameter("index"));
	} catch (Throwable _t) {
		_error.addVariable("index", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("refreshAndSave") && _parent.entityName.equals("refreshAndSave") && _linkProperty.container.modelName.equals("generated.MobileLibraryGUI.BookListWindowController") && _linkProperty.entityName.equals("detailsWindow") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::BookListWindowController/Event/refreshAndSave$eventParentLink,Forward,detailsWindow,BookDetailWindowController,refreshAndSave");
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		return true;

	}
	private java.lang.Object __currMember_eval() {
		try {
	return null;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::BookListWindowController/Property/currMember");
	throw _error;
}

	}
	protected void attachProperties(lu.uni.democles.runtime.Event e) {
		// Set Attached Properties:


	}
	private java.lang.Object eval_ep(final lu.uni.democles.runtime.Event e, final lu.uni.democles.runtime.Property p) {
		if (p.entityName.equals(this._p_detailsWindow.entityName) && e.entityName.equals(this._e_selectedBook.entityName)) {
	return _selectedBook_detailsWindow_eval(e);
}
		if (p.entityName.equals(this._p_mode.entityName) && e.entityName.equals(this._e_memberSessionStarted.entityName)) {
	return _memberSessionStarted_mode_eval(e);
}
		if (p.entityName.equals(this._p_currMember.entityName) && e.entityName.equals(this._e_memberSessionStarted.entityName)) {
	return _memberSessionStarted_currMember_eval(e);
}
		return null;

	}
	public lu.uni.democles.runtime.OCLSequence __pq_getBookCopiesData(final generated.Library.Book v_book) {
		try {
	return (((lu.uni.democles.runtime.OCLBag)((lu.uni.democles.runtime.OCLSet)((lu.uni.democles.runtime.Property)v_book.getEntity("copies")).evalInContainer()).collect(new lu.uni.democles.runtime.Function() {
	public Object _iteration(Object _value) {
final generated.Library.Copy v_temp1 = ((generated.Library.Copy)_value);
return _asObject(((((((java.lang.String)((lu.uni.democles.runtime.Property)v_temp1.getEntity("copyId")).evalInContainer().getValues().iterator().next()) + " ") + ((java.lang.String)((lu.uni.democles.runtime.Property)v_temp1.getEntity("state")).evalInContainer().getValues().iterator().next())) + " ") + ((java.lang.String)((lu.uni.democles.runtime.Property)v_temp1.getEntity("dueDate")).evalInContainer().getValues().iterator().next())));
	}
})).asSequence());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::BookListWindowController/Property/getBookCopiesData");
	_error.addVariable("book", v_book);
	throw _error;
}



	}
	protected java.lang.Object evalQuery(lu.uni.democles.runtime.Property p) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) return p.newVal;

if (p.isEvaluating()) throw new lu.uni.democles.runtime.ModificationCycleException();

p.setEvaluating(true);
java.lang.Object o = null;


		if ("detailsWindow".equals(p.entityName)) {
	o = __detailsWindow_eval();
	set(p, o);
}

		if ("title".equals(p.entityName)) {
	o = __title_eval();
	set(p, o);
}

		if ("mode".equals(p.entityName)) {
	o = __mode_eval();
	set(p, o);
}

		if ("currMember".equals(p.entityName)) {
	o = __currMember_eval();
	set(p, o);
}

		if ("window".equals(p.entityName)) {
	o = __window_eval();
	set(p, o);
}

		if ("bookListTable".equals(p.entityName)) {
	o = __bookListTable_eval();
	set(p, o);
}

		if (o instanceof lu.uni.democles.runtime.Instance) {
	((lu.uni.democles.runtime.Instance)o).initProps();
} else if (o instanceof lu.uni.democles.runtime.OCLCollection) {
	for (java.util.Iterator iter = ((lu.uni.democles.runtime.OCLCollection)o).getValues().iterator(); iter.hasNext();) {
		java.lang.Object entry = iter.next();
		if (entry instanceof lu.uni.democles.runtime.Instance) {
			((lu.uni.democles.runtime.Instance)entry).initProps();
		}
	}
}
p.setEvaluating(false);
return o;


	}
	public static void main(String[] args) {
	}
	protected java.lang.Object eval_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse, final java.lang.String _paramName) {
		
		if (_parent.entityName.equals("itemSelected") && _event.entityName.equals("bookSelected") && _linkProperty.entityName.equals("bookListTable") && _inverse == false && _paramName.equals("index")) {
try {
	return new java.lang.Integer(((int)((java.lang.Integer)_parent.getParameter("index")).intValue()));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|MobileLibraryGUI::BookListWindowController/Event/bookSelected$eventParentLink,Forward,bookListTable,GeneralGUI::SelectionList,itemSelected$index");
	try {
		_error.addVariable("index", _parent.getParameter("index"));
	} catch (Throwable _t) {
		_error.addVariable("index", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		return null;

	}
	public java.lang.String __pq_getAuthorsData(final generated.Library.Book v_book) {
		try {
	return ((java.lang.String)((lu.uni.democles.runtime.OCLSet)((lu.uni.democles.runtime.Property)v_book.getEntity("authors")).evalInContainer()).iterate(new lu.uni.democles.runtime.Function() {
	public Object _iterate(Object _value, Object _acc) {
final java.lang.String v_authorStr = ((java.lang.String)_acc);
final generated.Library.Author v_a = ((generated.Library.Author)_value);
return _asObject(((v_authorStr + ((java.lang.String)((lu.uni.democles.runtime.Property)v_a.getEntity("name")).evalInContainer().getValues().iterator().next())) + ", "));
	}
}, ""));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::BookListWindowController/Property/getAuthorsData");
	_error.addVariable("book", v_book);
	throw _error;
}



	}
	protected void resetNewVal() {
		this._p_detailsWindow.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_getAuthorsData.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_title.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_mode.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_getBookCopiesData.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_currMember.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_window.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_bookListTable.newVal = lu.uni.democles.runtime.Entity.nullObject;
	}
	private void handleImpact(lu.uni.democles.runtime.Event e, lu.uni.democles.runtime.Property p) {
		set(p, eval_ep(e, p));
	}
	private java.lang.Object _memberSessionStarted_currMember_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return ((generated.Library.Member)_event.getParameter("m"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|MobileLibraryGUI::BookListWindowController/Event/memberSessionStarted-impacts-MobileLibraryGUI::BookListWindowController/Property/currMember");
	try {
		_error.addVariable("m", _event.getParameter("m"));
	} catch (Throwable _t) {
		_error.addVariable("m", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	private java.lang.Object __title_eval() {
		try {
	return "Results";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::BookListWindowController/Property/title");
	throw _error;
}

	}
	protected boolean guard_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final lu.uni.democles.runtime.Instance linkedInstance, final int _link) {
		if (e1.entityName.equals("memberSessionStarted") && e2.entityName.equals("memberSessionStarted") && linkProperty.container.modelName.equals("generated.MobileLibraryGUI.BookListWindowController") && linkProperty.entityName.equals("detailsWindow")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::BookListWindowController/Event/memberSessionStarted$eventChildLink,Forward,detailsWindow,BookDetailWindowController,memberSessionStarted");
	try {
		_error.addVariable("m", e1.getParameter("m"));
	} catch (Throwable _t) {
		_error.addVariable("m", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		
		return true;

	}
	private java.lang.Object __bookListTable_eval() {
		try {
	return null;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::BookListWindowController/Property/bookListTable");
	throw _error;
}

	}
	private java.lang.Object _selectedBook_detailsWindow_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return (generated.MobileLibraryGUI.BookDetailWindowController.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "bookTitleLabel", (generated.GeneralGUI.Label.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "text", ((java.lang.String)((lu.uni.democles.runtime.Property)((generated.Library.Book)_event.getParameter("book")).getEntity("title")).evalInContainer().getValues().iterator().next()) })))), "bookAuthorLabel", (generated.GeneralGUI.Label.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "text", (((java.lang.String)generated.MobileLibraryGUI.BookListWindowController.this.evalQueryWithParameters("getAuthorsData", new Object[] { ((generated.Library.Book)_event.getParameter("book")) }))) })))), "bookIsbnLabel", (generated.GeneralGUI.Label.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "text", ((java.lang.String)((lu.uni.democles.runtime.Property)((generated.Library.Book)_event.getParameter("book")).getEntity("isbn")).evalInContainer().getValues().iterator().next()) })))), "bookCopies", (generated.GeneralGUI.SelectionList.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "items", (((lu.uni.democles.runtime.OCLSequence)generated.MobileLibraryGUI.BookListWindowController.this.evalQueryWithParameters("getBookCopiesData", new Object[] { ((generated.Library.Book)_event.getParameter("book")) }))) })))), "currBook", ((generated.Library.Book)_event.getParameter("book")), "currMember", ((generated.Library.Member)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.BookListWindowController.this.getEntity("currMember")).evalInContainer().getValues().iterator().next()), "mode", ((java.lang.String)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.BookListWindowController.this.getEntity("mode")).evalInContainer().getValues().iterator().next()) }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|MobileLibraryGUI::BookListWindowController/Event/selectedBook-impacts-MobileLibraryGUI::BookListWindowController/Property/detailsWindow");
	try {
		_error.addVariable("book", _event.getParameter("book"));
	} catch (Throwable _t) {
		_error.addVariable("book", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	protected void doModify(lu.uni.democles.runtime.Event event) {
		if ("memberSessionStarted".equals(event.entityName)) {
	handleImpact(event, this._p_currMember);
}
if ("memberSessionStarted".equals(event.entityName)) {
	handleImpact(event, this._p_mode);
}
if ("selectedBook".equals(event.entityName)) {
	handleImpact(event, this._p_detailsWindow);
}

	}
	private java.lang.Object _memberSessionStarted_mode_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return "LoggedIn";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|MobileLibraryGUI::BookListWindowController/Event/memberSessionStarted-impacts-MobileLibraryGUI::BookListWindowController/Property/mode");
	try {
		_error.addVariable("m", _event.getParameter("m"));
	} catch (Throwable _t) {
		_error.addVariable("m", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	private java.lang.Object __mode_eval() {
		try {
	return "NotLoggedIn";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::BookListWindowController/Property/mode");
	throw _error;
}

	}
	protected boolean guard(final lu.uni.democles.runtime.Event e1) {
		
		return true;

	}
	protected void set(lu.uni.democles.runtime.Property p, java.lang.Object v) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) {
	throw new lu.uni.democles.runtime.MultipleModificationException(p.toString());
}
p.newVal = v;
		super.set(p, v);
	}
	private java.lang.Object __detailsWindow_eval() {
		try {
	return null;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::BookListWindowController/Property/detailsWindow");
	throw _error;
}

	}
	protected java.lang.Object eval_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final java.lang.String paramName, final int _link) {
		if (e1.entityName.equals("memberSessionStarted") && e2.entityName.equals("memberSessionStarted") && linkProperty.entityName.equals("detailsWindow") && paramName.equals("m")) {
try {
	return ((generated.Library.Member)e1.getParameter("m"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|MobileLibraryGUI::BookListWindowController/Event/memberSessionStarted$eventChildLink,Forward,detailsWindow,BookDetailWindowController,memberSessionStarted$m");
	try {
		_error.addVariable("m", e1.getParameter("m"));
	} catch (Throwable _t) {
		_error.addVariable("m", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		
		return null;

	}
	private java.lang.Object __window_eval() {
		try {
	return (generated.GeneralGUI.Window.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "seqGUIElements", new lu.uni.democles.runtime.OCLSequence(new Object[] {((generated.GeneralGUI.SelectionList)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.BookListWindowController.this.getEntity("bookListTable")).evalInContainer().getValues().iterator().next())}), "title", ((java.lang.String)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.BookListWindowController.this.getEntity("title")).evalInContainer().getValues().iterator().next()) }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::BookListWindowController/Property/window");
	throw _error;
}

	}
	public void initProps() {
		if (this.isInitialized()) return;

		this._p_detailsWindow.oldVal = this.initialValues.containsKey("detailsWindow") ? this.initialValues.get("detailsWindow") : eval_p(this._p_detailsWindow).getValues().iterator().next();
this._p_detailsWindow.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_detailsWindow, this._p_detailsWindow.oldVal);

		this._p_title.oldVal = this.initialValues.containsKey("title") ? this.initialValues.get("title") : eval_p(this._p_title).getValues().iterator().next();
this._p_title.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_title, this._p_title.oldVal);

		this._p_mode.oldVal = this.initialValues.containsKey("mode") ? this.initialValues.get("mode") : eval_p(this._p_mode).getValues().iterator().next();
this._p_mode.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_mode, this._p_mode.oldVal);

		this._p_currMember.oldVal = this.initialValues.containsKey("currMember") ? this.initialValues.get("currMember") : eval_p(this._p_currMember).getValues().iterator().next();
this._p_currMember.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_currMember, this._p_currMember.oldVal);

		this._p_window.oldVal = this.initialValues.containsKey("window") ? this.initialValues.get("window") : eval_p(this._p_window).getValues().iterator().next();
this._p_window.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_window, this._p_window.oldVal);

		this._p_bookListTable.oldVal = this.initialValues.containsKey("bookListTable") ? this.initialValues.get("bookListTable") : eval_p(this._p_bookListTable).getValues().iterator().next();
this._p_bookListTable.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_bookListTable, this._p_bookListTable.oldVal);

		this.setInitialized();
this.initialValues = new java.util.HashMap();


	}
}
