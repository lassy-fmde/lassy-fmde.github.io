package generated.MobileLibraryGUI;

public class StartWindowController extends lu.uni.democles.runtime.Instance {
	private lu.uni.democles.runtime.Property _p_window = new lu.uni.democles.runtime.Property(this, "window", "StartWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_closeWIndow = new lu.uni.democles.runtime.Event(this, "closeWIndow", "StartWindowController", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "window", "generated.GeneralGUI.Window", "closeWindow", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Property _p_titleLabel = new lu.uni.democles.runtime.Property(this, "titleLabel", "StartWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_title = new lu.uni.democles.runtime.Property(this, "title", "StartWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_uniLogo = new lu.uni.democles.runtime.Property(this, "uniLogo", "StartWindowController", "Local", false, false, null, "single");
	protected java.lang.Object eval_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse, final java.lang.String _paramName) {
		
		return null;

	}
	protected boolean guard_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final lu.uni.democles.runtime.Instance linkedInstance, final int _link) {
		if (e1.entityName.equals("closeWIndow") && e2.entityName.equals("closeWindow") && linkProperty.container.modelName.equals("generated.MobileLibraryGUI.StartWindowController") && linkProperty.entityName.equals("window")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::StartWindowController/Event/closeWIndow$eventChildLink,Forward,window,GeneralGUI::Window,closeWindow");
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		return true;

	}
	private java.lang.Object __titleLabel_eval() {
		try {
	return (generated.GeneralGUI.Label.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "text", "        Starting the Mobile Library" }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::StartWindowController/Property/titleLabel");
	throw _error;
}

	}
	protected void attachProperties(lu.uni.democles.runtime.Event e) {
		// Set Attached Properties:


	}
	private java.lang.Object __uniLogo_eval() {
		try {
	return (generated.GeneralGUI.Image.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "imageFilename", "icon-Uni_lu.png" }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::StartWindowController/Property/uniLogo");
	throw _error;
}

	}
	public void initProps() {
		if (this.isInitialized()) return;

		this._p_title.oldVal = this.initialValues.containsKey("title") ? this.initialValues.get("title") : eval_p(this._p_title).getValues().iterator().next();
this._p_title.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_title, this._p_title.oldVal);

		this._p_titleLabel.oldVal = this.initialValues.containsKey("titleLabel") ? this.initialValues.get("titleLabel") : eval_p(this._p_titleLabel).getValues().iterator().next();
this._p_titleLabel.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_titleLabel, this._p_titleLabel.oldVal);

		this._p_uniLogo.oldVal = this.initialValues.containsKey("uniLogo") ? this.initialValues.get("uniLogo") : eval_p(this._p_uniLogo).getValues().iterator().next();
this._p_uniLogo.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_uniLogo, this._p_uniLogo.oldVal);

		this._p_window.oldVal = this.initialValues.containsKey("window") ? this.initialValues.get("window") : eval_p(this._p_window).getValues().iterator().next();
this._p_window.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_window, this._p_window.oldVal);

		this.setInitialized();
this.initialValues = new java.util.HashMap();


	}
	protected boolean guard_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse) {
		
		return true;

	}
	protected boolean guard(final lu.uni.democles.runtime.Event e1) {
		
		return true;

	}
	public StartWindowController() {
		super("generated.MobileLibraryGUI.StartWindowController", new java.lang.String[] {  });

	}
	protected void set(lu.uni.democles.runtime.Property p, java.lang.Object v) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) {
	throw new lu.uni.democles.runtime.MultipleModificationException(p.toString());
}
p.newVal = v;
		super.set(p, v);
	}
	protected java.lang.Object evalQuery(lu.uni.democles.runtime.Property p) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) return p.newVal;

if (p.isEvaluating()) throw new lu.uni.democles.runtime.ModificationCycleException();

p.setEvaluating(true);
java.lang.Object o = null;


		if ("title".equals(p.entityName)) {
	o = __title_eval();
	set(p, o);
}

		if ("titleLabel".equals(p.entityName)) {
	o = __titleLabel_eval();
	set(p, o);
}

		if ("uniLogo".equals(p.entityName)) {
	o = __uniLogo_eval();
	set(p, o);
}

		if ("window".equals(p.entityName)) {
	o = __window_eval();
	set(p, o);
}

		if (o instanceof lu.uni.democles.runtime.Instance) {
	((lu.uni.democles.runtime.Instance)o).initProps();
} else if (o instanceof lu.uni.democles.runtime.OCLCollection) {
	for (java.util.Iterator iter = ((lu.uni.democles.runtime.OCLCollection)o).getValues().iterator(); iter.hasNext();) {
		java.lang.Object entry = iter.next();
		if (entry instanceof lu.uni.democles.runtime.Instance) {
			((lu.uni.democles.runtime.Instance)entry).initProps();
		}
	}
}
p.setEvaluating(false);
return o;


	}
	private java.lang.Object __window_eval() {
		try {
	return (generated.GeneralGUI.Window.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "seqGUIElements", new lu.uni.democles.runtime.OCLSequence(new Object[] {((generated.GeneralGUI.Label)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.StartWindowController.this.getEntity("titleLabel")).evalInContainer().getValues().iterator().next()), ((generated.GeneralGUI.Image)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.StartWindowController.this.getEntity("uniLogo")).evalInContainer().getValues().iterator().next())}), "title", ((java.lang.String)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.StartWindowController.this.getEntity("title")).evalInContainer().getValues().iterator().next()) }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::StartWindowController/Property/window");
	throw _error;
}

	}
	protected java.lang.Object eval_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final java.lang.String paramName, final int _link) {
		
		return null;

	}
	private java.lang.Object __title_eval() {
		try {
	return "Starting...";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::StartWindowController/Property/title");
	throw _error;
}

	}
	protected void resetNewVal() {
		this._p_title.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_titleLabel.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_uniLogo.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_window.newVal = lu.uni.democles.runtime.Entity.nullObject;
	}
	public static void main(String[] args) {
	}
	public static StartWindowController newWithValues(java.util.HashMap values) {
		StartWindowController res = new StartWindowController();
res.initialValues = new java.util.HashMap(values);
res.initProps();
return res;
	}
}
