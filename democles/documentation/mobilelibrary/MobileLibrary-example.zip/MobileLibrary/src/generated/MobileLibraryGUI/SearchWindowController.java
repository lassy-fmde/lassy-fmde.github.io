package generated.MobileLibraryGUI;

public class SearchWindowController extends lu.uni.democles.runtime.Instance {
	private lu.uni.democles.runtime.Event _e_memberSessionStarted = new lu.uni.democles.runtime.Event(this, "memberSessionStarted", "SearchWindowController", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "resultWindow", "generated.MobileLibraryGUI.BookListWindowController", "memberSessionStarted", new java.lang.String[] {"m"}) });
	private lu.uni.democles.runtime.Property _p_searchField = new lu.uni.democles.runtime.Property(this, "searchField", "SearchWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_selectedBook = new lu.uni.democles.runtime.Event(this, "selectedBook", "SearchWindowController", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "resultWindow", "generated.MobileLibraryGUI.BookListWindowController", "selectedBook", new java.lang.String[] {"book"}) });
	private lu.uni.democles.runtime.Event _e_bookSelected = new lu.uni.democles.runtime.Event(this, "bookSelected", "SearchWindowController", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.MobileLibraryGUI.BookListWindowController", "resultWindow", "bookSelected", new java.lang.String[] {"index"}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.MobileLibraryGUI.SearchWindowController", "selectedBook", new java.lang.String[] {"book"}) });
	private lu.uni.democles.runtime.Property _p_mode = new lu.uni.democles.runtime.Property(this, "mode", "SearchWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_searchBook = new lu.uni.democles.runtime.Event(this, "searchBook", "SearchWindowController", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Property _p_currMember = new lu.uni.democles.runtime.Property(this, "currMember", "SearchWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_frame = new lu.uni.democles.runtime.Property(this, "frame", "SearchWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_booksFound = new lu.uni.democles.runtime.Property(this, "booksFound", "SearchWindowController", "Local", false, false, null, "sequence");
	private lu.uni.democles.runtime.Property _p_searchLabel = new lu.uni.democles.runtime.Property(this, "searchLabel", "SearchWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_getBooksFoundData = new lu.uni.democles.runtime.Property(this, "getBooksFoundData", "SearchWindowController", "Query", false, false, null, "sequence");
	private lu.uni.democles.runtime.Event _e_searchFinished = new lu.uni.democles.runtime.Event(this, "searchFinished", "SearchWindowController", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Property _p_resultWindow = new lu.uni.democles.runtime.Property(this, "resultWindow", "SearchWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_categorySelect = new lu.uni.democles.runtime.Property(this, "categorySelect", "SearchWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_title = new lu.uni.democles.runtime.Property(this, "title", "SearchWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_refreshAndSave = new lu.uni.democles.runtime.Event(this, "refreshAndSave", "SearchWindowController", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.MobileLibraryGUI.BookListWindowController", "resultWindow", "refreshAndSave", new java.lang.String[] {}) }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Property _p_searchButton = new lu.uni.democles.runtime.Property(this, "searchButton", "SearchWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_searchButtonClicked = new lu.uni.democles.runtime.Event(this, "searchButtonClicked", "SearchWindowController", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.GeneralGUI.Button", "searchButton", "clicked", new java.lang.String[] {}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.MobileLibraryGUI.SearchWindowController", "searchBook", new java.lang.String[] {"term", "category"}) });
	protected boolean guard_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse) {
		
		if (_event.entityName.equals("refreshAndSave") && _parent.entityName.equals("refreshAndSave") && _linkProperty.container.modelName.equals("generated.MobileLibraryGUI.SearchWindowController") && _linkProperty.entityName.equals("resultWindow") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::SearchWindowController/Event/refreshAndSave$eventParentLink,Forward,resultWindow,BookListWindowController,refreshAndSave");
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("searchButtonClicked") && _parent.entityName.equals("clicked") && _linkProperty.container.modelName.equals("generated.MobileLibraryGUI.SearchWindowController") && _linkProperty.entityName.equals("searchButton") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::SearchWindowController/Event/searchButtonClicked$eventParentLink,Forward,searchButton,GeneralGUI::Button,clicked");
	try {
		_error.addVariable("categorySelect", _parent.getAttachedProperty("SearchWindowController_categorySelect"));
	} catch (Throwable _t) {
		_error.addVariable("categorySelect", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("searchField", _parent.getAttachedProperty("SearchWindowController_searchField"));
	} catch (Throwable _t) {
		_error.addVariable("searchField", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("bookSelected") && _parent.entityName.equals("bookSelected") && _linkProperty.container.modelName.equals("generated.MobileLibraryGUI.SearchWindowController") && _linkProperty.entityName.equals("resultWindow") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::SearchWindowController/Event/bookSelected$eventParentLink,Forward,resultWindow,BookListWindowController,bookSelected");
	try {
		_error.addVariable("booksFound", _parent.getAttachedProperty("SearchWindowController_booksFound"));
	} catch (Throwable _t) {
		_error.addVariable("booksFound", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("index", _parent.getParameter("index"));
	} catch (Throwable _t) {
		_error.addVariable("index", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		return true;

	}
	private java.lang.Object __currMember_eval() {
		try {
	return null;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::SearchWindowController/Property/currMember");
	throw _error;
}

	}
	private java.lang.Object _searchFinished_booksFound_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return (((lu.uni.democles.runtime.OCLSet)_event.getParameter("booksFound")).asSequence());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|MobileLibraryGUI::SearchWindowController/Event/searchFinished-impacts-MobileLibraryGUI::SearchWindowController/Property/booksFound");
	try {
		_error.addVariable("booksFound", _event.getParameter("booksFound"));
	} catch (Throwable _t) {
		_error.addVariable("booksFound", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	protected void attachProperties(lu.uni.democles.runtime.Event e) {
		// Set Attached Properties:


		// Set Attached Properties:
if ("searchButtonClicked".equals(e.entityName)) {
	e.attachProperty("SearchWindowController_categorySelect", this._p_categorySelect.evalInContainer().getValues().iterator().next());
	e.attachProperty("SearchWindowController_searchField", this._p_searchField.evalInContainer().getValues().iterator().next());
}


		// Set Attached Properties:
if ("bookSelected".equals(e.entityName)) {
	e.attachProperty("SearchWindowController_booksFound", this._p_booksFound.evalInContainer());
}


	}
	private java.lang.Object eval_ep(final lu.uni.democles.runtime.Event e, final lu.uni.democles.runtime.Property p) {
		if (p.entityName.equals(this._p_booksFound.entityName) && e.entityName.equals(this._e_searchFinished.entityName)) {
	return _searchFinished_booksFound_eval(e);
}
		if (p.entityName.equals(this._p_currMember.entityName) && e.entityName.equals(this._e_memberSessionStarted.entityName)) {
	return _memberSessionStarted_currMember_eval(e);
}
		if (p.entityName.equals(this._p_mode.entityName) && e.entityName.equals(this._e_memberSessionStarted.entityName)) {
	return _memberSessionStarted_mode_eval(e);
}
		if (p.entityName.equals(this._p_resultWindow.entityName) && e.entityName.equals(this._e_searchFinished.entityName)) {
	return _searchFinished_resultWindow_eval(e);
}
		return null;

	}
	private java.lang.Object __resultWindow_eval() {
		try {
	return null;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::SearchWindowController/Property/resultWindow");
	throw _error;
}

	}
	protected java.lang.Object evalQuery(lu.uni.democles.runtime.Property p) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) return p.newVal;

if (p.isEvaluating()) throw new lu.uni.democles.runtime.ModificationCycleException();

p.setEvaluating(true);
java.lang.Object o = null;


		if ("booksFound".equals(p.entityName)) {
	o = __booksFound_eval();
	set(p, o);
}

		if ("frame".equals(p.entityName)) {
	o = __frame_eval();
	set(p, o);
}

		if ("searchButton".equals(p.entityName)) {
	o = __searchButton_eval();
	set(p, o);
}

		if ("currMember".equals(p.entityName)) {
	o = __currMember_eval();
	set(p, o);
}

		if ("categorySelect".equals(p.entityName)) {
	o = __categorySelect_eval();
	set(p, o);
}

		if ("searchLabel".equals(p.entityName)) {
	o = __searchLabel_eval();
	set(p, o);
}

		if ("resultWindow".equals(p.entityName)) {
	o = __resultWindow_eval();
	set(p, o);
}

		if ("searchField".equals(p.entityName)) {
	o = __searchField_eval();
	set(p, o);
}

		if ("mode".equals(p.entityName)) {
	o = __mode_eval();
	set(p, o);
}

		if ("title".equals(p.entityName)) {
	o = __title_eval();
	set(p, o);
}

		if (o instanceof lu.uni.democles.runtime.Instance) {
	((lu.uni.democles.runtime.Instance)o).initProps();
} else if (o instanceof lu.uni.democles.runtime.OCLCollection) {
	for (java.util.Iterator iter = ((lu.uni.democles.runtime.OCLCollection)o).getValues().iterator(); iter.hasNext();) {
		java.lang.Object entry = iter.next();
		if (entry instanceof lu.uni.democles.runtime.Instance) {
			((lu.uni.democles.runtime.Instance)entry).initProps();
		}
	}
}
p.setEvaluating(false);
return o;


	}
	public static void main(String[] args) {
	}
	private java.lang.Object __categorySelect_eval() {
		try {
	return (generated.GeneralGUI.SelectionBox.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "choices", new lu.uni.democles.runtime.OCLSequence(new Object[] {"Author", "Title", "ISBN"}) }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::SearchWindowController/Property/categorySelect");
	throw _error;
}

	}
	protected java.lang.Object eval_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse, final java.lang.String _paramName) {
		
		if (_parent.entityName.equals("bookSelected") && _event.entityName.equals("bookSelected") && _linkProperty.entityName.equals("resultWindow") && _inverse == false && _paramName.equals("index")) {
try {
	return new java.lang.Integer(((int)((java.lang.Integer)_parent.getParameter("index")).intValue()));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|MobileLibraryGUI::SearchWindowController/Event/bookSelected$eventParentLink,Forward,resultWindow,BookListWindowController,bookSelected$index");
	try {
		_error.addVariable("index", _parent.getParameter("index"));
	} catch (Throwable _t) {
		_error.addVariable("index", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		return null;

	}
	protected void resetNewVal() {
		this._p_booksFound.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_frame.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_searchButton.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_currMember.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_categorySelect.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_searchLabel.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_resultWindow.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_searchField.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_mode.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_title.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_getBooksFoundData.newVal = lu.uni.democles.runtime.Entity.nullObject;
	}
	private void handleImpact(lu.uni.democles.runtime.Event e, lu.uni.democles.runtime.Property p) {
		set(p, eval_ep(e, p));
	}
	private java.lang.Object _memberSessionStarted_currMember_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return ((generated.Library.Member)_event.getParameter("m"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|MobileLibraryGUI::SearchWindowController/Event/memberSessionStarted-impacts-MobileLibraryGUI::SearchWindowController/Property/currMember");
	try {
		_error.addVariable("m", _event.getParameter("m"));
	} catch (Throwable _t) {
		_error.addVariable("m", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	private java.lang.Object __title_eval() {
		try {
	return "Search";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::SearchWindowController/Property/title");
	throw _error;
}

	}
	protected boolean guard_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final lu.uni.democles.runtime.Instance linkedInstance, final int _link) {
		if (e1.entityName.equals("memberSessionStarted") && e2.entityName.equals("memberSessionStarted") && linkProperty.container.modelName.equals("generated.MobileLibraryGUI.SearchWindowController") && linkProperty.entityName.equals("resultWindow")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::SearchWindowController/Event/memberSessionStarted$eventChildLink,Forward,resultWindow,BookListWindowController,memberSessionStarted");
	try {
		_error.addVariable("m", e1.getParameter("m"));
	} catch (Throwable _t) {
		_error.addVariable("m", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		
		if (e1.entityName.equals("selectedBook") && e2.entityName.equals("selectedBook") && linkProperty.container.modelName.equals("generated.MobileLibraryGUI.SearchWindowController") && linkProperty.entityName.equals("resultWindow")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::SearchWindowController/Event/selectedBook$eventChildLink,Forward,resultWindow,BookListWindowController,selectedBook");
	try {
		_error.addVariable("book", e1.getParameter("book"));
	} catch (Throwable _t) {
		_error.addVariable("book", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("searchButtonClicked") && e2.entityName.equals("searchBook") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::SearchWindowController/Event/searchButtonClicked$eventChildLink,Local,searchBook");
	try {
		_error.addVariable("categorySelect", e1.getAttachedProperty("SearchWindowController_categorySelect"));
	} catch (Throwable _t) {
		_error.addVariable("categorySelect", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("searchField", e1.getAttachedProperty("SearchWindowController_searchField"));
	} catch (Throwable _t) {
		_error.addVariable("searchField", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("bookSelected") && e2.entityName.equals("selectedBook") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::SearchWindowController/Event/bookSelected$eventChildLink,Local,selectedBook");
	try {
		_error.addVariable("booksFound", e1.getAttachedProperty("SearchWindowController_booksFound"));
	} catch (Throwable _t) {
		_error.addVariable("booksFound", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("index", e1.getParameter("index"));
	} catch (Throwable _t) {
		_error.addVariable("index", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		return true;

	}
	protected void doModify(lu.uni.democles.runtime.Event event) {
		if ("searchFinished".equals(event.entityName)) {
	handleImpact(event, this._p_resultWindow);
}
if ("memberSessionStarted".equals(event.entityName)) {
	handleImpact(event, this._p_mode);
}
if ("memberSessionStarted".equals(event.entityName)) {
	handleImpact(event, this._p_currMember);
}
if ("searchFinished".equals(event.entityName)) {
	handleImpact(event, this._p_booksFound);
}

	}
	private java.lang.Object _memberSessionStarted_mode_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return "LoggedIn";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|MobileLibraryGUI::SearchWindowController/Event/memberSessionStarted-impacts-MobileLibraryGUI::SearchWindowController/Property/mode");
	try {
		_error.addVariable("m", _event.getParameter("m"));
	} catch (Throwable _t) {
		_error.addVariable("m", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	public static SearchWindowController newWithValues(java.util.HashMap values) {
		SearchWindowController res = new SearchWindowController();
res.initialValues = new java.util.HashMap(values);
res.initProps();
return res;
	}
	private java.lang.Object __booksFound_eval() {
		try {
	return new lu.uni.democles.runtime.OCLSequence(new Object[] {});

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::SearchWindowController/Property/booksFound");
	throw _error;
}

	}
	private java.lang.Object __mode_eval() {
		try {
	return "NotLoggedIn";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::SearchWindowController/Property/mode");
	throw _error;
}

	}
	protected boolean guard(final lu.uni.democles.runtime.Event e1) {
		
		return true;

	}
	protected void set(lu.uni.democles.runtime.Property p, java.lang.Object v) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) {
	throw new lu.uni.democles.runtime.MultipleModificationException(p.toString());
}
p.newVal = v;
		super.set(p, v);
	}
	public lu.uni.democles.runtime.OCLSequence __pq_getBooksFoundData(final lu.uni.democles.runtime.OCLSet v_books) {
		try {
	return (((lu.uni.democles.runtime.OCLSequence)(v_books.asSequence()).collect(new lu.uni.democles.runtime.Function() {
	public Object _iteration(Object _value) {
final generated.Library.Book v_b = ((generated.Library.Book)_value);
return _asObject(((java.lang.String)((lu.uni.democles.runtime.Property)v_b.getEntity("title")).evalInContainer().getValues().iterator().next()));
	}
})));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::SearchWindowController/Property/getBooksFoundData");
	_error.addVariable("books", v_books);
	throw _error;
}



	}
	private java.lang.Object __searchField_eval() {
		try {
	return (new generated.GeneralGUI.Textfield());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::SearchWindowController/Property/searchField");
	throw _error;
}

	}
	protected java.lang.Object eval_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final java.lang.String paramName, final int _link) {
		if (e1.entityName.equals("memberSessionStarted") && e2.entityName.equals("memberSessionStarted") && linkProperty.entityName.equals("resultWindow") && paramName.equals("m")) {
try {
	return ((generated.Library.Member)e1.getParameter("m"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|MobileLibraryGUI::SearchWindowController/Event/memberSessionStarted$eventChildLink,Forward,resultWindow,BookListWindowController,memberSessionStarted$m");
	try {
		_error.addVariable("m", e1.getParameter("m"));
	} catch (Throwable _t) {
		_error.addVariable("m", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		
		if (e1.entityName.equals("selectedBook") && e2.entityName.equals("selectedBook") && linkProperty.entityName.equals("resultWindow") && paramName.equals("book")) {
try {
	return ((generated.Library.Book)e1.getParameter("book"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|MobileLibraryGUI::SearchWindowController/Event/selectedBook$eventChildLink,Forward,resultWindow,BookListWindowController,selectedBook$book");
	try {
		_error.addVariable("book", e1.getParameter("book"));
	} catch (Throwable _t) {
		_error.addVariable("book", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("searchButtonClicked") && e2.entityName.equals("searchBook") && linkProperty == null && paramName.equals("term")) {
try {
	return ((java.lang.String)((lu.uni.democles.runtime.Property)((generated.GeneralGUI.Textfield)e1.getAttachedProperty("SearchWindowController_searchField")).getEntity("text")).evalInContainer().getValues().iterator().next());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|MobileLibraryGUI::SearchWindowController/Event/searchButtonClicked$eventChildLink,Local,searchBook$term");
	try {
		_error.addVariable("categorySelect", e1.getAttachedProperty("SearchWindowController_categorySelect"));
	} catch (Throwable _t) {
		_error.addVariable("categorySelect", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("searchField", e1.getAttachedProperty("SearchWindowController_searchField"));
	} catch (Throwable _t) {
		_error.addVariable("searchField", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}
if (e1.entityName.equals("searchButtonClicked") && e2.entityName.equals("searchBook") && linkProperty == null && paramName.equals("category")) {
try {
	return ((java.lang.String)((lu.uni.democles.runtime.Property)((generated.GeneralGUI.SelectionBox)e1.getAttachedProperty("SearchWindowController_categorySelect")).getEntity("selectedChoice")).evalInContainer().getValues().iterator().next());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|MobileLibraryGUI::SearchWindowController/Event/searchButtonClicked$eventChildLink,Local,searchBook$category");
	try {
		_error.addVariable("categorySelect", e1.getAttachedProperty("SearchWindowController_categorySelect"));
	} catch (Throwable _t) {
		_error.addVariable("categorySelect", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("searchField", e1.getAttachedProperty("SearchWindowController_searchField"));
	} catch (Throwable _t) {
		_error.addVariable("searchField", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("bookSelected") && e2.entityName.equals("selectedBook") && linkProperty == null && paramName.equals("book")) {
try {
	return (((generated.Library.Book)((lu.uni.democles.runtime.OCLSequence)e1.getAttachedProperty("SearchWindowController_booksFound")).at((int)((int)((java.lang.Integer)e1.getParameter("index")).intValue()))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|MobileLibraryGUI::SearchWindowController/Event/bookSelected$eventChildLink,Local,selectedBook$book");
	try {
		_error.addVariable("booksFound", e1.getAttachedProperty("SearchWindowController_booksFound"));
	} catch (Throwable _t) {
		_error.addVariable("booksFound", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("index", e1.getParameter("index"));
	} catch (Throwable _t) {
		_error.addVariable("index", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		return null;

	}
	public SearchWindowController() {
		super("generated.MobileLibraryGUI.SearchWindowController", new java.lang.String[] {  });

	}
	private java.lang.Object __searchLabel_eval() {
		try {
	return (generated.GeneralGUI.Label.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "text", "Search by:" }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::SearchWindowController/Property/searchLabel");
	throw _error;
}

	}
	public void initProps() {
		if (this.isInitialized()) return;

		this._p_booksFound.oldVal = this.initialValues.containsKey("booksFound") ? this.initialValues.get("booksFound") : eval_p(this._p_booksFound);
this._p_booksFound.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_booksFound, this._p_booksFound.oldVal);

		this._p_frame.oldVal = this.initialValues.containsKey("frame") ? this.initialValues.get("frame") : eval_p(this._p_frame).getValues().iterator().next();
this._p_frame.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_frame, this._p_frame.oldVal);

		this._p_searchButton.oldVal = this.initialValues.containsKey("searchButton") ? this.initialValues.get("searchButton") : eval_p(this._p_searchButton).getValues().iterator().next();
this._p_searchButton.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_searchButton, this._p_searchButton.oldVal);

		this._p_currMember.oldVal = this.initialValues.containsKey("currMember") ? this.initialValues.get("currMember") : eval_p(this._p_currMember).getValues().iterator().next();
this._p_currMember.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_currMember, this._p_currMember.oldVal);

		this._p_categorySelect.oldVal = this.initialValues.containsKey("categorySelect") ? this.initialValues.get("categorySelect") : eval_p(this._p_categorySelect).getValues().iterator().next();
this._p_categorySelect.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_categorySelect, this._p_categorySelect.oldVal);

		this._p_searchLabel.oldVal = this.initialValues.containsKey("searchLabel") ? this.initialValues.get("searchLabel") : eval_p(this._p_searchLabel).getValues().iterator().next();
this._p_searchLabel.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_searchLabel, this._p_searchLabel.oldVal);

		this._p_resultWindow.oldVal = this.initialValues.containsKey("resultWindow") ? this.initialValues.get("resultWindow") : eval_p(this._p_resultWindow).getValues().iterator().next();
this._p_resultWindow.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_resultWindow, this._p_resultWindow.oldVal);

		this._p_searchField.oldVal = this.initialValues.containsKey("searchField") ? this.initialValues.get("searchField") : eval_p(this._p_searchField).getValues().iterator().next();
this._p_searchField.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_searchField, this._p_searchField.oldVal);

		this._p_mode.oldVal = this.initialValues.containsKey("mode") ? this.initialValues.get("mode") : eval_p(this._p_mode).getValues().iterator().next();
this._p_mode.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_mode, this._p_mode.oldVal);

		this._p_title.oldVal = this.initialValues.containsKey("title") ? this.initialValues.get("title") : eval_p(this._p_title).getValues().iterator().next();
this._p_title.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_title, this._p_title.oldVal);

		this.setInitialized();
this.initialValues = new java.util.HashMap();


	}
	private java.lang.Object _searchFinished_resultWindow_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return (generated.MobileLibraryGUI.BookListWindowController.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "bookListTable", (generated.GeneralGUI.SelectionList.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "items", (((lu.uni.democles.runtime.OCLSequence)generated.MobileLibraryGUI.SearchWindowController.this.evalQueryWithParameters("getBooksFoundData", new Object[] { ((lu.uni.democles.runtime.OCLSet)_event.getParameter("booksFound")) }))) })))), "mode", ((java.lang.String)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.SearchWindowController.this.getEntity("mode")).evalInContainer().getValues().iterator().next()), "currMember", ((generated.Library.Member)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.SearchWindowController.this.getEntity("currMember")).evalInContainer().getValues().iterator().next()) }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|MobileLibraryGUI::SearchWindowController/Event/searchFinished-impacts-MobileLibraryGUI::SearchWindowController/Property/resultWindow");
	try {
		_error.addVariable("booksFound", _event.getParameter("booksFound"));
	} catch (Throwable _t) {
		_error.addVariable("booksFound", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	private java.lang.Object __searchButton_eval() {
		try {
	return (generated.GeneralGUI.Button.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "text", "Search" }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::SearchWindowController/Property/searchButton");
	throw _error;
}

	}
	private java.lang.Object __frame_eval() {
		try {
	return (generated.GeneralGUI.Frame.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "seqGUIElements", new lu.uni.democles.runtime.OCLSequence(new Object[] {((generated.GeneralGUI.Label)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.SearchWindowController.this.getEntity("searchLabel")).evalInContainer().getValues().iterator().next()), ((generated.GeneralGUI.SelectionBox)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.SearchWindowController.this.getEntity("categorySelect")).evalInContainer().getValues().iterator().next()), ((generated.GeneralGUI.Textfield)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.SearchWindowController.this.getEntity("searchField")).evalInContainer().getValues().iterator().next()), ((generated.GeneralGUI.Button)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.SearchWindowController.this.getEntity("searchButton")).evalInContainer().getValues().iterator().next())}), "frameTitle", ((java.lang.String)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.SearchWindowController.this.getEntity("title")).evalInContainer().getValues().iterator().next()), "iconFilename", "icon-search.png" }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::SearchWindowController/Property/frame");
	throw _error;
}

	}
}
