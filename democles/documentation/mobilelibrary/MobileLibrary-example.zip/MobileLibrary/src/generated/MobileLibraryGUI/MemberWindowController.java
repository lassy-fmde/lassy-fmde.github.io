package generated.MobileLibraryGUI;

public class MemberWindowController extends lu.uni.democles.runtime.Instance {
	private lu.uni.democles.runtime.Property _p_ackStatus = new lu.uni.democles.runtime.Property(this, "ackStatus", "MemberWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_currMsg = new lu.uni.democles.runtime.Property(this, "currMsg", "MemberWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_sessionOpened = new lu.uni.democles.runtime.Event(this, "sessionOpened", "MemberWindowController", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Property _p_memberNameLabel = new lu.uni.democles.runtime.Property(this, "memberNameLabel", "MemberWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_getBorrowItemsToDisplay = new lu.uni.democles.runtime.Property(this, "getBorrowItemsToDisplay", "MemberWindowController", "Query", false, false, null, "sequence");
	private lu.uni.democles.runtime.Event _e_setToNotWaiting = new lu.uni.democles.runtime.Event(this, "setToNotWaiting", "MemberWindowController", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_refreshData = new lu.uni.democles.runtime.Event(this, "refreshData", "MemberWindowController", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "borrowItems", "generated.GeneralGUI.SelectionList", "refreshItems", new java.lang.String[] {"items"}), new lu.uni.democles.runtime.ChildLink(false, "memberNameLabel", "generated.GeneralGUI.Label", "setText", new java.lang.String[] {"text"}), new lu.uni.democles.runtime.ChildLink(false, "collectItems", "generated.GeneralGUI.SelectionList", "refreshItems", new java.lang.String[] {"items"}) });
	private lu.uni.democles.runtime.Event _e_renewFailed = new lu.uni.democles.runtime.Event(this, "renewFailed", "MemberWindowController", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.Library.Copy", "selectedBorrowing", "renewFailed", new java.lang.String[] {}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.MobileLibraryGUI.MemberWindowController", "showRenewFailedMsg", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Event _e_borrowItemSelected = new lu.uni.democles.runtime.Event(this, "borrowItemSelected", "MemberWindowController", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.GeneralGUI.SelectionList", "borrowItems", "itemSelected", new java.lang.String[] {"index"}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.MobileLibraryGUI.MemberWindowController", "showConfirmRenewMsg", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Event _e_showRenewOkMsg = new lu.uni.democles.runtime.Event(this, "showRenewOkMsg", "MemberWindowController", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Property _p_dateHandler = new lu.uni.democles.runtime.Property(this, "dateHandler", "MemberWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_currMember = new lu.uni.democles.runtime.Property(this, "currMember", "MemberWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_copyRenewed = new lu.uni.democles.runtime.Event(this, "copyRenewed", "MemberWindowController", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.Library.Copy", "selectedBorrowing", "renewOk", new java.lang.String[] {}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.MobileLibraryGUI.MemberWindowController", "showRenewOkMsg", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Property _p_window = new lu.uni.democles.runtime.Property(this, "window", "MemberWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_borrowedItemsLabel = new lu.uni.democles.runtime.Property(this, "borrowedItemsLabel", "MemberWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_renewBorrowing = new lu.uni.democles.runtime.Event(this, "renewBorrowing", "MemberWindowController", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "selectedBorrowing", "generated.Library.Copy", "renew", new java.lang.String[] {"newDueDate"}) });
	private lu.uni.democles.runtime.Event _e_saveData = new lu.uni.democles.runtime.Event(this, "saveData", "MemberWindowController", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Property _p_yesNoMsg = new lu.uni.democles.runtime.Property(this, "yesNoMsg", "MemberWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_memberLabel = new lu.uni.democles.runtime.Property(this, "memberLabel", "MemberWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_renewAck = new lu.uni.democles.runtime.Event(this, "renewAck", "MemberWindowController", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.GeneralGUI.MsgDialog", "currMsg", "okClicked", new java.lang.String[] {}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.MobileLibraryGUI.MemberWindowController", "refreshData", new java.lang.String[] {}), new lu.uni.democles.runtime.ChildLink(true, "", "generated.MobileLibraryGUI.MemberWindowController", "saveData", new java.lang.String[] {}), new lu.uni.democles.runtime.ChildLink(true, "", "generated.MobileLibraryGUI.MemberWindowController", "setToNotWaiting", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Property _p_collectItems = new lu.uni.democles.runtime.Property(this, "collectItems", "MemberWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_title = new lu.uni.democles.runtime.Property(this, "title", "MemberWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_itemsToCollectLabel = new lu.uni.democles.runtime.Property(this, "itemsToCollectLabel", "MemberWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_borrowItems = new lu.uni.democles.runtime.Property(this, "borrowItems", "MemberWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_renewConfAck = new lu.uni.democles.runtime.Event(this, "renewConfAck", "MemberWindowController", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.GeneralGUI.ConfirmationDialog", "yesNoMsg", "okClicked", new java.lang.String[] {}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.MobileLibraryGUI.MemberWindowController", "renewBorrowing", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Event _e_showConfirmRenewMsg = new lu.uni.democles.runtime.Event(this, "showConfirmRenewMsg", "MemberWindowController", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_showRenewFailedMsg = new lu.uni.democles.runtime.Event(this, "showRenewFailedMsg", "MemberWindowController", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Property _p_selectedBorrowing = new lu.uni.democles.runtime.Property(this, "selectedBorrowing", "MemberWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_getToCollectItemsToDisplay = new lu.uni.democles.runtime.Property(this, "getToCollectItemsToDisplay", "MemberWindowController", "Query", false, false, null, "sequence");
	private java.lang.Object _setToNotWaiting_ackStatus_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return "NotWaiting";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|MobileLibraryGUI::MemberWindowController/Event/setToNotWaiting-impacts-MobileLibraryGUI::MemberWindowController/Property/ackStatus");
	throw _error;
}


	}
	private java.lang.Object _showConfirmRenewMsg_yesNoMsg_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return (generated.GeneralGUI.ConfirmationDialog.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "title", "Confirm", "message", "Would you like to renew the selected book?" }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|MobileLibraryGUI::MemberWindowController/Event/showConfirmRenewMsg-impacts-MobileLibraryGUI::MemberWindowController/Property/yesNoMsg");
	throw _error;
}


	}
	private java.lang.Object __currMsg_eval() {
		try {
	return null;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::MemberWindowController/Property/currMsg");
	throw _error;
}

	}
	protected java.lang.Object eval_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse, final java.lang.String _paramName) {
		
		if (_parent.entityName.equals("itemSelected") && _event.entityName.equals("borrowItemSelected") && _linkProperty.entityName.equals("borrowItems") && _inverse == false && _paramName.equals("index")) {
try {
	return new java.lang.Integer(((int)((java.lang.Integer)_parent.getParameter("index")).intValue()));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|MobileLibraryGUI::MemberWindowController/Event/borrowItemSelected$eventParentLink,Forward,borrowItems,GeneralGUI::SelectionList,itemSelected$index");
	try {
		_error.addVariable("index", _parent.getParameter("index"));
	} catch (Throwable _t) {
		_error.addVariable("index", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		return null;

	}
	private java.lang.Object __dateHandler_eval() {
		try {
	return (new generated.DateProcessing.DateHandler());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::MemberWindowController/Property/dateHandler");
	throw _error;
}

	}
	private java.lang.Object __getToCollectItemsToDisplay_eval() {
		try {
	return ((lu.uni.democles.runtime.OCLSequence)new lu.uni.democles.runtime.Function() {
	public Object _result() {
if ((!lu.uni.democles.runtime.Function._equals(((generated.Library.Member)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.MemberWindowController.this.getEntity("currMember")).evalInContainer().getValues().iterator().next()), null))) {
	return _asObject(((lu.uni.democles.runtime.OCLSequence)(((lu.uni.democles.runtime.OCLSet)((lu.uni.democles.runtime.Property)((generated.Library.Member)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.MemberWindowController.this.getEntity("currMember")).evalInContainer().getValues().iterator().next()).getEntity("toCollect")).evalInContainer()).asSequence()).collect(new lu.uni.democles.runtime.Function() {
	public Object _iteration(Object _value) {
final generated.Library.Copy v_c = ((generated.Library.Copy)_value);
return _asObject(((java.lang.String)((lu.uni.democles.runtime.Property)((generated.Library.Book)((lu.uni.democles.runtime.Property)v_c.getEntity("book")).evalInContainer().getValues().iterator().next()).getEntity("title")).evalInContainer().getValues().iterator().next()));
	}
})));
} else {
	return _asObject(new lu.uni.democles.runtime.OCLSequence(new Object[] {}));
}
}}._result());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::MemberWindowController/Property/getToCollectItemsToDisplay");
	throw _error;
}

	}
	private java.lang.Object __memberNameLabel_eval() {
		try {
	return (new generated.GeneralGUI.Label());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::MemberWindowController/Property/memberNameLabel");
	throw _error;
}

	}
	private java.lang.Object __borrowItems_eval() {
		try {
	return (generated.GeneralGUI.SelectionList.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "items", new lu.uni.democles.runtime.OCLSequence(new Object[] {}) }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::MemberWindowController/Property/borrowItems");
	throw _error;
}

	}
	private java.lang.Object __currMember_eval() {
		try {
	return null;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::MemberWindowController/Property/currMember");
	throw _error;
}

	}
	protected boolean guard(final lu.uni.democles.runtime.Event e1) {
		
			if ("renewAck".equals(e1.entityName)) {
try {
	return (lu.uni.democles.runtime.Function._equals(((java.lang.String)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.MemberWindowController.this.getEntity("ackStatus")).evalInContainer().getValues().iterator().next()), "WaitingRenewAck"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_GUARD|MobileLibraryGUI::MemberWindowController/Event/renewAck");
	throw _error;
}
	}

		return true;

	}
	private java.lang.Object __ackStatus_eval() {
		try {
	return "NotWaiting";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::MemberWindowController/Property/ackStatus");
	throw _error;
}

	}
	protected java.lang.Object eval_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final java.lang.String paramName, final int _link) {
		
		if (e1.entityName.equals("refreshData") && e2.entityName.equals("refreshItems") && linkProperty.entityName.equals("borrowItems") && paramName.equals("items")) {
try {
	return ((lu.uni.democles.runtime.OCLSequence)e1.getAttachedProperty("MemberWindowController_getBorrowItemsToDisplay"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|MobileLibraryGUI::MemberWindowController/Event/refreshData$eventChildLink,Forward,borrowItems,GeneralGUI::SelectionList,refreshItems$items");
	try {
		_error.addVariable("getBorrowItemsToDisplay", e1.getAttachedProperty("MemberWindowController_getBorrowItemsToDisplay"));
	} catch (Throwable _t) {
		_error.addVariable("getBorrowItemsToDisplay", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("getToCollectItemsToDisplay", e1.getAttachedProperty("MemberWindowController_getToCollectItemsToDisplay"));
	} catch (Throwable _t) {
		_error.addVariable("getToCollectItemsToDisplay", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("currMember", e1.getAttachedProperty("MemberWindowController_currMember"));
	} catch (Throwable _t) {
		_error.addVariable("currMember", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}
if (e1.entityName.equals("refreshData") && e2.entityName.equals("setText") && linkProperty.entityName.equals("memberNameLabel") && paramName.equals("text")) {
try {
	return ((java.lang.String)((lu.uni.democles.runtime.Property)((generated.Library.Member)e1.getAttachedProperty("MemberWindowController_currMember")).getEntity("name")).evalInContainer().getValues().iterator().next());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|MobileLibraryGUI::MemberWindowController/Event/refreshData$eventChildLink,Forward,memberNameLabel,GeneralGUI::Label,setText$text");
	try {
		_error.addVariable("getBorrowItemsToDisplay", e1.getAttachedProperty("MemberWindowController_getBorrowItemsToDisplay"));
	} catch (Throwable _t) {
		_error.addVariable("getBorrowItemsToDisplay", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("getToCollectItemsToDisplay", e1.getAttachedProperty("MemberWindowController_getToCollectItemsToDisplay"));
	} catch (Throwable _t) {
		_error.addVariable("getToCollectItemsToDisplay", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("currMember", e1.getAttachedProperty("MemberWindowController_currMember"));
	} catch (Throwable _t) {
		_error.addVariable("currMember", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}
if (e1.entityName.equals("refreshData") && e2.entityName.equals("refreshItems") && linkProperty.entityName.equals("collectItems") && paramName.equals("items")) {
try {
	return ((lu.uni.democles.runtime.OCLSequence)e1.getAttachedProperty("MemberWindowController_getToCollectItemsToDisplay"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|MobileLibraryGUI::MemberWindowController/Event/refreshData$eventChildLink,Forward,collectItems,GeneralGUI::SelectionList,refreshItems$items");
	try {
		_error.addVariable("getBorrowItemsToDisplay", e1.getAttachedProperty("MemberWindowController_getBorrowItemsToDisplay"));
	} catch (Throwable _t) {
		_error.addVariable("getBorrowItemsToDisplay", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("getToCollectItemsToDisplay", e1.getAttachedProperty("MemberWindowController_getToCollectItemsToDisplay"));
	} catch (Throwable _t) {
		_error.addVariable("getToCollectItemsToDisplay", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("currMember", e1.getAttachedProperty("MemberWindowController_currMember"));
	} catch (Throwable _t) {
		_error.addVariable("currMember", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("renewBorrowing") && e2.entityName.equals("renew") && linkProperty.entityName.equals("selectedBorrowing") && paramName.equals("newDueDate")) {
try {
	return (((java.lang.String)((generated.DateProcessing.DateHandler)e1.getAttachedProperty("MemberWindowController_dateHandler")).evalQueryWithParameters("calcAfterOneMonth", new Object[] { ((java.lang.String)((lu.uni.democles.runtime.Property)((generated.Library.Copy)e1.getAttachedProperty("MemberWindowController_selectedBorrowing")).getEntity("dueDate")).evalInContainer().getValues().iterator().next()) })));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|MobileLibraryGUI::MemberWindowController/Event/renewBorrowing$eventChildLink,Forward,selectedBorrowing,Library::Copy,renew$newDueDate");
	try {
		_error.addVariable("dateHandler", e1.getAttachedProperty("MemberWindowController_dateHandler"));
	} catch (Throwable _t) {
		_error.addVariable("dateHandler", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("selectedBorrowing", e1.getAttachedProperty("MemberWindowController_selectedBorrowing"));
	} catch (Throwable _t) {
		_error.addVariable("selectedBorrowing", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		return null;

	}
	protected boolean guard_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse) {
		if (_event.entityName.equals("renewConfAck") && _parent.entityName.equals("okClicked") && _linkProperty.container.modelName.equals("generated.MobileLibraryGUI.MemberWindowController") && _linkProperty.entityName.equals("yesNoMsg") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::MemberWindowController/Event/renewConfAck$eventParentLink,Forward,yesNoMsg,GeneralGUI::ConfirmationDialog,okClicked");
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		
		if (_event.entityName.equals("borrowItemSelected") && _parent.entityName.equals("itemSelected") && _linkProperty.container.modelName.equals("generated.MobileLibraryGUI.MemberWindowController") && _linkProperty.entityName.equals("borrowItems") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::MemberWindowController/Event/borrowItemSelected$eventParentLink,Forward,borrowItems,GeneralGUI::SelectionList,itemSelected");
	try {
		_error.addVariable("index", _parent.getParameter("index"));
	} catch (Throwable _t) {
		_error.addVariable("index", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("copyRenewed") && _parent.entityName.equals("renewOk") && _linkProperty.container.modelName.equals("generated.MobileLibraryGUI.MemberWindowController") && _linkProperty.entityName.equals("selectedBorrowing") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::MemberWindowController/Event/copyRenewed$eventParentLink,Forward,selectedBorrowing,Library::Copy,renewOk");
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("renewFailed") && _parent.entityName.equals("renewFailed") && _linkProperty.container.modelName.equals("generated.MobileLibraryGUI.MemberWindowController") && _linkProperty.entityName.equals("selectedBorrowing") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::MemberWindowController/Event/renewFailed$eventParentLink,Forward,selectedBorrowing,Library::Copy,renewFailed");
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("renewAck") && _parent.entityName.equals("okClicked") && _linkProperty.container.modelName.equals("generated.MobileLibraryGUI.MemberWindowController") && _linkProperty.entityName.equals("currMsg") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::MemberWindowController/Event/renewAck$eventParentLink,Forward,currMsg,GeneralGUI::MsgDialog,okClicked");
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		return true;

	}
	protected void resetNewVal() {
		this._p_getToCollectItemsToDisplay.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_collectItems.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_getBorrowItemsToDisplay.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_borrowItems.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_memberLabel.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_ackStatus.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_currMsg.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_title.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_selectedBorrowing.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_borrowedItemsLabel.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_memberNameLabel.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_window.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_currMember.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_yesNoMsg.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_itemsToCollectLabel.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_dateHandler.newVal = lu.uni.democles.runtime.Entity.nullObject;
	}
	private java.lang.Object __getBorrowItemsToDisplay_eval() {
		try {
	return ((lu.uni.democles.runtime.OCLSequence)new lu.uni.democles.runtime.Function() {
	public Object _result() {
if ((!lu.uni.democles.runtime.Function._equals(((generated.Library.Member)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.MemberWindowController.this.getEntity("currMember")).evalInContainer().getValues().iterator().next()), null))) {
	return _asObject(((lu.uni.democles.runtime.OCLSequence)(((lu.uni.democles.runtime.OCLSet)((lu.uni.democles.runtime.Property)((generated.Library.Member)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.MemberWindowController.this.getEntity("currMember")).evalInContainer().getValues().iterator().next()).getEntity("borrows")).evalInContainer()).asSequence()).collect(new lu.uni.democles.runtime.Function() {
	public Object _iteration(Object _value) {
final generated.Library.Copy v_c = ((generated.Library.Copy)_value);
return _asObject(((((java.lang.String)((lu.uni.democles.runtime.Property)((generated.Library.Book)((lu.uni.democles.runtime.Property)v_c.getEntity("book")).evalInContainer().getValues().iterator().next()).getEntity("title")).evalInContainer().getValues().iterator().next()) + " ") + ((java.lang.String)((lu.uni.democles.runtime.Property)v_c.getEntity("dueDate")).evalInContainer().getValues().iterator().next())));
	}
})));
} else {
	return _asObject(new lu.uni.democles.runtime.OCLSequence(new Object[] {}));
}
}}._result());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::MemberWindowController/Property/getBorrowItemsToDisplay");
	throw _error;
}

	}
	protected boolean guard_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final lu.uni.democles.runtime.Instance linkedInstance, final int _link) {
		if (e1.entityName.equals("renewConfAck") && e2.entityName.equals("renewBorrowing") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::MemberWindowController/Event/renewConfAck$eventChildLink,Local,renewBorrowing");
	throw _error;
}
	}

		
		if (e1.entityName.equals("refreshData") && e2.entityName.equals("refreshItems") && linkProperty.container.modelName.equals("generated.MobileLibraryGUI.MemberWindowController") && linkProperty.entityName.equals("borrowItems")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::MemberWindowController/Event/refreshData$eventChildLink,Forward,borrowItems,GeneralGUI::SelectionList,refreshItems");
	try {
		_error.addVariable("getBorrowItemsToDisplay", e1.getAttachedProperty("MemberWindowController_getBorrowItemsToDisplay"));
	} catch (Throwable _t) {
		_error.addVariable("getBorrowItemsToDisplay", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("getToCollectItemsToDisplay", e1.getAttachedProperty("MemberWindowController_getToCollectItemsToDisplay"));
	} catch (Throwable _t) {
		_error.addVariable("getToCollectItemsToDisplay", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("currMember", e1.getAttachedProperty("MemberWindowController_currMember"));
	} catch (Throwable _t) {
		_error.addVariable("currMember", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}
if (e1.entityName.equals("refreshData") && e2.entityName.equals("setText") && linkProperty.container.modelName.equals("generated.MobileLibraryGUI.MemberWindowController") && linkProperty.entityName.equals("memberNameLabel")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::MemberWindowController/Event/refreshData$eventChildLink,Forward,memberNameLabel,GeneralGUI::Label,setText");
	try {
		_error.addVariable("getBorrowItemsToDisplay", e1.getAttachedProperty("MemberWindowController_getBorrowItemsToDisplay"));
	} catch (Throwable _t) {
		_error.addVariable("getBorrowItemsToDisplay", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("getToCollectItemsToDisplay", e1.getAttachedProperty("MemberWindowController_getToCollectItemsToDisplay"));
	} catch (Throwable _t) {
		_error.addVariable("getToCollectItemsToDisplay", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("currMember", e1.getAttachedProperty("MemberWindowController_currMember"));
	} catch (Throwable _t) {
		_error.addVariable("currMember", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}
if (e1.entityName.equals("refreshData") && e2.entityName.equals("refreshItems") && linkProperty.container.modelName.equals("generated.MobileLibraryGUI.MemberWindowController") && linkProperty.entityName.equals("collectItems")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::MemberWindowController/Event/refreshData$eventChildLink,Forward,collectItems,GeneralGUI::SelectionList,refreshItems");
	try {
		_error.addVariable("getBorrowItemsToDisplay", e1.getAttachedProperty("MemberWindowController_getBorrowItemsToDisplay"));
	} catch (Throwable _t) {
		_error.addVariable("getBorrowItemsToDisplay", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("getToCollectItemsToDisplay", e1.getAttachedProperty("MemberWindowController_getToCollectItemsToDisplay"));
	} catch (Throwable _t) {
		_error.addVariable("getToCollectItemsToDisplay", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("currMember", e1.getAttachedProperty("MemberWindowController_currMember"));
	} catch (Throwable _t) {
		_error.addVariable("currMember", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("renewBorrowing") && e2.entityName.equals("renew") && linkProperty.container.modelName.equals("generated.MobileLibraryGUI.MemberWindowController") && linkProperty.entityName.equals("selectedBorrowing")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::MemberWindowController/Event/renewBorrowing$eventChildLink,Forward,selectedBorrowing,Library::Copy,renew");
	try {
		_error.addVariable("dateHandler", e1.getAttachedProperty("MemberWindowController_dateHandler"));
	} catch (Throwable _t) {
		_error.addVariable("dateHandler", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("selectedBorrowing", e1.getAttachedProperty("MemberWindowController_selectedBorrowing"));
	} catch (Throwable _t) {
		_error.addVariable("selectedBorrowing", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("borrowItemSelected") && e2.entityName.equals("showConfirmRenewMsg") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::MemberWindowController/Event/borrowItemSelected$eventChildLink,Local,showConfirmRenewMsg");
	try {
		_error.addVariable("index", e1.getParameter("index"));
	} catch (Throwable _t) {
		_error.addVariable("index", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("copyRenewed") && e2.entityName.equals("showRenewOkMsg") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::MemberWindowController/Event/copyRenewed$eventChildLink,Local,showRenewOkMsg");
	throw _error;
}
	}

		if (e1.entityName.equals("renewFailed") && e2.entityName.equals("showRenewFailedMsg") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::MemberWindowController/Event/renewFailed$eventChildLink,Local,showRenewFailedMsg");
	throw _error;
}
	}

		if (e1.entityName.equals("renewAck") && e2.entityName.equals("refreshData") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::MemberWindowController/Event/renewAck$eventChildLink,Local,refreshData");
	throw _error;
}
	}
if (e1.entityName.equals("renewAck") && e2.entityName.equals("saveData") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::MemberWindowController/Event/renewAck$eventChildLink,Local,saveData");
	throw _error;
}
	}
if (e1.entityName.equals("renewAck") && e2.entityName.equals("setToNotWaiting") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::MemberWindowController/Event/renewAck$eventChildLink,Local,setToNotWaiting");
	throw _error;
}
	}

		return true;

	}
	private java.lang.Object __borrowedItemsLabel_eval() {
		try {
	return (generated.GeneralGUI.Label.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "text", "Books on loan:" }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::MemberWindowController/Property/borrowedItemsLabel");
	throw _error;
}

	}
	private java.lang.Object __collectItems_eval() {
		try {
	return (generated.GeneralGUI.SelectionList.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "items", new lu.uni.democles.runtime.OCLSequence(new Object[] {}) }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::MemberWindowController/Property/collectItems");
	throw _error;
}

	}
	protected void attachProperties(lu.uni.democles.runtime.Event e) {
		// Set Attached Properties:


		// Set Attached Properties:
if ("refreshData".equals(e.entityName)) {
	e.attachProperty("MemberWindowController_getBorrowItemsToDisplay", this._p_getBorrowItemsToDisplay.evalInContainer());
	e.attachProperty("MemberWindowController_getToCollectItemsToDisplay", this._p_getToCollectItemsToDisplay.evalInContainer());
	e.attachProperty("MemberWindowController_currMember", this._p_currMember.evalInContainer().getValues().iterator().next());
}


		// Set Attached Properties:
if ("renewBorrowing".equals(e.entityName)) {
	e.attachProperty("MemberWindowController_dateHandler", this._p_dateHandler.evalInContainer().getValues().iterator().next());
	e.attachProperty("MemberWindowController_selectedBorrowing", this._p_selectedBorrowing.evalInContainer().getValues().iterator().next());
}


	}
	private java.lang.Object __yesNoMsg_eval() {
		try {
	return null;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::MemberWindowController/Property/yesNoMsg");
	throw _error;
}

	}
	public MemberWindowController() {
		super("generated.MobileLibraryGUI.MemberWindowController", new java.lang.String[] {  });

	}
	private java.lang.Object __itemsToCollectLabel_eval() {
		try {
	return (generated.GeneralGUI.Label.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "text", "Reserved Books awaiting collection:" }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::MemberWindowController/Property/itemsToCollectLabel");
	throw _error;
}

	}
	public void initProps() {
		if (this.isInitialized()) return;

		this._p_collectItems.oldVal = this.initialValues.containsKey("collectItems") ? this.initialValues.get("collectItems") : eval_p(this._p_collectItems).getValues().iterator().next();
this._p_collectItems.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_collectItems, this._p_collectItems.oldVal);

		this._p_borrowItems.oldVal = this.initialValues.containsKey("borrowItems") ? this.initialValues.get("borrowItems") : eval_p(this._p_borrowItems).getValues().iterator().next();
this._p_borrowItems.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_borrowItems, this._p_borrowItems.oldVal);

		this._p_memberLabel.oldVal = this.initialValues.containsKey("memberLabel") ? this.initialValues.get("memberLabel") : eval_p(this._p_memberLabel).getValues().iterator().next();
this._p_memberLabel.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_memberLabel, this._p_memberLabel.oldVal);

		this._p_ackStatus.oldVal = this.initialValues.containsKey("ackStatus") ? this.initialValues.get("ackStatus") : eval_p(this._p_ackStatus).getValues().iterator().next();
this._p_ackStatus.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_ackStatus, this._p_ackStatus.oldVal);

		this._p_currMsg.oldVal = this.initialValues.containsKey("currMsg") ? this.initialValues.get("currMsg") : eval_p(this._p_currMsg).getValues().iterator().next();
this._p_currMsg.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_currMsg, this._p_currMsg.oldVal);

		this._p_title.oldVal = this.initialValues.containsKey("title") ? this.initialValues.get("title") : eval_p(this._p_title).getValues().iterator().next();
this._p_title.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_title, this._p_title.oldVal);

		this._p_selectedBorrowing.oldVal = this.initialValues.containsKey("selectedBorrowing") ? this.initialValues.get("selectedBorrowing") : eval_p(this._p_selectedBorrowing).getValues().iterator().next();
this._p_selectedBorrowing.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_selectedBorrowing, this._p_selectedBorrowing.oldVal);

		this._p_borrowedItemsLabel.oldVal = this.initialValues.containsKey("borrowedItemsLabel") ? this.initialValues.get("borrowedItemsLabel") : eval_p(this._p_borrowedItemsLabel).getValues().iterator().next();
this._p_borrowedItemsLabel.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_borrowedItemsLabel, this._p_borrowedItemsLabel.oldVal);

		this._p_memberNameLabel.oldVal = this.initialValues.containsKey("memberNameLabel") ? this.initialValues.get("memberNameLabel") : eval_p(this._p_memberNameLabel).getValues().iterator().next();
this._p_memberNameLabel.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_memberNameLabel, this._p_memberNameLabel.oldVal);

		this._p_window.oldVal = this.initialValues.containsKey("window") ? this.initialValues.get("window") : eval_p(this._p_window).getValues().iterator().next();
this._p_window.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_window, this._p_window.oldVal);

		this._p_currMember.oldVal = this.initialValues.containsKey("currMember") ? this.initialValues.get("currMember") : eval_p(this._p_currMember).getValues().iterator().next();
this._p_currMember.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_currMember, this._p_currMember.oldVal);

		this._p_yesNoMsg.oldVal = this.initialValues.containsKey("yesNoMsg") ? this.initialValues.get("yesNoMsg") : eval_p(this._p_yesNoMsg).getValues().iterator().next();
this._p_yesNoMsg.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_yesNoMsg, this._p_yesNoMsg.oldVal);

		this._p_itemsToCollectLabel.oldVal = this.initialValues.containsKey("itemsToCollectLabel") ? this.initialValues.get("itemsToCollectLabel") : eval_p(this._p_itemsToCollectLabel).getValues().iterator().next();
this._p_itemsToCollectLabel.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_itemsToCollectLabel, this._p_itemsToCollectLabel.oldVal);

		this._p_dateHandler.oldVal = this.initialValues.containsKey("dateHandler") ? this.initialValues.get("dateHandler") : eval_p(this._p_dateHandler).getValues().iterator().next();
this._p_dateHandler.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_dateHandler, this._p_dateHandler.oldVal);

		this.setInitialized();
this.initialValues = new java.util.HashMap();


	}
	private java.lang.Object __window_eval() {
		try {
	return (generated.GeneralGUI.Frame.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "seqGUIElements", new lu.uni.democles.runtime.OCLSequence(new Object[] {((generated.GeneralGUI.Label)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.MemberWindowController.this.getEntity("memberLabel")).evalInContainer().getValues().iterator().next()), ((generated.GeneralGUI.Label)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.MemberWindowController.this.getEntity("memberNameLabel")).evalInContainer().getValues().iterator().next()), ((generated.GeneralGUI.Label)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.MemberWindowController.this.getEntity("borrowedItemsLabel")).evalInContainer().getValues().iterator().next()), ((generated.GeneralGUI.SelectionList)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.MemberWindowController.this.getEntity("borrowItems")).evalInContainer().getValues().iterator().next()), ((generated.GeneralGUI.Label)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.MemberWindowController.this.getEntity("itemsToCollectLabel")).evalInContainer().getValues().iterator().next()), ((generated.GeneralGUI.SelectionList)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.MemberWindowController.this.getEntity("collectItems")).evalInContainer().getValues().iterator().next())}), "frameTitle", ((java.lang.String)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.MemberWindowController.this.getEntity("title")).evalInContainer().getValues().iterator().next()), "iconFilename", "icon-house.png" }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::MemberWindowController/Property/window");
	throw _error;
}

	}
	private java.lang.Object __selectedBorrowing_eval() {
		try {
	return null;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::MemberWindowController/Property/selectedBorrowing");
	throw _error;
}

	}
	protected void set(lu.uni.democles.runtime.Property p, java.lang.Object v) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) {
	throw new lu.uni.democles.runtime.MultipleModificationException(p.toString());
}
p.newVal = v;
		super.set(p, v);
	}
	private java.lang.Object _showRenewFailedMsg_currMsg_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return (generated.GeneralGUI.MsgDialog.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "msg", (("Could not renew  borrowing of book " + ((java.lang.String)((lu.uni.democles.runtime.Property)((generated.Library.Book)((lu.uni.democles.runtime.Property)((generated.Library.Copy)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.MemberWindowController.this.getEntity("selectedBorrowing")).evalInContainer().getValues().iterator().next()).getEntity("book")).evalInContainer().getValues().iterator().next()).getEntity("title")).evalInContainer().getValues().iterator().next())) + ". You have reached the limit of renewals for this borrowing."), "viewTitle", "Error!" }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|MobileLibraryGUI::MemberWindowController/Event/showRenewFailedMsg-impacts-MobileLibraryGUI::MemberWindowController/Property/currMsg");
	throw _error;
}


	}
	protected java.lang.Object evalQuery(lu.uni.democles.runtime.Property p) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) return p.newVal;

if (p.isEvaluating()) throw new lu.uni.democles.runtime.ModificationCycleException();

p.setEvaluating(true);
java.lang.Object o = null;


		if ("getToCollectItemsToDisplay".equals(p.entityName)) {
	o = __getToCollectItemsToDisplay_eval();
	set(p, o);
}

		if ("collectItems".equals(p.entityName)) {
	o = __collectItems_eval();
	set(p, o);
}

		if ("getBorrowItemsToDisplay".equals(p.entityName)) {
	o = __getBorrowItemsToDisplay_eval();
	set(p, o);
}

		if ("borrowItems".equals(p.entityName)) {
	o = __borrowItems_eval();
	set(p, o);
}

		if ("memberLabel".equals(p.entityName)) {
	o = __memberLabel_eval();
	set(p, o);
}

		if ("ackStatus".equals(p.entityName)) {
	o = __ackStatus_eval();
	set(p, o);
}

		if ("currMsg".equals(p.entityName)) {
	o = __currMsg_eval();
	set(p, o);
}

		if ("title".equals(p.entityName)) {
	o = __title_eval();
	set(p, o);
}

		if ("selectedBorrowing".equals(p.entityName)) {
	o = __selectedBorrowing_eval();
	set(p, o);
}

		if ("borrowedItemsLabel".equals(p.entityName)) {
	o = __borrowedItemsLabel_eval();
	set(p, o);
}

		if ("memberNameLabel".equals(p.entityName)) {
	o = __memberNameLabel_eval();
	set(p, o);
}

		if ("window".equals(p.entityName)) {
	o = __window_eval();
	set(p, o);
}

		if ("currMember".equals(p.entityName)) {
	o = __currMember_eval();
	set(p, o);
}

		if ("yesNoMsg".equals(p.entityName)) {
	o = __yesNoMsg_eval();
	set(p, o);
}

		if ("itemsToCollectLabel".equals(p.entityName)) {
	o = __itemsToCollectLabel_eval();
	set(p, o);
}

		if ("dateHandler".equals(p.entityName)) {
	o = __dateHandler_eval();
	set(p, o);
}

		if (o instanceof lu.uni.democles.runtime.Instance) {
	((lu.uni.democles.runtime.Instance)o).initProps();
} else if (o instanceof lu.uni.democles.runtime.OCLCollection) {
	for (java.util.Iterator iter = ((lu.uni.democles.runtime.OCLCollection)o).getValues().iterator(); iter.hasNext();) {
		java.lang.Object entry = iter.next();
		if (entry instanceof lu.uni.democles.runtime.Instance) {
			((lu.uni.democles.runtime.Instance)entry).initProps();
		}
	}
}
p.setEvaluating(false);
return o;


	}
	protected void doModify(lu.uni.democles.runtime.Event event) {
		if ("setToNotWaiting".equals(event.entityName)) {
	handleImpact(event, this._p_ackStatus);
}
if ("showRenewOkMsg".equals(event.entityName)) {
	handleImpact(event, this._p_currMsg);
}
if ("borrowItemSelected".equals(event.entityName)) {
	handleImpact(event, this._p_selectedBorrowing);
}
if ("showRenewFailedMsg".equals(event.entityName)) {
	handleImpact(event, this._p_currMsg);
}
if ("showConfirmRenewMsg".equals(event.entityName)) {
	handleImpact(event, this._p_yesNoMsg);
}
if ("sessionOpened".equals(event.entityName)) {
	handleImpact(event, this._p_currMember);
}
if ("showRenewOkMsg".equals(event.entityName)) {
	handleImpact(event, this._p_ackStatus);
}

	}
	public static void main(String[] args) {
	}
	private void handleImpact(lu.uni.democles.runtime.Event e, lu.uni.democles.runtime.Property p) {
		set(p, eval_ep(e, p));
	}
	private java.lang.Object _borrowItemSelected_selectedBorrowing_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return (((generated.Library.Copy)(((lu.uni.democles.runtime.OCLSet)((lu.uni.democles.runtime.Property)((generated.Library.Member)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.MemberWindowController.this.getEntity("currMember")).evalInContainer().getValues().iterator().next()).getEntity("borrows")).evalInContainer()).asSequence()).at((int)((int)((java.lang.Integer)_event.getParameter("index")).intValue()))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|MobileLibraryGUI::MemberWindowController/Event/borrowItemSelected-impacts-MobileLibraryGUI::MemberWindowController/Property/selectedBorrowing");
	try {
		_error.addVariable("index", _event.getParameter("index"));
	} catch (Throwable _t) {
		_error.addVariable("index", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	private java.lang.Object eval_ep(final lu.uni.democles.runtime.Event e, final lu.uni.democles.runtime.Property p) {
		if (p.entityName.equals(this._p_currMember.entityName) && e.entityName.equals(this._e_sessionOpened.entityName)) {
	return _sessionOpened_currMember_eval(e);
}
		if (p.entityName.equals(this._p_selectedBorrowing.entityName) && e.entityName.equals(this._e_borrowItemSelected.entityName)) {
	return _borrowItemSelected_selectedBorrowing_eval(e);
}
		if (p.entityName.equals(this._p_currMsg.entityName) && e.entityName.equals(this._e_showRenewOkMsg.entityName)) {
	return _showRenewOkMsg_currMsg_eval(e);
}
		if (p.entityName.equals(this._p_ackStatus.entityName) && e.entityName.equals(this._e_showRenewOkMsg.entityName)) {
	return _showRenewOkMsg_ackStatus_eval(e);
}
		if (p.entityName.equals(this._p_currMsg.entityName) && e.entityName.equals(this._e_showRenewFailedMsg.entityName)) {
	return _showRenewFailedMsg_currMsg_eval(e);
}
		if (p.entityName.equals(this._p_yesNoMsg.entityName) && e.entityName.equals(this._e_showConfirmRenewMsg.entityName)) {
	return _showConfirmRenewMsg_yesNoMsg_eval(e);
}
		if (p.entityName.equals(this._p_ackStatus.entityName) && e.entityName.equals(this._e_setToNotWaiting.entityName)) {
	return _setToNotWaiting_ackStatus_eval(e);
}
		return null;

	}
	private java.lang.Object _showRenewOkMsg_currMsg_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return (generated.GeneralGUI.MsgDialog.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "msg", (("Book " + ((java.lang.String)((lu.uni.democles.runtime.Property)((generated.Library.Book)((lu.uni.democles.runtime.Property)((generated.Library.Copy)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.MemberWindowController.this.getEntity("selectedBorrowing")).evalInContainer().getValues().iterator().next()).getEntity("book")).evalInContainer().getValues().iterator().next()).getEntity("title")).evalInContainer().getValues().iterator().next())) + " renewed sucessfully."), "viewTitle", "Success!" }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|MobileLibraryGUI::MemberWindowController/Event/showRenewOkMsg-impacts-MobileLibraryGUI::MemberWindowController/Property/currMsg");
	throw _error;
}


	}
	private java.lang.Object __memberLabel_eval() {
		try {
	return (generated.GeneralGUI.Label.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "text", "Member" }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::MemberWindowController/Property/memberLabel");
	throw _error;
}

	}
	private java.lang.Object _showRenewOkMsg_ackStatus_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return "WaitingRenewAck";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|MobileLibraryGUI::MemberWindowController/Event/showRenewOkMsg-impacts-MobileLibraryGUI::MemberWindowController/Property/ackStatus");
	throw _error;
}


	}
	public static MemberWindowController newWithValues(java.util.HashMap values) {
		MemberWindowController res = new MemberWindowController();
res.initialValues = new java.util.HashMap(values);
res.initProps();
return res;
	}
	private java.lang.Object _sessionOpened_currMember_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return ((generated.Library.Member)_event.getParameter("m"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|MobileLibraryGUI::MemberWindowController/Event/sessionOpened-impacts-MobileLibraryGUI::MemberWindowController/Property/currMember");
	try {
		_error.addVariable("m", _event.getParameter("m"));
	} catch (Throwable _t) {
		_error.addVariable("m", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	private java.lang.Object __title_eval() {
		try {
	return "Member";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::MemberWindowController/Property/title");
	throw _error;
}

	}
}
