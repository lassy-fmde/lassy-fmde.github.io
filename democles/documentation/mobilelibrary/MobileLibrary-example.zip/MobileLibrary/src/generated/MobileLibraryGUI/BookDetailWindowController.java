package generated.MobileLibraryGUI;

public class BookDetailWindowController extends lu.uni.democles.runtime.Instance {
	private lu.uni.democles.runtime.Event _e_memberSessionStarted = new lu.uni.democles.runtime.Event(this, "memberSessionStarted", "BookDetailWindowController", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Property _p_ackStatus = new lu.uni.democles.runtime.Property(this, "ackStatus", "BookDetailWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_showReserveOkMsg = new lu.uni.democles.runtime.Event(this, "showReserveOkMsg", "BookDetailWindowController", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Property _p_bookIsbnLabel = new lu.uni.democles.runtime.Property(this, "bookIsbnLabel", "BookDetailWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_reserveBookCopyNotOk = new lu.uni.democles.runtime.Event(this, "reserveBookCopyNotOk", "BookDetailWindowController", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.MobileLibraryGUI.BookDetailWindowController", "showCannotReserveCopyMsg", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Event _e_showReserveFailedMsg = new lu.uni.democles.runtime.Event(this, "showReserveFailedMsg", "BookDetailWindowController", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.MobileLibraryGUI.BookDetailWindowController", "setToNotWaiting", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Property _p_msg = new lu.uni.democles.runtime.Property(this, "msg", "BookDetailWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_refreshBookCopiesData = new lu.uni.democles.runtime.Event(this, "refreshBookCopiesData", "BookDetailWindowController", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "bookCopies", "generated.GeneralGUI.SelectionList", "refreshItems", new java.lang.String[] {"items"}) });
	private lu.uni.democles.runtime.Event _e_setToNotWaiting = new lu.uni.democles.runtime.Event(this, "setToNotWaiting", "BookDetailWindowController", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_reserveBookCopyOk = new lu.uni.democles.runtime.Event(this, "reserveBookCopyOk", "BookDetailWindowController", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "selectedBookCopy", "generated.Library.Copy", "reserve", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Property _p_authorLabel = new lu.uni.democles.runtime.Property(this, "authorLabel", "BookDetailWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_mode = new lu.uni.democles.runtime.Property(this, "mode", "BookDetailWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_reserveConfAck = new lu.uni.democles.runtime.Event(this, "reserveConfAck", "BookDetailWindowController", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.GeneralGUI.ConfirmationDialog", "yesNoMsg", "okClicked", new java.lang.String[] {}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.MobileLibraryGUI.BookDetailWindowController", "reserveBookCopyOk", new java.lang.String[] {}), new lu.uni.democles.runtime.ChildLink(true, "", "generated.MobileLibraryGUI.BookDetailWindowController", "reserveBookCopyNotOk", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Event _e_bookCopyItemSelected = new lu.uni.democles.runtime.Event(this, "bookCopyItemSelected", "BookDetailWindowController", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.GeneralGUI.SelectionList", "bookCopies", "itemSelected", new java.lang.String[] {"index"}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.MobileLibraryGUI.BookDetailWindowController", "showConfirmReserveMsg", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Property _p_currMember = new lu.uni.democles.runtime.Property(this, "currMember", "BookDetailWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_addReservedToMember = new lu.uni.democles.runtime.Event(this, "addReservedToMember", "BookDetailWindowController", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "currMember", "generated.Library.Member", "addCopyToCollect", new java.lang.String[] {"copy"}) });
	private lu.uni.democles.runtime.Property _p_bookAuthorLabel = new lu.uni.democles.runtime.Property(this, "bookAuthorLabel", "BookDetailWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_copyReserved = new lu.uni.democles.runtime.Event(this, "copyReserved", "BookDetailWindowController", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.Library.Copy", "selectedBookCopy", "reserveOk", new java.lang.String[] {}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.MobileLibraryGUI.BookDetailWindowController", "showReserveOkMsg", new java.lang.String[] {}), new lu.uni.democles.runtime.ChildLink(true, "", "generated.MobileLibraryGUI.BookDetailWindowController", "addReservedToMember", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Property _p_window = new lu.uni.democles.runtime.Property(this, "window", "BookDetailWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_getBookCopiesData = new lu.uni.democles.runtime.Property(this, "getBookCopiesData", "BookDetailWindowController", "Query", false, false, null, "sequence");
	private lu.uni.democles.runtime.Event _e_showCannotReserveCopyMsg = new lu.uni.democles.runtime.Event(this, "showCannotReserveCopyMsg", "BookDetailWindowController", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.MobileLibraryGUI.BookDetailWindowController", "setToNotWaiting", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Event _e_showConfirmReserveMsg = new lu.uni.democles.runtime.Event(this, "showConfirmReserveMsg", "BookDetailWindowController", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Property _p_isbnLabel = new lu.uni.democles.runtime.Property(this, "isbnLabel", "BookDetailWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_reserveAck = new lu.uni.democles.runtime.Event(this, "reserveAck", "BookDetailWindowController", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.GeneralGUI.MsgDialog", "msg", "okClicked", new java.lang.String[] {}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.MobileLibraryGUI.BookDetailWindowController", "refreshAndSave", new java.lang.String[] {}), new lu.uni.democles.runtime.ChildLink(true, "", "generated.MobileLibraryGUI.BookDetailWindowController", "setToNotWaiting", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Property _p_selectedBookCopy = new lu.uni.democles.runtime.Property(this, "selectedBookCopy", "BookDetailWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_bookCopiesLabel = new lu.uni.democles.runtime.Property(this, "bookCopiesLabel", "BookDetailWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_bookTitleLabel = new lu.uni.democles.runtime.Property(this, "bookTitleLabel", "BookDetailWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_yesNoMsg = new lu.uni.democles.runtime.Property(this, "yesNoMsg", "BookDetailWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_bookCopies = new lu.uni.democles.runtime.Property(this, "bookCopies", "BookDetailWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_reserveFailed = new lu.uni.democles.runtime.Event(this, "reserveFailed", "BookDetailWindowController", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.Library.Copy", "selectedBookCopy", "reserveFailed", new java.lang.String[] {}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.MobileLibraryGUI.BookDetailWindowController", "showReserveFailedMsg", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Property _p_windowTitle = new lu.uni.democles.runtime.Property(this, "windowTitle", "BookDetailWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_titleLabel = new lu.uni.democles.runtime.Property(this, "titleLabel", "BookDetailWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_currBook = new lu.uni.democles.runtime.Property(this, "currBook", "BookDetailWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_refreshAndSave = new lu.uni.democles.runtime.Event(this, "refreshAndSave", "BookDetailWindowController", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "bookCopies", "generated.GeneralGUI.SelectionList", "refreshItems", new java.lang.String[] {"items"}) });
	private java.lang.Object _bookCopyItemSelected_selectedBookCopy_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return (((generated.Library.Copy)(((lu.uni.democles.runtime.OCLSet)((lu.uni.democles.runtime.Property)((generated.Library.Book)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.BookDetailWindowController.this.getEntity("currBook")).evalInContainer().getValues().iterator().next()).getEntity("copies")).evalInContainer()).asSequence()).at((int)((int)((java.lang.Integer)_event.getParameter("index")).intValue()))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|MobileLibraryGUI::BookDetailWindowController/Event/bookCopyItemSelected-impacts-MobileLibraryGUI::BookDetailWindowController/Property/selectedBookCopy");
	try {
		_error.addVariable("index", _event.getParameter("index"));
	} catch (Throwable _t) {
		_error.addVariable("index", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	private java.lang.Object _memberSessionStarted_currMember_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return ((generated.Library.Member)_event.getParameter("m"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|MobileLibraryGUI::BookDetailWindowController/Event/memberSessionStarted-impacts-MobileLibraryGUI::BookDetailWindowController/Property/currMember");
	try {
		_error.addVariable("m", _event.getParameter("m"));
	} catch (Throwable _t) {
		_error.addVariable("m", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	private java.lang.Object _setToNotWaiting_ackStatus_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return "NotWaiting";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|MobileLibraryGUI::BookDetailWindowController/Event/setToNotWaiting-impacts-MobileLibraryGUI::BookDetailWindowController/Property/ackStatus");
	throw _error;
}


	}
	private java.lang.Object __bookIsbnLabel_eval() {
		try {
	return null;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::BookDetailWindowController/Property/bookIsbnLabel");
	throw _error;
}

	}
	private java.lang.Object _showReserveFailedMsg_msg_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return (generated.GeneralGUI.MsgDialog.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "msg", (("The selected copy of book '" + ((java.lang.String)((lu.uni.democles.runtime.Property)((generated.Library.Book)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.BookDetailWindowController.this.getEntity("currBook")).evalInContainer().getValues().iterator().next()).getEntity("title")).evalInContainer().getValues().iterator().next())) + "' could not be reserved because it is not available for borrowing."), "viewTitle", "Copy Reservation Failed!" }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|MobileLibraryGUI::BookDetailWindowController/Event/showReserveFailedMsg-impacts-MobileLibraryGUI::BookDetailWindowController/Property/msg");
	throw _error;
}


	}
	protected java.lang.Object eval_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse, final java.lang.String _paramName) {
		
		if (_parent.entityName.equals("itemSelected") && _event.entityName.equals("bookCopyItemSelected") && _linkProperty.entityName.equals("bookCopies") && _inverse == false && _paramName.equals("index")) {
try {
	return new java.lang.Integer(((int)((java.lang.Integer)_parent.getParameter("index")).intValue()));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|MobileLibraryGUI::BookDetailWindowController/Event/bookCopyItemSelected$eventParentLink,Forward,bookCopies,GeneralGUI::SelectionList,itemSelected$index");
	try {
		_error.addVariable("index", _parent.getParameter("index"));
	} catch (Throwable _t) {
		_error.addVariable("index", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		return null;

	}
	private java.lang.Object __titleLabel_eval() {
		try {
	return (generated.GeneralGUI.Label.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "text", "Title: " }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::BookDetailWindowController/Property/titleLabel");
	throw _error;
}

	}
	private java.lang.Object __mode_eval() {
		try {
	return "NotLoggedIn";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::BookDetailWindowController/Property/mode");
	throw _error;
}

	}
	protected boolean guard(final lu.uni.democles.runtime.Event e1) {
		
			if ("reserveBookCopyNotOk".equals(e1.entityName)) {
try {
	return (lu.uni.democles.runtime.Function._equals(((java.lang.String)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.BookDetailWindowController.this.getEntity("mode")).evalInContainer().getValues().iterator().next()), "NotLoggedIn"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_GUARD|MobileLibraryGUI::BookDetailWindowController/Event/reserveBookCopyNotOk");
	throw _error;
}
	}

			if ("reserveBookCopyOk".equals(e1.entityName)) {
try {
	return (lu.uni.democles.runtime.Function._equals(((java.lang.String)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.BookDetailWindowController.this.getEntity("mode")).evalInContainer().getValues().iterator().next()), "LoggedIn"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_GUARD|MobileLibraryGUI::BookDetailWindowController/Event/reserveBookCopyOk");
	throw _error;
}
	}

			if ("reserveAck".equals(e1.entityName)) {
try {
	return (lu.uni.democles.runtime.Function._equals(((java.lang.String)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.BookDetailWindowController.this.getEntity("ackStatus")).evalInContainer().getValues().iterator().next()), "WaitingReserveAck"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_GUARD|MobileLibraryGUI::BookDetailWindowController/Event/reserveAck");
	throw _error;
}
	}

		return true;

	}
	private java.lang.Object __currBook_eval() {
		try {
	return null;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::BookDetailWindowController/Property/currBook");
	throw _error;
}

	}
	private java.lang.Object __ackStatus_eval() {
		try {
	return "NotWaiting";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::BookDetailWindowController/Property/ackStatus");
	throw _error;
}

	}
	private java.lang.Object __currMember_eval() {
		try {
	return null;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::BookDetailWindowController/Property/currMember");
	throw _error;
}

	}
	protected java.lang.Object eval_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final java.lang.String paramName, final int _link) {
		if (e1.entityName.equals("refreshAndSave") && e2.entityName.equals("refreshItems") && linkProperty.entityName.equals("bookCopies") && paramName.equals("items")) {
try {
	return ((lu.uni.democles.runtime.OCLSequence)e1.getAttachedProperty("BookDetailWindowController_getBookCopiesData"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|MobileLibraryGUI::BookDetailWindowController/Event/refreshAndSave$eventChildLink,Forward,bookCopies,GeneralGUI::SelectionList,refreshItems$items");
	try {
		_error.addVariable("getBookCopiesData", e1.getAttachedProperty("BookDetailWindowController_getBookCopiesData"));
	} catch (Throwable _t) {
		_error.addVariable("getBookCopiesData", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		
		if (e1.entityName.equals("addReservedToMember") && e2.entityName.equals("addCopyToCollect") && linkProperty.entityName.equals("currMember") && paramName.equals("copy")) {
try {
	return ((generated.Library.Copy)e1.getAttachedProperty("BookDetailWindowController_selectedBookCopy"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|MobileLibraryGUI::BookDetailWindowController/Event/addReservedToMember$eventChildLink,Forward,currMember,Library::Member,addCopyToCollect$copy");
	try {
		_error.addVariable("selectedBookCopy", e1.getAttachedProperty("BookDetailWindowController_selectedBookCopy"));
	} catch (Throwable _t) {
		_error.addVariable("selectedBookCopy", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("refreshBookCopiesData") && e2.entityName.equals("refreshItems") && linkProperty.entityName.equals("bookCopies") && paramName.equals("items")) {
try {
	return ((lu.uni.democles.runtime.OCLSequence)e1.getParameter("copiesData"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|MobileLibraryGUI::BookDetailWindowController/Event/refreshBookCopiesData$eventChildLink,Forward,bookCopies,GeneralGUI::SelectionList,refreshItems$items");
	try {
		_error.addVariable("copiesData", e1.getParameter("copiesData"));
	} catch (Throwable _t) {
		_error.addVariable("copiesData", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		return null;

	}
	private java.lang.Object __msg_eval() {
		try {
	return null;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::BookDetailWindowController/Property/msg");
	throw _error;
}

	}
	protected boolean guard_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse) {
		
		if (_event.entityName.equals("copyReserved") && _parent.entityName.equals("reserveOk") && _linkProperty.container.modelName.equals("generated.MobileLibraryGUI.BookDetailWindowController") && _linkProperty.entityName.equals("selectedBookCopy") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::BookDetailWindowController/Event/copyReserved$eventParentLink,Forward,selectedBookCopy,Library::Copy,reserveOk");
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("bookCopyItemSelected") && _parent.entityName.equals("itemSelected") && _linkProperty.container.modelName.equals("generated.MobileLibraryGUI.BookDetailWindowController") && _linkProperty.entityName.equals("bookCopies") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::BookDetailWindowController/Event/bookCopyItemSelected$eventParentLink,Forward,bookCopies,GeneralGUI::SelectionList,itemSelected");
	try {
		_error.addVariable("index", _parent.getParameter("index"));
	} catch (Throwable _t) {
		_error.addVariable("index", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("reserveConfAck") && _parent.entityName.equals("okClicked") && _linkProperty.container.modelName.equals("generated.MobileLibraryGUI.BookDetailWindowController") && _linkProperty.entityName.equals("yesNoMsg") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::BookDetailWindowController/Event/reserveConfAck$eventParentLink,Forward,yesNoMsg,GeneralGUI::ConfirmationDialog,okClicked");
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("reserveFailed") && _parent.entityName.equals("reserveFailed") && _linkProperty.container.modelName.equals("generated.MobileLibraryGUI.BookDetailWindowController") && _linkProperty.entityName.equals("selectedBookCopy") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::BookDetailWindowController/Event/reserveFailed$eventParentLink,Forward,selectedBookCopy,Library::Copy,reserveFailed");
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("reserveAck") && _parent.entityName.equals("okClicked") && _linkProperty.container.modelName.equals("generated.MobileLibraryGUI.BookDetailWindowController") && _linkProperty.entityName.equals("msg") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::BookDetailWindowController/Event/reserveAck$eventParentLink,Forward,msg,GeneralGUI::MsgDialog,okClicked");
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		return true;

	}
	public BookDetailWindowController() {
		super("generated.MobileLibraryGUI.BookDetailWindowController", new java.lang.String[] {  });

	}
	protected void resetNewVal() {
		this._p_bookTitleLabel.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_currBook.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_ackStatus.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_isbnLabel.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_bookAuthorLabel.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_currMember.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_authorLabel.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_windowTitle.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_titleLabel.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_selectedBookCopy.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_mode.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_window.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_bookIsbnLabel.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_getBookCopiesData.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_msg.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_bookCopies.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_yesNoMsg.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_bookCopiesLabel.newVal = lu.uni.democles.runtime.Entity.nullObject;
	}
	protected boolean guard_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final lu.uni.democles.runtime.Instance linkedInstance, final int _link) {
		if (e1.entityName.equals("refreshAndSave") && e2.entityName.equals("refreshItems") && linkProperty.container.modelName.equals("generated.MobileLibraryGUI.BookDetailWindowController") && linkProperty.entityName.equals("bookCopies")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::BookDetailWindowController/Event/refreshAndSave$eventChildLink,Forward,bookCopies,GeneralGUI::SelectionList,refreshItems");
	try {
		_error.addVariable("getBookCopiesData", e1.getAttachedProperty("BookDetailWindowController_getBookCopiesData"));
	} catch (Throwable _t) {
		_error.addVariable("getBookCopiesData", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("copyReserved") && e2.entityName.equals("showReserveOkMsg") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::BookDetailWindowController/Event/copyReserved$eventChildLink,Local,showReserveOkMsg");
	throw _error;
}
	}
if (e1.entityName.equals("copyReserved") && e2.entityName.equals("addReservedToMember") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::BookDetailWindowController/Event/copyReserved$eventChildLink,Local,addReservedToMember");
	throw _error;
}
	}

		if (e1.entityName.equals("reserveBookCopyNotOk") && e2.entityName.equals("showCannotReserveCopyMsg") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::BookDetailWindowController/Event/reserveBookCopyNotOk$eventChildLink,Local,showCannotReserveCopyMsg");
	throw _error;
}
	}

		if (e1.entityName.equals("bookCopyItemSelected") && e2.entityName.equals("showConfirmReserveMsg") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::BookDetailWindowController/Event/bookCopyItemSelected$eventChildLink,Local,showConfirmReserveMsg");
	try {
		_error.addVariable("index", e1.getParameter("index"));
	} catch (Throwable _t) {
		_error.addVariable("index", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("reserveConfAck") && e2.entityName.equals("reserveBookCopyOk") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::BookDetailWindowController/Event/reserveConfAck$eventChildLink,Local,reserveBookCopyOk");
	throw _error;
}
	}
if (e1.entityName.equals("reserveConfAck") && e2.entityName.equals("reserveBookCopyNotOk") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::BookDetailWindowController/Event/reserveConfAck$eventChildLink,Local,reserveBookCopyNotOk");
	throw _error;
}
	}

		if (e1.entityName.equals("reserveFailed") && e2.entityName.equals("showReserveFailedMsg") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::BookDetailWindowController/Event/reserveFailed$eventChildLink,Local,showReserveFailedMsg");
	throw _error;
}
	}

		if (e1.entityName.equals("addReservedToMember") && e2.entityName.equals("addCopyToCollect") && linkProperty.container.modelName.equals("generated.MobileLibraryGUI.BookDetailWindowController") && linkProperty.entityName.equals("currMember")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::BookDetailWindowController/Event/addReservedToMember$eventChildLink,Forward,currMember,Library::Member,addCopyToCollect");
	try {
		_error.addVariable("selectedBookCopy", e1.getAttachedProperty("BookDetailWindowController_selectedBookCopy"));
	} catch (Throwable _t) {
		_error.addVariable("selectedBookCopy", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("showReserveFailedMsg") && e2.entityName.equals("setToNotWaiting") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::BookDetailWindowController/Event/showReserveFailedMsg$eventChildLink,Local,setToNotWaiting");
	throw _error;
}
	}

		
		if (e1.entityName.equals("refreshBookCopiesData") && e2.entityName.equals("refreshItems") && linkProperty.container.modelName.equals("generated.MobileLibraryGUI.BookDetailWindowController") && linkProperty.entityName.equals("bookCopies")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::BookDetailWindowController/Event/refreshBookCopiesData$eventChildLink,Forward,bookCopies,GeneralGUI::SelectionList,refreshItems");
	try {
		_error.addVariable("copiesData", e1.getParameter("copiesData"));
	} catch (Throwable _t) {
		_error.addVariable("copiesData", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("reserveBookCopyOk") && e2.entityName.equals("reserve") && linkProperty.container.modelName.equals("generated.MobileLibraryGUI.BookDetailWindowController") && linkProperty.entityName.equals("selectedBookCopy")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::BookDetailWindowController/Event/reserveBookCopyOk$eventChildLink,Forward,selectedBookCopy,Library::Copy,reserve");
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (e1.entityName.equals("showCannotReserveCopyMsg") && e2.entityName.equals("setToNotWaiting") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::BookDetailWindowController/Event/showCannotReserveCopyMsg$eventChildLink,Local,setToNotWaiting");
	throw _error;
}
	}

		if (e1.entityName.equals("reserveAck") && e2.entityName.equals("refreshAndSave") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::BookDetailWindowController/Event/reserveAck$eventChildLink,Local,refreshAndSave");
	throw _error;
}
	}
if (e1.entityName.equals("reserveAck") && e2.entityName.equals("setToNotWaiting") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::BookDetailWindowController/Event/reserveAck$eventChildLink,Local,setToNotWaiting");
	throw _error;
}
	}

		return true;

	}
	private java.lang.Object _showReserveOkMsg_msg_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return (generated.GeneralGUI.MsgDialog.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "msg", (("A copy of book '" + ((java.lang.String)((lu.uni.democles.runtime.Property)((generated.Library.Book)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.BookDetailWindowController.this.getEntity("currBook")).evalInContainer().getValues().iterator().next()).getEntity("title")).evalInContainer().getValues().iterator().next())) + "' has been reserved and is now awaiting collection at your library."), "viewTitle", "Success!" }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|MobileLibraryGUI::BookDetailWindowController/Event/showReserveOkMsg-impacts-MobileLibraryGUI::BookDetailWindowController/Property/msg");
	throw _error;
}


	}
	public static BookDetailWindowController newWithValues(java.util.HashMap values) {
		BookDetailWindowController res = new BookDetailWindowController();
res.initialValues = new java.util.HashMap(values);
res.initProps();
return res;
	}
	protected void attachProperties(lu.uni.democles.runtime.Event e) {
		// Set Attached Properties:
if ("refreshAndSave".equals(e.entityName)) {
	e.attachProperty("BookDetailWindowController_getBookCopiesData", this._p_getBookCopiesData.evalInContainer());
}


		// Set Attached Properties:


		// Set Attached Properties:
if ("addReservedToMember".equals(e.entityName)) {
	e.attachProperty("BookDetailWindowController_selectedBookCopy", this._p_selectedBookCopy.evalInContainer().getValues().iterator().next());
}


	}
	private java.lang.Object __yesNoMsg_eval() {
		try {
	return null;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::BookDetailWindowController/Property/yesNoMsg");
	throw _error;
}

	}
	private java.lang.Object __bookCopies_eval() {
		try {
	return (generated.GeneralGUI.SelectionList.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "items", new lu.uni.democles.runtime.OCLSequence(new Object[] {}) }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::BookDetailWindowController/Property/bookCopies");
	throw _error;
}

	}
	private java.lang.Object __window_eval() {
		try {
	return (generated.GeneralGUI.Window.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "seqGUIElements", new lu.uni.democles.runtime.OCLSequence(new Object[] {((generated.GeneralGUI.Label)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.BookDetailWindowController.this.getEntity("titleLabel")).evalInContainer().getValues().iterator().next()), ((generated.GeneralGUI.Label)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.BookDetailWindowController.this.getEntity("bookTitleLabel")).evalInContainer().getValues().iterator().next()), ((generated.GeneralGUI.Label)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.BookDetailWindowController.this.getEntity("authorLabel")).evalInContainer().getValues().iterator().next()), ((generated.GeneralGUI.Label)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.BookDetailWindowController.this.getEntity("bookAuthorLabel")).evalInContainer().getValues().iterator().next()), ((generated.GeneralGUI.Label)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.BookDetailWindowController.this.getEntity("isbnLabel")).evalInContainer().getValues().iterator().next()), ((generated.GeneralGUI.Label)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.BookDetailWindowController.this.getEntity("bookIsbnLabel")).evalInContainer().getValues().iterator().next()), ((generated.GeneralGUI.Label)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.BookDetailWindowController.this.getEntity("bookCopiesLabel")).evalInContainer().getValues().iterator().next()), ((generated.GeneralGUI.SelectionList)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.BookDetailWindowController.this.getEntity("bookCopies")).evalInContainer().getValues().iterator().next())}), "title", ((java.lang.String)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.BookDetailWindowController.this.getEntity("windowTitle")).evalInContainer().getValues().iterator().next()) }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::BookDetailWindowController/Property/window");
	throw _error;
}

	}
	public void initProps() {
		if (this.isInitialized()) return;

		this._p_bookTitleLabel.oldVal = this.initialValues.containsKey("bookTitleLabel") ? this.initialValues.get("bookTitleLabel") : eval_p(this._p_bookTitleLabel).getValues().iterator().next();
this._p_bookTitleLabel.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_bookTitleLabel, this._p_bookTitleLabel.oldVal);

		this._p_currBook.oldVal = this.initialValues.containsKey("currBook") ? this.initialValues.get("currBook") : eval_p(this._p_currBook).getValues().iterator().next();
this._p_currBook.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_currBook, this._p_currBook.oldVal);

		this._p_ackStatus.oldVal = this.initialValues.containsKey("ackStatus") ? this.initialValues.get("ackStatus") : eval_p(this._p_ackStatus).getValues().iterator().next();
this._p_ackStatus.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_ackStatus, this._p_ackStatus.oldVal);

		this._p_isbnLabel.oldVal = this.initialValues.containsKey("isbnLabel") ? this.initialValues.get("isbnLabel") : eval_p(this._p_isbnLabel).getValues().iterator().next();
this._p_isbnLabel.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_isbnLabel, this._p_isbnLabel.oldVal);

		this._p_bookAuthorLabel.oldVal = this.initialValues.containsKey("bookAuthorLabel") ? this.initialValues.get("bookAuthorLabel") : eval_p(this._p_bookAuthorLabel).getValues().iterator().next();
this._p_bookAuthorLabel.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_bookAuthorLabel, this._p_bookAuthorLabel.oldVal);

		this._p_currMember.oldVal = this.initialValues.containsKey("currMember") ? this.initialValues.get("currMember") : eval_p(this._p_currMember).getValues().iterator().next();
this._p_currMember.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_currMember, this._p_currMember.oldVal);

		this._p_authorLabel.oldVal = this.initialValues.containsKey("authorLabel") ? this.initialValues.get("authorLabel") : eval_p(this._p_authorLabel).getValues().iterator().next();
this._p_authorLabel.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_authorLabel, this._p_authorLabel.oldVal);

		this._p_windowTitle.oldVal = this.initialValues.containsKey("windowTitle") ? this.initialValues.get("windowTitle") : eval_p(this._p_windowTitle).getValues().iterator().next();
this._p_windowTitle.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_windowTitle, this._p_windowTitle.oldVal);

		this._p_titleLabel.oldVal = this.initialValues.containsKey("titleLabel") ? this.initialValues.get("titleLabel") : eval_p(this._p_titleLabel).getValues().iterator().next();
this._p_titleLabel.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_titleLabel, this._p_titleLabel.oldVal);

		this._p_selectedBookCopy.oldVal = this.initialValues.containsKey("selectedBookCopy") ? this.initialValues.get("selectedBookCopy") : eval_p(this._p_selectedBookCopy).getValues().iterator().next();
this._p_selectedBookCopy.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_selectedBookCopy, this._p_selectedBookCopy.oldVal);

		this._p_mode.oldVal = this.initialValues.containsKey("mode") ? this.initialValues.get("mode") : eval_p(this._p_mode).getValues().iterator().next();
this._p_mode.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_mode, this._p_mode.oldVal);

		this._p_window.oldVal = this.initialValues.containsKey("window") ? this.initialValues.get("window") : eval_p(this._p_window).getValues().iterator().next();
this._p_window.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_window, this._p_window.oldVal);

		this._p_bookIsbnLabel.oldVal = this.initialValues.containsKey("bookIsbnLabel") ? this.initialValues.get("bookIsbnLabel") : eval_p(this._p_bookIsbnLabel).getValues().iterator().next();
this._p_bookIsbnLabel.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_bookIsbnLabel, this._p_bookIsbnLabel.oldVal);

		this._p_msg.oldVal = this.initialValues.containsKey("msg") ? this.initialValues.get("msg") : eval_p(this._p_msg).getValues().iterator().next();
this._p_msg.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_msg, this._p_msg.oldVal);

		this._p_bookCopies.oldVal = this.initialValues.containsKey("bookCopies") ? this.initialValues.get("bookCopies") : eval_p(this._p_bookCopies).getValues().iterator().next();
this._p_bookCopies.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_bookCopies, this._p_bookCopies.oldVal);

		this._p_yesNoMsg.oldVal = this.initialValues.containsKey("yesNoMsg") ? this.initialValues.get("yesNoMsg") : eval_p(this._p_yesNoMsg).getValues().iterator().next();
this._p_yesNoMsg.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_yesNoMsg, this._p_yesNoMsg.oldVal);

		this._p_bookCopiesLabel.oldVal = this.initialValues.containsKey("bookCopiesLabel") ? this.initialValues.get("bookCopiesLabel") : eval_p(this._p_bookCopiesLabel).getValues().iterator().next();
this._p_bookCopiesLabel.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_bookCopiesLabel, this._p_bookCopiesLabel.oldVal);

		this.setInitialized();
this.initialValues = new java.util.HashMap();


	}
	private java.lang.Object __windowTitle_eval() {
		try {
	return "Book Detail";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::BookDetailWindowController/Property/windowTitle");
	throw _error;
}

	}
	private java.lang.Object _memberSessionStarted_mode_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return "LoggedIn";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|MobileLibraryGUI::BookDetailWindowController/Event/memberSessionStarted-impacts-MobileLibraryGUI::BookDetailWindowController/Property/mode");
	try {
		_error.addVariable("m", _event.getParameter("m"));
	} catch (Throwable _t) {
		_error.addVariable("m", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	protected void set(lu.uni.democles.runtime.Property p, java.lang.Object v) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) {
	throw new lu.uni.democles.runtime.MultipleModificationException(p.toString());
}
p.newVal = v;
		super.set(p, v);
	}
	private java.lang.Object _showCannotReserveCopyMsg_msg_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return (generated.GeneralGUI.MsgDialog.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "msg", "Not possible to reserve the selected copy. No user is logged-in!", "viewTitle", "Error!" }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|MobileLibraryGUI::BookDetailWindowController/Event/showCannotReserveCopyMsg-impacts-MobileLibraryGUI::BookDetailWindowController/Property/msg");
	throw _error;
}


	}
	private java.lang.Object __bookTitleLabel_eval() {
		try {
	return null;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::BookDetailWindowController/Property/bookTitleLabel");
	throw _error;
}

	}
	protected java.lang.Object evalQuery(lu.uni.democles.runtime.Property p) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) return p.newVal;

if (p.isEvaluating()) throw new lu.uni.democles.runtime.ModificationCycleException();

p.setEvaluating(true);
java.lang.Object o = null;


		if ("bookTitleLabel".equals(p.entityName)) {
	o = __bookTitleLabel_eval();
	set(p, o);
}

		if ("currBook".equals(p.entityName)) {
	o = __currBook_eval();
	set(p, o);
}

		if ("ackStatus".equals(p.entityName)) {
	o = __ackStatus_eval();
	set(p, o);
}

		if ("isbnLabel".equals(p.entityName)) {
	o = __isbnLabel_eval();
	set(p, o);
}

		if ("bookAuthorLabel".equals(p.entityName)) {
	o = __bookAuthorLabel_eval();
	set(p, o);
}

		if ("currMember".equals(p.entityName)) {
	o = __currMember_eval();
	set(p, o);
}

		if ("authorLabel".equals(p.entityName)) {
	o = __authorLabel_eval();
	set(p, o);
}

		if ("windowTitle".equals(p.entityName)) {
	o = __windowTitle_eval();
	set(p, o);
}

		if ("titleLabel".equals(p.entityName)) {
	o = __titleLabel_eval();
	set(p, o);
}

		if ("selectedBookCopy".equals(p.entityName)) {
	o = __selectedBookCopy_eval();
	set(p, o);
}

		if ("mode".equals(p.entityName)) {
	o = __mode_eval();
	set(p, o);
}

		if ("window".equals(p.entityName)) {
	o = __window_eval();
	set(p, o);
}

		if ("bookIsbnLabel".equals(p.entityName)) {
	o = __bookIsbnLabel_eval();
	set(p, o);
}

		if ("getBookCopiesData".equals(p.entityName)) {
	o = __getBookCopiesData_eval();
	set(p, o);
}

		if ("msg".equals(p.entityName)) {
	o = __msg_eval();
	set(p, o);
}

		if ("bookCopies".equals(p.entityName)) {
	o = __bookCopies_eval();
	set(p, o);
}

		if ("yesNoMsg".equals(p.entityName)) {
	o = __yesNoMsg_eval();
	set(p, o);
}

		if ("bookCopiesLabel".equals(p.entityName)) {
	o = __bookCopiesLabel_eval();
	set(p, o);
}

		if (o instanceof lu.uni.democles.runtime.Instance) {
	((lu.uni.democles.runtime.Instance)o).initProps();
} else if (o instanceof lu.uni.democles.runtime.OCLCollection) {
	for (java.util.Iterator iter = ((lu.uni.democles.runtime.OCLCollection)o).getValues().iterator(); iter.hasNext();) {
		java.lang.Object entry = iter.next();
		if (entry instanceof lu.uni.democles.runtime.Instance) {
			((lu.uni.democles.runtime.Instance)entry).initProps();
		}
	}
}
p.setEvaluating(false);
return o;


	}
	private java.lang.Object __selectedBookCopy_eval() {
		try {
	return null;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::BookDetailWindowController/Property/selectedBookCopy");
	throw _error;
}

	}
	protected void doModify(lu.uni.democles.runtime.Event event) {
		if ("showReserveOkMsg".equals(event.entityName)) {
	handleImpact(event, this._p_ackStatus);
}
if ("showCannotReserveCopyMsg".equals(event.entityName)) {
	handleImpact(event, this._p_msg);
}
if ("showConfirmReserveMsg".equals(event.entityName)) {
	handleImpact(event, this._p_yesNoMsg);
}
if ("setToNotWaiting".equals(event.entityName)) {
	handleImpact(event, this._p_ackStatus);
}
if ("showReserveFailedMsg".equals(event.entityName)) {
	handleImpact(event, this._p_msg);
}
if ("bookCopyItemSelected".equals(event.entityName)) {
	handleImpact(event, this._p_selectedBookCopy);
}
if ("showReserveOkMsg".equals(event.entityName)) {
	handleImpact(event, this._p_msg);
}
if ("memberSessionStarted".equals(event.entityName)) {
	handleImpact(event, this._p_mode);
}
if ("memberSessionStarted".equals(event.entityName)) {
	handleImpact(event, this._p_currMember);
}

	}
	public static void main(String[] args) {
	}
	private java.lang.Object _showConfirmReserveMsg_yesNoMsg_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return (generated.GeneralGUI.ConfirmationDialog.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "title", "Confirm", "message", "Would you like to reserve the selected book copy?" }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|MobileLibraryGUI::BookDetailWindowController/Event/showConfirmReserveMsg-impacts-MobileLibraryGUI::BookDetailWindowController/Property/yesNoMsg");
	throw _error;
}


	}
	private void handleImpact(lu.uni.democles.runtime.Event e, lu.uni.democles.runtime.Property p) {
		set(p, eval_ep(e, p));
	}
	private java.lang.Object __bookAuthorLabel_eval() {
		try {
	return null;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::BookDetailWindowController/Property/bookAuthorLabel");
	throw _error;
}

	}
	private java.lang.Object eval_ep(final lu.uni.democles.runtime.Event e, final lu.uni.democles.runtime.Property p) {
		if (p.entityName.equals(this._p_ackStatus.entityName) && e.entityName.equals(this._e_showReserveOkMsg.entityName)) {
	return _showReserveOkMsg_ackStatus_eval(e);
}
		if (p.entityName.equals(this._p_msg.entityName) && e.entityName.equals(this._e_showReserveFailedMsg.entityName)) {
	return _showReserveFailedMsg_msg_eval(e);
}
		if (p.entityName.equals(this._p_selectedBookCopy.entityName) && e.entityName.equals(this._e_bookCopyItemSelected.entityName)) {
	return _bookCopyItemSelected_selectedBookCopy_eval(e);
}
		if (p.entityName.equals(this._p_msg.entityName) && e.entityName.equals(this._e_showCannotReserveCopyMsg.entityName)) {
	return _showCannotReserveCopyMsg_msg_eval(e);
}
		if (p.entityName.equals(this._p_yesNoMsg.entityName) && e.entityName.equals(this._e_showConfirmReserveMsg.entityName)) {
	return _showConfirmReserveMsg_yesNoMsg_eval(e);
}
		if (p.entityName.equals(this._p_ackStatus.entityName) && e.entityName.equals(this._e_setToNotWaiting.entityName)) {
	return _setToNotWaiting_ackStatus_eval(e);
}
		if (p.entityName.equals(this._p_mode.entityName) && e.entityName.equals(this._e_memberSessionStarted.entityName)) {
	return _memberSessionStarted_mode_eval(e);
}
		if (p.entityName.equals(this._p_currMember.entityName) && e.entityName.equals(this._e_memberSessionStarted.entityName)) {
	return _memberSessionStarted_currMember_eval(e);
}
		if (p.entityName.equals(this._p_msg.entityName) && e.entityName.equals(this._e_showReserveOkMsg.entityName)) {
	return _showReserveOkMsg_msg_eval(e);
}
		return null;

	}
	private java.lang.Object __authorLabel_eval() {
		try {
	return (generated.GeneralGUI.Label.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "text", "Authors: " }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::BookDetailWindowController/Property/authorLabel");
	throw _error;
}

	}
	private java.lang.Object __isbnLabel_eval() {
		try {
	return (generated.GeneralGUI.Label.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "text", "ISBN: " }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::BookDetailWindowController/Property/isbnLabel");
	throw _error;
}

	}
	private java.lang.Object __bookCopiesLabel_eval() {
		try {
	return (generated.GeneralGUI.Label.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "text", "Copies of books available in the library:" }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::BookDetailWindowController/Property/bookCopiesLabel");
	throw _error;
}

	}
	private java.lang.Object __getBookCopiesData_eval() {
		try {
	return (((lu.uni.democles.runtime.OCLBag)((lu.uni.democles.runtime.OCLSet)((lu.uni.democles.runtime.Property)((generated.Library.Book)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.BookDetailWindowController.this.getEntity("currBook")).evalInContainer().getValues().iterator().next()).getEntity("copies")).evalInContainer()).collect(new lu.uni.democles.runtime.Function() {
	public Object _iteration(Object _value) {
final generated.Library.Copy v_temp1 = ((generated.Library.Copy)_value);
return _asObject(((((((java.lang.String)((lu.uni.democles.runtime.Property)v_temp1.getEntity("copyId")).evalInContainer().getValues().iterator().next()) + " ") + ((java.lang.String)((lu.uni.democles.runtime.Property)v_temp1.getEntity("state")).evalInContainer().getValues().iterator().next())) + " ") + ((java.lang.String)((lu.uni.democles.runtime.Property)v_temp1.getEntity("dueDate")).evalInContainer().getValues().iterator().next())));
	}
})).asSequence());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::BookDetailWindowController/Property/getBookCopiesData");
	throw _error;
}

	}
	private java.lang.Object _showReserveOkMsg_ackStatus_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return "WaitingReserveAck";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|MobileLibraryGUI::BookDetailWindowController/Event/showReserveOkMsg-impacts-MobileLibraryGUI::BookDetailWindowController/Property/ackStatus");
	throw _error;
}


	}
}
