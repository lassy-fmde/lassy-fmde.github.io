package generated.MobileLibraryGUI;

public class LoginWindowController extends lu.uni.democles.runtime.Instance {
	private lu.uni.democles.runtime.Property _p_libraryNoLabel = new lu.uni.democles.runtime.Property(this, "libraryNoLabel", "LoginWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_ackStatus = new lu.uni.democles.runtime.Property(this, "ackStatus", "LoginWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_currMsg = new lu.uni.democles.runtime.Property(this, "currMsg", "LoginWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_sessionOpened = new lu.uni.democles.runtime.Event(this, "sessionOpened", "LoginWindowController", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.MobileLibraryGUI.LoginWindowController", "showLoginSucessfulMsg", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Event _e_setToNotWaiting = new lu.uni.democles.runtime.Event(this, "setToNotWaiting", "LoginWindowController", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_openSession = new lu.uni.democles.runtime.Event(this, "openSession", "LoginWindowController", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.GeneralGUI.Button", "loginButton", "clicked", new java.lang.String[] {"libNo", "password"}) }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Property _p_passwordField = new lu.uni.democles.runtime.Property(this, "passwordField", "LoginWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_showLoginSucessfulMsg = new lu.uni.democles.runtime.Event(this, "showLoginSucessfulMsg", "LoginWindowController", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Property _p_frame = new lu.uni.democles.runtime.Property(this, "frame", "LoginWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_loginFailed = new lu.uni.democles.runtime.Event(this, "loginFailed", "LoginWindowController", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.MobileLibraryGUI.LoginWindowController", "showInvalidLoginMsg", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Event _e_showInvalidLoginMsg = new lu.uni.democles.runtime.Event(this, "showInvalidLoginMsg", "LoginWindowController", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Property _p_getPassword = new lu.uni.democles.runtime.Property(this, "getPassword", "LoginWindowController", "Query", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_loginConfirmed = new lu.uni.democles.runtime.Event(this, "loginConfirmed", "LoginWindowController", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Property _p_passwordLabel = new lu.uni.democles.runtime.Property(this, "passwordLabel", "LoginWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_libraryNoField = new lu.uni.democles.runtime.Property(this, "libraryNoField", "LoginWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_loginAck = new lu.uni.democles.runtime.Event(this, "loginAck", "LoginWindowController", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.GeneralGUI.MsgDialog", "currMsg", "okClicked", new java.lang.String[] {}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.MobileLibraryGUI.LoginWindowController", "setToNotWaiting", new java.lang.String[] {}), new lu.uni.democles.runtime.ChildLink(true, "", "generated.MobileLibraryGUI.LoginWindowController", "loginConfirmed", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Property _p_title = new lu.uni.democles.runtime.Property(this, "title", "LoginWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_getLibraryNo = new lu.uni.democles.runtime.Property(this, "getLibraryNo", "LoginWindowController", "Query", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_loginButton = new lu.uni.democles.runtime.Property(this, "loginButton", "LoginWindowController", "Local", false, false, null, "single");
	protected boolean guard_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse) {
		
		if (_event.entityName.equals("loginAck") && _parent.entityName.equals("okClicked") && _linkProperty.container.modelName.equals("generated.MobileLibraryGUI.LoginWindowController") && _linkProperty.entityName.equals("currMsg") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::LoginWindowController/Event/loginAck$eventParentLink,Forward,currMsg,GeneralGUI::MsgDialog,okClicked");
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		if (_event.entityName.equals("openSession") && _parent.entityName.equals("clicked") && _linkProperty.container.modelName.equals("generated.MobileLibraryGUI.LoginWindowController") && _linkProperty.entityName.equals("loginButton") && _inverse == false) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::LoginWindowController/Event/openSession$eventParentLink,Forward,loginButton,GeneralGUI::Button,clicked");
	try {
		_error.addVariable("passwordField", _parent.getAttachedProperty("LoginWindowController_passwordField"));
	} catch (Throwable _t) {
		_error.addVariable("passwordField", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("libraryNoField", _parent.getAttachedProperty("LoginWindowController_libraryNoField"));
	} catch (Throwable _t) {
		_error.addVariable("libraryNoField", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("libNo", _parent.getParameter("libNo"));
	} catch (Throwable _t) {
		_error.addVariable("libNo", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("password", _parent.getParameter("password"));
	} catch (Throwable _t) {
		_error.addVariable("password", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", _linkProperty.container);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		return true;

	}
	protected void attachProperties(lu.uni.democles.runtime.Event e) {
		// Set Attached Properties:


		// Set Attached Properties:
if ("openSession".equals(e.entityName)) {
	e.attachProperty("LoginWindowController_passwordField", this._p_passwordField.evalInContainer().getValues().iterator().next());
	e.attachProperty("LoginWindowController_libraryNoField", this._p_libraryNoField.evalInContainer().getValues().iterator().next());
}


	}
	private java.lang.Object eval_ep(final lu.uni.democles.runtime.Event e, final lu.uni.democles.runtime.Property p) {
		if (p.entityName.equals(this._p_currMsg.entityName) && e.entityName.equals(this._e_showInvalidLoginMsg.entityName)) {
	return _showInvalidLoginMsg_currMsg_eval(e);
}
		if (p.entityName.equals(this._p_ackStatus.entityName) && e.entityName.equals(this._e_showLoginSucessfulMsg.entityName)) {
	return _showLoginSucessfulMsg_ackStatus_eval(e);
}
		if (p.entityName.equals(this._p_currMsg.entityName) && e.entityName.equals(this._e_showLoginSucessfulMsg.entityName)) {
	return _showLoginSucessfulMsg_currMsg_eval(e);
}
		if (p.entityName.equals(this._p_ackStatus.entityName) && e.entityName.equals(this._e_setToNotWaiting.entityName)) {
	return _setToNotWaiting_ackStatus_eval(e);
}
		return null;

	}
	private java.lang.Object __libraryNoField_eval() {
		try {
	return (generated.GeneralGUI.Textfield.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "text", "" }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::LoginWindowController/Property/libraryNoField");
	throw _error;
}

	}
	private java.lang.Object _showLoginSucessfulMsg_ackStatus_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return "WaitingLoginAck";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|MobileLibraryGUI::LoginWindowController/Event/showLoginSucessfulMsg-impacts-MobileLibraryGUI::LoginWindowController/Property/ackStatus");
	throw _error;
}


	}
	protected java.lang.Object evalQuery(lu.uni.democles.runtime.Property p) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) return p.newVal;

if (p.isEvaluating()) throw new lu.uni.democles.runtime.ModificationCycleException();

p.setEvaluating(true);
java.lang.Object o = null;


		if ("currMsg".equals(p.entityName)) {
	o = __currMsg_eval();
	set(p, o);
}

		if ("getLibraryNo".equals(p.entityName)) {
	o = __getLibraryNo_eval();
	set(p, o);
}

		if ("loginButton".equals(p.entityName)) {
	o = __loginButton_eval();
	set(p, o);
}

		if ("title".equals(p.entityName)) {
	o = __title_eval();
	set(p, o);
}

		if ("libraryNoLabel".equals(p.entityName)) {
	o = __libraryNoLabel_eval();
	set(p, o);
}

		if ("libraryNoField".equals(p.entityName)) {
	o = __libraryNoField_eval();
	set(p, o);
}

		if ("passwordLabel".equals(p.entityName)) {
	o = __passwordLabel_eval();
	set(p, o);
}

		if ("passwordField".equals(p.entityName)) {
	o = __passwordField_eval();
	set(p, o);
}

		if ("getPassword".equals(p.entityName)) {
	o = __getPassword_eval();
	set(p, o);
}

		if ("frame".equals(p.entityName)) {
	o = __frame_eval();
	set(p, o);
}

		if ("ackStatus".equals(p.entityName)) {
	o = __ackStatus_eval();
	set(p, o);
}

		if (o instanceof lu.uni.democles.runtime.Instance) {
	((lu.uni.democles.runtime.Instance)o).initProps();
} else if (o instanceof lu.uni.democles.runtime.OCLCollection) {
	for (java.util.Iterator iter = ((lu.uni.democles.runtime.OCLCollection)o).getValues().iterator(); iter.hasNext();) {
		java.lang.Object entry = iter.next();
		if (entry instanceof lu.uni.democles.runtime.Instance) {
			((lu.uni.democles.runtime.Instance)entry).initProps();
		}
	}
}
p.setEvaluating(false);
return o;


	}
	public static void main(String[] args) {
	}
	private java.lang.Object __ackStatus_eval() {
		try {
	return "NotWaiting";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::LoginWindowController/Property/ackStatus");
	throw _error;
}

	}
	private java.lang.Object _setToNotWaiting_ackStatus_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return "NotWaiting";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|MobileLibraryGUI::LoginWindowController/Event/setToNotWaiting-impacts-MobileLibraryGUI::LoginWindowController/Property/ackStatus");
	throw _error;
}


	}
	private java.lang.Object __passwordLabel_eval() {
		try {
	return (generated.GeneralGUI.Label.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "text", "Password:" }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::LoginWindowController/Property/passwordLabel");
	throw _error;
}

	}
	protected java.lang.Object eval_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse, final java.lang.String _paramName) {
		
		if (_parent.entityName.equals("clicked") && _event.entityName.equals("openSession") && _linkProperty.entityName.equals("loginButton") && _inverse == false && _paramName.equals("libNo")) {
try {
	return ((java.lang.String)((lu.uni.democles.runtime.Property)((generated.GeneralGUI.Textfield)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.LoginWindowController.this.getEntity("libraryNoField")).evalInContainer().getValues().iterator().next()).getEntity("text")).evalInContainer().getValues().iterator().next());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|MobileLibraryGUI::LoginWindowController/Event/openSession$eventParentLink,Forward,loginButton,GeneralGUI::Button,clicked$libNo");
	throw _error;
}
}
if (_parent.entityName.equals("clicked") && _event.entityName.equals("openSession") && _linkProperty.entityName.equals("loginButton") && _inverse == false && _paramName.equals("password")) {
try {
	return ((java.lang.String)((lu.uni.democles.runtime.Property)((generated.GeneralGUI.Textfield)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.LoginWindowController.this.getEntity("passwordField")).evalInContainer().getValues().iterator().next()).getEntity("text")).evalInContainer().getValues().iterator().next());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|MobileLibraryGUI::LoginWindowController/Event/openSession$eventParentLink,Forward,loginButton,GeneralGUI::Button,clicked$password");
	throw _error;
}
}

		return null;

	}
	protected void resetNewVal() {
		this._p_currMsg.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_getLibraryNo.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_loginButton.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_title.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_libraryNoLabel.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_libraryNoField.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_passwordLabel.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_passwordField.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_getPassword.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_frame.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_ackStatus.newVal = lu.uni.democles.runtime.Entity.nullObject;
	}
	private void handleImpact(lu.uni.democles.runtime.Event e, lu.uni.democles.runtime.Property p) {
		set(p, eval_ep(e, p));
	}
	private java.lang.Object __title_eval() {
		try {
	return "Login";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::LoginWindowController/Property/title");
	throw _error;
}

	}
	private java.lang.Object __getLibraryNo_eval() {
		try {
	return ((java.lang.String)((lu.uni.democles.runtime.Property)((generated.GeneralGUI.Textfield)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.LoginWindowController.this.getEntity("libraryNoField")).evalInContainer().getValues().iterator().next()).getEntity("text")).evalInContainer().getValues().iterator().next());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::LoginWindowController/Property/getLibraryNo");
	throw _error;
}

	}
	private java.lang.Object __getPassword_eval() {
		try {
	return ((java.lang.String)((lu.uni.democles.runtime.Property)((generated.GeneralGUI.Textfield)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.LoginWindowController.this.getEntity("passwordField")).evalInContainer().getValues().iterator().next()).getEntity("text")).evalInContainer().getValues().iterator().next());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::LoginWindowController/Property/getPassword");
	throw _error;
}

	}
	protected boolean guard_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final lu.uni.democles.runtime.Instance linkedInstance, final int _link) {
		
		if (e1.entityName.equals("loginAck") && e2.entityName.equals("setToNotWaiting") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::LoginWindowController/Event/loginAck$eventChildLink,Local,setToNotWaiting");
	throw _error;
}
	}
if (e1.entityName.equals("loginAck") && e2.entityName.equals("loginConfirmed") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::LoginWindowController/Event/loginAck$eventChildLink,Local,loginConfirmed");
	throw _error;
}
	}

		if (e1.entityName.equals("sessionOpened") && e2.entityName.equals("showLoginSucessfulMsg") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::LoginWindowController/Event/sessionOpened$eventChildLink,Local,showLoginSucessfulMsg");
	throw _error;
}
	}

		if (e1.entityName.equals("loginFailed") && e2.entityName.equals("showInvalidLoginMsg") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::LoginWindowController/Event/loginFailed$eventChildLink,Local,showInvalidLoginMsg");
	throw _error;
}
	}

		return true;

	}
	protected void doModify(lu.uni.democles.runtime.Event event) {
		if ("setToNotWaiting".equals(event.entityName)) {
	handleImpact(event, this._p_ackStatus);
}
if ("showLoginSucessfulMsg".equals(event.entityName)) {
	handleImpact(event, this._p_currMsg);
}
if ("showLoginSucessfulMsg".equals(event.entityName)) {
	handleImpact(event, this._p_ackStatus);
}
if ("showInvalidLoginMsg".equals(event.entityName)) {
	handleImpact(event, this._p_currMsg);
}

	}
	private java.lang.Object __loginButton_eval() {
		try {
	return (generated.GeneralGUI.Button.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "text", "Login" }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::LoginWindowController/Property/loginButton");
	throw _error;
}

	}
	private java.lang.Object __currMsg_eval() {
		try {
	return null;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::LoginWindowController/Property/currMsg");
	throw _error;
}

	}
	private java.lang.Object _showInvalidLoginMsg_currMsg_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return (generated.GeneralGUI.MsgDialog.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "msg", "Invalid Library Number  or wrong password!", "viewTitle", "Error!" }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|MobileLibraryGUI::LoginWindowController/Event/showInvalidLoginMsg-impacts-MobileLibraryGUI::LoginWindowController/Property/currMsg");
	throw _error;
}


	}
	protected boolean guard(final lu.uni.democles.runtime.Event e1) {
		
			if ("loginAck".equals(e1.entityName)) {
try {
	return (lu.uni.democles.runtime.Function._equals(((java.lang.String)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.LoginWindowController.this.getEntity("ackStatus")).evalInContainer().getValues().iterator().next()), "WaitingLoginAck"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_GUARD|MobileLibraryGUI::LoginWindowController/Event/loginAck");
	throw _error;
}
	}

		return true;

	}
	public static LoginWindowController newWithValues(java.util.HashMap values) {
		LoginWindowController res = new LoginWindowController();
res.initialValues = new java.util.HashMap(values);
res.initProps();
return res;
	}
	private java.lang.Object _showLoginSucessfulMsg_currMsg_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return (generated.GeneralGUI.MsgDialog.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "msg", "You are now logged into the library!", "viewTitle", "Success!" }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|MobileLibraryGUI::LoginWindowController/Event/showLoginSucessfulMsg-impacts-MobileLibraryGUI::LoginWindowController/Property/currMsg");
	throw _error;
}


	}
	private java.lang.Object __libraryNoLabel_eval() {
		try {
	return (generated.GeneralGUI.Label.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "text", "Library No:" }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::LoginWindowController/Property/libraryNoLabel");
	throw _error;
}

	}
	protected void set(lu.uni.democles.runtime.Property p, java.lang.Object v) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) {
	throw new lu.uni.democles.runtime.MultipleModificationException(p.toString());
}
p.newVal = v;
		super.set(p, v);
	}
	private java.lang.Object __passwordField_eval() {
		try {
	return (generated.GeneralGUI.Textfield.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "text", "" }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::LoginWindowController/Property/passwordField");
	throw _error;
}

	}
	protected java.lang.Object eval_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final java.lang.String paramName, final int _link) {
		
		return null;

	}
	public void initProps() {
		if (this.isInitialized()) return;

		this._p_currMsg.oldVal = this.initialValues.containsKey("currMsg") ? this.initialValues.get("currMsg") : eval_p(this._p_currMsg).getValues().iterator().next();
this._p_currMsg.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_currMsg, this._p_currMsg.oldVal);

		this._p_loginButton.oldVal = this.initialValues.containsKey("loginButton") ? this.initialValues.get("loginButton") : eval_p(this._p_loginButton).getValues().iterator().next();
this._p_loginButton.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_loginButton, this._p_loginButton.oldVal);

		this._p_title.oldVal = this.initialValues.containsKey("title") ? this.initialValues.get("title") : eval_p(this._p_title).getValues().iterator().next();
this._p_title.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_title, this._p_title.oldVal);

		this._p_libraryNoLabel.oldVal = this.initialValues.containsKey("libraryNoLabel") ? this.initialValues.get("libraryNoLabel") : eval_p(this._p_libraryNoLabel).getValues().iterator().next();
this._p_libraryNoLabel.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_libraryNoLabel, this._p_libraryNoLabel.oldVal);

		this._p_libraryNoField.oldVal = this.initialValues.containsKey("libraryNoField") ? this.initialValues.get("libraryNoField") : eval_p(this._p_libraryNoField).getValues().iterator().next();
this._p_libraryNoField.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_libraryNoField, this._p_libraryNoField.oldVal);

		this._p_passwordLabel.oldVal = this.initialValues.containsKey("passwordLabel") ? this.initialValues.get("passwordLabel") : eval_p(this._p_passwordLabel).getValues().iterator().next();
this._p_passwordLabel.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_passwordLabel, this._p_passwordLabel.oldVal);

		this._p_passwordField.oldVal = this.initialValues.containsKey("passwordField") ? this.initialValues.get("passwordField") : eval_p(this._p_passwordField).getValues().iterator().next();
this._p_passwordField.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_passwordField, this._p_passwordField.oldVal);

		this._p_frame.oldVal = this.initialValues.containsKey("frame") ? this.initialValues.get("frame") : eval_p(this._p_frame).getValues().iterator().next();
this._p_frame.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_frame, this._p_frame.oldVal);

		this._p_ackStatus.oldVal = this.initialValues.containsKey("ackStatus") ? this.initialValues.get("ackStatus") : eval_p(this._p_ackStatus).getValues().iterator().next();
this._p_ackStatus.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_ackStatus, this._p_ackStatus.oldVal);

		this.setInitialized();
this.initialValues = new java.util.HashMap();


	}
	public LoginWindowController() {
		super("generated.MobileLibraryGUI.LoginWindowController", new java.lang.String[] {  });

	}
	private java.lang.Object __frame_eval() {
		try {
	return (generated.GeneralGUI.Frame.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "seqGUIElements", new lu.uni.democles.runtime.OCLSequence(new Object[] {((generated.GeneralGUI.Label)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.LoginWindowController.this.getEntity("libraryNoLabel")).evalInContainer().getValues().iterator().next()), ((generated.GeneralGUI.Textfield)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.LoginWindowController.this.getEntity("libraryNoField")).evalInContainer().getValues().iterator().next()), ((generated.GeneralGUI.Label)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.LoginWindowController.this.getEntity("passwordLabel")).evalInContainer().getValues().iterator().next()), ((generated.GeneralGUI.Textfield)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.LoginWindowController.this.getEntity("passwordField")).evalInContainer().getValues().iterator().next()), ((generated.GeneralGUI.Button)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.LoginWindowController.this.getEntity("loginButton")).evalInContainer().getValues().iterator().next())}), "frameTitle", ((java.lang.String)((lu.uni.democles.runtime.Property)generated.MobileLibraryGUI.LoginWindowController.this.getEntity("title")).evalInContainer().getValues().iterator().next()), "iconFilename", "icon-house.png" }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::LoginWindowController/Property/frame");
	throw _error;
}

	}
}
