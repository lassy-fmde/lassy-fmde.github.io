package generated.MobileLibraryGUI;

public class ViewsWindowController extends lu.uni.democles.runtime.Instance {
	private lu.uni.democles.runtime.Property _p_viewsWindow = new lu.uni.democles.runtime.Property(this, "viewsWindow", "ViewsWindowController", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_changeFromLoginToMember = new lu.uni.democles.runtime.Event(this, "changeFromLoginToMember", "ViewsWindowController", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "viewsWindow", "generated.GeneralGUI.TabbedWindow", "changeView", new java.lang.String[] {"index", "view"}) });
	private lu.uni.democles.runtime.Event _e_startViewsWindow = new lu.uni.democles.runtime.Event(this, "startViewsWindow", "ViewsWindowController", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	protected boolean guard_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse) {
		
		return true;

	}
	protected void attachProperties(lu.uni.democles.runtime.Event e) {
		// Set Attached Properties:


	}
	private java.lang.Object eval_ep(final lu.uni.democles.runtime.Event e, final lu.uni.democles.runtime.Property p) {
		if (p.entityName.equals(this._p_viewsWindow.entityName) && e.entityName.equals(this._e_startViewsWindow.entityName)) {
	return _startViewsWindow_viewsWindow_eval(e);
}
		return null;

	}
	protected java.lang.Object evalQuery(lu.uni.democles.runtime.Property p) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) return p.newVal;

if (p.isEvaluating()) throw new lu.uni.democles.runtime.ModificationCycleException();

p.setEvaluating(true);
java.lang.Object o = null;


		if ("viewsWindow".equals(p.entityName)) {
	o = __viewsWindow_eval();
	set(p, o);
}

		if (o instanceof lu.uni.democles.runtime.Instance) {
	((lu.uni.democles.runtime.Instance)o).initProps();
} else if (o instanceof lu.uni.democles.runtime.OCLCollection) {
	for (java.util.Iterator iter = ((lu.uni.democles.runtime.OCLCollection)o).getValues().iterator(); iter.hasNext();) {
		java.lang.Object entry = iter.next();
		if (entry instanceof lu.uni.democles.runtime.Instance) {
			((lu.uni.democles.runtime.Instance)entry).initProps();
		}
	}
}
p.setEvaluating(false);
return o;


	}
	public static void main(String[] args) {
	}
	protected java.lang.Object eval_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse, final java.lang.String _paramName) {
		
		return null;

	}
	protected void resetNewVal() {
		this._p_viewsWindow.newVal = lu.uni.democles.runtime.Entity.nullObject;
	}
	public ViewsWindowController() {
		super("generated.MobileLibraryGUI.ViewsWindowController", new java.lang.String[] {  });

	}
	private void handleImpact(lu.uni.democles.runtime.Event e, lu.uni.democles.runtime.Property p) {
		set(p, eval_ep(e, p));
	}
	private java.lang.Object __viewsWindow_eval() {
		try {
	return null;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|MobileLibraryGUI::ViewsWindowController/Property/viewsWindow");
	throw _error;
}

	}
	public static ViewsWindowController newWithValues(java.util.HashMap values) {
		ViewsWindowController res = new ViewsWindowController();
res.initialValues = new java.util.HashMap(values);
res.initProps();
return res;
	}
	protected boolean guard_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final lu.uni.democles.runtime.Instance linkedInstance, final int _link) {
		if (e1.entityName.equals("changeFromLoginToMember") && e2.entityName.equals("changeView") && linkProperty.container.modelName.equals("generated.MobileLibraryGUI.ViewsWindowController") && linkProperty.entityName.equals("viewsWindow")) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|MobileLibraryGUI::ViewsWindowController/Event/changeFromLoginToMember$eventChildLink,Forward,viewsWindow,GeneralGUI::TabbedWindow,changeView");
	try {
		_error.addVariable("memberFrame", e1.getParameter("memberFrame"));
	} catch (Throwable _t) {
		_error.addVariable("memberFrame", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("self", linkedInstance);
	} catch (Throwable _t) {
		_error.addVariable("self", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		
		return true;

	}
	private java.lang.Object _startViewsWindow_viewsWindow_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return (generated.GeneralGUI.TabbedWindow.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "views", new lu.uni.democles.runtime.OCLSequence(new Object[] {((java.lang.Object)_event.getParameter("searchWindow")), ((java.lang.Object)_event.getParameter("loginWindow"))}) }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|MobileLibraryGUI::ViewsWindowController/Event/startViewsWindow-impacts-MobileLibraryGUI::ViewsWindowController/Property/viewsWindow");
	try {
		_error.addVariable("searchWindow", _event.getParameter("searchWindow"));
	} catch (Throwable _t) {
		_error.addVariable("searchWindow", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("loginWindow", _event.getParameter("loginWindow"));
	} catch (Throwable _t) {
		_error.addVariable("loginWindow", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	protected void doModify(lu.uni.democles.runtime.Event event) {
		if ("startViewsWindow".equals(event.entityName)) {
	handleImpact(event, this._p_viewsWindow);
}

	}
	protected boolean guard(final lu.uni.democles.runtime.Event e1) {
		
		return true;

	}
	protected void set(lu.uni.democles.runtime.Property p, java.lang.Object v) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) {
	throw new lu.uni.democles.runtime.MultipleModificationException(p.toString());
}
p.newVal = v;
		super.set(p, v);
	}
	protected java.lang.Object eval_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final java.lang.String paramName, final int _link) {
		if (e1.entityName.equals("changeFromLoginToMember") && e2.entityName.equals("changeView") && linkProperty.entityName.equals("viewsWindow") && paramName.equals("index")) {
try {
	return new java.lang.Integer(2);

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|MobileLibraryGUI::ViewsWindowController/Event/changeFromLoginToMember$eventChildLink,Forward,viewsWindow,GeneralGUI::TabbedWindow,changeView$index");
	try {
		_error.addVariable("memberFrame", e1.getParameter("memberFrame"));
	} catch (Throwable _t) {
		_error.addVariable("memberFrame", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}
if (e1.entityName.equals("changeFromLoginToMember") && e2.entityName.equals("changeView") && linkProperty.entityName.equals("viewsWindow") && paramName.equals("view")) {
try {
	return ((java.lang.Object)e1.getParameter("memberFrame"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PARAMETER_MAPPING|MobileLibraryGUI::ViewsWindowController/Event/changeFromLoginToMember$eventChildLink,Forward,viewsWindow,GeneralGUI::TabbedWindow,changeView$view");
	try {
		_error.addVariable("memberFrame", e1.getParameter("memberFrame"));
	} catch (Throwable _t) {
		_error.addVariable("memberFrame", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		
		return null;

	}
	public void initProps() {
		if (this.isInitialized()) return;

		this._p_viewsWindow.oldVal = this.initialValues.containsKey("viewsWindow") ? this.initialValues.get("viewsWindow") : eval_p(this._p_viewsWindow).getValues().iterator().next();
this._p_viewsWindow.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_viewsWindow, this._p_viewsWindow.oldVal);

		this.setInitialized();
this.initialValues = new java.util.HashMap();


	}
}
