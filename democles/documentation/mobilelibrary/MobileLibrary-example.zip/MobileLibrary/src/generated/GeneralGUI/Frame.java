package generated.GeneralGUI;

public class Frame extends lu.uni.democles.runtime.Instance {
	private lu.uni.democles.runtime.Property _p_seqGUIElements = new lu.uni.democles.runtime.Property(this, "seqGUIElements", "Frame", "Local", false, false, null, "sequence");
	private lu.uni.democles.runtime.Property _p_iconFilename = new lu.uni.democles.runtime.Property(this, "iconFilename", "Frame", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_frameTitle = new lu.uni.democles.runtime.Property(this, "frameTitle", "Frame", "Local", false, false, null, "single");
	public Frame() {
		super("generated.GeneralGUI.Frame", new java.lang.String[] {  });

	}
	public void initProps() {
		if (this.isInitialized()) return;

		this._p_iconFilename.oldVal = this.initialValues.containsKey("iconFilename") ? this.initialValues.get("iconFilename") : eval_p(this._p_iconFilename).getValues().iterator().next();
this._p_iconFilename.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_iconFilename, this._p_iconFilename.oldVal);

		this._p_frameTitle.oldVal = this.initialValues.containsKey("frameTitle") ? this.initialValues.get("frameTitle") : eval_p(this._p_frameTitle).getValues().iterator().next();
this._p_frameTitle.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_frameTitle, this._p_frameTitle.oldVal);

		this._p_seqGUIElements.oldVal = this.initialValues.containsKey("seqGUIElements") ? this.initialValues.get("seqGUIElements") : eval_p(this._p_seqGUIElements);
this._p_seqGUIElements.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_seqGUIElements, this._p_seqGUIElements.oldVal);

		this.setInitialized();
this.initialValues = new java.util.HashMap();


	}
	private java.lang.Object __frameTitle_eval() {
		try {
	return "";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|GeneralGUI::Frame/Property/frameTitle");
	throw _error;
}

	}
	public static Frame newWithValues(java.util.HashMap values) {
		Frame res = new Frame();
res.initialValues = new java.util.HashMap(values);
res.initProps();
return res;
	}
	protected void set(lu.uni.democles.runtime.Property p, java.lang.Object v) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) {
	throw new lu.uni.democles.runtime.MultipleModificationException(p.toString());
}
p.newVal = v;
		super.set(p, v);
	}
	protected java.lang.Object evalQuery(lu.uni.democles.runtime.Property p) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) return p.newVal;

if (p.isEvaluating()) throw new lu.uni.democles.runtime.ModificationCycleException();

p.setEvaluating(true);
java.lang.Object o = null;


		if ("iconFilename".equals(p.entityName)) {
	o = __iconFilename_eval();
	set(p, o);
}

		if ("frameTitle".equals(p.entityName)) {
	o = __frameTitle_eval();
	set(p, o);
}

		if ("seqGUIElements".equals(p.entityName)) {
	o = __seqGUIElements_eval();
	set(p, o);
}

		if (o instanceof lu.uni.democles.runtime.Instance) {
	((lu.uni.democles.runtime.Instance)o).initProps();
} else if (o instanceof lu.uni.democles.runtime.OCLCollection) {
	for (java.util.Iterator iter = ((lu.uni.democles.runtime.OCLCollection)o).getValues().iterator(); iter.hasNext();) {
		java.lang.Object entry = iter.next();
		if (entry instanceof lu.uni.democles.runtime.Instance) {
			((lu.uni.democles.runtime.Instance)entry).initProps();
		}
	}
}
p.setEvaluating(false);
return o;


	}
	private java.lang.Object __seqGUIElements_eval() {
		try {
	return new lu.uni.democles.runtime.OCLSequence(new Object[] {});

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|GeneralGUI::Frame/Property/seqGUIElements");
	throw _error;
}

	}
	private java.lang.Object __iconFilename_eval() {
		try {
	return "";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|GeneralGUI::Frame/Property/iconFilename");
	throw _error;
}

	}
	protected void resetNewVal() {
		this._p_iconFilename.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_frameTitle.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_seqGUIElements.newVal = lu.uni.democles.runtime.Entity.nullObject;
	}
	public static void main(String[] args) {
	}
}
