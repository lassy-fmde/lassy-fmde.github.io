package generated.GeneralGUI;

public class TabbedWindow extends lu.uni.democles.runtime.Instance {
	private lu.uni.democles.runtime.Property _p_views = new lu.uni.democles.runtime.Property(this, "views", "TabbedWindow", "Local", false, false, null, "sequence");
	private lu.uni.democles.runtime.Event _e_changeView = new lu.uni.democles.runtime.Event(this, "changeView", "TabbedWindow", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_closeWindow = new lu.uni.democles.runtime.Event(this, "closeWindow", "TabbedWindow", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_addView = new lu.uni.democles.runtime.Event(this, "addView", "TabbedWindow", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	protected boolean guard_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse) {
		
		return true;

	}
	protected void attachProperties(lu.uni.democles.runtime.Event e) {
		// Set Attached Properties:


	}
	private java.lang.Object eval_ep(final lu.uni.democles.runtime.Event e, final lu.uni.democles.runtime.Property p) {
		if (p.entityName.equals(this._p_views.entityName) && e.entityName.equals(this._e_addView.entityName)) {
	return _addView_views_eval(e);
}
		if (p.entityName.equals(this._p_views.entityName) && e.entityName.equals(this._e_changeView.entityName)) {
	return _changeView_views_eval(e);
}
		return null;

	}
	public static TabbedWindow newWithValues(java.util.HashMap values) {
		TabbedWindow res = new TabbedWindow();
res.initialValues = new java.util.HashMap(values);
res.initProps();
return res;
	}
	private java.lang.Object _changeView_views_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return ((lu.uni.democles.runtime.OCLSequence)(((lu.uni.democles.runtime.OCLSequence)((lu.uni.democles.runtime.Property)generated.GeneralGUI.TabbedWindow.this.getEntity("views")).evalInContainer()).subSequence((((int)((java.lang.Integer)_event.getParameter("index")).intValue()) + 1), (((lu.uni.democles.runtime.OCLSequence)((lu.uni.democles.runtime.Property)generated.GeneralGUI.TabbedWindow.this.getEntity("views")).evalInContainer()).size()))).iterate(new lu.uni.democles.runtime.Function() {
	public Object _iterate(Object _value, Object _acc) {
final lu.uni.democles.runtime.OCLSequence v_res = ((lu.uni.democles.runtime.OCLSequence)_acc);
final java.lang.Object v_elem = ((java.lang.Object)_value);
return _asObject((v_res.append(v_elem)));
	}
}, ((((lu.uni.democles.runtime.OCLSequence)((lu.uni.democles.runtime.Property)generated.GeneralGUI.TabbedWindow.this.getEntity("views")).evalInContainer()).subSequence(1, (((int)((java.lang.Integer)_event.getParameter("index")).intValue()) - 1))).append(((java.lang.Object)_event.getParameter("view"))))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|GeneralGUI::TabbedWindow/Event/changeView-impacts-GeneralGUI::TabbedWindow/Property/views");
	try {
		_error.addVariable("index", _event.getParameter("index"));
	} catch (Throwable _t) {
		_error.addVariable("index", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("view", _event.getParameter("view"));
	} catch (Throwable _t) {
		_error.addVariable("view", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	protected java.lang.Object evalQuery(lu.uni.democles.runtime.Property p) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) return p.newVal;

if (p.isEvaluating()) throw new lu.uni.democles.runtime.ModificationCycleException();

p.setEvaluating(true);
java.lang.Object o = null;


		if ("views".equals(p.entityName)) {
	o = __views_eval();
	set(p, o);
}

		if (o instanceof lu.uni.democles.runtime.Instance) {
	((lu.uni.democles.runtime.Instance)o).initProps();
} else if (o instanceof lu.uni.democles.runtime.OCLCollection) {
	for (java.util.Iterator iter = ((lu.uni.democles.runtime.OCLCollection)o).getValues().iterator(); iter.hasNext();) {
		java.lang.Object entry = iter.next();
		if (entry instanceof lu.uni.democles.runtime.Instance) {
			((lu.uni.democles.runtime.Instance)entry).initProps();
		}
	}
}
p.setEvaluating(false);
return o;


	}
	public static void main(String[] args) {
	}
	private java.lang.Object _addView_views_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return (((lu.uni.democles.runtime.OCLSequence)((lu.uni.democles.runtime.Property)generated.GeneralGUI.TabbedWindow.this.getEntity("views")).evalInContainer()).append(((java.lang.Object)_event.getParameter("view"))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|GeneralGUI::TabbedWindow/Event/addView-impacts-GeneralGUI::TabbedWindow/Property/views");
	try {
		_error.addVariable("view", _event.getParameter("view"));
	} catch (Throwable _t) {
		_error.addVariable("view", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	private java.lang.Object __views_eval() {
		try {
	return new lu.uni.democles.runtime.OCLSequence(new Object[] {});

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|GeneralGUI::TabbedWindow/Property/views");
	throw _error;
}

	}
	protected java.lang.Object eval_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse, final java.lang.String _paramName) {
		
		return null;

	}
	protected void resetNewVal() {
		this._p_views.newVal = lu.uni.democles.runtime.Entity.nullObject;
	}
	private void handleImpact(lu.uni.democles.runtime.Event e, lu.uni.democles.runtime.Property p) {
		set(p, eval_ep(e, p));
	}
	protected boolean guard_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final lu.uni.democles.runtime.Instance linkedInstance, final int _link) {
		
		return true;

	}
	protected void doModify(lu.uni.democles.runtime.Event event) {
		if ("addView".equals(event.entityName)) {
	handleImpact(event, this._p_views);
}
if ("changeView".equals(event.entityName)) {
	handleImpact(event, this._p_views);
}

	}
	protected boolean guard(final lu.uni.democles.runtime.Event e1) {
		
			if ("changeView".equals(e1.entityName)) {
try {
	return ((((int)((java.lang.Integer)e1.getParameter("index")).intValue()) >= 1) && (((int)((java.lang.Integer)e1.getParameter("index")).intValue()) <= (((lu.uni.democles.runtime.OCLSequence)((lu.uni.democles.runtime.Property)generated.GeneralGUI.TabbedWindow.this.getEntity("views")).evalInContainer()).size())));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_GUARD|GeneralGUI::TabbedWindow/Event/changeView");
	try {
		_error.addVariable("index", e1.getParameter("index"));
	} catch (Throwable _t) {
		_error.addVariable("index", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("view", e1.getParameter("view"));
	} catch (Throwable _t) {
		_error.addVariable("view", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
	}

		return true;

	}
	protected void set(lu.uni.democles.runtime.Property p, java.lang.Object v) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) {
	throw new lu.uni.democles.runtime.MultipleModificationException(p.toString());
}
p.newVal = v;
		super.set(p, v);
	}
	protected java.lang.Object eval_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final java.lang.String paramName, final int _link) {
		
		return null;

	}
	public TabbedWindow() {
		super("generated.GeneralGUI.TabbedWindow", new java.lang.String[] {  });

	}
	public void initProps() {
		if (this.isInitialized()) return;

		this._p_views.oldVal = this.initialValues.containsKey("views") ? this.initialValues.get("views") : eval_p(this._p_views);
this._p_views.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_views, this._p_views.oldVal);

		this.setInitialized();
this.initialValues = new java.util.HashMap();


	}
}
