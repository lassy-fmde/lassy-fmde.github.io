package generated.GeneralGUI;

public class MsgDialog extends lu.uni.democles.runtime.Instance {
	private lu.uni.democles.runtime.Event _e_close = new lu.uni.democles.runtime.Event(this, "close", "MsgDialog", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Property _p_viewTitle = new lu.uni.democles.runtime.Property(this, "viewTitle", "MsgDialog", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_msg = new lu.uni.democles.runtime.Property(this, "msg", "MsgDialog", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_okClicked = new lu.uni.democles.runtime.Event(this, "okClicked", "MsgDialog", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.GeneralGUI.MsgDialog", "close", new java.lang.String[] {}) });
	protected java.lang.Object eval_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse, final java.lang.String _paramName) {
		
		return null;

	}
	private java.lang.Object __msg_eval() {
		try {
	return "";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|GeneralGUI::MsgDialog/Property/msg");
	throw _error;
}

	}
	protected boolean guard_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final lu.uni.democles.runtime.Instance linkedInstance, final int _link) {
		
		if (e1.entityName.equals("okClicked") && e2.entityName.equals("close") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|GeneralGUI::MsgDialog/Event/okClicked$eventChildLink,Local,close");
	throw _error;
}
	}

		return true;

	}
	private java.lang.Object __viewTitle_eval() {
		try {
	return "";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|GeneralGUI::MsgDialog/Property/viewTitle");
	throw _error;
}

	}
	protected void attachProperties(lu.uni.democles.runtime.Event e) {
		// Set Attached Properties:


	}
	public void initProps() {
		if (this.isInitialized()) return;

		this._p_viewTitle.oldVal = this.initialValues.containsKey("viewTitle") ? this.initialValues.get("viewTitle") : eval_p(this._p_viewTitle).getValues().iterator().next();
this._p_viewTitle.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_viewTitle, this._p_viewTitle.oldVal);

		this._p_msg.oldVal = this.initialValues.containsKey("msg") ? this.initialValues.get("msg") : eval_p(this._p_msg).getValues().iterator().next();
this._p_msg.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_msg, this._p_msg.oldVal);

		this.setInitialized();
this.initialValues = new java.util.HashMap();


	}
	protected boolean guard_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse) {
		
		return true;

	}
	protected boolean guard(final lu.uni.democles.runtime.Event e1) {
		
		return true;

	}
	public MsgDialog() {
		super("generated.GeneralGUI.MsgDialog", new java.lang.String[] {  });

	}
	protected java.lang.Object evalQuery(lu.uni.democles.runtime.Property p) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) return p.newVal;

if (p.isEvaluating()) throw new lu.uni.democles.runtime.ModificationCycleException();

p.setEvaluating(true);
java.lang.Object o = null;


		if ("viewTitle".equals(p.entityName)) {
	o = __viewTitle_eval();
	set(p, o);
}

		if ("msg".equals(p.entityName)) {
	o = __msg_eval();
	set(p, o);
}

		if (o instanceof lu.uni.democles.runtime.Instance) {
	((lu.uni.democles.runtime.Instance)o).initProps();
} else if (o instanceof lu.uni.democles.runtime.OCLCollection) {
	for (java.util.Iterator iter = ((lu.uni.democles.runtime.OCLCollection)o).getValues().iterator(); iter.hasNext();) {
		java.lang.Object entry = iter.next();
		if (entry instanceof lu.uni.democles.runtime.Instance) {
			((lu.uni.democles.runtime.Instance)entry).initProps();
		}
	}
}
p.setEvaluating(false);
return o;


	}
	protected void set(lu.uni.democles.runtime.Property p, java.lang.Object v) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) {
	throw new lu.uni.democles.runtime.MultipleModificationException(p.toString());
}
p.newVal = v;
		super.set(p, v);
	}
	public static MsgDialog newWithValues(java.util.HashMap values) {
		MsgDialog res = new MsgDialog();
res.initialValues = new java.util.HashMap(values);
res.initProps();
return res;
	}
	protected java.lang.Object eval_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final java.lang.String paramName, final int _link) {
		
		return null;

	}
	protected void resetNewVal() {
		this._p_viewTitle.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_msg.newVal = lu.uni.democles.runtime.Entity.nullObject;
	}
	public static void main(String[] args) {
	}
}
