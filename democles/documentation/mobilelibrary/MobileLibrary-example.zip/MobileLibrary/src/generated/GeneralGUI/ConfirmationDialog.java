package generated.GeneralGUI;

public class ConfirmationDialog extends lu.uni.democles.runtime.Instance {
	private lu.uni.democles.runtime.Event _e_close = new lu.uni.democles.runtime.Event(this, "close", "ConfirmationDialog", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Property _p_message = new lu.uni.democles.runtime.Property(this, "message", "ConfirmationDialog", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_cancelClicked = new lu.uni.democles.runtime.Event(this, "cancelClicked", "ConfirmationDialog", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.GeneralGUI.ConfirmationDialog", "close", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Event _e_okClicked = new lu.uni.democles.runtime.Event(this, "okClicked", "ConfirmationDialog", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.GeneralGUI.ConfirmationDialog", "close", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Property _p_title = new lu.uni.democles.runtime.Property(this, "title", "ConfirmationDialog", "Local", false, false, null, "single");
	private java.lang.Object __message_eval() {
		try {
	return "";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|GeneralGUI::ConfirmationDialog/Property/message");
	throw _error;
}

	}
	protected java.lang.Object eval_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse, final java.lang.String _paramName) {
		
		return null;

	}
	public ConfirmationDialog() {
		super("generated.GeneralGUI.ConfirmationDialog", new java.lang.String[] {  });

	}
	protected boolean guard_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final lu.uni.democles.runtime.Instance linkedInstance, final int _link) {
		
		if (e1.entityName.equals("cancelClicked") && e2.entityName.equals("close") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|GeneralGUI::ConfirmationDialog/Event/cancelClicked$eventChildLink,Local,close");
	throw _error;
}
	}

		if (e1.entityName.equals("okClicked") && e2.entityName.equals("close") && linkProperty == null) {
try {
	return true;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("EVENT_LINK_GUARD|GeneralGUI::ConfirmationDialog/Event/okClicked$eventChildLink,Local,close");
	throw _error;
}
	}

		return true;

	}
	protected void attachProperties(lu.uni.democles.runtime.Event e) {
		// Set Attached Properties:


	}
	public void initProps() {
		if (this.isInitialized()) return;

		this._p_message.oldVal = this.initialValues.containsKey("message") ? this.initialValues.get("message") : eval_p(this._p_message).getValues().iterator().next();
this._p_message.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_message, this._p_message.oldVal);

		this._p_title.oldVal = this.initialValues.containsKey("title") ? this.initialValues.get("title") : eval_p(this._p_title).getValues().iterator().next();
this._p_title.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_title, this._p_title.oldVal);

		this.setInitialized();
this.initialValues = new java.util.HashMap();


	}
	protected boolean guard_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse) {
		
		return true;

	}
	protected boolean guard(final lu.uni.democles.runtime.Event e1) {
		
		return true;

	}
	protected java.lang.Object evalQuery(lu.uni.democles.runtime.Property p) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) return p.newVal;

if (p.isEvaluating()) throw new lu.uni.democles.runtime.ModificationCycleException();

p.setEvaluating(true);
java.lang.Object o = null;


		if ("message".equals(p.entityName)) {
	o = __message_eval();
	set(p, o);
}

		if ("title".equals(p.entityName)) {
	o = __title_eval();
	set(p, o);
}

		if (o instanceof lu.uni.democles.runtime.Instance) {
	((lu.uni.democles.runtime.Instance)o).initProps();
} else if (o instanceof lu.uni.democles.runtime.OCLCollection) {
	for (java.util.Iterator iter = ((lu.uni.democles.runtime.OCLCollection)o).getValues().iterator(); iter.hasNext();) {
		java.lang.Object entry = iter.next();
		if (entry instanceof lu.uni.democles.runtime.Instance) {
			((lu.uni.democles.runtime.Instance)entry).initProps();
		}
	}
}
p.setEvaluating(false);
return o;


	}
	protected void set(lu.uni.democles.runtime.Property p, java.lang.Object v) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) {
	throw new lu.uni.democles.runtime.MultipleModificationException(p.toString());
}
p.newVal = v;
		super.set(p, v);
	}
	public static ConfirmationDialog newWithValues(java.util.HashMap values) {
		ConfirmationDialog res = new ConfirmationDialog();
res.initialValues = new java.util.HashMap(values);
res.initProps();
return res;
	}
	protected java.lang.Object eval_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final java.lang.String paramName, final int _link) {
		
		return null;

	}
	private java.lang.Object __title_eval() {
		try {
	return "";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|GeneralGUI::ConfirmationDialog/Property/title");
	throw _error;
}

	}
	protected void resetNewVal() {
		this._p_message.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_title.newVal = lu.uni.democles.runtime.Entity.nullObject;
	}
	public static void main(String[] args) {
	}
}
