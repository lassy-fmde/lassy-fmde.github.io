package generated.GeneralGUI;

public class Textfield extends lu.uni.democles.runtime.Instance {
	private lu.uni.democles.runtime.Property _p_text = new lu.uni.democles.runtime.Property(this, "text", "Textfield", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_setText = new lu.uni.democles.runtime.Event(this, "setText", "Textfield", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	protected boolean guard_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse) {
		
		return true;

	}
	public Textfield() {
		super("generated.GeneralGUI.Textfield", new java.lang.String[] {  });

	}
	protected void attachProperties(lu.uni.democles.runtime.Event e) {
		// Set Attached Properties:


	}
	private java.lang.Object eval_ep(final lu.uni.democles.runtime.Event e, final lu.uni.democles.runtime.Property p) {
		if (p.entityName.equals(this._p_text.entityName) && e.entityName.equals(this._e_setText.entityName)) {
	return _setText_text_eval(e);
}
		return null;

	}
	protected java.lang.Object evalQuery(lu.uni.democles.runtime.Property p) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) return p.newVal;

if (p.isEvaluating()) throw new lu.uni.democles.runtime.ModificationCycleException();

p.setEvaluating(true);
java.lang.Object o = null;


		if ("text".equals(p.entityName)) {
	o = __text_eval();
	set(p, o);
}

		if (o instanceof lu.uni.democles.runtime.Instance) {
	((lu.uni.democles.runtime.Instance)o).initProps();
} else if (o instanceof lu.uni.democles.runtime.OCLCollection) {
	for (java.util.Iterator iter = ((lu.uni.democles.runtime.OCLCollection)o).getValues().iterator(); iter.hasNext();) {
		java.lang.Object entry = iter.next();
		if (entry instanceof lu.uni.democles.runtime.Instance) {
			((lu.uni.democles.runtime.Instance)entry).initProps();
		}
	}
}
p.setEvaluating(false);
return o;


	}
	public static void main(String[] args) {
	}
	protected java.lang.Object eval_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse, final java.lang.String _paramName) {
		
		return null;

	}
	protected void resetNewVal() {
		this._p_text.newVal = lu.uni.democles.runtime.Entity.nullObject;
	}
	private void handleImpact(lu.uni.democles.runtime.Event e, lu.uni.democles.runtime.Property p) {
		set(p, eval_ep(e, p));
	}
	private java.lang.Object _setText_text_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return ((java.lang.String)_event.getParameter("text"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|GeneralGUI::Textfield/Event/setText-impacts-GeneralGUI::Textfield/Property/text");
	try {
		_error.addVariable("text", _event.getParameter("text"));
	} catch (Throwable _t) {
		_error.addVariable("text", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	protected boolean guard_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final lu.uni.democles.runtime.Instance linkedInstance, final int _link) {
		
		return true;

	}
	protected void doModify(lu.uni.democles.runtime.Event event) {
		if ("setText".equals(event.entityName)) {
	handleImpact(event, this._p_text);
}

	}
	public static Textfield newWithValues(java.util.HashMap values) {
		Textfield res = new Textfield();
res.initialValues = new java.util.HashMap(values);
res.initProps();
return res;
	}
	private java.lang.Object __text_eval() {
		try {
	return "";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|GeneralGUI::Textfield/Property/text");
	throw _error;
}

	}
	protected boolean guard(final lu.uni.democles.runtime.Event e1) {
		
		return true;

	}
	protected void set(lu.uni.democles.runtime.Property p, java.lang.Object v) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) {
	throw new lu.uni.democles.runtime.MultipleModificationException(p.toString());
}
p.newVal = v;
		super.set(p, v);
	}
	protected java.lang.Object eval_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final java.lang.String paramName, final int _link) {
		
		return null;

	}
	public void initProps() {
		if (this.isInitialized()) return;

		this._p_text.oldVal = this.initialValues.containsKey("text") ? this.initialValues.get("text") : eval_p(this._p_text).getValues().iterator().next();
this._p_text.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_text, this._p_text.oldVal);

		this.setInitialized();
this.initialValues = new java.util.HashMap();


	}
}
