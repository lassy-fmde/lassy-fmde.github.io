package generated.GeneralGUI;

public class Image extends lu.uni.democles.runtime.Instance {
	private lu.uni.democles.runtime.Property _p_imageFilename = new lu.uni.democles.runtime.Property(this, "imageFilename", "Image", "Local", false, false, null, "single");
	private java.lang.Object __imageFilename_eval() {
		try {
	return null;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|GeneralGUI::Image/Property/imageFilename");
	throw _error;
}

	}
	public Image() {
		super("generated.GeneralGUI.Image", new java.lang.String[] {  });

	}
	protected void resetNewVal() {
		this._p_imageFilename.newVal = lu.uni.democles.runtime.Entity.nullObject;
	}
	protected java.lang.Object evalQuery(lu.uni.democles.runtime.Property p) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) return p.newVal;

if (p.isEvaluating()) throw new lu.uni.democles.runtime.ModificationCycleException();

p.setEvaluating(true);
java.lang.Object o = null;


		if ("imageFilename".equals(p.entityName)) {
	o = __imageFilename_eval();
	set(p, o);
}

		if (o instanceof lu.uni.democles.runtime.Instance) {
	((lu.uni.democles.runtime.Instance)o).initProps();
} else if (o instanceof lu.uni.democles.runtime.OCLCollection) {
	for (java.util.Iterator iter = ((lu.uni.democles.runtime.OCLCollection)o).getValues().iterator(); iter.hasNext();) {
		java.lang.Object entry = iter.next();
		if (entry instanceof lu.uni.democles.runtime.Instance) {
			((lu.uni.democles.runtime.Instance)entry).initProps();
		}
	}
}
p.setEvaluating(false);
return o;


	}
	public static void main(String[] args) {
	}
	public static Image newWithValues(java.util.HashMap values) {
		Image res = new Image();
res.initialValues = new java.util.HashMap(values);
res.initProps();
return res;
	}
	protected void set(lu.uni.democles.runtime.Property p, java.lang.Object v) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) {
	throw new lu.uni.democles.runtime.MultipleModificationException(p.toString());
}
p.newVal = v;
		super.set(p, v);
	}
	public void initProps() {
		if (this.isInitialized()) return;

		this._p_imageFilename.oldVal = this.initialValues.containsKey("imageFilename") ? this.initialValues.get("imageFilename") : eval_p(this._p_imageFilename).getValues().iterator().next();
this._p_imageFilename.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_imageFilename, this._p_imageFilename.oldVal);

		this.setInitialized();
this.initialValues = new java.util.HashMap();


	}
}
