package generated.GeneralGUI;

public class SelectionBox extends lu.uni.democles.runtime.Instance {
	private lu.uni.democles.runtime.Property _p_selectedChoice = new lu.uni.democles.runtime.Property(this, "selectedChoice", "SelectionBox", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_rowSelected = new lu.uni.democles.runtime.Event(this, "rowSelected", "SelectionBox", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Property _p_choices = new lu.uni.democles.runtime.Property(this, "choices", "SelectionBox", "Local", false, false, null, "sequence");
	public SelectionBox() {
		super("generated.GeneralGUI.SelectionBox", new java.lang.String[] {  });

	}
	protected boolean guard_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse) {
		
		return true;

	}
	private java.lang.Object eval_ep(final lu.uni.democles.runtime.Event e, final lu.uni.democles.runtime.Property p) {
		if (p.entityName.equals(this._p_selectedChoice.entityName) && e.entityName.equals(this._e_rowSelected.entityName)) {
	return _rowSelected_selectedChoice_eval(e);
}
		return null;

	}
	protected void attachProperties(lu.uni.democles.runtime.Event e) {
		// Set Attached Properties:


	}
	protected java.lang.Object evalQuery(lu.uni.democles.runtime.Property p) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) return p.newVal;

if (p.isEvaluating()) throw new lu.uni.democles.runtime.ModificationCycleException();

p.setEvaluating(true);
java.lang.Object o = null;


		if ("choices".equals(p.entityName)) {
	o = __choices_eval();
	set(p, o);
}

		if ("selectedChoice".equals(p.entityName)) {
	o = __selectedChoice_eval();
	set(p, o);
}

		if (o instanceof lu.uni.democles.runtime.Instance) {
	((lu.uni.democles.runtime.Instance)o).initProps();
} else if (o instanceof lu.uni.democles.runtime.OCLCollection) {
	for (java.util.Iterator iter = ((lu.uni.democles.runtime.OCLCollection)o).getValues().iterator(); iter.hasNext();) {
		java.lang.Object entry = iter.next();
		if (entry instanceof lu.uni.democles.runtime.Instance) {
			((lu.uni.democles.runtime.Instance)entry).initProps();
		}
	}
}
p.setEvaluating(false);
return o;


	}
	public static void main(String[] args) {
	}
	protected java.lang.Object eval_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse, final java.lang.String _paramName) {
		
		return null;

	}
	protected void resetNewVal() {
		this._p_choices.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_selectedChoice.newVal = lu.uni.democles.runtime.Entity.nullObject;
	}
	private void handleImpact(lu.uni.democles.runtime.Event e, lu.uni.democles.runtime.Property p) {
		set(p, eval_ep(e, p));
	}
	private java.lang.Object __selectedChoice_eval() {
		try {
	return "";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|GeneralGUI::SelectionBox/Property/selectedChoice");
	throw _error;
}

	}
	protected boolean guard_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final lu.uni.democles.runtime.Instance linkedInstance, final int _link) {
		
		return true;

	}
	protected void doModify(lu.uni.democles.runtime.Event event) {
		if ("rowSelected".equals(event.entityName)) {
	handleImpact(event, this._p_selectedChoice);
}

	}
	private java.lang.Object __choices_eval() {
		try {
	return new lu.uni.democles.runtime.OCLSequence(new Object[] {});

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("PROPERTY|GeneralGUI::SelectionBox/Property/choices");
	throw _error;
}

	}
	private java.lang.Object _rowSelected_selectedChoice_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return (((java.lang.String)((lu.uni.democles.runtime.OCLSequence)((lu.uni.democles.runtime.Property)generated.GeneralGUI.SelectionBox.this.getEntity("choices")).evalInContainer()).at((int)((int)((java.lang.Integer)_event.getParameter("id")).intValue()))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception, this);
	_error.setContextId("IMPACTS|GeneralGUI::SelectionBox/Event/rowSelected-impacts-GeneralGUI::SelectionBox/Property/selectedChoice");
	try {
		_error.addVariable("id", _event.getParameter("id"));
	} catch (Throwable _t) {
		_error.addVariable("id", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	protected boolean guard(final lu.uni.democles.runtime.Event e1) {
		
		return true;

	}
	protected void set(lu.uni.democles.runtime.Property p, java.lang.Object v) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) {
	throw new lu.uni.democles.runtime.MultipleModificationException(p.toString());
}
p.newVal = v;
		super.set(p, v);
	}
	protected java.lang.Object eval_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final java.lang.String paramName, final int _link) {
		
		return null;

	}
	public static SelectionBox newWithValues(java.util.HashMap values) {
		SelectionBox res = new SelectionBox();
res.initialValues = new java.util.HashMap(values);
res.initProps();
return res;
	}
	public void initProps() {
		if (this.isInitialized()) return;

		this._p_choices.oldVal = this.initialValues.containsKey("choices") ? this.initialValues.get("choices") : eval_p(this._p_choices);
this._p_choices.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_choices, this._p_choices.oldVal);

		this._p_selectedChoice.oldVal = this.initialValues.containsKey("selectedChoice") ? this.initialValues.get("selectedChoice") : eval_p(this._p_selectedChoice).getValues().iterator().next();
this._p_selectedChoice.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_selectedChoice, this._p_selectedChoice.oldVal);

		this.setInitialized();
this.initialValues = new java.util.HashMap();


	}
}
