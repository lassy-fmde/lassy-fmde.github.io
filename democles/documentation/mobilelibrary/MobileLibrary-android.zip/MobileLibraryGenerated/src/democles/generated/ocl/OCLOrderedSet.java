package democles.generated.ocl;

import java.util.Arrays;
import java.util.Vector;
import java.util.Iterator;

public class OCLOrderedSet extends OCLSet {
    
    public Vector<OCLAny> values = new Vector<OCLAny>();

    @Override
    public OCLCollection newCollection() {
        return new OCLOrderedSet();
    }

    @Override
    public void add(OCLAny object) {
        if (!this.values.contains(object)) {
            this.values.add(object);
        }
    }

    @Override
    public OCLInteger size() {
        return new OCLInteger(this.values.size());
    }

    @Override
    public OCLBoolean includes(OCLAny object) {
        return new OCLBoolean(this.values.contains(object));
    }

    @Override
    public String collectionName() {
        return "OrderedSet";
    }

    public OCLOrderedSet append(OCLAny object) {
        OCLOrderedSet res = new OCLOrderedSet();
        res.values.addAll(this.values);
        res.add(object);
        return res;
    }

    public OCLOrderedSet prepend(OCLAny object) {
        OCLOrderedSet res = new OCLOrderedSet();
        if (!this.values.contains(object)) {
            res.add(object);
        }
        res.values.addAll(this.values);
        return res;
    }
    
    public OCLOrderedSet insertAt(OCLInteger index, OCLAny object) {
        OCLOrderedSet res = new OCLOrderedSet();
        res.values.addAll(this.values);
        if (!res.values.contains(object)) { // ???
            res.values.insertElementAt(object, index.value - 1);
        }
        return res;
    }
    
    public OCLOrderedSet subOrderedSet(OCLInteger lower, OCLInteger upper) {
        OCLOrderedSet res = new OCLOrderedSet();
        res.values.addAll(this.values.subList(lower.value - 1, upper.value - 1));
        return res;
    }
    
    public OCLAny at(OCLInteger index) {
        return this.values.elementAt(index.value - 1);
    }
    
    public OCLInteger indexOf(OCLAny object) {
        return new OCLInteger(this.values.indexOf(object) + 1);
    }
    
    public OCLAny first() {
        return this.values.firstElement();
    }
    
    public OCLAny last() {
        return this.values.lastElement();
    }
    
    public OCLOrderedSet flatten() {
        return (OCLOrderedSet)super.flatten();
    }
  
    @Override
    public Iterator<OCLAny> iterator() {
        return this.values.iterator();
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((values == null) ? 0 : values.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        OCLOrderedSet other = (OCLOrderedSet)obj;
        if (values == null) {
            if (other.values != null)
                return false;
        } else if (!values.equals(other.values))
            return false;
        return true;
    }
}
