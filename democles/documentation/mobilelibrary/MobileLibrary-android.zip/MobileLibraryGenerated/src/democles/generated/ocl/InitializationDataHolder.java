package democles.generated.ocl;

import java.util.Hashtable;
import java.util.Map;

public class InitializationDataHolder {

    private static Map<Long, Object> data = new Hashtable<Long, Object>();
    
    public static Long putData(Object o) {
        long key = System.identityHashCode(o);
        data.put(key, o);
        return key;
    }
    
    public static Object retrieveData(Long key) {
        return data.remove(key);
    }
}
