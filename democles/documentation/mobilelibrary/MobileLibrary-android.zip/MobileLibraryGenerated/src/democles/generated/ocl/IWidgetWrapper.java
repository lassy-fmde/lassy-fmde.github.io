package democles.generated.ocl;

import android.content.Context;
import android.view.View;

public interface IWidgetWrapper {

    public View createWidget(Context context);
}
