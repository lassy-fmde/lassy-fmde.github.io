package democles.generated.ocl;

import android.content.Context;
import android.view.View;
import android.graphics.drawable.Drawable;

public interface IViewWrapper {

    public String getTitle();
    
    public Drawable getIcon();
    
    public View createView(Context context);
}
