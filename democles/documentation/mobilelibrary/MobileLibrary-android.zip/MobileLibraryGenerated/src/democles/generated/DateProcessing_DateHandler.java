 
	  
package democles.generated;

import java.util.Vector;
import java.util.ArrayList;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
import android.content.Context;
import android.view.View;

	
import java.util.Date;
import java.text.SimpleDateFormat;
import java.text.ParseException; 

	 
public class DateProcessing_DateHandler implements OCLAny {
	 

	public Vector<OCLAny> MobileLibraryGUI_MemberWindowController_dateHandler_back = new Vector<OCLAny>();

	private Object context;
	private OCLTuple initialPropertyValues = new OCLTuple();
	

	 
	private DateProcessing_DateHandler(Object context) {
		super();
		this.context = context;
		 


	}
	
	static public DateProcessing_DateHandler newInstance(Object context) {
		if (context == null) throw new NullPointerException();
		return new DateProcessing_DateHandler(context);
	}
 
	 
	private DateProcessing_DateHandler(Object context, OCLTuple values) {
		super();
		this.context = context;
		if (values != null) this.initialPropertyValues = values;

		 

		if (values == null) values = new OCLTuple(); // Empty
        this.initialPropertyValues = values;
		


	}

	static public DateProcessing_DateHandler newInstance(Object context, OCLTuple values) {
		if (context == null) throw new NullPointerException();
		return new DateProcessing_DateHandler(context, values);
	}

	 


	 






	 


	 
	public OCLString get_calcAfterOneMonth(OCLString p_currDate) {
	    SimpleDateFormat format = new SimpleDateFormat("d-M-y");
        Date date;
	    try {
            date = format.parse(p_currDate.string);            
        } catch (ParseException e) {
            return null;
        }

   	    long monthMillis = 30l * 24l * 60l * 60l * 1000l;
	    long dateStamp = date.getTime();
	    Date d = new Date(dateStamp + monthMillis); 
	    
		return new OCLString(format.format(d));
	}

	 
	public void onPropertyChange(String propertyName, Object value) {
	}

	 
	public void onEvent(String eventName, OCLTuple parameters) {
	}

	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

