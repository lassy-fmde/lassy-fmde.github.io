 
	  
package democles.generated;

import java.util.Vector;
import java.util.ArrayList;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
public class Library_Member implements OCLAny {
	 
	private OCLString _libraryNo;
	private boolean _libraryNo_isInitialized;
	private OCLString _name;
	private boolean _name_isInitialized;
	private OCLSet _borrows;
	private boolean _borrows_isInitialized;
	private OCLSet _toCollect;
	private boolean _toCollect_isInitialized;
	private OCLString _password;
	private boolean _password_isInitialized;

	public Vector<OCLAny> MobileLibraryGUI_MemberWindowController_currMember_back = new Vector<OCLAny>();
	public Vector<OCLAny> MobileLibraryGUI_SearchWindowController_currMember_back = new Vector<OCLAny>();
	public Vector<OCLAny> Library_Library_members_back = new Vector<OCLAny>();
	public Vector<OCLAny> LibraryPersistence_LibraryLoader_members_back = new Vector<OCLAny>();
	public Vector<OCLAny> MobileLibraryGUI_BookListWindowController_currMember_back = new Vector<OCLAny>();
	public Vector<OCLAny> MobileLibraryGUI_BookDetailWindowController_currMember_back = new Vector<OCLAny>();

	private Object context;
	private OCLTuple initialPropertyValues = new OCLTuple();
	

	 
	private Library_Member(Object context) {
		super();
		this.context = context;
		 
		if (!this._libraryNo_isInitialized) this.set_libraryNo(this.initial_libraryNo()); 
		if (!this._name_isInitialized) this.set_name(this.initial_name()); 
		if (!this._borrows_isInitialized) this.set_borrows(this.initial_borrows()); 
		if (!this._toCollect_isInitialized) this.set_toCollect(this.initial_toCollect()); 
		if (!this._password_isInitialized) this.set_password(this.initial_password()); 


	}
	
	static public Library_Member newInstance(Object context) {
		if (context == null) throw new NullPointerException();
		return new Library_Member(context);
	}
 
	 
	private Library_Member(Object context, OCLTuple values) {
		super();
		this.context = context;
		if (values != null) this.initialPropertyValues = values;

		 
		this._libraryNo_isInitialized = false; 
		this._name_isInitialized = false; 
		this._borrows_isInitialized = false; 
		this._toCollect_isInitialized = false; 
		this._password_isInitialized = false; 

		if (values == null) values = new OCLTuple(); // Empty
        this.initialPropertyValues = values;
		
		if (values.containsKey("libraryNo")) {
			this.set_libraryNo((OCLString)values.objectForKey("libraryNo"));
		} else {
			if (!this._libraryNo_isInitialized) this.set_libraryNo(this.initial_libraryNo());
		}
		if (values.containsKey("name")) {
			this.set_name((OCLString)values.objectForKey("name"));
		} else {
			if (!this._name_isInitialized) this.set_name(this.initial_name());
		}
		if (values.containsKey("borrows")) {
			this.set_borrows((OCLSet)values.objectForKey("borrows"));
		} else {
			if (!this._borrows_isInitialized) this.set_borrows(this.initial_borrows());
		}
		if (values.containsKey("toCollect")) {
			this.set_toCollect((OCLSet)values.objectForKey("toCollect"));
		} else {
			if (!this._toCollect_isInitialized) this.set_toCollect(this.initial_toCollect());
		}
		if (values.containsKey("password")) {
			this.set_password((OCLString)values.objectForKey("password"));
		} else {
			if (!this._password_isInitialized) this.set_password(this.initial_password());
		}


	}

	static public Library_Member newInstance(Object context, OCLTuple values) {
		if (context == null) throw new NullPointerException();
		return new Library_Member(context, values);
	}

	 
	public OCLString initial_libraryNo() {
		if (this.initialPropertyValues.containsKey("libraryNo")) {
			return (OCLString)this.initialPropertyValues.objectForKey("libraryNo");
		}
		/* ==================================================
	 * null
	 * ================================================== */
	
	OCLString v0 = null;
	
		return v0;
	}

	public OCLString get_libraryNo(){
		if (this._libraryNo_isInitialized) {
			return _libraryNo;
		} else { 
			this.set_libraryNo(this.initial_libraryNo());
		}
		this._libraryNo_isInitialized = true;
		return this._libraryNo;
	}
	public OCLString initial_name() {
		if (this.initialPropertyValues.containsKey("name")) {
			return (OCLString)this.initialPropertyValues.objectForKey("name");
		}
		/* ==================================================
	 * null
	 * ================================================== */
	
	OCLString v0 = null;
	
		return v0;
	}

	public OCLString get_name(){
		if (this._name_isInitialized) {
			return _name;
		} else { 
			this.set_name(this.initial_name());
		}
		this._name_isInitialized = true;
		return this._name;
	}
	public OCLSet initial_borrows() {
		if (this.initialPropertyValues.containsKey("borrows")) {
			return (OCLSet)this.initialPropertyValues.objectForKey("borrows");
		}
		/* ==================================================
	 * Set {}
	 * ================================================== */
	
	OCLSet v0 = new OCLSet();
	
		return v0;
	}

	public OCLSet get_borrows(){
		if (this._borrows_isInitialized) {
			return _borrows;
		} else { 
			this.set_borrows(this.initial_borrows());
		}
		this._borrows_isInitialized = true;
		return this._borrows;
	}
	public OCLSet initial_toCollect() {
		if (this.initialPropertyValues.containsKey("toCollect")) {
			return (OCLSet)this.initialPropertyValues.objectForKey("toCollect");
		}
		/* ==================================================
	 * Set {}
	 * ================================================== */
	
	OCLSet v0 = new OCLSet();
	
		return v0;
	}

	public OCLSet get_toCollect(){
		if (this._toCollect_isInitialized) {
			return _toCollect;
		} else { 
			this.set_toCollect(this.initial_toCollect());
		}
		this._toCollect_isInitialized = true;
		return this._toCollect;
	}
	public OCLString initial_password() {
		if (this.initialPropertyValues.containsKey("password")) {
			return (OCLString)this.initialPropertyValues.objectForKey("password");
		}
		/* ==================================================
	 * null
	 * ================================================== */
	
	OCLString v0 = null;
	
		return v0;
	}

	public OCLString get_password(){
		if (this._password_isInitialized) {
			return _password;
		} else { 
			this.set_password(this.initial_password());
		}
		this._password_isInitialized = true;
		return this._password;
	}


	 
	public void set_libraryNo(OCLString value) {
	 	
		this._libraryNo = value;
		this._libraryNo_isInitialized = true;

	}
	public void set_name(OCLString value) {
	 	
		this._name = value;
		this._name_isInitialized = true;

	}
	public void set_password(OCLString value) {
	 	
		this._password = value;
		this._password_isInitialized = true;

	}




 	public void set_borrows(OCLSet value) {
	 	
		if (this._borrows!= null) {
			// Clear back pointer on old instance
			for (OCLAny object : this._borrows) {
				Library_Copy o = (Library_Copy)object;
				Vector<OCLAny> backpointers = o.Library_Member_borrows_back;
				backpointers.removeElement(this);
			}
		}
		this._borrows = value;
		if (this._borrows!= null) {
			// Add back pointer on new instance
			for (OCLAny object : this._borrows) {
				Library_Copy o = (Library_Copy)object;
				Vector<OCLAny> backpointers = o.Library_Member_borrows_back;
				backpointers.addElement(this);
			}
		}
		this._borrows_isInitialized = true;

	}
 	public void set_toCollect(OCLSet value) {
	 	
		if (this._toCollect!= null) {
			// Clear back pointer on old instance
			for (OCLAny object : this._toCollect) {
				Library_Copy o = (Library_Copy)object;
				Vector<OCLAny> backpointers = o.Library_Member_toCollect_back;
				backpointers.removeElement(this);
			}
		}
		this._toCollect = value;
		if (this._toCollect!= null) {
			// Add back pointer on new instance
			for (OCLAny object : this._toCollect) {
				Library_Copy o = (Library_Copy)object;
				Vector<OCLAny> backpointers = o.Library_Member_toCollect_back;
				backpointers.addElement(this);
			}
		}
		this._toCollect_isInitialized = true;

	}


	 
 	public void event_setBorrows_pushed (PropertyChangeList changes  , OCLSet p_borrows ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_setBorrows_pushed in model Library_Member");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * -- Generated impacts relationship code:
		 * borrows
		 * ================================================== */
		
		OCLSet v0 = p_borrows;
		
			OCLSet _borrows_newValue = v0;
			changes.addChange("_borrows", this, _borrows_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_setToCollect_pushed (PropertyChangeList changes  , OCLSet p_toCollect ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_setToCollect_pushed in model Library_Member");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * -- Generated impacts relationship code:
		 * toCollect
		 * ================================================== */
		
		OCLSet v0 = p_toCollect;
		
			OCLSet _toCollect_newValue = v0;
			changes.addChange("_toCollect", this, _toCollect_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_addCopyToCollect_pushed (PropertyChangeList changes  , Library_Copy p_copy ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_addCopyToCollect_pushed in model Library_Member");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * toCollect->union(Set{copy})
		 * ================================================== */
		
		Library_Member v2 = this;
		OCLSet v1 = v2.get_toCollect();
		Library_Copy v5 = p_copy;
		Library_Copy v4 = v5;
		OCLSet v3 = new OCLSet();
		v3.add(v4);
		OCLSet v0 = v1.union(v3);
		
			OCLSet _toCollect_newValue = v0;
			changes.addChange("_toCollect", this, _toCollect_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 




	 


	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

