package democles.generated.ocl;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.LinkedHashSet;
import java.util.Iterator;

public class PropertyChangeList {

    private static class Entry {
        public final String propertyName;
        public final OCLAny instance;
        public final OCLAny value;
        
        public Entry(String propertyName, OCLAny instance, OCLAny value) {
            this.propertyName = propertyName;
            this.instance = instance;
            this.value = value;
        }
        
        public void apply() {
            // TODO check if the name is computed correctly
            String setterName = "set" + this.propertyName;
            
            Method method = null;
            
            for (Method m : this.instance.getClass().getMethods()) {
                if (m.getName().equals(setterName)) {
                    method = m;
                    break;
                }
            }
            
            try {
                method.invoke(this.instance, this.value);
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
        }
        
        @Override
        public String toString() {
            return this.instance + "." + this.propertyName + " = " + this.value;  
        }

        // hashCode and equals do not include value field so that we can quickly
        // check if an entry for the given property on the given instance already exists,
        // regardless of the new value.
        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + ((instance == null) ? 0 : instance.hashCode());
            result = prime * result + ((propertyName == null) ? 0 : propertyName.hashCode());
            return result;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj)
                return true;
            if (obj == null)
                return false;
            if (getClass() != obj.getClass())
                return false;
            Entry other = (Entry)obj;
            if (instance == null) {
                if (other.instance != null)
                    return false;
            } else if (!instance.equals(other.instance))
                return false;
            if (propertyName == null) {
                if (other.propertyName != null)
                    return false;
            } else if (!propertyName.equals(other.propertyName))
                return false;
            return true;
        }
    }
    
    private int depth = 0;
    
    private LinkedHashSet<Entry> entries = new LinkedHashSet<Entry>();
    
    public void enter() {
        this.depth++;
    }
    
    public void leave() {
        if (this.depth == 0) {
            throw new RuntimeException("Can not leave PropertyChangeList because depth is already 0");
        } else if (this.depth == 1) {
            for (Entry e : this.entries) {
                e.apply();
            }
            this.entries.clear();
        }
        
        this.depth--;        
    }
    
    public void addChange(String propertyName, OCLAny instance, OCLAny value) {
        Entry entry = new Entry(propertyName, instance, value);
        
        if (this.entries.contains(entry)) {
            throw new MultipleModificationException();
        }
        
        this.entries.add(entry);
    }
    
    @Override
    public String toString() {
        StringBuffer res = new StringBuffer("[");
        
        Iterator<Entry> iter = this.entries.iterator();
        while (iter.hasNext()) {
            Entry e = iter.next();
            res.append(e);
            if (iter.hasNext()) {
                res.append(",\n");
            }
        }
        
        res.append("]\n");
        return res.toString();
    }
}
