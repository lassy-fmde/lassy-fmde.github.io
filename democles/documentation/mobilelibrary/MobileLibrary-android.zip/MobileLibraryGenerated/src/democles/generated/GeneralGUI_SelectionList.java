 
	  
package democles.generated;

import java.util.Vector;
import java.util.ArrayList;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
import android.content.Context;
import android.view.View;

	 
import android.app.Activity;
import java.lang.Runnable;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;
import java.util.List;
import java.util.ArrayList;

	 
public class GeneralGUI_SelectionList implements IWidgetWrapper, OCLAny {
	 
	private OCLSequence _items;
	private boolean _items_isInitialized;

	public Vector<OCLAny> MobileLibraryGUI_MemberWindowController_collectItems_back = new Vector<OCLAny>();
	public Vector<OCLAny> MobileLibraryGUI_BookDetailWindowController_bookCopies_back = new Vector<OCLAny>();
	public Vector<OCLAny> MobileLibraryGUI_BookListWindowController_bookListTable_back = new Vector<OCLAny>();
	public Vector<OCLAny> MobileLibraryGUI_MemberWindowController_borrowItems_back = new Vector<OCLAny>();

	private Object context;
	private OCLTuple initialPropertyValues = new OCLTuple();
	

	  
	private ListView listView;

	 
	private GeneralGUI_SelectionList(Object context) {
		super();
		this.context = context;
		 
		if (!this._items_isInitialized) this.set_items(this.initial_items()); 


	}
	
	static public GeneralGUI_SelectionList newInstance(Object context) {
		if (context == null) throw new NullPointerException();
		return new GeneralGUI_SelectionList(context);
	}
 
	 
	private GeneralGUI_SelectionList(Object context, OCLTuple values) {
		super();
		this.context = context;
		if (values != null) this.initialPropertyValues = values;

		 
		this._items_isInitialized = false; 

		if (values == null) values = new OCLTuple(); // Empty
        this.initialPropertyValues = values;
		
		if (values.containsKey("items")) {
			this.set_items((OCLSequence)values.objectForKey("items"));
		} else {
			if (!this._items_isInitialized) this.set_items(this.initial_items());
		}


	}

	static public GeneralGUI_SelectionList newInstance(Object context, OCLTuple values) {
		if (context == null) throw new NullPointerException();
		return new GeneralGUI_SelectionList(context, values);
	}

	 
	public OCLSequence initial_items() {
		if (this.initialPropertyValues.containsKey("items")) {
			return (OCLSequence)this.initialPropertyValues.objectForKey("items");
		}
		/* ==================================================
	 * Sequence {}
	 * ================================================== */
	
	OCLSequence v0 = new OCLSequence();
	
		return v0;
	}

	public OCLSequence get_items(){
		if (this._items_isInitialized) {
			return _items;
		} else { 
			this.set_items(this.initial_items());
		}
		this._items_isInitialized = true;
		return this._items;
	}


	 
	public void set_items(OCLSequence value) {
		 	
		this._items = value;
		this._items_isInitialized = true;

		this.onPropertyChange("items",value);
	}






	 
 	public void event_itemSelected_pushed (PropertyChangeList changes  , OCLInteger p_index ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			parameterTuple.addItem("index", p_index);
			this.onEvent("itemSelected", parameterTuple);
			
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges
			for (OCLAny o : this.MobileLibraryGUI_BookListWindowController_bookListTable_back) {
				((MobileLibraryGUI_BookListWindowController)o).event_bookSelected_pulled_edge0(changes, this , p_index);
			}
			for (OCLAny o : this.MobileLibraryGUI_BookDetailWindowController_bookCopies_back) {
				((MobileLibraryGUI_BookDetailWindowController)o).event_bookCopyItemSelected_pulled_edge0(changes, this , p_index);
			}
			for (OCLAny o : this.MobileLibraryGUI_MemberWindowController_borrowItems_back) {
				((MobileLibraryGUI_MemberWindowController)o).event_borrowItemSelected_pulled_edge0(changes, this , p_index);
			}


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_refreshItems_pushed (PropertyChangeList changes  , OCLSequence p_items ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			parameterTuple.addItem("items", p_items);
			this.onEvent("refreshItems", parameterTuple);
			
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * items
		 * ================================================== */
		
		OCLSequence v0 = p_items;
		
			OCLSequence _items_newValue = v0;
			changes.addChange("_items", this, _items_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 




	 


	 
	public void onPropertyChange(String propertyName, Object value) {
		if (propertyName.equals("items")) {
			if (value != null) {
				updateListView();
			}
		}
	}

	 
	public void onEvent(String eventName, OCLTuple parameters) {
	}

	  
	@Override
    public View createWidget(Context context) {
        this.context = context;
        this.listView = new ListView(context);

        this.listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                new Thread() { @Override public void run() {
					OCLInteger posOCL = new OCLInteger(position + 1);
	                event_itemSelected_pushed(null, posOCL);
                }}.start();
			}
		});

        this.updateListView();
        
        return this.listView;
    }
    
    private java.util.List<String> getEntries() {
    	List<String> res = new ArrayList<String>();
		for (OCLAny s : this.get_items()) {
			res.add(((OCLString)s).string);
		}
    	return res;
    }

    private void updateListView() {
    	if (this.listView == null) return;
        final java.util.List<String> entries = this.getEntries();
    	((Activity)this.context).runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ArrayAdapter<String> adapter = new ArrayAdapter<String>((Context)context, android.R.layout.simple_list_item_1, entries);
                listView.setAdapter(adapter);
            }    	    
    	});
    }

	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

