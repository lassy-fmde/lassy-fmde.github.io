 
	  
package democles.generated;

import java.util.Vector;
import java.util.ArrayList;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
import android.content.Context;
import android.view.View;

	 
import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;
import android.widget.TabWidget;
import android.widget.LinearLayout;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.graphics.drawable.Drawable;
import java.util.Collection;

	 
public class GeneralGUI_TabbedWindow extends TabActivity implements OCLAny {
	 
	private OCLSequence _views;
	private boolean _views_isInitialized;

	public Vector<OCLAny> MobileLibraryGUI_ViewsWindowController_viewsWindow_back = new Vector<OCLAny>();

	private Object context;
	private OCLTuple initialPropertyValues = new OCLTuple();
	

	  
	final static private String INIT_PROP_VALUES_KEY = "initialPropertyValues";
	final static private String HOLDER_KEY = "instanceHolder";
    
    static class Holder {
        public GeneralGUI_TabbedWindow instance = null;
    }

	 
    public GeneralGUI_TabbedWindow() {
        super();
        this.context = this;
    }

	 
    public static GeneralGUI_TabbedWindow newInstance(Object contextObject) {
		if (contextObject == null) throw new NullPointerException();
    	return newInstance(contextObject, null);
    }
    
    public static GeneralGUI_TabbedWindow newInstance(Object contextObject, OCLTuple initialPropertyValues) {
		if (contextObject == null) throw new NullPointerException();
    	Context context = (Context)contextObject;
        Thread currentThread = Thread.currentThread();
        Thread mainThread = context.getMainLooper().getThread();
        
        if (currentThread == mainThread) {
            throw new RuntimeException("GeneralGUI_TabbedWindow can not be instantiated from the UI thread.");
        }
        
        final Intent intent = new Intent(context, GeneralGUI_TabbedWindow.class);
        if (initialPropertyValues != null) {
            Long initDataKey = InitializationDataHolder.putData(initialPropertyValues);
            intent.putExtra(INIT_PROP_VALUES_KEY, initDataKey);
        }
        
        Holder holder = new Holder();
        Long holderKey = InitializationDataHolder.putData(holder);
        intent.putExtra(HOLDER_KEY, holderKey);

        final Context contextClosure = context;
        new Thread() {
            public void run() {
                contextClosure.startActivity(intent);
            };
        }.start();
        
        synchronized(holder) {
            try {
                holder.wait();
            } catch (InterruptedException e) {
            }
        }
        return holder.instance;
    }
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        OCLTuple values = null;
        
        Bundle extras = this.getIntent().getExtras();
        if (extras != null) {
            Long initDataKey = extras.getLong(INIT_PROP_VALUES_KEY);
            if (initDataKey != null) {
                values = (OCLTuple)InitializationDataHolder.retrieveData(initDataKey);
            }
            
            Long holderKey = extras.getLong(HOLDER_KEY);
            Holder holder = (Holder)InitializationDataHolder.retrieveData(holderKey);
            holder.instance = this;
            
            synchronized(holder) {
                holder.notify();
            }
        }
        
		 
		this._views_isInitialized = false; 

		if (values == null) values = new OCLTuple(); // Empty
        this.initialPropertyValues = values;
		
		if (values.containsKey("views")) {
			this.set_views((OCLSequence)values.objectForKey("views"));
		} else {
			if (!this._views_isInitialized) this.set_views(this.initial_views());
		}


        
        this.updateTabs();
    }

	 
	public OCLSequence initial_views() {
		if (this.initialPropertyValues.containsKey("views")) {
			return (OCLSequence)this.initialPropertyValues.objectForKey("views");
		}
		/* ==================================================
	 * Sequence {}
	 * ================================================== */
	
	OCLSequence v0 = new OCLSequence();
	
		return v0;
	}

	public OCLSequence get_views(){
		if (this._views_isInitialized) {
			return _views;
		} else { 
			this.set_views(this.initial_views());
		}
		this._views_isInitialized = true;
		return this._views;
	}


	 
	public void set_views(OCLSequence value) {
		 	
		this._views = value;
		this._views_isInitialized = true;

		this.onPropertyChange("views",value);
	}






	 
 	public void event_closeWindow_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			
			this.onEvent("closeWindow", parameterTuple);
			
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_addView_pushed (PropertyChangeList changes  , OCLAny p_view ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			parameterTuple.addItem("view", p_view);
			this.onEvent("addView", parameterTuple);
			
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * views->append(view)
		 * ================================================== */
		
		GeneralGUI_TabbedWindow v2 = this;
		OCLSequence v1 = v2.get_views();
		OCLAny v3 = p_view;
		OCLSequence v0 = v1.append(v3);
		
			OCLSequence _views_newValue = v0;
			changes.addChange("_views", this, _views_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_changeView_pushed (PropertyChangeList changes  , OCLInteger p_index , OCLAny p_view ){
		{ // New scope for following guard expression:
			/* ==================================================
             * index>=1 and index <= views->size()
             * ================================================== */
            
            OCLInteger v2 = p_index;
            OCLInteger v3 = new OCLInteger(1);
            OCLBoolean v1 = v2.gte(v3);
            OCLInteger v5 = p_index;
            GeneralGUI_TabbedWindow v8 = this;
            OCLSequence v7 = v8.get_views();
            OCLInteger v6 = v7.size();
            OCLBoolean v4 = v5.lte(v6);
            OCLBoolean v0 = v1.and(v4);
            			
			if (!v0.value) {
				return;
			}
		}
		
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			parameterTuple.addItem("index", p_index);parameterTuple.addItem("view", p_view);
			this.onEvent("changeView", parameterTuple);
			
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * views->subSequence(index+1, views->size())->iterate(
		 * 	elem : OclAny; 
		 * 	res : Sequence (OclAny) = views->subSequence(1, index-1)->append(view)
		 * 	| res->append(elem))
		 * ================================================== */
		
		GeneralGUI_TabbedWindow v3 = this;
		OCLSequence v2 = v3.get_views();
		OCLInteger v5 = p_index;
		OCLInteger v6 = new OCLInteger(1);
		OCLInteger v4 = v5.plus(v6);
		GeneralGUI_TabbedWindow v9 = this;
		OCLSequence v8 = v9.get_views();
		OCLInteger v7 = v8.size();
		OCLSequence v1 = v2.subSequence(v4, v7);
		GeneralGUI_TabbedWindow v15 = this;
		OCLSequence v14 = v15.get_views();
		OCLInteger v16 = new OCLInteger(1);
		OCLInteger v18 = p_index;
		OCLInteger v19 = new OCLInteger(1);
		OCLInteger v17 = v18.minus(v19);
		OCLSequence v13 = v14.subSequence(v16, v17);
		OCLAny v20 = p_view;
		OCLSequence v12 = v13.append(v20);
		OCLSequence v11 = (OCLSequence)v12;
		Iterator<OCLAny> v0_iter = v1.iterator();
		while (v0_iter.hasNext()) {
				OCLAny v10 = (OCLAny)v0_iter.next();
				OCLSequence v22 = v11;
				OCLAny v23 = v10;
				OCLSequence v21 = v22.append(v23);
				v11 = v21;
		}
		OCLSequence v0 = v11;
		
			OCLSequence _views_newValue = v0;
			changes.addChange("_views", this, _views_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 




	 


	 
	public void onPropertyChange(String propertyName, Object value) {
		if (propertyName.equals("views")) {
			if (value != null) {
				updateTabs();
			}
		}
	}

	 
	public void onEvent(String eventName, OCLTuple parameters) {
		if (eventName.equals("closeWindow")) {
			this.finish();
		}
	}

	  

    private Collection<IViewWrapper> getViews() {
        return (Collection)this.get_views().values;
    }

    // This must happen on change of "views" property, and in onCreate
    private void updateTabs() {
        this.runOnUiThread(new Runnable() {
			@Override
			public void run() {
			    int currentTab = getTabHost().getCurrentTab();			
				getTabHost().setCurrentTab(0);
		        getTabHost().clearAllTabs();
		        
		        int i = 0;
		        for (final IViewWrapper view : getViews()) {
		            TabSpec ts = getTabHost().newTabSpec("TAB_TAG_" + i++);
		
		            String tabLabel = view.getTitle();
		            Drawable tabIcon = view.getIcon();
		            ts.setIndicator(tabLabel, tabIcon);
		
		            ts.setContent(new TabHost.TabContentFactory() {
		                @Override
		                public View createTabContent(String tag) {
		                    return view.createView(GeneralGUI_TabbedWindow.this);
		                }
		            });
		
		            getTabHost().addTab(ts);
		        }

		        for (int j = 0; j < getTabWidget().getTabCount(); j++) {
                    ViewGroup tabView = (ViewGroup)getTabWidget().getChildTabViewAt(j);
                    TextView label = (TextView)tabView.getChildAt(1);
                    label.setTextAppearance((Context)context, android.R.style.TextAppearance_Medium);
                    if (j == getTabHost().getCurrentTab()) {
                        tabView.setSelected(true);
                    }
                }
		        if (getTabHost().getTabWidget().getTabCount() > currentTab) {
		            getTabHost().setCurrentTab(currentTab);
		        }
			}
        });        
    }

	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

