 
	  
package democles.generated;

import android.content.Context;
import java.util.Vector;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import java.io.IOException;
import java.io.InputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import democles.generated.ocl.*;

	 
public class Persistence_FileHandler implements OCLAny {
	 

	public Vector<OCLAny> LibraryPersistence_LibraryLoader_memberFileHandler_back = new Vector<OCLAny>();
	public Vector<OCLAny> LibraryPersistence_LibraryLoader_authorFileHandler_back = new Vector<OCLAny>();
	public Vector<OCLAny> LibraryPersistence_LibraryLoader_bookFileHandler_back = new Vector<OCLAny>();
	public Vector<OCLAny> LibraryPersistence_LibraryLoader_borrowsFileHandler_back = new Vector<OCLAny>();
	public Vector<OCLAny> LibraryPersistence_LibraryLoader_copyFileHandler_back = new Vector<OCLAny>();
	public Vector<OCLAny> LibraryPersistence_LibraryLoader_saveCopiesFileHandler_back = new Vector<OCLAny>();
	public Vector<OCLAny> LibraryPersistence_LibraryLoader_saveToCollectFileHandler_back = new Vector<OCLAny>();
	public Vector<OCLAny> LibraryPersistence_LibraryLoader_toCollectFileHandler_back = new Vector<OCLAny>();
	public Vector<OCLAny> LibraryPersistence_LibraryLoader_saveBorrowsFileHandler_back = new Vector<OCLAny>();

	private Object context;
	private OCLTuple initialPropertyValues = new OCLTuple();
	

	 
	private Persistence_FileHandler(Object context) {
		super();
		this.context = context;
		 


	}
	
	static public Persistence_FileHandler newInstance(Object context) {
		if (context == null) throw new NullPointerException();
		return new Persistence_FileHandler(context);
	}
 
	 
	private Persistence_FileHandler(Object context, OCLTuple values) {
		super();
		this.context = context;
		if (values != null) this.initialPropertyValues = values;

		 

		if (values == null) values = new OCLTuple(); // Empty
        this.initialPropertyValues = values;
		


	}

	static public Persistence_FileHandler newInstance(Object context, OCLTuple values) {
		if (context == null) throw new NullPointerException();
		return new Persistence_FileHandler(context, values);
	}

	 


	 






	 
 	public void event_openFile_pushed (PropertyChangeList changes  , OCLString p_filename ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			parameterTuple.addItem("filename", p_filename);
			this.onEvent("openFile", parameterTuple);
			
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_fileOpened_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			
			this.onEvent("fileOpened", parameterTuple);
			
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_lineread_pushed (PropertyChangeList changes  , OCLString p_line ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			parameterTuple.addItem("line", p_line);
			this.onEvent("lineread", parameterTuple);
			
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges
			for (OCLAny o : this.LibraryPersistence_LibraryLoader_bookFileHandler_back) {
				((LibraryPersistence_LibraryLoader)o).event_bookLineRead_pulled_edge0(changes, this , p_line);
			}
			for (OCLAny o : this.LibraryPersistence_LibraryLoader_authorFileHandler_back) {
				((LibraryPersistence_LibraryLoader)o).event_authorsLineRead_pulled_edge0(changes, this , p_line);
			}
			for (OCLAny o : this.LibraryPersistence_LibraryLoader_copyFileHandler_back) {
				((LibraryPersistence_LibraryLoader)o).event_copyLineRead_pulled_edge0(changes, this , p_line);
			}
			for (OCLAny o : this.LibraryPersistence_LibraryLoader_memberFileHandler_back) {
				((LibraryPersistence_LibraryLoader)o).event_memberLineRead_pulled_edge0(changes, this , p_line);
			}
			for (OCLAny o : this.LibraryPersistence_LibraryLoader_toCollectFileHandler_back) {
				((LibraryPersistence_LibraryLoader)o).event_toCollectLineRead_pulled_edge0(changes, this , p_line);
			}
			for (OCLAny o : this.LibraryPersistence_LibraryLoader_borrowsFileHandler_back) {
				((LibraryPersistence_LibraryLoader)o).event_borrowsLineRead_pulled_edge0(changes, this , p_line);
			}


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_fileClosed_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			
			this.onEvent("fileClosed", parameterTuple);
			
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges
			for (OCLAny o : this.LibraryPersistence_LibraryLoader_bookFileHandler_back) {
				((LibraryPersistence_LibraryLoader)o).event_bookFileClosed_pulled_edge0(changes, this );
			}
			for (OCLAny o : this.LibraryPersistence_LibraryLoader_borrowsFileHandler_back) {
				((LibraryPersistence_LibraryLoader)o).event_borrowsFileClosed_pulled_edge0(changes, this );
			}
			for (OCLAny o : this.LibraryPersistence_LibraryLoader_authorFileHandler_back) {
				((LibraryPersistence_LibraryLoader)o).event_authorsFileClosed_pulled_edge0(changes, this );
			}
			for (OCLAny o : this.LibraryPersistence_LibraryLoader_memberFileHandler_back) {
				((LibraryPersistence_LibraryLoader)o).event_memberFileClosed_pulled_edge0(changes, this );
			}
			for (OCLAny o : this.LibraryPersistence_LibraryLoader_toCollectFileHandler_back) {
				((LibraryPersistence_LibraryLoader)o).event_toCollectFileClosed_pulled_edge0(changes, this );
			}
			for (OCLAny o : this.LibraryPersistence_LibraryLoader_copyFileHandler_back) {
				((LibraryPersistence_LibraryLoader)o).event_copyFileClosed_pulled_edge0(changes, this );
			}


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_saveString_pushed (PropertyChangeList changes  , OCLString p_filename , OCLString p_content ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			parameterTuple.addItem("filename", p_filename);parameterTuple.addItem("content", p_content);
			this.onEvent("saveString", parameterTuple);
			
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_stringSaved_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			
			this.onEvent("stringSaved", parameterTuple);
			
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 




	 


	 
	public void onEvent(String eventName, OCLTuple parameters) {
		if (eventName.equals("openFile")) {
			String filename = ((OCLString)parameters.objectForKey("filename")).string;

			InputStream input = null;
			try {
				input = ((Context)this.context).openFileInput(filename); 
			} catch (FileNotFoundException fnfe) {
				try {
		            input = ((Context)this.context).getAssets().open(filename);
		        } catch (Exception e) {
		        }
			}
			
			if (input == null) {
	            this.event_fileOpened_pushed(null);
	            this.event_fileClosed_pushed(null);
	            return;
			}
				
	        try {
	            BufferedReader reader = new BufferedReader(new InputStreamReader(input));
	            
	            this.event_fileOpened_pushed(null);
	            
	            String line = reader.readLine();
	            while (line != null) {	                
		            this.event_lineread_pushed(null, new OCLString(line));
	                line = reader.readLine();
	            };
	            
	            this.event_fileClosed_pushed(null);
	        } catch (Exception e) {
	            this.event_fileOpened_pushed(null);
	            this.event_fileClosed_pushed(null);
	        }
		}

		if (eventName.equals("saveString")) {
			String filename = ((OCLString)parameters.objectForKey("filename")).string;
			String content = ((OCLString)parameters.objectForKey("content")).string;
			
			try {
				FileOutputStream fos = ((Context)this.context).openFileOutput(filename, Context.MODE_PRIVATE);
				fos.write(content.getBytes());
				fos.close();
			} catch (IOException e) {
			} finally {
	            this.event_stringSaved_pushed(null);
			}
		}
	}

	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

