 
	  
package democles.generated;

import java.util.Vector;
import java.util.ArrayList;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
import android.content.Context;
import android.view.View;

	 
import android.widget.EditText;
import android.text.TextWatcher;
import android.text.Editable;

	 
public class GeneralGUI_Textfield implements IWidgetWrapper, OCLAny {
	 
	private OCLString _text;
	private boolean _text_isInitialized;

	public Vector<OCLAny> MobileLibraryGUI_LoginWindowController_libraryNoField_back = new Vector<OCLAny>();
	public Vector<OCLAny> MobileLibraryGUI_SearchWindowController_searchField_back = new Vector<OCLAny>();
	public Vector<OCLAny> MobileLibraryGUI_LoginWindowController_passwordField_back = new Vector<OCLAny>();

	private Object context;
	private OCLTuple initialPropertyValues = new OCLTuple();
	

	  
	private EditText editText;

	 
	private GeneralGUI_Textfield(Object context) {
		super();
		this.context = context;
		 
		if (!this._text_isInitialized) this.set_text(this.initial_text()); 


	}
	
	static public GeneralGUI_Textfield newInstance(Object context) {
		if (context == null) throw new NullPointerException();
		return new GeneralGUI_Textfield(context);
	}
 
	 
	private GeneralGUI_Textfield(Object context, OCLTuple values) {
		super();
		this.context = context;
		if (values != null) this.initialPropertyValues = values;

		 
		this._text_isInitialized = false; 

		if (values == null) values = new OCLTuple(); // Empty
        this.initialPropertyValues = values;
		
		if (values.containsKey("text")) {
			this.set_text((OCLString)values.objectForKey("text"));
		} else {
			if (!this._text_isInitialized) this.set_text(this.initial_text());
		}


	}

	static public GeneralGUI_Textfield newInstance(Object context, OCLTuple values) {
		if (context == null) throw new NullPointerException();
		return new GeneralGUI_Textfield(context, values);
	}

	 
	public OCLString initial_text() {
		if (this.initialPropertyValues.containsKey("text")) {
			return (OCLString)this.initialPropertyValues.objectForKey("text");
		}
		/* ==================================================
	 * ''
	 * ================================================== */
	
	OCLString v0 = new OCLString("");
	
		return v0;
	}

	public OCLString get_text(){
		if (this._text_isInitialized) {
			return _text;
		} else { 
			this.set_text(this.initial_text());
		}
		this._text_isInitialized = true;
		return this._text;
	}


	 
	public void set_text(OCLString value) {
		 	
		this._text = value;
		this._text_isInitialized = true;

		this.onPropertyChange("text",value);
	}






	 
 	public void event_setText_pushed (PropertyChangeList changes  , OCLString p_text ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			parameterTuple.addItem("text", p_text);
			this.onEvent("setText", parameterTuple);
			
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * -- Generated impacts relationship code:
		 * text
		 * ================================================== */
		
		OCLString v0 = p_text;
		
			OCLString _text_newValue = v0;
			changes.addChange("_text", this, _text_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 




	 


	 
	public void onPropertyChange(String propertyName, Object value) {
		if (propertyName.equals("text")) {
			if (value != null) {
				updateEditText();
			}
		}
	}

	 
	public void onEvent(String eventName, OCLTuple parameters) {
	}

	  
	@Override
    public View createWidget(Context context) {
        this.editText = new EditText(context);
        this.editText.addTextChangedListener(new TextWatcher() {
			@Override public void onTextChanged(CharSequence s, int start, int before, int count) {}			
			@Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
			@Override
			public void afterTextChanged(Editable s) {
            	String text = s.toString();
            	_text = new OCLString(text); // Silent update of property, should be done differently?
			}
		});

        this.updateEditText();
        
        return this.editText;
    }

    private void updateEditText() {
    	if (this.editText == null) return;
    
    	OCLString s = this.get_text();
		if (s != null) {
        	this.editText.setText(s.string);
		}	
    }

	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

