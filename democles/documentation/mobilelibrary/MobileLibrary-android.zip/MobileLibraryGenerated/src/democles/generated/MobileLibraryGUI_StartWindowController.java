 
	  
package democles.generated;

import java.util.Vector;
import java.util.ArrayList;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
public class MobileLibraryGUI_StartWindowController implements OCLAny {
	 
	private GeneralGUI_Label _titleLabel;
	private boolean _titleLabel_isInitialized;
	private OCLString _title;
	private boolean _title_isInitialized;
	private GeneralGUI_Window _window;
	private boolean _window_isInitialized;
	private GeneralGUI_Image _uniLogo;
	private boolean _uniLogo_isInitialized;

	public Vector<OCLAny> Application_Main_startWindowControl_back = new Vector<OCLAny>();

	private Object context;
	private OCLTuple initialPropertyValues = new OCLTuple();
	

	 
	private MobileLibraryGUI_StartWindowController(Object context) {
		super();
		this.context = context;
		 
		if (!this._titleLabel_isInitialized) this.set_titleLabel(this.initial_titleLabel()); 
		if (!this._title_isInitialized) this.set_title(this.initial_title()); 
		if (!this._window_isInitialized) this.set_window(this.initial_window()); 
		if (!this._uniLogo_isInitialized) this.set_uniLogo(this.initial_uniLogo()); 


	}
	
	static public MobileLibraryGUI_StartWindowController newInstance(Object context) {
		if (context == null) throw new NullPointerException();
		return new MobileLibraryGUI_StartWindowController(context);
	}
 
	 
	private MobileLibraryGUI_StartWindowController(Object context, OCLTuple values) {
		super();
		this.context = context;
		if (values != null) this.initialPropertyValues = values;

		 
		this._titleLabel_isInitialized = false; 
		this._title_isInitialized = false; 
		this._window_isInitialized = false; 
		this._uniLogo_isInitialized = false; 

		if (values == null) values = new OCLTuple(); // Empty
        this.initialPropertyValues = values;
		
		if (values.containsKey("titleLabel")) {
			this.set_titleLabel((GeneralGUI_Label)values.objectForKey("titleLabel"));
		} else {
			if (!this._titleLabel_isInitialized) this.set_titleLabel(this.initial_titleLabel());
		}
		if (values.containsKey("title")) {
			this.set_title((OCLString)values.objectForKey("title"));
		} else {
			if (!this._title_isInitialized) this.set_title(this.initial_title());
		}
		if (values.containsKey("window")) {
			this.set_window((GeneralGUI_Window)values.objectForKey("window"));
		} else {
			if (!this._window_isInitialized) this.set_window(this.initial_window());
		}
		if (values.containsKey("uniLogo")) {
			this.set_uniLogo((GeneralGUI_Image)values.objectForKey("uniLogo"));
		} else {
			if (!this._uniLogo_isInitialized) this.set_uniLogo(this.initial_uniLogo());
		}


	}

	static public MobileLibraryGUI_StartWindowController newInstance(Object context, OCLTuple values) {
		if (context == null) throw new NullPointerException();
		return new MobileLibraryGUI_StartWindowController(context, values);
	}

	 
	public GeneralGUI_Label initial_titleLabel() {
		if (this.initialPropertyValues.containsKey("titleLabel")) {
			return (GeneralGUI_Label)this.initialPropertyValues.objectForKey("titleLabel");
		}
		/* ==================================================
	 * GeneralGUI::Label::create(Tuple { text = '        Starting the Mobile Library' })
	 * ================================================== */
	
	OCLString v4 = new OCLString("        Starting the Mobile Library");
	OCLString v3 = v4;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("text", v3);
	GeneralGUI_Label v0 = GeneralGUI_Label.newInstance(this.context, v2);
	
		return v0;
	}

	public GeneralGUI_Label get_titleLabel(){
		if (this._titleLabel_isInitialized) {
			return _titleLabel;
		} else { 
			this.set_titleLabel(this.initial_titleLabel());
		}
		this._titleLabel_isInitialized = true;
		return this._titleLabel;
	}
	public OCLString initial_title() {
		if (this.initialPropertyValues.containsKey("title")) {
			return (OCLString)this.initialPropertyValues.objectForKey("title");
		}
		/* ==================================================
	 * 'Starting...'
	 * ================================================== */
	
	OCLString v0 = new OCLString("Starting...");
	
		return v0;
	}

	public OCLString get_title(){
		if (this._title_isInitialized) {
			return _title;
		} else { 
			this.set_title(this.initial_title());
		}
		this._title_isInitialized = true;
		return this._title;
	}
	public GeneralGUI_Window initial_window() {
		if (this.initialPropertyValues.containsKey("window")) {
			return (GeneralGUI_Window)this.initialPropertyValues.objectForKey("window");
		}
		/* ==================================================
	 * GeneralGUI::Window::create(
	 * 	Tuple { seqGUIElements = Sequence {titleLabel, uniLogo}, title = title })
	 * ================================================== */
	
	MobileLibraryGUI_StartWindowController v7 = this;
	GeneralGUI_Label v6 = v7.get_titleLabel();
	GeneralGUI_Label v5 = v6;
	MobileLibraryGUI_StartWindowController v10 = this;
	GeneralGUI_Image v9 = v10.get_uniLogo();
	GeneralGUI_Image v8 = v9;
	OCLSequence v4 = new OCLSequence();
	v4.add(v5);
	v4.add(v8);
	OCLSequence v3 = v4;
	MobileLibraryGUI_StartWindowController v13 = this;
	OCLString v12 = v13.get_title();
	OCLString v11 = v12;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("seqGUIElements", v3);
	v2.addItem("title", v11);
	GeneralGUI_Window v0 = GeneralGUI_Window.newInstance(this.context, v2);
	
		return v0;
	}

	public GeneralGUI_Window get_window(){
		if (this._window_isInitialized) {
			return _window;
		} else { 
			this.set_window(this.initial_window());
		}
		this._window_isInitialized = true;
		return this._window;
	}
	public GeneralGUI_Image initial_uniLogo() {
		if (this.initialPropertyValues.containsKey("uniLogo")) {
			return (GeneralGUI_Image)this.initialPropertyValues.objectForKey("uniLogo");
		}
		/* ==================================================
	 * GeneralGUI::Image::create(Tuple { imageFilename = 'icon-Uni_lu.png' })
	 * 
	 * ================================================== */
	
	OCLString v4 = new OCLString("icon-Uni_lu.png");
	OCLString v3 = v4;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("imageFilename", v3);
	GeneralGUI_Image v0 = GeneralGUI_Image.newInstance(this.context, v2);
	
		return v0;
	}

	public GeneralGUI_Image get_uniLogo(){
		if (this._uniLogo_isInitialized) {
			return _uniLogo;
		} else { 
			this.set_uniLogo(this.initial_uniLogo());
		}
		this._uniLogo_isInitialized = true;
		return this._uniLogo;
	}


	 
	public void set_title(OCLString value) {
	 	
		this._title = value;
		this._title_isInitialized = true;

	}


	public void set_titleLabel(GeneralGUI_Label value) {
	 	
		if (this._titleLabel!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._titleLabel.MobileLibraryGUI_StartWindowController_titleLabel_back;
			backpointers.removeElement(this);
		}
		this._titleLabel = value;
		if (this._titleLabel!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._titleLabel.MobileLibraryGUI_StartWindowController_titleLabel_back;
			backpointers.addElement(this);
		}
		this._titleLabel_isInitialized = true;

	}
	public void set_window(GeneralGUI_Window value) {
	 	
		if (this._window!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._window.MobileLibraryGUI_StartWindowController_window_back;
			backpointers.removeElement(this);
		}
		this._window = value;
		if (this._window!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._window.MobileLibraryGUI_StartWindowController_window_back;
			backpointers.addElement(this);
		}
		this._window_isInitialized = true;

	}
	public void set_uniLogo(GeneralGUI_Image value) {
	 	
		if (this._uniLogo!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._uniLogo.MobileLibraryGUI_StartWindowController_uniLogo_back;
			backpointers.removeElement(this);
		}
		this._uniLogo = value;
		if (this._uniLogo!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._uniLogo.MobileLibraryGUI_StartWindowController_uniLogo_back;
			backpointers.addElement(this);
		}
		this._uniLogo_isInitialized = true;

	}




	 
 	public void event_closeWIndow_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_closeWIndow_pushed in model MobileLibraryGUI_StartWindowController");
			 		
			// Trigger Push edges


			if (this._window != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._window);
				for (Object o : edge0_values) {
					GeneralGUI_Window edge0_target = (GeneralGUI_Window)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {

						edge0_target.event_closeWindow_pushed(changes );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 




	 


	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

