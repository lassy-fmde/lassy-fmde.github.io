 
	  
package democles.generated;

import java.util.Vector;
import java.util.ArrayList;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
public class Library_Library implements OCLAny {
	 
	private OCLSet _catalogue;
	private boolean _catalogue_isInitialized;
	private OCLSet _members;
	private boolean _members_isInitialized;

	public Vector<OCLAny> Application_Main_library_back = new Vector<OCLAny>();

	private Object context;
	private OCLTuple initialPropertyValues = new OCLTuple();
	

	 
	private Library_Library(Object context) {
		super();
		this.context = context;
		 
		if (!this._catalogue_isInitialized) this.set_catalogue(this.initial_catalogue()); 
		if (!this._members_isInitialized) this.set_members(this.initial_members()); 


	}
	
	static public Library_Library newInstance(Object context) {
		if (context == null) throw new NullPointerException();
		return new Library_Library(context);
	}
 
	 
	private Library_Library(Object context, OCLTuple values) {
		super();
		this.context = context;
		if (values != null) this.initialPropertyValues = values;

		 
		this._catalogue_isInitialized = false; 
		this._members_isInitialized = false; 

		if (values == null) values = new OCLTuple(); // Empty
        this.initialPropertyValues = values;
		
		if (values.containsKey("catalogue")) {
			this.set_catalogue((OCLSet)values.objectForKey("catalogue"));
		} else {
			if (!this._catalogue_isInitialized) this.set_catalogue(this.initial_catalogue());
		}
		if (values.containsKey("members")) {
			this.set_members((OCLSet)values.objectForKey("members"));
		} else {
			if (!this._members_isInitialized) this.set_members(this.initial_members());
		}


	}

	static public Library_Library newInstance(Object context, OCLTuple values) {
		if (context == null) throw new NullPointerException();
		return new Library_Library(context, values);
	}

	 
	public OCLSet initial_catalogue() {
		if (this.initialPropertyValues.containsKey("catalogue")) {
			return (OCLSet)this.initialPropertyValues.objectForKey("catalogue");
		}
		/* ==================================================
	 * Set {}
	 * ================================================== */
	
	OCLSet v0 = new OCLSet();
	
		return v0;
	}

	public OCLSet get_catalogue(){
		if (this._catalogue_isInitialized) {
			return _catalogue;
		} else { 
			this.set_catalogue(this.initial_catalogue());
		}
		this._catalogue_isInitialized = true;
		return this._catalogue;
	}
	public OCLSet initial_members() {
		if (this.initialPropertyValues.containsKey("members")) {
			return (OCLSet)this.initialPropertyValues.objectForKey("members");
		}
		/* ==================================================
	 * Set {}
	 * ================================================== */
	
	OCLSet v0 = new OCLSet();
	
		return v0;
	}

	public OCLSet get_members(){
		if (this._members_isInitialized) {
			return _members;
		} else { 
			this.set_members(this.initial_members());
		}
		this._members_isInitialized = true;
		return this._members;
	}


	 




 	public void set_catalogue(OCLSet value) {
	 	
		if (this._catalogue!= null) {
			// Clear back pointer on old instance
			for (OCLAny object : this._catalogue) {
				Library_Book o = (Library_Book)object;
				Vector<OCLAny> backpointers = o.Library_Library_catalogue_back;
				backpointers.removeElement(this);
			}
		}
		this._catalogue = value;
		if (this._catalogue!= null) {
			// Add back pointer on new instance
			for (OCLAny object : this._catalogue) {
				Library_Book o = (Library_Book)object;
				Vector<OCLAny> backpointers = o.Library_Library_catalogue_back;
				backpointers.addElement(this);
			}
		}
		this._catalogue_isInitialized = true;

	}
 	public void set_members(OCLSet value) {
	 	
		if (this._members!= null) {
			// Clear back pointer on old instance
			for (OCLAny object : this._members) {
				Library_Member o = (Library_Member)object;
				Vector<OCLAny> backpointers = o.Library_Library_members_back;
				backpointers.removeElement(this);
			}
		}
		this._members = value;
		if (this._members!= null) {
			// Add back pointer on new instance
			for (OCLAny object : this._members) {
				Library_Member o = (Library_Member)object;
				Vector<OCLAny> backpointers = o.Library_Library_members_back;
				backpointers.addElement(this);
			}
		}
		this._members_isInitialized = true;

	}


	 
 	public void event_searchBook_pushed (PropertyChangeList changes  , OCLString p_term , OCLString p_category ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_searchBook_pushed in model Library_Library");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {
				/* ==================================================
			 * findBooks (term, category)
			 * ================================================== */
			
			Library_Library v2 = this;
			OCLString v3 = p_term;
			OCLString v4 = p_category;
			OCLSet v1 = v2.get_findBooks(v3, v4);
			
				OCLSet parameter_p_foundBooks = v1;

				this.event_booksFound_pushed(changes , parameter_p_foundBooks );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_booksFound_pushed (PropertyChangeList changes  , OCLSet p_foundBooks ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_booksFound_pushed in model Library_Library");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges
			for (OCLAny o : this.Application_Main_library_back) {
				((Application_Main)o).event_searchFinished_pulled_edge0(changes, this , p_foundBooks);
			}


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_authenticateMember_pushed (PropertyChangeList changes  , OCLString p_libNo , OCLString p_pw ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_authenticateMember_pushed in model Library_Library");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * existsMember (libNo, pw)
		 * ================================================== */
		
		Library_Library v1 = this;
		OCLString v2 = p_libNo;
		OCLString v3 = p_pw;
		OCLBoolean v0 = v1.get_existsMember(v2, v3);
		
			if (v0.value == true) {
				/* ==================================================
			 * findMember (libNo)
			 * ================================================== */
			
			Library_Library v5 = this;
			OCLString v6 = p_libNo;
			Library_Member v4 = v5.get_findMember(v6);
			
				Library_Member parameter_p_member = v4;

				this.event_sessionOpened_pushed(changes , parameter_p_member );
			}
			/* ==================================================
		 * not existsMember (libNo, pw)
		 * ================================================== */
		
		Library_Library v9 = this;
		OCLString v10 = p_libNo;
		OCLString v11 = p_pw;
		OCLBoolean v8 = v9.get_existsMember(v10, v11);
		OCLBoolean v7 = v8.not();
		
			if (v7.value == true) {

				this.event_loginFailed_pushed(changes );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_sessionOpened_pushed (PropertyChangeList changes  , Library_Member p_member ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_sessionOpened_pushed in model Library_Library");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges
			for (OCLAny o : this.Application_Main_library_back) {
				((Application_Main)o).event_sessionOpened_pulled_edge0(changes, this , p_member);
			}


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_loginFailed_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_loginFailed_pushed in model Library_Library");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges
			for (OCLAny o : this.Application_Main_library_back) {
				((Application_Main)o).event_loginFailed_pulled_edge0(changes, this );
			}


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 




	 
	public OCLSet get_findBooks(OCLString p_term, OCLString p_category) {
		/* ==================================================
	 * catalogue->select(b:Book | 
	 *    (category='Title' and b.title=term)
	 *    or (category = 'ISBN' and b.isbn = term)
	 *    or (category ='Author' and b.authors->exists(a : Author | a.name = term)))
	 * ================================================== */
	
	Library_Library v2 = this;
	OCLSet v1 = v2.get_catalogue();
	OCLSet v0 = new OCLSet();
	Iterator<OCLAny> v0_iter = v1.iterator();
	while (v0_iter.hasNext()) {
			Library_Book v3 = (Library_Book)v0_iter.next();
			OCLString v8 = p_category;
			OCLString v9 = new OCLString("Title");
			OCLBoolean v7;
			if (v8 == null || v9 == null) {
					v7 = new OCLBoolean(v8 == v9);
			} else {
					v7 = v8.eq(v9);
			}
			Library_Book v12 = v3;
			OCLString v11 = v12.get_title();
			OCLString v13 = p_term;
			OCLBoolean v10;
			if (v11 == null || v13 == null) {
					v10 = new OCLBoolean(v11 == v13);
			} else {
					v10 = v11.eq(v13);
			}
			OCLBoolean v6 = v7.and(v10);
			OCLString v16 = p_category;
			OCLString v17 = new OCLString("ISBN");
			OCLBoolean v15;
			if (v16 == null || v17 == null) {
					v15 = new OCLBoolean(v16 == v17);
			} else {
					v15 = v16.eq(v17);
			}
			Library_Book v20 = v3;
			OCLString v19 = v20.get_isbn();
			OCLString v21 = p_term;
			OCLBoolean v18;
			if (v19 == null || v21 == null) {
					v18 = new OCLBoolean(v19 == v21);
			} else {
					v18 = v19.eq(v21);
			}
			OCLBoolean v14 = v15.and(v18);
			OCLBoolean v5 = v6.or(v14);
			OCLString v24 = p_category;
			OCLString v25 = new OCLString("Author");
			OCLBoolean v23;
			if (v24 == null || v25 == null) {
					v23 = new OCLBoolean(v24 == v25);
			} else {
					v23 = v24.eq(v25);
			}
			Library_Book v28 = v3;
			OCLSet v27 = v28.get_authors();
			OCLBoolean v26 = new OCLBoolean(false);
			Iterator<OCLAny> v26_iter = v27.iterator();
			while (v26_iter.hasNext()) {
					Library_Author v29 = (Library_Author)v26_iter.next();
					Library_Author v32 = v29;
					OCLString v31 = v32.get_name();
					OCLString v33 = p_term;
					OCLBoolean v30;
					if (v31 == null || v33 == null) {
							v30 = new OCLBoolean(v31 == v33);
					} else {
							v30 = v31.eq(v33);
					}
					if (v30.value == true) {
							v26 = new OCLBoolean(true);
					}
					if (v26.value == true) { break; }
			}
			OCLBoolean v22 = v23.and(v26);
			OCLBoolean v4 = v5.or(v22);
			if (v4.value == true) { v0.add(v3); }
	}
	;
		return v0;
	}
	public Library_Member get_findMember(OCLString p_libNo) {
		/* ==================================================
	 * members->any (m: Library::Member | m.libraryNo = libNo) 
	 * ================================================== */
	
	Library_Library v2 = this;
	OCLSet v1 = v2.get_members();
	Library_Member v0 = null;
	Iterator<OCLAny> v0_iter = v1.iterator();
	while (v0_iter.hasNext()) {
			Library_Member v3 = (Library_Member)v0_iter.next();
			Library_Member v6 = v3;
			OCLString v5 = v6.get_libraryNo();
			OCLString v7 = p_libNo;
			OCLBoolean v4;
			if (v5 == null || v7 == null) {
					v4 = new OCLBoolean(v5 == v7);
			} else {
					v4 = v5.eq(v7);
			}
			if (v4.value == true) {
					v0 = v3;
			}
			if (v0 != null) { break; }
	}
	;
		return v0;
	}
	public OCLSet get_copies() {
		/* ==================================================
	 * catalogue->collect(copies)->asSet()
	 * ================================================== */
	
	Library_Library v3 = this;
	OCLSet v2 = v3.get_catalogue();
	OCLBag v1_nested = new OCLBag();
	Iterator<OCLAny> v1_iter = v2.iterator();
	while (v1_iter.hasNext()) {
			Library_Book v4 = (Library_Book)v1_iter.next();
			Library_Book v6 = v4;
			OCLSet v5 = v6.get_copies();
			v1_nested.add(v5);
	}
	OCLBag v1 = v1_nested.flatten();
	OCLSet v0 = v1.asSet();
	;
		return v0;
	}
	public OCLBoolean get_existsMember(OCLString p_libNo, OCLString p_pw) {
		/* ==================================================
	 * members->exists (m: Library::Member | m.libraryNo = libNo and m.password = pw) 
	 * ================================================== */
	
	Library_Library v2 = this;
	OCLSet v1 = v2.get_members();
	OCLBoolean v0 = new OCLBoolean(false);
	Iterator<OCLAny> v0_iter = v1.iterator();
	while (v0_iter.hasNext()) {
			Library_Member v3 = (Library_Member)v0_iter.next();
			Library_Member v7 = v3;
			OCLString v6 = v7.get_libraryNo();
			OCLString v8 = p_libNo;
			OCLBoolean v5;
			if (v6 == null || v8 == null) {
					v5 = new OCLBoolean(v6 == v8);
			} else {
					v5 = v6.eq(v8);
			}
			Library_Member v11 = v3;
			OCLString v10 = v11.get_password();
			OCLString v12 = p_pw;
			OCLBoolean v9;
			if (v10 == null || v12 == null) {
					v9 = new OCLBoolean(v10 == v12);
			} else {
					v9 = v10.eq(v12);
			}
			OCLBoolean v4 = v5.and(v9);
			if (v4.value == true) {
					v0 = new OCLBoolean(true);
			}
			if (v0.value == true) { break; }
	}
	;
		return v0;
	}


	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

