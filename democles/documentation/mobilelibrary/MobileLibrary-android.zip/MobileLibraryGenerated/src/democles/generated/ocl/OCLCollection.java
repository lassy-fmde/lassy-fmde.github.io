package democles.generated.ocl;

import java.util.Arrays;
import java.util.Iterator;

abstract public class OCLCollection implements OCLAny, Iterable<OCLAny> {
    
    abstract public OCLCollection newCollection();
    
    abstract public void add(OCLAny object);
    
    abstract public OCLInteger size();
    
    abstract public OCLBoolean includes(OCLAny object);
    
    public OCLCollection flatten() {
        OCLCollection res = this.newCollection();
        
        for (OCLAny o : this) {
            if (o instanceof OCLCollection) {
                OCLCollection flattenedContainedCollection = ((OCLCollection)o).flatten(); 
                for (OCLAny o2 : flattenedContainedCollection) {
                    res.add(o2);
                }
            } else {
                res.add(o);
            }
        }
        return res;
    }
    
    abstract public String collectionName();
    
    public OCLInteger count(OCLAny object) {
        int res = 0;
        
        for (OCLAny o : this) {
            if (o == null) {
                res += object == null ? 1 : 0;
            } else {
                res += o.equals(object) ? 1 : 0;
            }
        }
        
        return new OCLInteger(res);
    }
    
    public OCLBoolean excludes(OCLAny object) {
        return this.includes(object).not();
    }

    public OCLBoolean includesAll(OCLCollection collection) {
        boolean res = true;
        
        OCLInteger cCount = collection.size();
        OCLInteger thisCount = this.size();
        
        if (thisCount.gte(cCount).value) {
            for (OCLAny o : collection) {
                OCLBoolean included = this.includes(o);
                if (included.not().value) {
                    res = false;
                    break;
                }
            }
        } else {
            res = false;
        }
        return new OCLBoolean(res);
    }

    public OCLBoolean excludesAll(OCLCollection collection) {
        boolean res = true;
        
        for (OCLAny o : collection) {
            OCLBoolean included = this.includes(o);
            if (included.value) {
                res = false;
                break;
            }
        }
        
        return new OCLBoolean(res);
    }
    
    public OCLBoolean isEmpty() {
        return new OCLBoolean(this.size().value == 0);
    }

    public OCLBoolean notEmpty() {
        return this.isEmpty().not();
    }

    public OCLAny sum() {
        
        if (this.isEmpty().value) {
            return new OCLInteger(0);
        }

        // TODO suboptimal: we look at the first element to determine the result type.
        // It would be better to start with integer and promote to real when a real is encountered. 
        OCLAny first = this.iterator().next();
        if (first instanceof OCLInteger) {
            int res = 0;
            for (OCLAny o1 : this) {
                res += ((OCLInteger)o1).value;
            }
            return new OCLInteger(res);
        } else { // must be OCLReal
            float res = 0;
            for (OCLAny o1 : this) {
                res += ((OCLReal)o1).value;
            }
            return new OCLReal(res);
        }        
    }
    
    public OCLSet product(OCLCollection collection) {
        OCLSet res = new OCLSet();
        
        for (OCLAny o1 : this) {
            for (OCLAny o2 : collection) {
                OCLTuple tuple = new OCLTuple();
                tuple.addItem("first", o1);
                tuple.addItem("second", o2);
                res.add(tuple);
            }
        }
        
        return res;        
    }
    
    public OCLSet asSet() {
        OCLSet res = new OCLSet();
        for (OCLAny o : this) {
            res.add(o);
        }
        return res;
    }
    
    public OCLOrderedSet asOrderedSet() {
        OCLOrderedSet res = new OCLOrderedSet();
        for (OCLAny o : this) {
            res.add(o);
        }
        return res;
    }
    
    public OCLSequence asSequence() {
        OCLSequence res = new OCLSequence();
        for (OCLAny o : this) {
            res.add(o);
        }
        return res;
    }

    public OCLBag asBag() {
        OCLBag res = new OCLBag();
        for (OCLAny o : this) {
            res.add(o);
        }
        return res;
    }

    @Override
    public String toString() {
        StringBuffer res = new StringBuffer(this.collectionName());
        res.append("(");
        
        Iterator<OCLAny> iter = this.iterator();
        while (iter.hasNext()) {
            OCLAny item = iter.next();
            res.append(item);
            if (iter.hasNext()) {
                res.append(", ");
            }
        }
        
        res.append(")");
        return res.toString();
    }

    // OCLAny implementation, using delegation so that inheritance remains available. -----------------
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }
}
