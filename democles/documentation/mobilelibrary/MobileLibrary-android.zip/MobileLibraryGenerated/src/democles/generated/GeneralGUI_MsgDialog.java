 
	  
package democles.generated;

import java.util.Vector;
import java.util.ArrayList;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
import android.content.Context;
import android.view.View;

	 
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Intent;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;
import java.util.Collection;

	 
public class GeneralGUI_MsgDialog extends Activity implements OCLAny {
	 
	private OCLString _msg;
	private boolean _msg_isInitialized;
	private OCLString _viewTitle;
	private boolean _viewTitle_isInitialized;

	public Vector<OCLAny> MobileLibraryGUI_BookDetailWindowController_msg_back = new Vector<OCLAny>();
	public Vector<OCLAny> MobileLibraryGUI_MemberWindowController_currMsg_back = new Vector<OCLAny>();
	public Vector<OCLAny> MobileLibraryGUI_LoginWindowController_currMsg_back = new Vector<OCLAny>();

	private Object context;
	private OCLTuple initialPropertyValues = new OCLTuple();
	

	
  
	final static private String INIT_PROP_VALUES_KEY = "initialPropertyValues";
	final static private String HOLDER_KEY = "instanceHolder";
    
    static class Holder {
        public GeneralGUI_MsgDialog instance = null;
    }

	 
    public GeneralGUI_MsgDialog() {
        super();
        this.context = this;
    }

	 
    public static GeneralGUI_MsgDialog newInstance(Object contextObject) {
		if (contextObject == null) throw new NullPointerException();
    	return newInstance(contextObject, null);
    }
    
    public static GeneralGUI_MsgDialog newInstance(Object contextObject, OCLTuple initialPropertyValues) {
		if (contextObject == null) throw new NullPointerException();

    	Context context = (Context)contextObject;
        Thread currentThread = Thread.currentThread();
        Thread mainThread = context.getMainLooper().getThread();
        
        if (currentThread == mainThread) {
            throw new RuntimeException("GeneralGUI_MsgDialog can not be instantiated from the UI thread.");
        }
        
        final Intent intent = new Intent(context, GeneralGUI_MsgDialog.class);
        if (initialPropertyValues != null) {
            Long initDataKey = InitializationDataHolder.putData(initialPropertyValues);
            intent.putExtra(INIT_PROP_VALUES_KEY, initDataKey);
        }
        
        Holder holder = new Holder();
        Long holderKey = InitializationDataHolder.putData(holder);
        intent.putExtra(HOLDER_KEY, holderKey);

        final Context contextClosure = context;
        new Thread() {
            public void run() {
                contextClosure.startActivity(intent);
            };
        }.start();
        
        synchronized(holder) {
            try {
                holder.wait();
            } catch (InterruptedException e) {
            }
        }
        return holder.instance;
    }
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        OCLTuple values = null;
        
        Bundle extras = this.getIntent().getExtras();
        if (extras != null) {
            Long initDataKey = extras.getLong(INIT_PROP_VALUES_KEY);
            if (initDataKey != null) {
                values = (OCLTuple)InitializationDataHolder.retrieveData(initDataKey);
            }
            
            Long holderKey = extras.getLong(HOLDER_KEY);
            Holder holder = (Holder)InitializationDataHolder.retrieveData(holderKey);
            holder.instance = this;
            
            synchronized(holder) {
                holder.notify();
            }
        }
        
		 
		this._msg_isInitialized = false; 
		this._viewTitle_isInitialized = false; 

		if (values == null) values = new OCLTuple(); // Empty
        this.initialPropertyValues = values;
		
		if (values.containsKey("msg")) {
			this.set_msg((OCLString)values.objectForKey("msg"));
		} else {
			if (!this._msg_isInitialized) this.set_msg(this.initial_msg());
		}
		if (values.containsKey("viewTitle")) {
			this.set_viewTitle((OCLString)values.objectForKey("viewTitle"));
		} else {
			if (!this._viewTitle_isInitialized) this.set_viewTitle(this.initial_viewTitle());
		}


        
        this.showAlert();
    }

	 
	public OCLString initial_msg() {
		if (this.initialPropertyValues.containsKey("msg")) {
			return (OCLString)this.initialPropertyValues.objectForKey("msg");
		}
		/* ==================================================
	 * ''
	 * ================================================== */
	
	OCLString v0 = new OCLString("");
	
		return v0;
	}

	public OCLString get_msg(){
		if (this._msg_isInitialized) {
			return _msg;
		} else { 
			this.set_msg(this.initial_msg());
		}
		this._msg_isInitialized = true;
		return this._msg;
	}
	public OCLString initial_viewTitle() {
		if (this.initialPropertyValues.containsKey("viewTitle")) {
			return (OCLString)this.initialPropertyValues.objectForKey("viewTitle");
		}
		/* ==================================================
	 * ''
	 * ================================================== */
	
	OCLString v0 = new OCLString("");
	
		return v0;
	}

	public OCLString get_viewTitle(){
		if (this._viewTitle_isInitialized) {
			return _viewTitle;
		} else { 
			this.set_viewTitle(this.initial_viewTitle());
		}
		this._viewTitle_isInitialized = true;
		return this._viewTitle;
	}


	 
	public void set_msg(OCLString value) {
		 	
		this._msg = value;
		this._msg_isInitialized = true;

		this.onPropertyChange("msg",value);
	}
	public void set_viewTitle(OCLString value) {
		 	
		this._viewTitle = value;
		this._viewTitle_isInitialized = true;

		this.onPropertyChange("viewTitle",value);
	}






	 
 	public void event_okClicked_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			
			this.onEvent("okClicked", parameterTuple);
			
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges
			for (OCLAny o : this.MobileLibraryGUI_LoginWindowController_currMsg_back) {
				((MobileLibraryGUI_LoginWindowController)o).event_loginAck_pulled_edge0(changes, this );
			}
			for (OCLAny o : this.MobileLibraryGUI_BookDetailWindowController_msg_back) {
				((MobileLibraryGUI_BookDetailWindowController)o).event_reserveAck_pulled_edge0(changes, this );
			}
			for (OCLAny o : this.MobileLibraryGUI_MemberWindowController_currMsg_back) {
				((MobileLibraryGUI_MemberWindowController)o).event_renewAck_pulled_edge0(changes, this );
			}


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {

				this.event_close_pushed(changes );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_close_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			
			this.onEvent("close", parameterTuple);
			
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 




	 


	 
	public void onPropertyChange(String propertyName, Object value) {
	}

	 
	public void onEvent(String eventName, OCLTuple parameters) {
		if (eventName.equals("close")) {
			this.finish();
		}
	}

	  
	private void showAlert() {
		Builder bldr = new AlertDialog.Builder(this);
		bldr.setMessage(this.get_msg().string);
		bldr.setTitle(this.get_viewTitle().string);
		bldr.setPositiveButton("Ok", new DialogInterface.OnClickListener() {			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				new Thread() {
					public void run() {
						event_okClicked_pushed(null);
					};
				}.start();
			}
		});
		bldr.setCancelable(false);
		bldr.show();
	}

	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

