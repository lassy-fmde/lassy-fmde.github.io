 
	  
package democles.generated;

import java.util.Vector;
import java.util.ArrayList;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
public class MobileLibraryGUI_BookListWindowController implements OCLAny {
	 
	private GeneralGUI_SelectionList _bookListTable;
	private boolean _bookListTable_isInitialized;
	private MobileLibraryGUI_BookDetailWindowController _detailsWindow;
	private boolean _detailsWindow_isInitialized;
	private OCLString _title;
	private boolean _title_isInitialized;
	private GeneralGUI_Window _window;
	private boolean _window_isInitialized;
	private OCLString _mode;
	private boolean _mode_isInitialized;
	private Library_Member _currMember;
	private boolean _currMember_isInitialized;

	public Vector<OCLAny> MobileLibraryGUI_SearchWindowController_resultWindow_back = new Vector<OCLAny>();

	private Object context;
	private OCLTuple initialPropertyValues = new OCLTuple();
	

	 
	private MobileLibraryGUI_BookListWindowController(Object context) {
		super();
		this.context = context;
		 
		if (!this._bookListTable_isInitialized) this.set_bookListTable(this.initial_bookListTable()); 
		if (!this._detailsWindow_isInitialized) this.set_detailsWindow(this.initial_detailsWindow()); 
		if (!this._title_isInitialized) this.set_title(this.initial_title()); 
		if (!this._window_isInitialized) this.set_window(this.initial_window()); 
		if (!this._mode_isInitialized) this.set_mode(this.initial_mode()); 
		if (!this._currMember_isInitialized) this.set_currMember(this.initial_currMember()); 


	}
	
	static public MobileLibraryGUI_BookListWindowController newInstance(Object context) {
		if (context == null) throw new NullPointerException();
		return new MobileLibraryGUI_BookListWindowController(context);
	}
 
	 
	private MobileLibraryGUI_BookListWindowController(Object context, OCLTuple values) {
		super();
		this.context = context;
		if (values != null) this.initialPropertyValues = values;

		 
		this._bookListTable_isInitialized = false; 
		this._detailsWindow_isInitialized = false; 
		this._title_isInitialized = false; 
		this._window_isInitialized = false; 
		this._mode_isInitialized = false; 
		this._currMember_isInitialized = false; 

		if (values == null) values = new OCLTuple(); // Empty
        this.initialPropertyValues = values;
		
		if (values.containsKey("bookListTable")) {
			this.set_bookListTable((GeneralGUI_SelectionList)values.objectForKey("bookListTable"));
		} else {
			if (!this._bookListTable_isInitialized) this.set_bookListTable(this.initial_bookListTable());
		}
		if (values.containsKey("detailsWindow")) {
			this.set_detailsWindow((MobileLibraryGUI_BookDetailWindowController)values.objectForKey("detailsWindow"));
		} else {
			if (!this._detailsWindow_isInitialized) this.set_detailsWindow(this.initial_detailsWindow());
		}
		if (values.containsKey("title")) {
			this.set_title((OCLString)values.objectForKey("title"));
		} else {
			if (!this._title_isInitialized) this.set_title(this.initial_title());
		}
		if (values.containsKey("window")) {
			this.set_window((GeneralGUI_Window)values.objectForKey("window"));
		} else {
			if (!this._window_isInitialized) this.set_window(this.initial_window());
		}
		if (values.containsKey("mode")) {
			this.set_mode((OCLString)values.objectForKey("mode"));
		} else {
			if (!this._mode_isInitialized) this.set_mode(this.initial_mode());
		}
		if (values.containsKey("currMember")) {
			this.set_currMember((Library_Member)values.objectForKey("currMember"));
		} else {
			if (!this._currMember_isInitialized) this.set_currMember(this.initial_currMember());
		}


	}

	static public MobileLibraryGUI_BookListWindowController newInstance(Object context, OCLTuple values) {
		if (context == null) throw new NullPointerException();
		return new MobileLibraryGUI_BookListWindowController(context, values);
	}

	 
	public GeneralGUI_SelectionList initial_bookListTable() {
		if (this.initialPropertyValues.containsKey("bookListTable")) {
			return (GeneralGUI_SelectionList)this.initialPropertyValues.objectForKey("bookListTable");
		}
		/* ==================================================
	 * null
	 * ================================================== */
	
	GeneralGUI_SelectionList v0 = null;
	
		return v0;
	}

	public GeneralGUI_SelectionList get_bookListTable(){
		if (this._bookListTable_isInitialized) {
			return _bookListTable;
		} else { 
			this.set_bookListTable(this.initial_bookListTable());
		}
		this._bookListTable_isInitialized = true;
		return this._bookListTable;
	}
	public MobileLibraryGUI_BookDetailWindowController initial_detailsWindow() {
		if (this.initialPropertyValues.containsKey("detailsWindow")) {
			return (MobileLibraryGUI_BookDetailWindowController)this.initialPropertyValues.objectForKey("detailsWindow");
		}
		/* ==================================================
	 * null
	 * ================================================== */
	
	MobileLibraryGUI_BookDetailWindowController v0 = null;
	
		return v0;
	}

	public MobileLibraryGUI_BookDetailWindowController get_detailsWindow(){
		if (this._detailsWindow_isInitialized) {
			return _detailsWindow;
		} else { 
			this.set_detailsWindow(this.initial_detailsWindow());
		}
		this._detailsWindow_isInitialized = true;
		return this._detailsWindow;
	}
	public OCLString initial_title() {
		if (this.initialPropertyValues.containsKey("title")) {
			return (OCLString)this.initialPropertyValues.objectForKey("title");
		}
		/* ==================================================
	 * 'Results'
	 * ================================================== */
	
	OCLString v0 = new OCLString("Results");
	
		return v0;
	}

	public OCLString get_title(){
		if (this._title_isInitialized) {
			return _title;
		} else { 
			this.set_title(this.initial_title());
		}
		this._title_isInitialized = true;
		return this._title;
	}
	public GeneralGUI_Window initial_window() {
		if (this.initialPropertyValues.containsKey("window")) {
			return (GeneralGUI_Window)this.initialPropertyValues.objectForKey("window");
		}
		/* ==================================================
	 * GeneralGUI::Window::create(
	 * 	Tuple { seqGUIElements = Sequence {bookListTable }, 
	 * 	title = title })
	 * ================================================== */
	
	MobileLibraryGUI_BookListWindowController v7 = this;
	GeneralGUI_SelectionList v6 = v7.get_bookListTable();
	GeneralGUI_SelectionList v5 = v6;
	OCLSequence v4 = new OCLSequence();
	v4.add(v5);
	OCLSequence v3 = v4;
	MobileLibraryGUI_BookListWindowController v10 = this;
	OCLString v9 = v10.get_title();
	OCLString v8 = v9;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("seqGUIElements", v3);
	v2.addItem("title", v8);
	GeneralGUI_Window v0 = GeneralGUI_Window.newInstance(this.context, v2);
	
		return v0;
	}

	public GeneralGUI_Window get_window(){
		if (this._window_isInitialized) {
			return _window;
		} else { 
			this.set_window(this.initial_window());
		}
		this._window_isInitialized = true;
		return this._window;
	}
	public OCLString initial_mode() {
		if (this.initialPropertyValues.containsKey("mode")) {
			return (OCLString)this.initialPropertyValues.objectForKey("mode");
		}
		/* ==================================================
	 * 'NotLoggedIn'
	 * ================================================== */
	
	OCLString v0 = new OCLString("NotLoggedIn");
	
		return v0;
	}

	public OCLString get_mode(){
		if (this._mode_isInitialized) {
			return _mode;
		} else { 
			this.set_mode(this.initial_mode());
		}
		this._mode_isInitialized = true;
		return this._mode;
	}
	public Library_Member initial_currMember() {
		if (this.initialPropertyValues.containsKey("currMember")) {
			return (Library_Member)this.initialPropertyValues.objectForKey("currMember");
		}
		/* ==================================================
	 * null
	 * ================================================== */
	
	Library_Member v0 = null;
	
		return v0;
	}

	public Library_Member get_currMember(){
		if (this._currMember_isInitialized) {
			return _currMember;
		} else { 
			this.set_currMember(this.initial_currMember());
		}
		this._currMember_isInitialized = true;
		return this._currMember;
	}


	 
	public void set_title(OCLString value) {
	 	
		this._title = value;
		this._title_isInitialized = true;

	}
	public void set_mode(OCLString value) {
	 	
		this._mode = value;
		this._mode_isInitialized = true;

	}


	public void set_bookListTable(GeneralGUI_SelectionList value) {
	 	
		if (this._bookListTable!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._bookListTable.MobileLibraryGUI_BookListWindowController_bookListTable_back;
			backpointers.removeElement(this);
		}
		this._bookListTable = value;
		if (this._bookListTable!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._bookListTable.MobileLibraryGUI_BookListWindowController_bookListTable_back;
			backpointers.addElement(this);
		}
		this._bookListTable_isInitialized = true;

	}
	public void set_detailsWindow(MobileLibraryGUI_BookDetailWindowController value) {
	 	
		if (this._detailsWindow!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._detailsWindow.MobileLibraryGUI_BookListWindowController_detailsWindow_back;
			backpointers.removeElement(this);
		}
		this._detailsWindow = value;
		if (this._detailsWindow!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._detailsWindow.MobileLibraryGUI_BookListWindowController_detailsWindow_back;
			backpointers.addElement(this);
		}
		this._detailsWindow_isInitialized = true;

	}
	public void set_window(GeneralGUI_Window value) {
	 	
		if (this._window!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._window.MobileLibraryGUI_BookListWindowController_window_back;
			backpointers.removeElement(this);
		}
		this._window = value;
		if (this._window!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._window.MobileLibraryGUI_BookListWindowController_window_back;
			backpointers.addElement(this);
		}
		this._window_isInitialized = true;

	}
	public void set_currMember(Library_Member value) {
	 	
		if (this._currMember!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._currMember.MobileLibraryGUI_BookListWindowController_currMember_back;
			backpointers.removeElement(this);
		}
		this._currMember = value;
		if (this._currMember!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._currMember.MobileLibraryGUI_BookListWindowController_currMember_back;
			backpointers.addElement(this);
		}
		this._currMember_isInitialized = true;

	}




	 
 	public void event_bookSelected_pushed (PropertyChangeList changes  , OCLInteger p_index ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_bookSelected_pushed in model MobileLibraryGUI_BookListWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges
			for (OCLAny o : this.MobileLibraryGUI_SearchWindowController_resultWindow_back) {
				((MobileLibraryGUI_SearchWindowController)o).event_bookSelected_pulled_edge0(changes, this , p_index);
			}


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_bookSelected_pulled_edge0(PropertyChangeList changes, GeneralGUI_SelectionList parentInstance ,OCLInteger p_index  ) {
		System.out.println("event_bookSelected_pulled in model MobileLibraryGUI_BookListWindowController from event _itemSelected in model GeneralGUI_SelectionList");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {
			/* ==================================================
		 * index
		 * ================================================== */
		
		OCLInteger v1 = p_index;
		
			OCLInteger parameter_p_index = v1;

			this.event_bookSelected_pushed(changes ,parameter_p_index  );
		}
	}


 	public void event_selectedBook_pushed (PropertyChangeList changes  , Library_Book p_book ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_selectedBook_pushed in model MobileLibraryGUI_BookListWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * BookDetailWindowController::create(
		 * Tuple { 
		 * 	bookTitleLabel = GeneralGUI::Label::create(Tuple { text = book.title }), 
		 * 	bookAuthorLabel = GeneralGUI::Label::create(Tuple { text = getAuthorsData (book) }), 
		 * 	bookIsbnLabel = GeneralGUI::Label::create(Tuple { text = book.isbn }),
		 * 	bookCopies = GeneralGUI::SelectionList::create(Tuple { items = getBookCopiesData (book) }),
		 * 	currBook = book,
		 * 	currMember = currMember,
		 * 	mode = mode
		 * })
		 * ================================================== */
		
		Library_Book v9 = p_book;
		OCLString v8 = v9.get_title();
		OCLString v7 = v8;
		OCLTuple v6 = new OCLTuple();
		v6.addItem("text", v7);
		GeneralGUI_Label v4 = GeneralGUI_Label.newInstance(this.context, v6);
		GeneralGUI_Label v3 = v4;
		MobileLibraryGUI_BookListWindowController v16 = this;
		Library_Book v17 = p_book;
		OCLString v15 = v16.get_getAuthorsData(v17);
		OCLString v14 = v15;
		OCLTuple v13 = new OCLTuple();
		v13.addItem("text", v14);
		GeneralGUI_Label v11 = GeneralGUI_Label.newInstance(this.context, v13);
		GeneralGUI_Label v10 = v11;
		Library_Book v24 = p_book;
		OCLString v23 = v24.get_isbn();
		OCLString v22 = v23;
		OCLTuple v21 = new OCLTuple();
		v21.addItem("text", v22);
		GeneralGUI_Label v19 = GeneralGUI_Label.newInstance(this.context, v21);
		GeneralGUI_Label v18 = v19;
		MobileLibraryGUI_BookListWindowController v31 = this;
		Library_Book v32 = p_book;
		OCLSequence v30 = v31.get_getBookCopiesData(v32);
		OCLSequence v29 = v30;
		OCLTuple v28 = new OCLTuple();
		v28.addItem("items", v29);
		GeneralGUI_SelectionList v26 = GeneralGUI_SelectionList.newInstance(this.context, v28);
		GeneralGUI_SelectionList v25 = v26;
		Library_Book v34 = p_book;
		Library_Book v33 = v34;
		MobileLibraryGUI_BookListWindowController v37 = this;
		Library_Member v36 = v37.get_currMember();
		Library_Member v35 = v36;
		MobileLibraryGUI_BookListWindowController v40 = this;
		OCLString v39 = v40.get_mode();
		OCLString v38 = v39;
		OCLTuple v2 = new OCLTuple();
		v2.addItem("bookTitleLabel", v3);
		v2.addItem("bookAuthorLabel", v10);
		v2.addItem("bookIsbnLabel", v18);
		v2.addItem("bookCopies", v25);
		v2.addItem("currBook", v33);
		v2.addItem("currMember", v35);
		v2.addItem("mode", v38);
		MobileLibraryGUI_BookDetailWindowController v0 = MobileLibraryGUI_BookDetailWindowController.newInstance(this.context, v2);
		
			MobileLibraryGUI_BookDetailWindowController _detailsWindow_newValue = v0;
			changes.addChange("_detailsWindow", this, _detailsWindow_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_refreshAndSave_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_refreshAndSave_pushed in model MobileLibraryGUI_BookListWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges
			for (OCLAny o : this.MobileLibraryGUI_SearchWindowController_resultWindow_back) {
				((MobileLibraryGUI_SearchWindowController)o).event_refreshAndSave_pulled_edge0(changes, this );
			}


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_refreshAndSave_pulled_edge0(PropertyChangeList changes, MobileLibraryGUI_BookDetailWindowController parentInstance  ) {
		System.out.println("event_refreshAndSave_pulled in model MobileLibraryGUI_BookListWindowController from event _refreshAndSave in model MobileLibraryGUI_BookDetailWindowController");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {

			this.event_refreshAndSave_pushed(changes  );
		}
	}


 	public void event_memberSessionStarted_pushed (PropertyChangeList changes  , Library_Member p_m ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_memberSessionStarted_pushed in model MobileLibraryGUI_BookListWindowController");
			 		
			// Trigger Push edges


			if (this._detailsWindow != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._detailsWindow);
				for (Object o : edge0_values) {
					MobileLibraryGUI_BookDetailWindowController edge0_target = (MobileLibraryGUI_BookDetailWindowController)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * m
				 * ================================================== */
				
				Library_Member v1 = p_m;
				
						Library_Member parameter_p_m = v1;

						edge0_target.event_memberSessionStarted_pushed(changes ,parameter_p_m );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * 'LoggedIn'
		 * ================================================== */
		
		OCLString v0 = new OCLString("LoggedIn");
		
			OCLString _mode_newValue = v0;
			changes.addChange("_mode", this, _mode_newValue);
			/* ==================================================
		 * m
		 * ================================================== */
		
		Library_Member v1 = p_m;
		
			Library_Member _currMember_newValue = v1;
			changes.addChange("_currMember", this, _currMember_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 




	 
	public OCLSequence get_getBookCopiesData(Library_Book p_book) {
		/* ==================================================
	 * book.copies->collect(
	 * 	copyId.concat(' ').concat(state).concat(' ').concat(dueDate)
	 * )->asSequence()
	 * ================================================== */
	
	Library_Book v3 = p_book;
	OCLSet v2 = v3.get_copies();
	OCLBag v1_nested = new OCLBag();
	Iterator<OCLAny> v1_iter = v2.iterator();
	while (v1_iter.hasNext()) {
			Library_Copy v4 = (Library_Copy)v1_iter.next();
			Library_Copy v10 = v4;
			OCLString v9 = v10.get_copyId();
			OCLString v11 = new OCLString(" ");
			OCLString v8 = v9.concat(v11);
			Library_Copy v13 = v4;
			OCLString v12 = v13.get_state();
			OCLString v7 = v8.concat(v12);
			OCLString v14 = new OCLString(" ");
			OCLString v6 = v7.concat(v14);
			Library_Copy v16 = v4;
			OCLString v15 = v16.get_dueDate();
			OCLString v5 = v6.concat(v15);
			v1_nested.add(v5);
	}
	OCLBag v1 = v1_nested.flatten();
	OCLSequence v0 = v1.asSequence();
	;
		return v0;
	}
	public OCLString get_getAuthorsData(Library_Book p_book) {
		/* ==================================================
	 * book.authors->iterate(a : Library::Author; authorStr : String = '' | authorStr.concat(a.name).concat(', '))
	 * ================================================== */
	
	Library_Book v2 = p_book;
	OCLSet v1 = v2.get_authors();
	OCLString v5 = new OCLString("");
	OCLString v4 = (OCLString)v5;
	Iterator<OCLAny> v0_iter = v1.iterator();
	while (v0_iter.hasNext()) {
			Library_Author v3 = (Library_Author)v0_iter.next();
			OCLString v8 = v4;
			Library_Author v10 = v3;
			OCLString v9 = v10.get_name();
			OCLString v7 = v8.concat(v9);
			OCLString v11 = new OCLString(", ");
			OCLString v6 = v7.concat(v11);
			v4 = v6;
	}
	OCLString v0 = v4;
	;
		return v0;
	}


	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

