 
	  
package democles.generated;

import java.util.Vector;
import java.util.ArrayList;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
import android.content.Context;
import android.view.View;

	 
import android.widget.ImageView;
import android.app.Activity;
import java.io.IOException;
import java.io.InputStream;
import android.graphics.drawable.BitmapDrawable;

	 
public class GeneralGUI_Image implements IWidgetWrapper, OCLAny {
	 
	private OCLString _imageFilename;
	private boolean _imageFilename_isInitialized;

	public Vector<OCLAny> MobileLibraryGUI_StartWindowController_uniLogo_back = new Vector<OCLAny>();

	private Object context;
	private OCLTuple initialPropertyValues = new OCLTuple();
	

	  
	private ImageView imageView;

	 
	private GeneralGUI_Image(Object context) {
		super();
		this.context = context;
		 
		if (!this._imageFilename_isInitialized) this.set_imageFilename(this.initial_imageFilename()); 


	}
	
	static public GeneralGUI_Image newInstance(Object context) {
		if (context == null) throw new NullPointerException();
		return new GeneralGUI_Image(context);
	}
 
	 
	private GeneralGUI_Image(Object context, OCLTuple values) {
		super();
		this.context = context;
		if (values != null) this.initialPropertyValues = values;

		 
		this._imageFilename_isInitialized = false; 

		if (values == null) values = new OCLTuple(); // Empty
        this.initialPropertyValues = values;
		
		if (values.containsKey("imageFilename")) {
			this.set_imageFilename((OCLString)values.objectForKey("imageFilename"));
		} else {
			if (!this._imageFilename_isInitialized) this.set_imageFilename(this.initial_imageFilename());
		}


	}

	static public GeneralGUI_Image newInstance(Object context, OCLTuple values) {
		if (context == null) throw new NullPointerException();
		return new GeneralGUI_Image(context, values);
	}

	 
	public OCLString initial_imageFilename() {
		if (this.initialPropertyValues.containsKey("imageFilename")) {
			return (OCLString)this.initialPropertyValues.objectForKey("imageFilename");
		}
		/* ==================================================
	 * null
	 * ================================================== */
	
	OCLString v0 = null;
	
		return v0;
	}

	public OCLString get_imageFilename(){
		if (this._imageFilename_isInitialized) {
			return _imageFilename;
		} else { 
			this.set_imageFilename(this.initial_imageFilename());
		}
		this._imageFilename_isInitialized = true;
		return this._imageFilename;
	}


	 
	public void set_imageFilename(OCLString value) {
		 	
		this._imageFilename = value;
		this._imageFilename_isInitialized = true;

		this.onPropertyChange("imageFilename",value);
	}






	 


	 


	 
	public void onPropertyChange(String propertyName, Object value) {
		if (propertyName.equals("imageFilename")) {
			if (value != null) {
				updateImageView();
			}
		}
	}

	 
	public void onEvent(String eventName, OCLTuple parameters) {
	}

	  
	@Override
    public View createWidget(Context context) {
    	this.imageView = new ImageView(context);
        this.updateImageView();
        return this.imageView;
    }

    private void updateImageView() {
    	if (this.imageView == null) return;
    	((Activity)this.context).runOnUiThread(new Runnable() {
            @Override
            public void run() {
            	InputStream stream;
                try {
	            	stream = ((Context)context).getAssets().open(get_imageFilename().string); 
                    BitmapDrawable d = new BitmapDrawable(stream);
                    imageView.setImageDrawable(d);
                } catch (IOException e) {
                } 
            }    	    
    	});
    }

	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

