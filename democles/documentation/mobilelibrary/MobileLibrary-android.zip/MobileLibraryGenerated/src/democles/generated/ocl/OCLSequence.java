package democles.generated.ocl;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Vector;
import java.util.Iterator;

public class OCLSequence extends OCLCollection {

    public Vector<OCLAny> values = new Vector<OCLAny>();
    
    @Override
    public OCLCollection newCollection() {
        return new OCLSequence();
    }

    @Override
    public void add(OCLAny object) {
        this.values.add(object);
    }

    @Override
    public OCLInteger size() {
        return new OCLInteger(this.values.size());
    }

    @Override
    public OCLBoolean includes(OCLAny object) {
        return new OCLBoolean(this.values.contains(object));
    }

    @Override
    public String collectionName() {
        return "Sequence";
    }

    public OCLSequence union(OCLSequence other) {
        OCLSequence res = new OCLSequence();
        res.values.addAll(this.values);
        res.values.addAll(other.values);
        return res;
    }
    
    public OCLSequence append(OCLAny object) {
        OCLSequence res = new OCLSequence();
        res.values.addAll(this.values);
        res.add(object);
        return res;
    }

    public OCLSequence prepend(OCLAny object) {
        OCLSequence res = new OCLSequence();
        res.add(object);
        res.values.addAll(this.values);
        return res;
    }
    
    public OCLSequence insertAt(OCLInteger index, OCLAny object) {
        OCLSequence res = new OCLSequence();
        res.values.addAll(this.values);
        res.values.insertElementAt(object, index.value - 1);
        return res;
    }
    
    public OCLSequence subSequence(OCLInteger lower, OCLInteger upper) {
        OCLSequence res = new OCLSequence();
        res.values.addAll(this.values.subList(lower.value - 1, upper.value));
        return res;
    }
    
    public OCLAny at(OCLInteger index) {
        return this.values.elementAt(index.value - 1);
    }
    
    public OCLInteger indexOf(OCLAny object) {
        return new OCLInteger(this.values.indexOf(object) + 1);
    }
    
    public OCLAny first() {
        return this.values.firstElement();
    }
    
    public OCLAny last() {
        return this.values.lastElement();
    }

    public OCLSequence including(OCLAny object) {
        return this.append(object);
    }
    
    public OCLSequence excluding(OCLAny object) {
        OCLSequence res = new OCLSequence();
        res.values.addAll(this.values);
        res.values.remove(object);
        return res;
    }
    
    public OCLSequence sortedByFirstSubElement() {
        OCLSequence res = new OCLSequence();
        res.values.addAll(this.values);
        
        Collections.sort(res.values, new Comparator<OCLAny>() {
            @Override
            public int compare(OCLAny o1, OCLAny o2) {
                if (o1 instanceof OCLInteger) {
                    return ((OCLInteger)o2).value - ((OCLInteger)o1).value; 
                } else if (o1 instanceof OCLReal) {
                    float diff = ((OCLReal)o2).value - ((OCLReal)o1).value;
                    if (diff == 0.0f) return 0;
                    return diff > 0.0f ? 1 : -1; 
                } else if (o1 instanceof OCLString) {
                    return ((OCLString)o2).string.compareTo(((OCLString)o1).string); 
                    
                }
                
                return 0;
            }
        });
        
        return res;
    }
    
    public OCLSequence flatten() {
        return (OCLSequence)super.flatten();
    }    

    @Override
    public Iterator<OCLAny> iterator() {
        return this.values.iterator();
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((values == null) ? 0 : values.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        OCLSequence other = (OCLSequence)obj;
        if (values == null) {
            if (other.values != null)
                return false;
        } else if (!values.equals(other.values))
            return false;
        return true;
    }
}
