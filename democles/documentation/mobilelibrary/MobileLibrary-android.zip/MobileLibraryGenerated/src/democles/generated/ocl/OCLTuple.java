package democles.generated.ocl;

import java.util.HashMap;
import java.util.Map;

public class OCLTuple implements OCLAny {

    private Map<String, OCLAny> values = new HashMap<String, OCLAny>();
    
    public void addItem(String name, OCLAny value) {
        this.values.put(name, value);
    }
    
    public OCLAny remove(String name) {
        return this.values.remove(name);
    }
    
    public Iterable<String> keyIterable() {
        return this.values.keySet();
    }
    
    public boolean containsKey(String key) {
        return this.values.containsKey(key);
    }
    
    public OCLAny objectForKey(String key) {
        return this.values.get(key);
    }
    
    @Override
    public String toString() {
        return this.values.toString();
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((values == null) ? 0 : values.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        OCLTuple other = (OCLTuple)obj;
        if (values == null) {
            if (other.values != null)
                return false;
        } else if (!values.equals(other.values))
            return false;
        return true;
    }

    // OCLAny implementation, using delegation so that inheritance remains available. -----------------
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }
}
