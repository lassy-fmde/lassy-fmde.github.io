package democles.generated.ocl;

public class OCLBoolean implements OCLAny {

    public boolean value;
    
    public OCLBoolean(boolean value) {
        this.value = value;
    }
    
    public OCLBoolean or(OCLBoolean other) {
        return new OCLBoolean(this.value || other.value);
    }
    
    public OCLBoolean xor(OCLBoolean other) {
        return new OCLBoolean(this.value ^ other.value);
    }
    
    public OCLBoolean and(OCLBoolean other) {
        return new OCLBoolean(this.value && other.value);
    }
    
    public OCLBoolean not() {
        return new OCLBoolean(!this.value);
    }

    public OCLBoolean implies(OCLBoolean other) {
        return new OCLBoolean((!this.value) || (this.value && other.value));
    }
    
    @Override
    public String toString() {
        return Boolean.toString(this.value);
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (value ? 1231 : 1237);
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        OCLBoolean other = (OCLBoolean)obj;
        if (value != other.value)
            return false;
        return true;
    }

    // OCLAny implementation, using delegation so that inheritance remains available. -----------------
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }
}
