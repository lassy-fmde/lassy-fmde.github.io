 
	  
package democles.generated;

import java.util.Vector;
import java.util.ArrayList;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
public class LibraryPersistence_LibraryLoader implements OCLAny {
	 
	private OCLSet _books;
	private boolean _books_isInitialized;
	private Persistence_FileHandler _bookFileHandler;
	private boolean _bookFileHandler_isInitialized;
	private StringUtils_StringTokenizer _bookStringTokenizer;
	private boolean _bookStringTokenizer_isInitialized;
	private OCLSet _authors;
	private boolean _authors_isInitialized;
	private StringUtils_StringTokenizer _authorStringTokenizer;
	private boolean _authorStringTokenizer_isInitialized;
	private Persistence_FileHandler _authorFileHandler;
	private boolean _authorFileHandler_isInitialized;
	private Persistence_FileHandler _copyFileHandler;
	private boolean _copyFileHandler_isInitialized;
	private StringUtils_StringTokenizer _copyStringTokenizer;
	private boolean _copyStringTokenizer_isInitialized;
	private OCLSet _copies;
	private boolean _copies_isInitialized;
	private Persistence_FileHandler _memberFileHandler;
	private boolean _memberFileHandler_isInitialized;
	private StringUtils_StringTokenizer _memberStringTokenizer;
	private boolean _memberStringTokenizer_isInitialized;
	private OCLSet _members;
	private boolean _members_isInitialized;
	private Persistence_FileHandler _saveCopiesFileHandler;
	private boolean _saveCopiesFileHandler_isInitialized;
	private Persistence_FileHandler _borrowsFileHandler;
	private boolean _borrowsFileHandler_isInitialized;
	private StringUtils_StringTokenizer _borrowsStringTokenizer;
	private boolean _borrowsStringTokenizer_isInitialized;
	private Persistence_FileHandler _toCollectFileHandler;
	private boolean _toCollectFileHandler_isInitialized;
	private StringUtils_StringTokenizer _toCollectStringTokenizer;
	private boolean _toCollectStringTokenizer_isInitialized;
	private Persistence_FileHandler _saveBorrowsFileHandler;
	private boolean _saveBorrowsFileHandler_isInitialized;
	private Persistence_FileHandler _saveToCollectFileHandler;
	private boolean _saveToCollectFileHandler_isInitialized;

	public Vector<OCLAny> Application_Main_libraryFileHandler_back = new Vector<OCLAny>();

	private Object context;
	private OCLTuple initialPropertyValues = new OCLTuple();
	

	 
	private LibraryPersistence_LibraryLoader(Object context) {
		super();
		this.context = context;
		 
		if (!this._books_isInitialized) this.set_books(this.initial_books()); 
		if (!this._bookFileHandler_isInitialized) this.set_bookFileHandler(this.initial_bookFileHandler()); 
		if (!this._bookStringTokenizer_isInitialized) this.set_bookStringTokenizer(this.initial_bookStringTokenizer()); 
		if (!this._authors_isInitialized) this.set_authors(this.initial_authors()); 
		if (!this._authorStringTokenizer_isInitialized) this.set_authorStringTokenizer(this.initial_authorStringTokenizer()); 
		if (!this._authorFileHandler_isInitialized) this.set_authorFileHandler(this.initial_authorFileHandler()); 
		if (!this._copyFileHandler_isInitialized) this.set_copyFileHandler(this.initial_copyFileHandler()); 
		if (!this._copyStringTokenizer_isInitialized) this.set_copyStringTokenizer(this.initial_copyStringTokenizer()); 
		if (!this._copies_isInitialized) this.set_copies(this.initial_copies()); 
		if (!this._memberFileHandler_isInitialized) this.set_memberFileHandler(this.initial_memberFileHandler()); 
		if (!this._memberStringTokenizer_isInitialized) this.set_memberStringTokenizer(this.initial_memberStringTokenizer()); 
		if (!this._members_isInitialized) this.set_members(this.initial_members()); 
		if (!this._saveCopiesFileHandler_isInitialized) this.set_saveCopiesFileHandler(this.initial_saveCopiesFileHandler()); 
		if (!this._borrowsFileHandler_isInitialized) this.set_borrowsFileHandler(this.initial_borrowsFileHandler()); 
		if (!this._borrowsStringTokenizer_isInitialized) this.set_borrowsStringTokenizer(this.initial_borrowsStringTokenizer()); 
		if (!this._toCollectFileHandler_isInitialized) this.set_toCollectFileHandler(this.initial_toCollectFileHandler()); 
		if (!this._toCollectStringTokenizer_isInitialized) this.set_toCollectStringTokenizer(this.initial_toCollectStringTokenizer()); 
		if (!this._saveBorrowsFileHandler_isInitialized) this.set_saveBorrowsFileHandler(this.initial_saveBorrowsFileHandler()); 
		if (!this._saveToCollectFileHandler_isInitialized) this.set_saveToCollectFileHandler(this.initial_saveToCollectFileHandler()); 


	}
	
	static public LibraryPersistence_LibraryLoader newInstance(Object context) {
		if (context == null) throw new NullPointerException();
		return new LibraryPersistence_LibraryLoader(context);
	}
 
	 
	private LibraryPersistence_LibraryLoader(Object context, OCLTuple values) {
		super();
		this.context = context;
		if (values != null) this.initialPropertyValues = values;

		 
		this._books_isInitialized = false; 
		this._bookFileHandler_isInitialized = false; 
		this._bookStringTokenizer_isInitialized = false; 
		this._authors_isInitialized = false; 
		this._authorStringTokenizer_isInitialized = false; 
		this._authorFileHandler_isInitialized = false; 
		this._copyFileHandler_isInitialized = false; 
		this._copyStringTokenizer_isInitialized = false; 
		this._copies_isInitialized = false; 
		this._memberFileHandler_isInitialized = false; 
		this._memberStringTokenizer_isInitialized = false; 
		this._members_isInitialized = false; 
		this._saveCopiesFileHandler_isInitialized = false; 
		this._borrowsFileHandler_isInitialized = false; 
		this._borrowsStringTokenizer_isInitialized = false; 
		this._toCollectFileHandler_isInitialized = false; 
		this._toCollectStringTokenizer_isInitialized = false; 
		this._saveBorrowsFileHandler_isInitialized = false; 
		this._saveToCollectFileHandler_isInitialized = false; 

		if (values == null) values = new OCLTuple(); // Empty
        this.initialPropertyValues = values;
		
		if (values.containsKey("books")) {
			this.set_books((OCLSet)values.objectForKey("books"));
		} else {
			if (!this._books_isInitialized) this.set_books(this.initial_books());
		}
		if (values.containsKey("bookFileHandler")) {
			this.set_bookFileHandler((Persistence_FileHandler)values.objectForKey("bookFileHandler"));
		} else {
			if (!this._bookFileHandler_isInitialized) this.set_bookFileHandler(this.initial_bookFileHandler());
		}
		if (values.containsKey("bookStringTokenizer")) {
			this.set_bookStringTokenizer((StringUtils_StringTokenizer)values.objectForKey("bookStringTokenizer"));
		} else {
			if (!this._bookStringTokenizer_isInitialized) this.set_bookStringTokenizer(this.initial_bookStringTokenizer());
		}
		if (values.containsKey("authors")) {
			this.set_authors((OCLSet)values.objectForKey("authors"));
		} else {
			if (!this._authors_isInitialized) this.set_authors(this.initial_authors());
		}
		if (values.containsKey("authorStringTokenizer")) {
			this.set_authorStringTokenizer((StringUtils_StringTokenizer)values.objectForKey("authorStringTokenizer"));
		} else {
			if (!this._authorStringTokenizer_isInitialized) this.set_authorStringTokenizer(this.initial_authorStringTokenizer());
		}
		if (values.containsKey("authorFileHandler")) {
			this.set_authorFileHandler((Persistence_FileHandler)values.objectForKey("authorFileHandler"));
		} else {
			if (!this._authorFileHandler_isInitialized) this.set_authorFileHandler(this.initial_authorFileHandler());
		}
		if (values.containsKey("copyFileHandler")) {
			this.set_copyFileHandler((Persistence_FileHandler)values.objectForKey("copyFileHandler"));
		} else {
			if (!this._copyFileHandler_isInitialized) this.set_copyFileHandler(this.initial_copyFileHandler());
		}
		if (values.containsKey("copyStringTokenizer")) {
			this.set_copyStringTokenizer((StringUtils_StringTokenizer)values.objectForKey("copyStringTokenizer"));
		} else {
			if (!this._copyStringTokenizer_isInitialized) this.set_copyStringTokenizer(this.initial_copyStringTokenizer());
		}
		if (values.containsKey("copies")) {
			this.set_copies((OCLSet)values.objectForKey("copies"));
		} else {
			if (!this._copies_isInitialized) this.set_copies(this.initial_copies());
		}
		if (values.containsKey("memberFileHandler")) {
			this.set_memberFileHandler((Persistence_FileHandler)values.objectForKey("memberFileHandler"));
		} else {
			if (!this._memberFileHandler_isInitialized) this.set_memberFileHandler(this.initial_memberFileHandler());
		}
		if (values.containsKey("memberStringTokenizer")) {
			this.set_memberStringTokenizer((StringUtils_StringTokenizer)values.objectForKey("memberStringTokenizer"));
		} else {
			if (!this._memberStringTokenizer_isInitialized) this.set_memberStringTokenizer(this.initial_memberStringTokenizer());
		}
		if (values.containsKey("members")) {
			this.set_members((OCLSet)values.objectForKey("members"));
		} else {
			if (!this._members_isInitialized) this.set_members(this.initial_members());
		}
		if (values.containsKey("saveCopiesFileHandler")) {
			this.set_saveCopiesFileHandler((Persistence_FileHandler)values.objectForKey("saveCopiesFileHandler"));
		} else {
			if (!this._saveCopiesFileHandler_isInitialized) this.set_saveCopiesFileHandler(this.initial_saveCopiesFileHandler());
		}
		if (values.containsKey("borrowsFileHandler")) {
			this.set_borrowsFileHandler((Persistence_FileHandler)values.objectForKey("borrowsFileHandler"));
		} else {
			if (!this._borrowsFileHandler_isInitialized) this.set_borrowsFileHandler(this.initial_borrowsFileHandler());
		}
		if (values.containsKey("borrowsStringTokenizer")) {
			this.set_borrowsStringTokenizer((StringUtils_StringTokenizer)values.objectForKey("borrowsStringTokenizer"));
		} else {
			if (!this._borrowsStringTokenizer_isInitialized) this.set_borrowsStringTokenizer(this.initial_borrowsStringTokenizer());
		}
		if (values.containsKey("toCollectFileHandler")) {
			this.set_toCollectFileHandler((Persistence_FileHandler)values.objectForKey("toCollectFileHandler"));
		} else {
			if (!this._toCollectFileHandler_isInitialized) this.set_toCollectFileHandler(this.initial_toCollectFileHandler());
		}
		if (values.containsKey("toCollectStringTokenizer")) {
			this.set_toCollectStringTokenizer((StringUtils_StringTokenizer)values.objectForKey("toCollectStringTokenizer"));
		} else {
			if (!this._toCollectStringTokenizer_isInitialized) this.set_toCollectStringTokenizer(this.initial_toCollectStringTokenizer());
		}
		if (values.containsKey("saveBorrowsFileHandler")) {
			this.set_saveBorrowsFileHandler((Persistence_FileHandler)values.objectForKey("saveBorrowsFileHandler"));
		} else {
			if (!this._saveBorrowsFileHandler_isInitialized) this.set_saveBorrowsFileHandler(this.initial_saveBorrowsFileHandler());
		}
		if (values.containsKey("saveToCollectFileHandler")) {
			this.set_saveToCollectFileHandler((Persistence_FileHandler)values.objectForKey("saveToCollectFileHandler"));
		} else {
			if (!this._saveToCollectFileHandler_isInitialized) this.set_saveToCollectFileHandler(this.initial_saveToCollectFileHandler());
		}


	}

	static public LibraryPersistence_LibraryLoader newInstance(Object context, OCLTuple values) {
		if (context == null) throw new NullPointerException();
		return new LibraryPersistence_LibraryLoader(context, values);
	}

	 
	public OCLSet initial_books() {
		if (this.initialPropertyValues.containsKey("books")) {
			return (OCLSet)this.initialPropertyValues.objectForKey("books");
		}
		/* ==================================================
	 * Set { }
	 * ================================================== */
	
	OCLSet v0 = new OCLSet();
	
		return v0;
	}

	public OCLSet get_books(){
		if (this._books_isInitialized) {
			return _books;
		} else { 
			this.set_books(this.initial_books());
		}
		this._books_isInitialized = true;
		return this._books;
	}
	public Persistence_FileHandler initial_bookFileHandler() {
		if (this.initialPropertyValues.containsKey("bookFileHandler")) {
			return (Persistence_FileHandler)this.initialPropertyValues.objectForKey("bookFileHandler");
		}
		/* ==================================================
	 * Persistence::FileHandler::create()
	 * ================================================== */
	
	Persistence_FileHandler v0 = Persistence_FileHandler.newInstance(this.context);
	
		return v0;
	}

	public Persistence_FileHandler get_bookFileHandler(){
		if (this._bookFileHandler_isInitialized) {
			return _bookFileHandler;
		} else { 
			this.set_bookFileHandler(this.initial_bookFileHandler());
		}
		this._bookFileHandler_isInitialized = true;
		return this._bookFileHandler;
	}
	public StringUtils_StringTokenizer initial_bookStringTokenizer() {
		if (this.initialPropertyValues.containsKey("bookStringTokenizer")) {
			return (StringUtils_StringTokenizer)this.initialPropertyValues.objectForKey("bookStringTokenizer");
		}
		/* ==================================================
	 * StringUtils::StringTokenizer::create()
	 * ================================================== */
	
	StringUtils_StringTokenizer v0 = StringUtils_StringTokenizer.newInstance(this.context);
	
		return v0;
	}

	public StringUtils_StringTokenizer get_bookStringTokenizer(){
		if (this._bookStringTokenizer_isInitialized) {
			return _bookStringTokenizer;
		} else { 
			this.set_bookStringTokenizer(this.initial_bookStringTokenizer());
		}
		this._bookStringTokenizer_isInitialized = true;
		return this._bookStringTokenizer;
	}
	public OCLSet initial_authors() {
		if (this.initialPropertyValues.containsKey("authors")) {
			return (OCLSet)this.initialPropertyValues.objectForKey("authors");
		}
		/* ==================================================
	 * Set {}
	 * ================================================== */
	
	OCLSet v0 = new OCLSet();
	
		return v0;
	}

	public OCLSet get_authors(){
		if (this._authors_isInitialized) {
			return _authors;
		} else { 
			this.set_authors(this.initial_authors());
		}
		this._authors_isInitialized = true;
		return this._authors;
	}
	public StringUtils_StringTokenizer initial_authorStringTokenizer() {
		if (this.initialPropertyValues.containsKey("authorStringTokenizer")) {
			return (StringUtils_StringTokenizer)this.initialPropertyValues.objectForKey("authorStringTokenizer");
		}
		/* ==================================================
	 * StringUtils::StringTokenizer::create()
	 * ================================================== */
	
	StringUtils_StringTokenizer v0 = StringUtils_StringTokenizer.newInstance(this.context);
	
		return v0;
	}

	public StringUtils_StringTokenizer get_authorStringTokenizer(){
		if (this._authorStringTokenizer_isInitialized) {
			return _authorStringTokenizer;
		} else { 
			this.set_authorStringTokenizer(this.initial_authorStringTokenizer());
		}
		this._authorStringTokenizer_isInitialized = true;
		return this._authorStringTokenizer;
	}
	public Persistence_FileHandler initial_authorFileHandler() {
		if (this.initialPropertyValues.containsKey("authorFileHandler")) {
			return (Persistence_FileHandler)this.initialPropertyValues.objectForKey("authorFileHandler");
		}
		/* ==================================================
	 * Persistence::FileHandler::create()
	 * ================================================== */
	
	Persistence_FileHandler v0 = Persistence_FileHandler.newInstance(this.context);
	
		return v0;
	}

	public Persistence_FileHandler get_authorFileHandler(){
		if (this._authorFileHandler_isInitialized) {
			return _authorFileHandler;
		} else { 
			this.set_authorFileHandler(this.initial_authorFileHandler());
		}
		this._authorFileHandler_isInitialized = true;
		return this._authorFileHandler;
	}
	public Persistence_FileHandler initial_copyFileHandler() {
		if (this.initialPropertyValues.containsKey("copyFileHandler")) {
			return (Persistence_FileHandler)this.initialPropertyValues.objectForKey("copyFileHandler");
		}
		/* ==================================================
	 * Persistence::FileHandler::create()
	 * ================================================== */
	
	Persistence_FileHandler v0 = Persistence_FileHandler.newInstance(this.context);
	
		return v0;
	}

	public Persistence_FileHandler get_copyFileHandler(){
		if (this._copyFileHandler_isInitialized) {
			return _copyFileHandler;
		} else { 
			this.set_copyFileHandler(this.initial_copyFileHandler());
		}
		this._copyFileHandler_isInitialized = true;
		return this._copyFileHandler;
	}
	public StringUtils_StringTokenizer initial_copyStringTokenizer() {
		if (this.initialPropertyValues.containsKey("copyStringTokenizer")) {
			return (StringUtils_StringTokenizer)this.initialPropertyValues.objectForKey("copyStringTokenizer");
		}
		/* ==================================================
	 * StringUtils::StringTokenizer::create()
	 * ================================================== */
	
	StringUtils_StringTokenizer v0 = StringUtils_StringTokenizer.newInstance(this.context);
	
		return v0;
	}

	public StringUtils_StringTokenizer get_copyStringTokenizer(){
		if (this._copyStringTokenizer_isInitialized) {
			return _copyStringTokenizer;
		} else { 
			this.set_copyStringTokenizer(this.initial_copyStringTokenizer());
		}
		this._copyStringTokenizer_isInitialized = true;
		return this._copyStringTokenizer;
	}
	public OCLSet initial_copies() {
		if (this.initialPropertyValues.containsKey("copies")) {
			return (OCLSet)this.initialPropertyValues.objectForKey("copies");
		}
		/* ==================================================
	 * Set { }
	 * ================================================== */
	
	OCLSet v0 = new OCLSet();
	
		return v0;
	}

	public OCLSet get_copies(){
		if (this._copies_isInitialized) {
			return _copies;
		} else { 
			this.set_copies(this.initial_copies());
		}
		this._copies_isInitialized = true;
		return this._copies;
	}
	public Persistence_FileHandler initial_memberFileHandler() {
		if (this.initialPropertyValues.containsKey("memberFileHandler")) {
			return (Persistence_FileHandler)this.initialPropertyValues.objectForKey("memberFileHandler");
		}
		/* ==================================================
	 * Persistence::FileHandler::create()
	 * ================================================== */
	
	Persistence_FileHandler v0 = Persistence_FileHandler.newInstance(this.context);
	
		return v0;
	}

	public Persistence_FileHandler get_memberFileHandler(){
		if (this._memberFileHandler_isInitialized) {
			return _memberFileHandler;
		} else { 
			this.set_memberFileHandler(this.initial_memberFileHandler());
		}
		this._memberFileHandler_isInitialized = true;
		return this._memberFileHandler;
	}
	public StringUtils_StringTokenizer initial_memberStringTokenizer() {
		if (this.initialPropertyValues.containsKey("memberStringTokenizer")) {
			return (StringUtils_StringTokenizer)this.initialPropertyValues.objectForKey("memberStringTokenizer");
		}
		/* ==================================================
	 * StringUtils::StringTokenizer::create()
	 * ================================================== */
	
	StringUtils_StringTokenizer v0 = StringUtils_StringTokenizer.newInstance(this.context);
	
		return v0;
	}

	public StringUtils_StringTokenizer get_memberStringTokenizer(){
		if (this._memberStringTokenizer_isInitialized) {
			return _memberStringTokenizer;
		} else { 
			this.set_memberStringTokenizer(this.initial_memberStringTokenizer());
		}
		this._memberStringTokenizer_isInitialized = true;
		return this._memberStringTokenizer;
	}
	public OCLSet initial_members() {
		if (this.initialPropertyValues.containsKey("members")) {
			return (OCLSet)this.initialPropertyValues.objectForKey("members");
		}
		/* ==================================================
	 * Set { }
	 * ================================================== */
	
	OCLSet v0 = new OCLSet();
	
		return v0;
	}

	public OCLSet get_members(){
		if (this._members_isInitialized) {
			return _members;
		} else { 
			this.set_members(this.initial_members());
		}
		this._members_isInitialized = true;
		return this._members;
	}
	public Persistence_FileHandler initial_saveCopiesFileHandler() {
		if (this.initialPropertyValues.containsKey("saveCopiesFileHandler")) {
			return (Persistence_FileHandler)this.initialPropertyValues.objectForKey("saveCopiesFileHandler");
		}
		/* ==================================================
	 * Persistence::FileHandler::create()
	 * ================================================== */
	
	Persistence_FileHandler v0 = Persistence_FileHandler.newInstance(this.context);
	
		return v0;
	}

	public Persistence_FileHandler get_saveCopiesFileHandler(){
		if (this._saveCopiesFileHandler_isInitialized) {
			return _saveCopiesFileHandler;
		} else { 
			this.set_saveCopiesFileHandler(this.initial_saveCopiesFileHandler());
		}
		this._saveCopiesFileHandler_isInitialized = true;
		return this._saveCopiesFileHandler;
	}
	public Persistence_FileHandler initial_borrowsFileHandler() {
		if (this.initialPropertyValues.containsKey("borrowsFileHandler")) {
			return (Persistence_FileHandler)this.initialPropertyValues.objectForKey("borrowsFileHandler");
		}
		/* ==================================================
	 * Persistence::FileHandler::create()
	 * ================================================== */
	
	Persistence_FileHandler v0 = Persistence_FileHandler.newInstance(this.context);
	
		return v0;
	}

	public Persistence_FileHandler get_borrowsFileHandler(){
		if (this._borrowsFileHandler_isInitialized) {
			return _borrowsFileHandler;
		} else { 
			this.set_borrowsFileHandler(this.initial_borrowsFileHandler());
		}
		this._borrowsFileHandler_isInitialized = true;
		return this._borrowsFileHandler;
	}
	public StringUtils_StringTokenizer initial_borrowsStringTokenizer() {
		if (this.initialPropertyValues.containsKey("borrowsStringTokenizer")) {
			return (StringUtils_StringTokenizer)this.initialPropertyValues.objectForKey("borrowsStringTokenizer");
		}
		/* ==================================================
	 * StringUtils::StringTokenizer::create()
	 * ================================================== */
	
	StringUtils_StringTokenizer v0 = StringUtils_StringTokenizer.newInstance(this.context);
	
		return v0;
	}

	public StringUtils_StringTokenizer get_borrowsStringTokenizer(){
		if (this._borrowsStringTokenizer_isInitialized) {
			return _borrowsStringTokenizer;
		} else { 
			this.set_borrowsStringTokenizer(this.initial_borrowsStringTokenizer());
		}
		this._borrowsStringTokenizer_isInitialized = true;
		return this._borrowsStringTokenizer;
	}
	public Persistence_FileHandler initial_toCollectFileHandler() {
		if (this.initialPropertyValues.containsKey("toCollectFileHandler")) {
			return (Persistence_FileHandler)this.initialPropertyValues.objectForKey("toCollectFileHandler");
		}
		/* ==================================================
	 * Persistence::FileHandler::create()
	 * ================================================== */
	
	Persistence_FileHandler v0 = Persistence_FileHandler.newInstance(this.context);
	
		return v0;
	}

	public Persistence_FileHandler get_toCollectFileHandler(){
		if (this._toCollectFileHandler_isInitialized) {
			return _toCollectFileHandler;
		} else { 
			this.set_toCollectFileHandler(this.initial_toCollectFileHandler());
		}
		this._toCollectFileHandler_isInitialized = true;
		return this._toCollectFileHandler;
	}
	public StringUtils_StringTokenizer initial_toCollectStringTokenizer() {
		if (this.initialPropertyValues.containsKey("toCollectStringTokenizer")) {
			return (StringUtils_StringTokenizer)this.initialPropertyValues.objectForKey("toCollectStringTokenizer");
		}
		/* ==================================================
	 * StringUtils::StringTokenizer::create()
	 * ================================================== */
	
	StringUtils_StringTokenizer v0 = StringUtils_StringTokenizer.newInstance(this.context);
	
		return v0;
	}

	public StringUtils_StringTokenizer get_toCollectStringTokenizer(){
		if (this._toCollectStringTokenizer_isInitialized) {
			return _toCollectStringTokenizer;
		} else { 
			this.set_toCollectStringTokenizer(this.initial_toCollectStringTokenizer());
		}
		this._toCollectStringTokenizer_isInitialized = true;
		return this._toCollectStringTokenizer;
	}
	public Persistence_FileHandler initial_saveBorrowsFileHandler() {
		if (this.initialPropertyValues.containsKey("saveBorrowsFileHandler")) {
			return (Persistence_FileHandler)this.initialPropertyValues.objectForKey("saveBorrowsFileHandler");
		}
		/* ==================================================
	 * Persistence::FileHandler::create()
	 * ================================================== */
	
	Persistence_FileHandler v0 = Persistence_FileHandler.newInstance(this.context);
	
		return v0;
	}

	public Persistence_FileHandler get_saveBorrowsFileHandler(){
		if (this._saveBorrowsFileHandler_isInitialized) {
			return _saveBorrowsFileHandler;
		} else { 
			this.set_saveBorrowsFileHandler(this.initial_saveBorrowsFileHandler());
		}
		this._saveBorrowsFileHandler_isInitialized = true;
		return this._saveBorrowsFileHandler;
	}
	public Persistence_FileHandler initial_saveToCollectFileHandler() {
		if (this.initialPropertyValues.containsKey("saveToCollectFileHandler")) {
			return (Persistence_FileHandler)this.initialPropertyValues.objectForKey("saveToCollectFileHandler");
		}
		/* ==================================================
	 * Persistence::FileHandler::create()
	 * ================================================== */
	
	Persistence_FileHandler v0 = Persistence_FileHandler.newInstance(this.context);
	
		return v0;
	}

	public Persistence_FileHandler get_saveToCollectFileHandler(){
		if (this._saveToCollectFileHandler_isInitialized) {
			return _saveToCollectFileHandler;
		} else { 
			this.set_saveToCollectFileHandler(this.initial_saveToCollectFileHandler());
		}
		this._saveToCollectFileHandler_isInitialized = true;
		return this._saveToCollectFileHandler;
	}


	 


	public void set_bookFileHandler(Persistence_FileHandler value) {
	 	
		if (this._bookFileHandler!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._bookFileHandler.LibraryPersistence_LibraryLoader_bookFileHandler_back;
			backpointers.removeElement(this);
		}
		this._bookFileHandler = value;
		if (this._bookFileHandler!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._bookFileHandler.LibraryPersistence_LibraryLoader_bookFileHandler_back;
			backpointers.addElement(this);
		}
		this._bookFileHandler_isInitialized = true;

	}
	public void set_bookStringTokenizer(StringUtils_StringTokenizer value) {
	 	
		if (this._bookStringTokenizer!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._bookStringTokenizer.LibraryPersistence_LibraryLoader_bookStringTokenizer_back;
			backpointers.removeElement(this);
		}
		this._bookStringTokenizer = value;
		if (this._bookStringTokenizer!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._bookStringTokenizer.LibraryPersistence_LibraryLoader_bookStringTokenizer_back;
			backpointers.addElement(this);
		}
		this._bookStringTokenizer_isInitialized = true;

	}
	public void set_authorStringTokenizer(StringUtils_StringTokenizer value) {
	 	
		if (this._authorStringTokenizer!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._authorStringTokenizer.LibraryPersistence_LibraryLoader_authorStringTokenizer_back;
			backpointers.removeElement(this);
		}
		this._authorStringTokenizer = value;
		if (this._authorStringTokenizer!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._authorStringTokenizer.LibraryPersistence_LibraryLoader_authorStringTokenizer_back;
			backpointers.addElement(this);
		}
		this._authorStringTokenizer_isInitialized = true;

	}
	public void set_authorFileHandler(Persistence_FileHandler value) {
	 	
		if (this._authorFileHandler!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._authorFileHandler.LibraryPersistence_LibraryLoader_authorFileHandler_back;
			backpointers.removeElement(this);
		}
		this._authorFileHandler = value;
		if (this._authorFileHandler!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._authorFileHandler.LibraryPersistence_LibraryLoader_authorFileHandler_back;
			backpointers.addElement(this);
		}
		this._authorFileHandler_isInitialized = true;

	}
	public void set_copyFileHandler(Persistence_FileHandler value) {
	 	
		if (this._copyFileHandler!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._copyFileHandler.LibraryPersistence_LibraryLoader_copyFileHandler_back;
			backpointers.removeElement(this);
		}
		this._copyFileHandler = value;
		if (this._copyFileHandler!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._copyFileHandler.LibraryPersistence_LibraryLoader_copyFileHandler_back;
			backpointers.addElement(this);
		}
		this._copyFileHandler_isInitialized = true;

	}
	public void set_copyStringTokenizer(StringUtils_StringTokenizer value) {
	 	
		if (this._copyStringTokenizer!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._copyStringTokenizer.LibraryPersistence_LibraryLoader_copyStringTokenizer_back;
			backpointers.removeElement(this);
		}
		this._copyStringTokenizer = value;
		if (this._copyStringTokenizer!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._copyStringTokenizer.LibraryPersistence_LibraryLoader_copyStringTokenizer_back;
			backpointers.addElement(this);
		}
		this._copyStringTokenizer_isInitialized = true;

	}
	public void set_memberFileHandler(Persistence_FileHandler value) {
	 	
		if (this._memberFileHandler!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._memberFileHandler.LibraryPersistence_LibraryLoader_memberFileHandler_back;
			backpointers.removeElement(this);
		}
		this._memberFileHandler = value;
		if (this._memberFileHandler!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._memberFileHandler.LibraryPersistence_LibraryLoader_memberFileHandler_back;
			backpointers.addElement(this);
		}
		this._memberFileHandler_isInitialized = true;

	}
	public void set_memberStringTokenizer(StringUtils_StringTokenizer value) {
	 	
		if (this._memberStringTokenizer!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._memberStringTokenizer.LibraryPersistence_LibraryLoader_memberStringTokenizer_back;
			backpointers.removeElement(this);
		}
		this._memberStringTokenizer = value;
		if (this._memberStringTokenizer!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._memberStringTokenizer.LibraryPersistence_LibraryLoader_memberStringTokenizer_back;
			backpointers.addElement(this);
		}
		this._memberStringTokenizer_isInitialized = true;

	}
	public void set_saveCopiesFileHandler(Persistence_FileHandler value) {
	 	
		if (this._saveCopiesFileHandler!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._saveCopiesFileHandler.LibraryPersistence_LibraryLoader_saveCopiesFileHandler_back;
			backpointers.removeElement(this);
		}
		this._saveCopiesFileHandler = value;
		if (this._saveCopiesFileHandler!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._saveCopiesFileHandler.LibraryPersistence_LibraryLoader_saveCopiesFileHandler_back;
			backpointers.addElement(this);
		}
		this._saveCopiesFileHandler_isInitialized = true;

	}
	public void set_borrowsFileHandler(Persistence_FileHandler value) {
	 	
		if (this._borrowsFileHandler!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._borrowsFileHandler.LibraryPersistence_LibraryLoader_borrowsFileHandler_back;
			backpointers.removeElement(this);
		}
		this._borrowsFileHandler = value;
		if (this._borrowsFileHandler!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._borrowsFileHandler.LibraryPersistence_LibraryLoader_borrowsFileHandler_back;
			backpointers.addElement(this);
		}
		this._borrowsFileHandler_isInitialized = true;

	}
	public void set_borrowsStringTokenizer(StringUtils_StringTokenizer value) {
	 	
		if (this._borrowsStringTokenizer!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._borrowsStringTokenizer.LibraryPersistence_LibraryLoader_borrowsStringTokenizer_back;
			backpointers.removeElement(this);
		}
		this._borrowsStringTokenizer = value;
		if (this._borrowsStringTokenizer!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._borrowsStringTokenizer.LibraryPersistence_LibraryLoader_borrowsStringTokenizer_back;
			backpointers.addElement(this);
		}
		this._borrowsStringTokenizer_isInitialized = true;

	}
	public void set_toCollectFileHandler(Persistence_FileHandler value) {
	 	
		if (this._toCollectFileHandler!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._toCollectFileHandler.LibraryPersistence_LibraryLoader_toCollectFileHandler_back;
			backpointers.removeElement(this);
		}
		this._toCollectFileHandler = value;
		if (this._toCollectFileHandler!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._toCollectFileHandler.LibraryPersistence_LibraryLoader_toCollectFileHandler_back;
			backpointers.addElement(this);
		}
		this._toCollectFileHandler_isInitialized = true;

	}
	public void set_toCollectStringTokenizer(StringUtils_StringTokenizer value) {
	 	
		if (this._toCollectStringTokenizer!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._toCollectStringTokenizer.LibraryPersistence_LibraryLoader_toCollectStringTokenizer_back;
			backpointers.removeElement(this);
		}
		this._toCollectStringTokenizer = value;
		if (this._toCollectStringTokenizer!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._toCollectStringTokenizer.LibraryPersistence_LibraryLoader_toCollectStringTokenizer_back;
			backpointers.addElement(this);
		}
		this._toCollectStringTokenizer_isInitialized = true;

	}
	public void set_saveBorrowsFileHandler(Persistence_FileHandler value) {
	 	
		if (this._saveBorrowsFileHandler!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._saveBorrowsFileHandler.LibraryPersistence_LibraryLoader_saveBorrowsFileHandler_back;
			backpointers.removeElement(this);
		}
		this._saveBorrowsFileHandler = value;
		if (this._saveBorrowsFileHandler!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._saveBorrowsFileHandler.LibraryPersistence_LibraryLoader_saveBorrowsFileHandler_back;
			backpointers.addElement(this);
		}
		this._saveBorrowsFileHandler_isInitialized = true;

	}
	public void set_saveToCollectFileHandler(Persistence_FileHandler value) {
	 	
		if (this._saveToCollectFileHandler!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._saveToCollectFileHandler.LibraryPersistence_LibraryLoader_saveToCollectFileHandler_back;
			backpointers.removeElement(this);
		}
		this._saveToCollectFileHandler = value;
		if (this._saveToCollectFileHandler!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._saveToCollectFileHandler.LibraryPersistence_LibraryLoader_saveToCollectFileHandler_back;
			backpointers.addElement(this);
		}
		this._saveToCollectFileHandler_isInitialized = true;

	}


 	public void set_books(OCLSet value) {
	 	
		if (this._books!= null) {
			// Clear back pointer on old instance
			for (OCLAny object : this._books) {
				Library_Book o = (Library_Book)object;
				Vector<OCLAny> backpointers = o.LibraryPersistence_LibraryLoader_books_back;
				backpointers.removeElement(this);
			}
		}
		this._books = value;
		if (this._books!= null) {
			// Add back pointer on new instance
			for (OCLAny object : this._books) {
				Library_Book o = (Library_Book)object;
				Vector<OCLAny> backpointers = o.LibraryPersistence_LibraryLoader_books_back;
				backpointers.addElement(this);
			}
		}
		this._books_isInitialized = true;

	}
 	public void set_authors(OCLSet value) {
	 	
		if (this._authors!= null) {
			// Clear back pointer on old instance
			for (OCLAny object : this._authors) {
				Library_Author o = (Library_Author)object;
				Vector<OCLAny> backpointers = o.LibraryPersistence_LibraryLoader_authors_back;
				backpointers.removeElement(this);
			}
		}
		this._authors = value;
		if (this._authors!= null) {
			// Add back pointer on new instance
			for (OCLAny object : this._authors) {
				Library_Author o = (Library_Author)object;
				Vector<OCLAny> backpointers = o.LibraryPersistence_LibraryLoader_authors_back;
				backpointers.addElement(this);
			}
		}
		this._authors_isInitialized = true;

	}
 	public void set_copies(OCLSet value) {
	 	
		if (this._copies!= null) {
			// Clear back pointer on old instance
			for (OCLAny object : this._copies) {
				Library_Copy o = (Library_Copy)object;
				Vector<OCLAny> backpointers = o.LibraryPersistence_LibraryLoader_copies_back;
				backpointers.removeElement(this);
			}
		}
		this._copies = value;
		if (this._copies!= null) {
			// Add back pointer on new instance
			for (OCLAny object : this._copies) {
				Library_Copy o = (Library_Copy)object;
				Vector<OCLAny> backpointers = o.LibraryPersistence_LibraryLoader_copies_back;
				backpointers.addElement(this);
			}
		}
		this._copies_isInitialized = true;

	}
 	public void set_members(OCLSet value) {
	 	
		if (this._members!= null) {
			// Clear back pointer on old instance
			for (OCLAny object : this._members) {
				Library_Member o = (Library_Member)object;
				Vector<OCLAny> backpointers = o.LibraryPersistence_LibraryLoader_members_back;
				backpointers.removeElement(this);
			}
		}
		this._members = value;
		if (this._members!= null) {
			// Add back pointer on new instance
			for (OCLAny object : this._members) {
				Library_Member o = (Library_Member)object;
				Vector<OCLAny> backpointers = o.LibraryPersistence_LibraryLoader_members_back;
				backpointers.addElement(this);
			}
		}
		this._members_isInitialized = true;

	}


	 
 	public void event_loadBooks_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_loadBooks_pushed in model LibraryPersistence_LibraryLoader");
			 		
			// Trigger Push edges


			if (this._bookFileHandler != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._bookFileHandler);
				for (Object o : edge0_values) {
					Persistence_FileHandler edge0_target = (Persistence_FileHandler)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * 'BookData.dat'
				 * ================================================== */
				
				OCLString v1 = new OCLString("BookData.dat");
				
						OCLString parameter_p_filename = v1;

						edge0_target.event_openFile_pushed(changes ,parameter_p_filename );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_bookLineRead_pushed (PropertyChangeList changes  , OCLString p_line ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_bookLineRead_pushed in model LibraryPersistence_LibraryLoader");
			 		
			// Trigger Push edges


			if (this._bookStringTokenizer != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._bookStringTokenizer);
				for (Object o : edge0_values) {
					StringUtils_StringTokenizer edge0_target = (StringUtils_StringTokenizer)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * line
				 * ================================================== */
				
				OCLString v1 = p_line;
				
						OCLString parameter_p_string = v1;
						/* ==================================================
				 * ';'
				 * ================================================== */
				
				OCLString v2 = new OCLString(";");
				
						OCLString parameter_p_separator = v2;

						edge0_target.event_tokenizeString_pushed(changes ,parameter_p_string ,parameter_p_separator );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_bookLineRead_pulled_edge0(PropertyChangeList changes, Persistence_FileHandler parentInstance ,OCLString p_line  ) {
		System.out.println("event_bookLineRead_pulled in model LibraryPersistence_LibraryLoader from event _lineread in model Persistence_FileHandler");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {
			/* ==================================================
		 * line
		 * ================================================== */
		
		OCLString v1 = p_line;
		
			OCLString parameter_p_line = v1;

			this.event_bookLineRead_pushed(changes ,parameter_p_line  );
		}
	}


 	public void event_bookFileClosed_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_bookFileClosed_pushed in model LibraryPersistence_LibraryLoader");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {

				this.event_loadCopies_pushed(changes );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_bookFileClosed_pulled_edge0(PropertyChangeList changes, Persistence_FileHandler parentInstance  ) {
		System.out.println("event_bookFileClosed_pulled in model LibraryPersistence_LibraryLoader from event _fileClosed in model Persistence_FileHandler");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {

			this.event_bookFileClosed_pushed(changes  );
		}
	}


 	public void event_bookLineTokenized_pushed (PropertyChangeList changes  , OCLSequence p_tokens ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_bookLineTokenized_pushed in model LibraryPersistence_LibraryLoader");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * books->including(
		 *     Library::Book::create(Tuple {
		 *     	bookId = tokens->at(1),
		 *     	title = tokens->at(2),
		 *     	isbn = tokens->at(3),
		 *     	authors = findAuthors(tokens->subSequence(4, tokens->size())->asSet()),
		 *     	copies = Set { } -- updated later, after copies are loaded
		 *     })
		 * )
		 * 
		 * ================================================== */
		
		LibraryPersistence_LibraryLoader v2 = this;
		OCLSet v1 = v2.get_books();
		OCLSequence v8 = p_tokens;
		OCLInteger v9 = new OCLInteger(1);
		OCLString v7 = ((OCLString)v8.at(v9));
		OCLString v6 = v7;
		OCLSequence v12 = p_tokens;
		OCLInteger v13 = new OCLInteger(2);
		OCLString v11 = ((OCLString)v12.at(v13));
		OCLString v10 = v11;
		OCLSequence v16 = p_tokens;
		OCLInteger v17 = new OCLInteger(3);
		OCLString v15 = ((OCLString)v16.at(v17));
		OCLString v14 = v15;
		LibraryPersistence_LibraryLoader v20 = this;
		OCLSequence v23 = p_tokens;
		OCLInteger v24 = new OCLInteger(4);
		OCLSequence v26 = p_tokens;
		OCLInteger v25 = v26.size();
		OCLSequence v22 = v23.subSequence(v24, v25);
		OCLSet v21 = v22.asSet();
		OCLSet v19 = v20.get_findAuthors(v21);
		OCLSet v18 = v19;
		OCLSet v28 = new OCLSet();
		OCLSet v27 = v28;
		OCLTuple v5 = new OCLTuple();
		v5.addItem("bookId", v6);
		v5.addItem("title", v10);
		v5.addItem("isbn", v14);
		v5.addItem("authors", v18);
		v5.addItem("copies", v27);
		Library_Book v3 = Library_Book.newInstance(this.context, v5);
		OCLSet v0 = v1.including(v3);
		
			OCLSet _books_newValue = v0;
			changes.addChange("_books", this, _books_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_bookLineTokenized_pulled_edge0(PropertyChangeList changes, StringUtils_StringTokenizer parentInstance ,OCLSequence p_tokens  ) {
		System.out.println("event_bookLineTokenized_pulled in model LibraryPersistence_LibraryLoader from event _stringTokenized in model StringUtils_StringTokenizer");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {
			/* ==================================================
		 * tokens
		 * ================================================== */
		
		OCLSequence v1 = p_tokens;
		
			OCLSequence parameter_p_tokens = v1;

			this.event_bookLineTokenized_pushed(changes ,parameter_p_tokens  );
		}
	}


 	public void event_load_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_load_pushed in model LibraryPersistence_LibraryLoader");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {

				this.event_loadAuthors_pushed(changes );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_loadAuthors_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_loadAuthors_pushed in model LibraryPersistence_LibraryLoader");
			 		
			// Trigger Push edges


			if (this._authorFileHandler != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._authorFileHandler);
				for (Object o : edge0_values) {
					Persistence_FileHandler edge0_target = (Persistence_FileHandler)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * 'AuthorData.dat'
				 * ================================================== */
				
				OCLString v1 = new OCLString("AuthorData.dat");
				
						OCLString parameter_p_filename = v1;

						edge0_target.event_openFile_pushed(changes ,parameter_p_filename );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_authorsLineRead_pushed (PropertyChangeList changes  , OCLString p_line ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_authorsLineRead_pushed in model LibraryPersistence_LibraryLoader");
			 		
			// Trigger Push edges


			if (this._authorStringTokenizer != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._authorStringTokenizer);
				for (Object o : edge0_values) {
					StringUtils_StringTokenizer edge0_target = (StringUtils_StringTokenizer)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * line
				 * ================================================== */
				
				OCLString v1 = p_line;
				
						OCLString parameter_p_string = v1;
						/* ==================================================
				 * ';'
				 * ================================================== */
				
				OCLString v2 = new OCLString(";");
				
						OCLString parameter_p_separator = v2;

						edge0_target.event_tokenizeString_pushed(changes ,parameter_p_string ,parameter_p_separator );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_authorsLineRead_pulled_edge0(PropertyChangeList changes, Persistence_FileHandler parentInstance ,OCLString p_line  ) {
		System.out.println("event_authorsLineRead_pulled in model LibraryPersistence_LibraryLoader from event _lineread in model Persistence_FileHandler");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {
			/* ==================================================
		 * line
		 * ================================================== */
		
		OCLString v1 = p_line;
		
			OCLString parameter_p_line = v1;

			this.event_authorsLineRead_pushed(changes ,parameter_p_line  );
		}
	}


 	public void event_authorsLineTokenized_pushed (PropertyChangeList changes  , OCLSequence p_tokens ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_authorsLineTokenized_pushed in model LibraryPersistence_LibraryLoader");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * authors->including(
		 * 	Library::Author::create(Tuple { name = tokens->at(2), authorId = tokens->at(1) })
		 * )
		 * 
		 * ================================================== */
		
		LibraryPersistence_LibraryLoader v2 = this;
		OCLSet v1 = v2.get_authors();
		OCLSequence v8 = p_tokens;
		OCLInteger v9 = new OCLInteger(2);
		OCLString v7 = ((OCLString)v8.at(v9));
		OCLString v6 = v7;
		OCLSequence v12 = p_tokens;
		OCLInteger v13 = new OCLInteger(1);
		OCLString v11 = ((OCLString)v12.at(v13));
		OCLString v10 = v11;
		OCLTuple v5 = new OCLTuple();
		v5.addItem("name", v6);
		v5.addItem("authorId", v10);
		Library_Author v3 = Library_Author.newInstance(this.context, v5);
		OCLSet v0 = v1.including(v3);
		
			OCLSet _authors_newValue = v0;
			changes.addChange("_authors", this, _authors_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_authorsLineTokenized_pulled_edge0(PropertyChangeList changes, StringUtils_StringTokenizer parentInstance ,OCLSequence p_tokens  ) {
		System.out.println("event_authorsLineTokenized_pulled in model LibraryPersistence_LibraryLoader from event _stringTokenized in model StringUtils_StringTokenizer");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {
			/* ==================================================
		 * tokens
		 * ================================================== */
		
		OCLSequence v1 = p_tokens;
		
			OCLSequence parameter_p_tokens = v1;

			this.event_authorsLineTokenized_pushed(changes ,parameter_p_tokens  );
		}
	}


 	public void event_authorsFileClosed_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_authorsFileClosed_pushed in model LibraryPersistence_LibraryLoader");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {

				this.event_loadBooks_pushed(changes );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_authorsFileClosed_pulled_edge0(PropertyChangeList changes, Persistence_FileHandler parentInstance  ) {
		System.out.println("event_authorsFileClosed_pulled in model LibraryPersistence_LibraryLoader from event _fileClosed in model Persistence_FileHandler");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {

			this.event_authorsFileClosed_pushed(changes  );
		}
	}


 	public void event_copyLineRead_pushed (PropertyChangeList changes  , OCLString p_line ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_copyLineRead_pushed in model LibraryPersistence_LibraryLoader");
			 		
			// Trigger Push edges


			if (this._copyStringTokenizer != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._copyStringTokenizer);
				for (Object o : edge0_values) {
					StringUtils_StringTokenizer edge0_target = (StringUtils_StringTokenizer)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * line
				 * ================================================== */
				
				OCLString v1 = p_line;
				
						OCLString parameter_p_string = v1;
						/* ==================================================
				 * ';'
				 * ================================================== */
				
				OCLString v2 = new OCLString(";");
				
						OCLString parameter_p_separator = v2;

						edge0_target.event_tokenizeString_pushed(changes ,parameter_p_string ,parameter_p_separator );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_copyLineRead_pulled_edge0(PropertyChangeList changes, Persistence_FileHandler parentInstance ,OCLString p_line  ) {
		System.out.println("event_copyLineRead_pulled in model LibraryPersistence_LibraryLoader from event _lineread in model Persistence_FileHandler");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {
			/* ==================================================
		 * line
		 * ================================================== */
		
		OCLString v1 = p_line;
		
			OCLString parameter_p_line = v1;

			this.event_copyLineRead_pushed(changes ,parameter_p_line  );
		}
	}


 	public void event_loadCopies_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_loadCopies_pushed in model LibraryPersistence_LibraryLoader");
			 		
			// Trigger Push edges


			if (this._copyFileHandler != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._copyFileHandler);
				for (Object o : edge0_values) {
					Persistence_FileHandler edge0_target = (Persistence_FileHandler)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * 'CopyData.dat'
				 * ================================================== */
				
				OCLString v1 = new OCLString("CopyData.dat");
				
						OCLString parameter_p_filename = v1;

						edge0_target.event_openFile_pushed(changes ,parameter_p_filename );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_copyLineTokenized_pushed (PropertyChangeList changes  , OCLSequence p_tokens ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_copyLineTokenized_pushed in model LibraryPersistence_LibraryLoader");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * copies->including(
		 * 	Library::Copy::create(Tuple {
		 * 		copyId = tokens->at(1),
		 * 		book = findBook(tokens->at(5)), 
		 * 		dueDate = tokens->at(3),
		 * 		renewals = tokens->at(4).toInteger(),
		 * 		state = tokens->at(2) }
		 * 	)
		 * )
		 * ================================================== */
		
		LibraryPersistence_LibraryLoader v2 = this;
		OCLSet v1 = v2.get_copies();
		OCLSequence v8 = p_tokens;
		OCLInteger v9 = new OCLInteger(1);
		OCLString v7 = ((OCLString)v8.at(v9));
		OCLString v6 = v7;
		LibraryPersistence_LibraryLoader v12 = this;
		OCLSequence v14 = p_tokens;
		OCLInteger v15 = new OCLInteger(5);
		OCLString v13 = ((OCLString)v14.at(v15));
		Library_Book v11 = v12.get_findBook(v13);
		Library_Book v10 = v11;
		OCLSequence v18 = p_tokens;
		OCLInteger v19 = new OCLInteger(3);
		OCLString v17 = ((OCLString)v18.at(v19));
		OCLString v16 = v17;
		OCLSequence v23 = p_tokens;
		OCLInteger v24 = new OCLInteger(4);
		OCLString v22 = ((OCLString)v23.at(v24));
		OCLInteger v21 = v22.toInteger();
		OCLInteger v20 = v21;
		OCLSequence v27 = p_tokens;
		OCLInteger v28 = new OCLInteger(2);
		OCLString v26 = ((OCLString)v27.at(v28));
		OCLString v25 = v26;
		OCLTuple v5 = new OCLTuple();
		v5.addItem("copyId", v6);
		v5.addItem("book", v10);
		v5.addItem("dueDate", v16);
		v5.addItem("renewals", v20);
		v5.addItem("state", v25);
		Library_Copy v3 = Library_Copy.newInstance(this.context, v5);
		OCLSet v0 = v1.including(v3);
		
			OCLSet _copies_newValue = v0;
			changes.addChange("_copies", this, _copies_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_copyLineTokenized_pulled_edge0(PropertyChangeList changes, StringUtils_StringTokenizer parentInstance ,OCLSequence p_tokens  ) {
		System.out.println("event_copyLineTokenized_pulled in model LibraryPersistence_LibraryLoader from event _stringTokenized in model StringUtils_StringTokenizer");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {
			/* ==================================================
		 * tokens
		 * ================================================== */
		
		OCLSequence v1 = p_tokens;
		
			OCLSequence parameter_p_tokens = v1;

			this.event_copyLineTokenized_pushed(changes ,parameter_p_tokens  );
		}
	}


 	public void event_copyFileClosed_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_copyFileClosed_pushed in model LibraryPersistence_LibraryLoader");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {

				this.event_updateBookCopies_pushed(changes );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_copyFileClosed_pulled_edge0(PropertyChangeList changes, Persistence_FileHandler parentInstance  ) {
		System.out.println("event_copyFileClosed_pulled in model LibraryPersistence_LibraryLoader from event _fileClosed in model Persistence_FileHandler");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {

			this.event_copyFileClosed_pushed(changes  );
		}
	}


 	public void event_updateBookCopies_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_updateBookCopies_pushed in model LibraryPersistence_LibraryLoader");
			 		
			// Trigger Push edges
			if (this._books != null) {
			
				for (OCLAny o : this._books) {
					Library_Book edge0_target = (Library_Book)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * copies->select(book = _iter)
				 * 
				 * ================================================== */
				
				OCLSet v2 = this.get_copies();
				OCLSet v1 = new OCLSet();
				Iterator<OCLAny> v1_iter = v2.iterator();
				while (v1_iter.hasNext()) {
						Library_Copy v3 = (Library_Copy)v1_iter.next();
						Library_Copy v6 = v3;
						Library_Book v5 = v6.get_book();
						Library_Book v7 = edge0_target;
						OCLBoolean v4;
						if (v5 == null || v7 == null) {
								v4 = new OCLBoolean(v5 == v7);
						} else {
								v4 = v5.eq(v7);
						}
						if (v4.value == true) { v1.add(v3); }
				}
				
						OCLSet parameter_p_copies = v1;

						edge0_target.event_setCopies_pushed(changes ,parameter_p_copies );
					}
				}

			}




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {

				this.event_loadMembers_pushed(changes );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_loadMembers_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_loadMembers_pushed in model LibraryPersistence_LibraryLoader");
			 		
			// Trigger Push edges


			if (this._memberFileHandler != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._memberFileHandler);
				for (Object o : edge0_values) {
					Persistence_FileHandler edge0_target = (Persistence_FileHandler)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * 'MemberData.dat'
				 * ================================================== */
				
				OCLString v1 = new OCLString("MemberData.dat");
				
						OCLString parameter_p_filename = v1;

						edge0_target.event_openFile_pushed(changes ,parameter_p_filename );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_memberLineRead_pushed (PropertyChangeList changes  , OCLString p_line ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_memberLineRead_pushed in model LibraryPersistence_LibraryLoader");
			 		
			// Trigger Push edges


			if (this._memberStringTokenizer != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._memberStringTokenizer);
				for (Object o : edge0_values) {
					StringUtils_StringTokenizer edge0_target = (StringUtils_StringTokenizer)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * line
				 * ================================================== */
				
				OCLString v1 = p_line;
				
						OCLString parameter_p_string = v1;
						/* ==================================================
				 * ';'
				 * ================================================== */
				
				OCLString v2 = new OCLString(";");
				
						OCLString parameter_p_separator = v2;

						edge0_target.event_tokenizeString_pushed(changes ,parameter_p_string ,parameter_p_separator );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_memberLineRead_pulled_edge0(PropertyChangeList changes, Persistence_FileHandler parentInstance ,OCLString p_line  ) {
		System.out.println("event_memberLineRead_pulled in model LibraryPersistence_LibraryLoader from event _lineread in model Persistence_FileHandler");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {
			/* ==================================================
		 * line
		 * ================================================== */
		
		OCLString v1 = p_line;
		
			OCLString parameter_p_line = v1;

			this.event_memberLineRead_pushed(changes ,parameter_p_line  );
		}
	}


 	public void event_memberLineTokenized_pushed (PropertyChangeList changes  , OCLSequence p_tokens ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_memberLineTokenized_pushed in model LibraryPersistence_LibraryLoader");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * members->including(
		 * 	Library::Member::create(Tuple {
		 * 		libraryNo = tokens->at(1),
		 * 		password = tokens->at(3),
		 * 		name = tokens->at(2),
		 * 		borrows = Set { },
		 * 		toCollect = Set { }
		 * 	})
		 * )
		 * ================================================== */
		
		LibraryPersistence_LibraryLoader v2 = this;
		OCLSet v1 = v2.get_members();
		OCLSequence v8 = p_tokens;
		OCLInteger v9 = new OCLInteger(1);
		OCLString v7 = ((OCLString)v8.at(v9));
		OCLString v6 = v7;
		OCLSequence v12 = p_tokens;
		OCLInteger v13 = new OCLInteger(3);
		OCLString v11 = ((OCLString)v12.at(v13));
		OCLString v10 = v11;
		OCLSequence v16 = p_tokens;
		OCLInteger v17 = new OCLInteger(2);
		OCLString v15 = ((OCLString)v16.at(v17));
		OCLString v14 = v15;
		OCLSet v19 = new OCLSet();
		OCLSet v18 = v19;
		OCLSet v21 = new OCLSet();
		OCLSet v20 = v21;
		OCLTuple v5 = new OCLTuple();
		v5.addItem("libraryNo", v6);
		v5.addItem("password", v10);
		v5.addItem("name", v14);
		v5.addItem("borrows", v18);
		v5.addItem("toCollect", v20);
		Library_Member v3 = Library_Member.newInstance(this.context, v5);
		OCLSet v0 = v1.including(v3);
		
			OCLSet _members_newValue = v0;
			changes.addChange("_members", this, _members_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_memberLineTokenized_pulled_edge0(PropertyChangeList changes, StringUtils_StringTokenizer parentInstance ,OCLSequence p_tokens  ) {
		System.out.println("event_memberLineTokenized_pulled in model LibraryPersistence_LibraryLoader from event _stringTokenized in model StringUtils_StringTokenizer");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {
			/* ==================================================
		 * tokens
		 * ================================================== */
		
		OCLSequence v1 = p_tokens;
		
			OCLSequence parameter_p_tokens = v1;

			this.event_memberLineTokenized_pushed(changes ,parameter_p_tokens  );
		}
	}


 	public void event_memberFileClosed_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_memberFileClosed_pushed in model LibraryPersistence_LibraryLoader");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {

				this.event_loadBorrows_pushed(changes );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_memberFileClosed_pulled_edge0(PropertyChangeList changes, Persistence_FileHandler parentInstance  ) {
		System.out.println("event_memberFileClosed_pulled in model LibraryPersistence_LibraryLoader from event _fileClosed in model Persistence_FileHandler");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {

			this.event_memberFileClosed_pushed(changes  );
		}
	}


 	public void event_libraryLoaded_pushed (PropertyChangeList changes  , Library_Library p_library ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_libraryLoaded_pushed in model LibraryPersistence_LibraryLoader");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges
			for (OCLAny o : this.Application_Main_libraryFileHandler_back) {
				((Application_Main)o).event_libraryBooksLoaded_pulled_edge0(changes, this , p_library);
			}


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_saveCopies_pushed (PropertyChangeList changes  , OCLSequence p_copies ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_saveCopies_pushed in model LibraryPersistence_LibraryLoader");
			 		
			// Trigger Push edges


			if (this._saveCopiesFileHandler != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._saveCopiesFileHandler);
				for (Object o : edge0_values) {
					Persistence_FileHandler edge0_target = (Persistence_FileHandler)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * 'CopyData.dat'
				 * ================================================== */
				
				OCLString v1 = new OCLString("CopyData.dat");
				
						OCLString parameter_p_filename = v1;
						/* ==================================================
				 * let copyStrings: Sequence(String) =	copies->collect(
				 * 	copyId.concat(';').concat(state).concat(';').concat(dueDate).concat(';').concat(intToString(renewals)).concat(';').concat(book.bookId)
				 * ) in
				 * copyStrings->iterate(line: String; output: String = '' |
				 * 	output.concat(line).concat('\n')
				 * )
				 * 
				 * ================================================== */
				
				OCLSequence v5 = p_copies;
				OCLSequence v4_nested = new OCLSequence();
				Iterator<OCLAny> v4_iter = v5.iterator();
				while (v4_iter.hasNext()) {
						Library_Copy v6 = (Library_Copy)v4_iter.next();
						Library_Copy v16 = v6;
						OCLString v15 = v16.get_copyId();
						OCLString v17 = new OCLString(";");
						OCLString v14 = v15.concat(v17);
						Library_Copy v19 = v6;
						OCLString v18 = v19.get_state();
						OCLString v13 = v14.concat(v18);
						OCLString v20 = new OCLString(";");
						OCLString v12 = v13.concat(v20);
						Library_Copy v22 = v6;
						OCLString v21 = v22.get_dueDate();
						OCLString v11 = v12.concat(v21);
						OCLString v23 = new OCLString(";");
						OCLString v10 = v11.concat(v23);
						LibraryPersistence_LibraryLoader v25 = this;
						Library_Copy v27 = v6;
						OCLInteger v26 = v27.get_renewals();
						OCLString v24 = v25.get_intToString(v26);
						OCLString v9 = v10.concat(v24);
						OCLString v28 = new OCLString(";");
						OCLString v8 = v9.concat(v28);
						Library_Copy v31 = v6;
						Library_Book v30 = v31.get_book();
						OCLString v29 = v30.get_bookId();
						OCLString v7 = v8.concat(v29);
						v4_nested.add(v7);
				}
				OCLSequence v4 = v4_nested.flatten();
				OCLSequence v3 = (OCLSequence)v4;
				OCLSequence v33 = v3;
				OCLString v36 = new OCLString("");
				OCLString v35 = (OCLString)v36;
				Iterator<OCLAny> v32_iter = v33.iterator();
				while (v32_iter.hasNext()) {
						OCLString v34 = (OCLString)v32_iter.next();
						OCLString v39 = v35;
						OCLString v40 = v34;
						OCLString v38 = v39.concat(v40);
						OCLString v41 = new OCLString("\n");
						OCLString v37 = v38.concat(v41);
						v35 = v37;
				}
				OCLString v32 = v35;
				OCLString v2 = v32;
				
						OCLString parameter_p_content = v2;

						edge0_target.event_saveString_pushed(changes ,parameter_p_filename ,parameter_p_content );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_loadBorrows_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_loadBorrows_pushed in model LibraryPersistence_LibraryLoader");
			 		
			// Trigger Push edges


			if (this._borrowsFileHandler != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._borrowsFileHandler);
				for (Object o : edge0_values) {
					Persistence_FileHandler edge0_target = (Persistence_FileHandler)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * 'BorrowsData.dat'
				 * ================================================== */
				
				OCLString v1 = new OCLString("BorrowsData.dat");
				
						OCLString parameter_p_filename = v1;

						edge0_target.event_openFile_pushed(changes ,parameter_p_filename );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_borrowsLineRead_pushed (PropertyChangeList changes  , OCLString p_line ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_borrowsLineRead_pushed in model LibraryPersistence_LibraryLoader");
			 		
			// Trigger Push edges


			if (this._borrowsStringTokenizer != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._borrowsStringTokenizer);
				for (Object o : edge0_values) {
					StringUtils_StringTokenizer edge0_target = (StringUtils_StringTokenizer)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * line
				 * ================================================== */
				
				OCLString v1 = p_line;
				
						OCLString parameter_p_string = v1;
						/* ==================================================
				 * ';'
				 * ================================================== */
				
				OCLString v2 = new OCLString(";");
				
						OCLString parameter_p_separator = v2;

						edge0_target.event_tokenizeString_pushed(changes ,parameter_p_string ,parameter_p_separator );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_borrowsLineRead_pulled_edge0(PropertyChangeList changes, Persistence_FileHandler parentInstance ,OCLString p_line  ) {
		System.out.println("event_borrowsLineRead_pulled in model LibraryPersistence_LibraryLoader from event _lineread in model Persistence_FileHandler");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {
			/* ==================================================
		 * line
		 * ================================================== */
		
		OCLString v1 = p_line;
		
			OCLString parameter_p_line = v1;

			this.event_borrowsLineRead_pushed(changes ,parameter_p_line  );
		}
	}


 	public void event_borrowsLineTokenized_pushed (PropertyChangeList changes  , OCLSequence p_tokens ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_borrowsLineTokenized_pushed in model LibraryPersistence_LibraryLoader");
			 		
			// Trigger Push edges
			if (this._members != null) {
			
				for (OCLAny o : this._members) {
					Library_Member edge0_target = (Library_Member)o;					
					/* ==================================================
			 * _iter.libraryNo = tokens->at(1)
			 * ================================================== */
			
			Library_Member v2 = edge0_target;
			OCLString v1 = v2.get_libraryNo();
			OCLSequence v4 = p_tokens;
			OCLInteger v5 = new OCLInteger(1);
			OCLString v3 = ((OCLString)v4.at(v5));
			OCLBoolean v0;
			if (v1 == null || v3 == null) {
					v0 = new OCLBoolean(v1 == v3);
			} else {
					v0 = v1.eq(v3);
			}
			
					if (v0.value == true) {
						/* ==================================================
				 * _iter.borrows->including(findCopy(tokens->at(2)))
				 * ================================================== */
				
				Library_Member v8 = edge0_target;
				OCLSet v7 = v8.get_borrows();
				LibraryPersistence_LibraryLoader v10 = this;
				OCLSequence v12 = p_tokens;
				OCLInteger v13 = new OCLInteger(2);
				OCLString v11 = ((OCLString)v12.at(v13));
				Library_Copy v9 = v10.get_findCopy(v11);
				OCLSet v6 = v7.including(v9);
				
						OCLSet parameter_p_borrows = v6;

						edge0_target.event_setBorrows_pushed(changes ,parameter_p_borrows );
					}
				}

			}




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_borrowsLineTokenized_pulled_edge0(PropertyChangeList changes, StringUtils_StringTokenizer parentInstance ,OCLSequence p_tokens  ) {
		System.out.println("event_borrowsLineTokenized_pulled in model LibraryPersistence_LibraryLoader from event _stringTokenized in model StringUtils_StringTokenizer");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {
			/* ==================================================
		 * tokens
		 * ================================================== */
		
		OCLSequence v1 = p_tokens;
		
			OCLSequence parameter_p_tokens = v1;

			this.event_borrowsLineTokenized_pushed(changes ,parameter_p_tokens  );
		}
	}


 	public void event_borrowsFileClosed_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_borrowsFileClosed_pushed in model LibraryPersistence_LibraryLoader");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {

				this.event_loadToCollect_pushed(changes );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_borrowsFileClosed_pulled_edge0(PropertyChangeList changes, Persistence_FileHandler parentInstance  ) {
		System.out.println("event_borrowsFileClosed_pulled in model LibraryPersistence_LibraryLoader from event _fileClosed in model Persistence_FileHandler");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {

			this.event_borrowsFileClosed_pushed(changes  );
		}
	}


 	public void event_loadToCollect_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_loadToCollect_pushed in model LibraryPersistence_LibraryLoader");
			 		
			// Trigger Push edges


			if (this._toCollectFileHandler != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._toCollectFileHandler);
				for (Object o : edge0_values) {
					Persistence_FileHandler edge0_target = (Persistence_FileHandler)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * 'ToCollectData.dat'
				 * ================================================== */
				
				OCLString v1 = new OCLString("ToCollectData.dat");
				
						OCLString parameter_p_filename = v1;

						edge0_target.event_openFile_pushed(changes ,parameter_p_filename );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_toCollectLineTokenized_pushed (PropertyChangeList changes  , OCLSequence p_tokens ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_toCollectLineTokenized_pushed in model LibraryPersistence_LibraryLoader");
			 		
			// Trigger Push edges
			if (this._members != null) {
			
				for (OCLAny o : this._members) {
					Library_Member edge0_target = (Library_Member)o;					
					/* ==================================================
			 * _iter.libraryNo = tokens->at(1)
			 * ================================================== */
			
			Library_Member v2 = edge0_target;
			OCLString v1 = v2.get_libraryNo();
			OCLSequence v4 = p_tokens;
			OCLInteger v5 = new OCLInteger(1);
			OCLString v3 = ((OCLString)v4.at(v5));
			OCLBoolean v0;
			if (v1 == null || v3 == null) {
					v0 = new OCLBoolean(v1 == v3);
			} else {
					v0 = v1.eq(v3);
			}
			
					if (v0.value == true) {
						/* ==================================================
				 * _iter.toCollect->including(findCopy(tokens->at(2)))
				 * ================================================== */
				
				Library_Member v8 = edge0_target;
				OCLSet v7 = v8.get_toCollect();
				LibraryPersistence_LibraryLoader v10 = this;
				OCLSequence v12 = p_tokens;
				OCLInteger v13 = new OCLInteger(2);
				OCLString v11 = ((OCLString)v12.at(v13));
				Library_Copy v9 = v10.get_findCopy(v11);
				OCLSet v6 = v7.including(v9);
				
						OCLSet parameter_p_toCollect = v6;

						edge0_target.event_setToCollect_pushed(changes ,parameter_p_toCollect );
					}
				}

			}




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_toCollectLineTokenized_pulled_edge0(PropertyChangeList changes, StringUtils_StringTokenizer parentInstance ,OCLSequence p_tokens  ) {
		System.out.println("event_toCollectLineTokenized_pulled in model LibraryPersistence_LibraryLoader from event _stringTokenized in model StringUtils_StringTokenizer");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {
			/* ==================================================
		 * tokens
		 * ================================================== */
		
		OCLSequence v1 = p_tokens;
		
			OCLSequence parameter_p_tokens = v1;

			this.event_toCollectLineTokenized_pushed(changes ,parameter_p_tokens  );
		}
	}


 	public void event_toCollectFileClosed_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_toCollectFileClosed_pushed in model LibraryPersistence_LibraryLoader");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {
				/* ==================================================
			 * Library::Library::create(Tuple { catalogue = books, members = members })
			 * ================================================== */
			
			OCLSet v5 = this.get_books();
			OCLSet v4 = v5;
			OCLSet v7 = this.get_members();
			OCLSet v6 = v7;
			OCLTuple v3 = new OCLTuple();
			v3.addItem("catalogue", v4);
			v3.addItem("members", v6);
			Library_Library v1 = Library_Library.newInstance(this.context, v3);
			
				Library_Library parameter_p_library = v1;

				this.event_libraryLoaded_pushed(changes , parameter_p_library );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_toCollectFileClosed_pulled_edge0(PropertyChangeList changes, Persistence_FileHandler parentInstance  ) {
		System.out.println("event_toCollectFileClosed_pulled in model LibraryPersistence_LibraryLoader from event _fileClosed in model Persistence_FileHandler");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {

			this.event_toCollectFileClosed_pushed(changes  );
		}
	}


 	public void event_toCollectLineRead_pushed (PropertyChangeList changes  , OCLString p_line ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_toCollectLineRead_pushed in model LibraryPersistence_LibraryLoader");
			 		
			// Trigger Push edges


			if (this._toCollectStringTokenizer != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._toCollectStringTokenizer);
				for (Object o : edge0_values) {
					StringUtils_StringTokenizer edge0_target = (StringUtils_StringTokenizer)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * line
				 * ================================================== */
				
				OCLString v1 = p_line;
				
						OCLString parameter_p_string = v1;
						/* ==================================================
				 * ';'
				 * ================================================== */
				
				OCLString v2 = new OCLString(";");
				
						OCLString parameter_p_separator = v2;

						edge0_target.event_tokenizeString_pushed(changes ,parameter_p_string ,parameter_p_separator );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_toCollectLineRead_pulled_edge0(PropertyChangeList changes, Persistence_FileHandler parentInstance ,OCLString p_line  ) {
		System.out.println("event_toCollectLineRead_pulled in model LibraryPersistence_LibraryLoader from event _lineread in model Persistence_FileHandler");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {
			/* ==================================================
		 * line
		 * ================================================== */
		
		OCLString v1 = p_line;
		
			OCLString parameter_p_line = v1;

			this.event_toCollectLineRead_pushed(changes ,parameter_p_line  );
		}
	}


 	public void event_saveBorrows_pushed (PropertyChangeList changes  , OCLSequence p_members ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_saveBorrows_pushed in model LibraryPersistence_LibraryLoader");
			 		
			// Trigger Push edges


			if (this._saveBorrowsFileHandler != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._saveBorrowsFileHandler);
				for (Object o : edge0_values) {
					Persistence_FileHandler edge0_target = (Persistence_FileHandler)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * 'BorrowsData.dat'
				 * ================================================== */
				
				OCLString v1 = new OCLString("BorrowsData.dat");
				
						OCLString parameter_p_filename = v1;
						/* ==================================================
				 * members->collect(m: Library::Member |
				 * 	m.borrows->collect(c: Library::Copy |
				 * 		m.libraryNo.concat(';').concat(c.copyId)
				 * 	)
				 * )->iterate(line: String; result: String = '' | 
				 * 	result.concat(line).concat('\n')
				 * )
				 * 
				 * ================================================== */
				
				OCLSequence v4 = p_members;
				OCLSequence v3_nested = new OCLSequence();
				Iterator<OCLAny> v3_iter = v4.iterator();
				while (v3_iter.hasNext()) {
						Library_Member v5 = (Library_Member)v3_iter.next();
						Library_Member v8 = v5;
						OCLSet v7 = v8.get_borrows();
						OCLBag v6_nested = new OCLBag();
						Iterator<OCLAny> v6_iter = v7.iterator();
						while (v6_iter.hasNext()) {
								Library_Copy v9 = (Library_Copy)v6_iter.next();
								Library_Member v13 = v5;
								OCLString v12 = v13.get_libraryNo();
								OCLString v14 = new OCLString(";");
								OCLString v11 = v12.concat(v14);
								Library_Copy v16 = v9;
								OCLString v15 = v16.get_copyId();
								OCLString v10 = v11.concat(v15);
								v6_nested.add(v10);
						}
						OCLBag v6 = v6_nested.flatten();
						v3_nested.add(v6);
				}
				OCLSequence v3 = v3_nested.flatten();
				OCLString v19 = new OCLString("");
				OCLString v18 = (OCLString)v19;
				Iterator<OCLAny> v2_iter = v3.iterator();
				while (v2_iter.hasNext()) {
						OCLString v17 = (OCLString)v2_iter.next();
						OCLString v22 = v18;
						OCLString v23 = v17;
						OCLString v21 = v22.concat(v23);
						OCLString v24 = new OCLString("\n");
						OCLString v20 = v21.concat(v24);
						v18 = v20;
				}
				OCLString v2 = v18;
				
						OCLString parameter_p_content = v2;

						edge0_target.event_saveString_pushed(changes ,parameter_p_filename ,parameter_p_content );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_saveLibrary_pushed (PropertyChangeList changes  , Library_Library p_library ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_saveLibrary_pushed in model LibraryPersistence_LibraryLoader");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {
				/* ==================================================
			 * library.copies->asSequence()
			 * ================================================== */
			
			Library_Library v3 = p_library;
			OCLSet v2 = v3.get_copies();
			OCLSequence v1 = v2.asSequence();
			
				OCLSequence parameter_p_copies = v1;

				this.event_saveCopies_pushed(changes , parameter_p_copies );
			}
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v4 = new OCLBoolean(true);
		
			if (v4.value == true) {
				/* ==================================================
			 * library.members->asSequence()
			 * ================================================== */
			
			Library_Library v7 = p_library;
			OCLSet v6 = v7.get_members();
			OCLSequence v5 = v6.asSequence();
			
				OCLSequence parameter_p_members = v5;

				this.event_saveBorrows_pushed(changes , parameter_p_members );
			}
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v8 = new OCLBoolean(true);
		
			if (v8.value == true) {
				/* ==================================================
			 * library.members->asSequence()
			 * ================================================== */
			
			Library_Library v11 = p_library;
			OCLSet v10 = v11.get_members();
			OCLSequence v9 = v10.asSequence();
			
				OCLSequence parameter_p_members = v9;

				this.event_saveToCollect_pushed(changes , parameter_p_members );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_saveToCollect_pushed (PropertyChangeList changes  , OCLSequence p_members ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_saveToCollect_pushed in model LibraryPersistence_LibraryLoader");
			 		
			// Trigger Push edges


			if (this._saveToCollectFileHandler != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._saveToCollectFileHandler);
				for (Object o : edge0_values) {
					Persistence_FileHandler edge0_target = (Persistence_FileHandler)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * 'ToCollectData.dat'
				 * ================================================== */
				
				OCLString v1 = new OCLString("ToCollectData.dat");
				
						OCLString parameter_p_filename = v1;
						/* ==================================================
				 * members->collect(m: Library::Member |
				 * 	m.toCollect->collect(c: Library::Copy |
				 * 		m.libraryNo.concat(';').concat(c.copyId)
				 * 	)
				 * )->iterate(line: String; result: String = '' | 
				 * 	result.concat(line).concat('\n')
				 * )
				 * 
				 * ================================================== */
				
				OCLSequence v4 = p_members;
				OCLSequence v3_nested = new OCLSequence();
				Iterator<OCLAny> v3_iter = v4.iterator();
				while (v3_iter.hasNext()) {
						Library_Member v5 = (Library_Member)v3_iter.next();
						Library_Member v8 = v5;
						OCLSet v7 = v8.get_toCollect();
						OCLBag v6_nested = new OCLBag();
						Iterator<OCLAny> v6_iter = v7.iterator();
						while (v6_iter.hasNext()) {
								Library_Copy v9 = (Library_Copy)v6_iter.next();
								Library_Member v13 = v5;
								OCLString v12 = v13.get_libraryNo();
								OCLString v14 = new OCLString(";");
								OCLString v11 = v12.concat(v14);
								Library_Copy v16 = v9;
								OCLString v15 = v16.get_copyId();
								OCLString v10 = v11.concat(v15);
								v6_nested.add(v10);
						}
						OCLBag v6 = v6_nested.flatten();
						v3_nested.add(v6);
				}
				OCLSequence v3 = v3_nested.flatten();
				OCLString v19 = new OCLString("");
				OCLString v18 = (OCLString)v19;
				Iterator<OCLAny> v2_iter = v3.iterator();
				while (v2_iter.hasNext()) {
						OCLString v17 = (OCLString)v2_iter.next();
						OCLString v22 = v18;
						OCLString v23 = v17;
						OCLString v21 = v22.concat(v23);
						OCLString v24 = new OCLString("\n");
						OCLString v20 = v21.concat(v24);
						v18 = v20;
				}
				OCLString v2 = v18;
				
						OCLString parameter_p_content = v2;

						edge0_target.event_saveString_pushed(changes ,parameter_p_filename ,parameter_p_content );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 




	 
	public OCLSet get_findAuthors(OCLSet p_authorIds) {
		/* ==================================================
	 * authors->select(a: Library::Author | authorIds->includes(a.authorId))
	 * ================================================== */
	
	LibraryPersistence_LibraryLoader v2 = this;
	OCLSet v1 = v2.get_authors();
	OCLSet v0 = new OCLSet();
	Iterator<OCLAny> v0_iter = v1.iterator();
	while (v0_iter.hasNext()) {
			Library_Author v3 = (Library_Author)v0_iter.next();
			OCLSet v5 = p_authorIds;
			Library_Author v7 = v3;
			OCLString v6 = v7.get_authorId();
			OCLBoolean v4 = v5.includes(v6);
			if (v4.value == true) { v0.add(v3); }
	}
	;
		return v0;
	}
	public Library_Book get_findBook(OCLString p_bookId) {
		/* ==================================================
	 * books->any(b: Library::Book | b.bookId = bookId)
	 * ================================================== */
	
	LibraryPersistence_LibraryLoader v2 = this;
	OCLSet v1 = v2.get_books();
	Library_Book v0 = null;
	Iterator<OCLAny> v0_iter = v1.iterator();
	while (v0_iter.hasNext()) {
			Library_Book v3 = (Library_Book)v0_iter.next();
			Library_Book v6 = v3;
			OCLString v5 = v6.get_bookId();
			OCLString v7 = p_bookId;
			OCLBoolean v4;
			if (v5 == null || v7 == null) {
					v4 = new OCLBoolean(v5 == v7);
			} else {
					v4 = v5.eq(v7);
			}
			if (v4.value == true) {
					v0 = v3;
			}
			if (v0 != null) { break; }
	}
	;
		return v0;
	}
	public OCLSet get_findCopies(OCLSet p_copyIds) {
		/* ==================================================
	 * copies->select(c: Library::Copy | copyIds->includes(c.copyId))
	 * ================================================== */
	
	LibraryPersistence_LibraryLoader v2 = this;
	OCLSet v1 = v2.get_copies();
	OCLSet v0 = new OCLSet();
	Iterator<OCLAny> v0_iter = v1.iterator();
	while (v0_iter.hasNext()) {
			Library_Copy v3 = (Library_Copy)v0_iter.next();
			OCLSet v5 = p_copyIds;
			Library_Copy v7 = v3;
			OCLString v6 = v7.get_copyId();
			OCLBoolean v4 = v5.includes(v6);
			if (v4.value == true) { v0.add(v3); }
	}
	;
		return v0;
	}
	public OCLString get_intToString(OCLInteger p_int) {
		/* ==================================================
	 * if int > 0 then
	 * 	OrderedSet{1000000, 10000, 1000, 100, 10, 1}->iterate(
	 *             denominator : Integer;
	 *             s : String = ''|
	 *             let numberAsString : String = OrderedSet{
	 *                     '0','1','2','3','4','5','6','7','8','9'
	 *                 }->at(int.div(denominator).mod(10) + 1)
	 *             in
	 *                 if s='' and numberAsString = '0' then
	 *                     s
	 *                 else
	 *                     s.concat(numberAsString)
	 *                 endif
	 *         )
	 * else
	 * 	'0'
	 * endif
	 * 
	 * ================================================== */
	
	OCLInteger v2 = p_int;
	OCLInteger v3 = new OCLInteger(0);
	OCLBoolean v1 = v2.gt(v3);
	OCLString v0;
	if (v1.value == true) {
			OCLInteger v7 = new OCLInteger(1000000);
			OCLInteger v6 = v7;
			OCLInteger v9 = new OCLInteger(10000);
			OCLInteger v8 = v9;
			OCLInteger v11 = new OCLInteger(1000);
			OCLInteger v10 = v11;
			OCLInteger v13 = new OCLInteger(100);
			OCLInteger v12 = v13;
			OCLInteger v15 = new OCLInteger(10);
			OCLInteger v14 = v15;
			OCLInteger v17 = new OCLInteger(1);
			OCLInteger v16 = v17;
			OCLOrderedSet v5 = new OCLOrderedSet();
			v5.add(v6);
			v5.add(v8);
			v5.add(v10);
			v5.add(v12);
			v5.add(v14);
			v5.add(v16);
			OCLString v20 = new OCLString("");
			OCLString v19 = (OCLString)v20;
			Iterator<OCLAny> v4_iter = v5.iterator();
			while (v4_iter.hasNext()) {
					OCLInteger v18 = (OCLInteger)v4_iter.next();
					OCLString v26 = new OCLString("0");
					OCLString v25 = v26;
					OCLString v28 = new OCLString("1");
					OCLString v27 = v28;
					OCLString v30 = new OCLString("2");
					OCLString v29 = v30;
					OCLString v32 = new OCLString("3");
					OCLString v31 = v32;
					OCLString v34 = new OCLString("4");
					OCLString v33 = v34;
					OCLString v36 = new OCLString("5");
					OCLString v35 = v36;
					OCLString v38 = new OCLString("6");
					OCLString v37 = v38;
					OCLString v40 = new OCLString("7");
					OCLString v39 = v40;
					OCLString v42 = new OCLString("8");
					OCLString v41 = v42;
					OCLString v44 = new OCLString("9");
					OCLString v43 = v44;
					OCLOrderedSet v24 = new OCLOrderedSet();
					v24.add(v25);
					v24.add(v27);
					v24.add(v29);
					v24.add(v31);
					v24.add(v33);
					v24.add(v35);
					v24.add(v37);
					v24.add(v39);
					v24.add(v41);
					v24.add(v43);
					OCLInteger v48 = p_int;
					OCLInteger v49 = v18;
					OCLInteger v47 = v48.idiv(v49);
					OCLInteger v50 = new OCLInteger(10);
					OCLInteger v46 = v47.mod(v50);
					OCLInteger v51 = new OCLInteger(1);
					OCLInteger v45 = v46.plus(v51);
					OCLString v23 = ((OCLString)v24.at(v45));
					OCLString v22 = (OCLString)v23;
					OCLString v55 = v19;
					OCLString v56 = new OCLString("");
					OCLBoolean v54;
					if (v55 == null || v56 == null) {
							v54 = new OCLBoolean(v55 == v56);
					} else {
							v54 = v55.eq(v56);
					}
					OCLString v58 = v22;
					OCLString v59 = new OCLString("0");
					OCLBoolean v57;
					if (v58 == null || v59 == null) {
							v57 = new OCLBoolean(v58 == v59);
					} else {
							v57 = v58.eq(v59);
					}
					OCLBoolean v53 = v54.and(v57);
					OCLString v52;
					if (v53.value == true) {
							OCLString v60 = v19;
							v52 = (OCLString)v60;
					} else {
							OCLString v62 = v19;
							OCLString v63 = v22;
							OCLString v61 = v62.concat(v63);
							v52 = (OCLString)v61;
					}
					OCLString v21 = v52;
					v19 = v21;
			}
			OCLString v4 = v19;
			v0 = (OCLString)v4;
	} else {
			OCLString v64 = new OCLString("0");
			v0 = (OCLString)v64;
	}
	;
		return v0;
	}
	public Library_Copy get_findCopy(OCLString p_copyId) {
		/* ==================================================
	 * copies->any(c: Library::Copy | copyId = c.copyId)
	 * ================================================== */
	
	LibraryPersistence_LibraryLoader v2 = this;
	OCLSet v1 = v2.get_copies();
	Library_Copy v0 = null;
	Iterator<OCLAny> v0_iter = v1.iterator();
	while (v0_iter.hasNext()) {
			Library_Copy v3 = (Library_Copy)v0_iter.next();
			OCLString v5 = p_copyId;
			Library_Copy v7 = v3;
			OCLString v6 = v7.get_copyId();
			OCLBoolean v4;
			if (v5 == null || v6 == null) {
					v4 = new OCLBoolean(v5 == v6);
			} else {
					v4 = v5.eq(v6);
			}
			if (v4.value == true) {
					v0 = v3;
			}
			if (v0 != null) { break; }
	}
	;
		return v0;
	}


	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

