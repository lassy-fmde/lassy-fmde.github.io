 
	  
package democles.generated;

import java.util.Vector;
import java.util.ArrayList;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
import android.content.Context;
import android.view.View;

	 
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;
import java.util.Collection;

	 
public class GeneralGUI_Window extends Activity implements OCLAny {
	 
	private OCLSequence _seqGUIElements;
	private boolean _seqGUIElements_isInitialized;
	private OCLString _title;
	private boolean _title_isInitialized;

	public Vector<OCLAny> MobileLibraryGUI_StartWindowController_window_back = new Vector<OCLAny>();
	public Vector<OCLAny> MobileLibraryGUI_BookDetailWindowController_window_back = new Vector<OCLAny>();
	public Vector<OCLAny> MobileLibraryGUI_BookListWindowController_window_back = new Vector<OCLAny>();

	private Object context;
	private OCLTuple initialPropertyValues = new OCLTuple();
	

	  
	private LinearLayout layout;
	 
	final static private String INIT_PROP_VALUES_KEY = "initialPropertyValues";
	final static private String HOLDER_KEY = "instanceHolder";
    
    static class Holder {
        public GeneralGUI_Window instance = null;
    }

	 
    public GeneralGUI_Window() {
        super();
        this.context = this;
    }

	 
    public static GeneralGUI_Window newInstance(Object contextObject) {
		if (contextObject == null) throw new NullPointerException();
    	return newInstance(contextObject, null);
    }
    
    public static GeneralGUI_Window newInstance(Object contextObject, OCLTuple initialPropertyValues) {
		if (contextObject == null) throw new NullPointerException();

    	Context context = (Context)contextObject;
        Thread currentThread = Thread.currentThread();
        Thread mainThread = context.getMainLooper().getThread();
        
        if (currentThread == mainThread) {
            throw new RuntimeException("GeneralGUI_Window can not be instantiated from the UI thread.");
        }
        
        final Intent intent = new Intent(context, GeneralGUI_Window.class);
        if (initialPropertyValues != null) {
            Long initDataKey = InitializationDataHolder.putData(initialPropertyValues);
            intent.putExtra(INIT_PROP_VALUES_KEY, initDataKey);
        }
        
        Holder holder = new Holder();
        Long holderKey = InitializationDataHolder.putData(holder);
        intent.putExtra(HOLDER_KEY, holderKey);

        final Context contextClosure = context;
        new Thread() {
            public void run() {
                contextClosure.startActivity(intent);
            };
        }.start();
        
        synchronized(holder) {
            try {
                holder.wait();
            } catch (InterruptedException e) {
            }
        }
        return holder.instance;
    }
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        OCLTuple values = null;
        
        Bundle extras = this.getIntent().getExtras();
        if (extras != null) {
            Long initDataKey = extras.getLong(INIT_PROP_VALUES_KEY);
            if (initDataKey != null) {
                values = (OCLTuple)InitializationDataHolder.retrieveData(initDataKey);
            }
            
            Long holderKey = extras.getLong(HOLDER_KEY);
            Holder holder = (Holder)InitializationDataHolder.retrieveData(holderKey);
            holder.instance = this;
            
            synchronized(holder) {
                holder.notify();
            }
        }
        
		 
		this._seqGUIElements_isInitialized = false; 
		this._title_isInitialized = false; 

		if (values == null) values = new OCLTuple(); // Empty
        this.initialPropertyValues = values;
		
		if (values.containsKey("seqGUIElements")) {
			this.set_seqGUIElements((OCLSequence)values.objectForKey("seqGUIElements"));
		} else {
			if (!this._seqGUIElements_isInitialized) this.set_seqGUIElements(this.initial_seqGUIElements());
		}
		if (values.containsKey("title")) {
			this.set_title((OCLString)values.objectForKey("title"));
		} else {
			if (!this._title_isInitialized) this.set_title(this.initial_title());
		}


        
        this.updateLayout();
    }

	 
	public OCLSequence initial_seqGUIElements() {
		if (this.initialPropertyValues.containsKey("seqGUIElements")) {
			return (OCLSequence)this.initialPropertyValues.objectForKey("seqGUIElements");
		}
		/* ==================================================
	 * Sequence {}
	 * ================================================== */
	
	OCLSequence v0 = new OCLSequence();
	
		return v0;
	}

	public OCLSequence get_seqGUIElements(){
		if (this._seqGUIElements_isInitialized) {
			return _seqGUIElements;
		} else { 
			this.set_seqGUIElements(this.initial_seqGUIElements());
		}
		this._seqGUIElements_isInitialized = true;
		return this._seqGUIElements;
	}
	public OCLString initial_title() {
		if (this.initialPropertyValues.containsKey("title")) {
			return (OCLString)this.initialPropertyValues.objectForKey("title");
		}
		/* ==================================================
	 * ''
	 * ================================================== */
	
	OCLString v0 = new OCLString("");
	
		return v0;
	}

	public OCLString get_title(){
		if (this._title_isInitialized) {
			return _title;
		} else { 
			this.set_title(this.initial_title());
		}
		this._title_isInitialized = true;
		return this._title;
	}


	 
	public void set_seqGUIElements(OCLSequence value) {
		 	
		this._seqGUIElements = value;
		this._seqGUIElements_isInitialized = true;

		this.onPropertyChange("seqGUIElements",value);
	}
	public void set_title(OCLString value) {
		 	
		this._title = value;
		this._title_isInitialized = true;

		this.onPropertyChange("title",value);
	}






	 
 	public void event_closeWindow_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			
			this.onEvent("closeWindow", parameterTuple);
			
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 




	 


	 
	public void onPropertyChange(String propertyName, Object value) {
		if (propertyName.equals("seqGUIElements")) {
			if (value != null) {
				updateLayout();
			}
		}
	}

	 
	public void onEvent(String eventName, OCLTuple parameters) {
		if (eventName.equals("closeWindow")) {
			this.finish();
		}
	}

	  
    private Collection<IWidgetWrapper> getWidgets() {
        return (Collection)this.get_seqGUIElements().values;
    }
    
    private void updateLayout() {
        this.layout = new LinearLayout(this);
        this.layout.setOrientation(LinearLayout.VERTICAL);
        
        this.setContentView(this.layout);
        
        for (IWidgetWrapper wrapper : this.getWidgets()) {
            View widget = wrapper.createWidget(this);

            this.layout.addView(widget, new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
        }
    }

	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

