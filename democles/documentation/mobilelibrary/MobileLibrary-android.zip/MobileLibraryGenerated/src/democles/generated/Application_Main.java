 
	  
package democles.generated;

import java.util.Vector;
import java.util.ArrayList;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
import android.content.Context;
import android.view.View;

	 
import android.app.Activity;
import android.os.Bundle;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import java.util.Collection;

	 
public class Application_Main extends Activity implements OCLAny {
	 
	private Library_Library _library;
	private boolean _library_isInitialized;
	private LibraryPersistence_LibraryLoader _libraryFileHandler;
	private boolean _libraryFileHandler_isInitialized;
	private MobileLibraryGUI_ViewsWindowController _viewsControl;
	private boolean _viewsControl_isInitialized;
	private MobileLibraryGUI_StartWindowController _startWindowControl;
	private boolean _startWindowControl_isInitialized;
	private MobileLibraryGUI_SearchWindowController _searchControl;
	private boolean _searchControl_isInitialized;
	private OCLString _memberViewMode;
	private boolean _memberViewMode_isInitialized;
	private MobileLibraryGUI_MemberWindowController _memberControl;
	private boolean _memberControl_isInitialized;
	private MobileLibraryGUI_LoginWindowController _loginControl;
	private boolean _loginControl_isInitialized;


	private Object context;
	private OCLTuple initialPropertyValues = new OCLTuple();
	

	 
	public Application_Main() {
		this(null);
	}

	private Application_Main(Object context) {
		super();
		this.context = this;
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);

	    new Thread() {
	        @Override
	        public void run() {
	        	initializePropertiesAndTriggerInitEvent();
	        }
	    }.start();
	}
	
	private void initializePropertiesAndTriggerInitEvent() {
		 
		if (!this._library_isInitialized) this.set_library(this.initial_library()); 
		if (!this._libraryFileHandler_isInitialized) this.set_libraryFileHandler(this.initial_libraryFileHandler()); 
		if (!this._viewsControl_isInitialized) this.set_viewsControl(this.initial_viewsControl()); 
		if (!this._startWindowControl_isInitialized) this.set_startWindowControl(this.initial_startWindowControl()); 
		if (!this._searchControl_isInitialized) this.set_searchControl(this.initial_searchControl()); 
		if (!this._memberViewMode_isInitialized) this.set_memberViewMode(this.initial_memberViewMode()); 
		if (!this._memberControl_isInitialized) this.set_memberControl(this.initial_memberControl()); 
		if (!this._loginControl_isInitialized) this.set_loginControl(this.initial_loginControl()); 


		
        try {
        	Method init = Application_Main.this.getClass().getMethod("event_init_pushed", PropertyChangeList.class);
        	init.invoke(Application_Main.this, (Object)null);
        } catch (IllegalAccessException e) {
        } catch (InvocationTargetException e) {
        } catch (NoSuchMethodException e) {
        }
	}

	 
	public Library_Library initial_library() {
		if (this.initialPropertyValues.containsKey("library")) {
			return (Library_Library)this.initialPropertyValues.objectForKey("library");
		}
		/* ==================================================
	 * Library::Library::create(
	 * 	Tuple { 
	 * 		catalogue = Set {
	 * 			Library::Book::create(Tuple { title = 'Test', isbn = '1234', 
	 * 			    authors = Set {Library::Author::create (Tuple {name = 'John Doe'})}})
	 * 		},
	 * 		members = Set {}
	 * 	})
	 * ================================================== */
	
	OCLString v10 = new OCLString("Test");
	OCLString v9 = v10;
	OCLString v12 = new OCLString("1234");
	OCLString v11 = v12;
	OCLString v20 = new OCLString("John Doe");
	OCLString v19 = v20;
	OCLTuple v18 = new OCLTuple();
	v18.addItem("name", v19);
	Library_Author v16 = Library_Author.newInstance(this.context, v18);
	Library_Author v15 = v16;
	OCLSet v14 = new OCLSet();
	v14.add(v15);
	OCLSet v13 = v14;
	OCLTuple v8 = new OCLTuple();
	v8.addItem("title", v9);
	v8.addItem("isbn", v11);
	v8.addItem("authors", v13);
	Library_Book v6 = Library_Book.newInstance(this.context, v8);
	Library_Book v5 = v6;
	OCLSet v4 = new OCLSet();
	v4.add(v5);
	OCLSet v3 = v4;
	OCLSet v22 = new OCLSet();
	OCLSet v21 = v22;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("catalogue", v3);
	v2.addItem("members", v21);
	Library_Library v0 = Library_Library.newInstance(this.context, v2);
	
		return v0;
	}

	public Library_Library get_library(){
		if (this._library_isInitialized) {
			return _library;
		} else { 
			this.set_library(this.initial_library());
		}
		this._library_isInitialized = true;
		return this._library;
	}
	public LibraryPersistence_LibraryLoader initial_libraryFileHandler() {
		if (this.initialPropertyValues.containsKey("libraryFileHandler")) {
			return (LibraryPersistence_LibraryLoader)this.initialPropertyValues.objectForKey("libraryFileHandler");
		}
		/* ==================================================
	 * LibraryPersistence::LibraryLoader::create()
	 * ================================================== */
	
	LibraryPersistence_LibraryLoader v0 = LibraryPersistence_LibraryLoader.newInstance(this.context);
	
		return v0;
	}

	public LibraryPersistence_LibraryLoader get_libraryFileHandler(){
		if (this._libraryFileHandler_isInitialized) {
			return _libraryFileHandler;
		} else { 
			this.set_libraryFileHandler(this.initial_libraryFileHandler());
		}
		this._libraryFileHandler_isInitialized = true;
		return this._libraryFileHandler;
	}
	public MobileLibraryGUI_ViewsWindowController initial_viewsControl() {
		if (this.initialPropertyValues.containsKey("viewsControl")) {
			return (MobileLibraryGUI_ViewsWindowController)this.initialPropertyValues.objectForKey("viewsControl");
		}
		/* ==================================================
	 * MobileLibraryGUI::ViewsWindowController::create()
	 * ================================================== */
	
	MobileLibraryGUI_ViewsWindowController v0 = MobileLibraryGUI_ViewsWindowController.newInstance(this.context);
	
		return v0;
	}

	public MobileLibraryGUI_ViewsWindowController get_viewsControl(){
		if (this._viewsControl_isInitialized) {
			return _viewsControl;
		} else { 
			this.set_viewsControl(this.initial_viewsControl());
		}
		this._viewsControl_isInitialized = true;
		return this._viewsControl;
	}
	public MobileLibraryGUI_StartWindowController initial_startWindowControl() {
		if (this.initialPropertyValues.containsKey("startWindowControl")) {
			return (MobileLibraryGUI_StartWindowController)this.initialPropertyValues.objectForKey("startWindowControl");
		}
		/* ==================================================
	 * MobileLibraryGUI::StartWindowController::create()
	 * ================================================== */
	
	MobileLibraryGUI_StartWindowController v0 = MobileLibraryGUI_StartWindowController.newInstance(this.context);
	
		return v0;
	}

	public MobileLibraryGUI_StartWindowController get_startWindowControl(){
		if (this._startWindowControl_isInitialized) {
			return _startWindowControl;
		} else { 
			this.set_startWindowControl(this.initial_startWindowControl());
		}
		this._startWindowControl_isInitialized = true;
		return this._startWindowControl;
	}
	public MobileLibraryGUI_SearchWindowController initial_searchControl() {
		if (this.initialPropertyValues.containsKey("searchControl")) {
			return (MobileLibraryGUI_SearchWindowController)this.initialPropertyValues.objectForKey("searchControl");
		}
		/* ==================================================
	 * MobileLibraryGUI::SearchWindowController::create()
	 * ================================================== */
	
	MobileLibraryGUI_SearchWindowController v0 = MobileLibraryGUI_SearchWindowController.newInstance(this.context);
	
		return v0;
	}

	public MobileLibraryGUI_SearchWindowController get_searchControl(){
		if (this._searchControl_isInitialized) {
			return _searchControl;
		} else { 
			this.set_searchControl(this.initial_searchControl());
		}
		this._searchControl_isInitialized = true;
		return this._searchControl;
	}
	public OCLString initial_memberViewMode() {
		if (this.initialPropertyValues.containsKey("memberViewMode")) {
			return (OCLString)this.initialPropertyValues.objectForKey("memberViewMode");
		}
		/* ==================================================
	 * 'Login'
	 * ================================================== */
	
	OCLString v0 = new OCLString("Login");
	
		return v0;
	}

	public OCLString get_memberViewMode(){
		if (this._memberViewMode_isInitialized) {
			return _memberViewMode;
		} else { 
			this.set_memberViewMode(this.initial_memberViewMode());
		}
		this._memberViewMode_isInitialized = true;
		return this._memberViewMode;
	}
	public MobileLibraryGUI_MemberWindowController initial_memberControl() {
		if (this.initialPropertyValues.containsKey("memberControl")) {
			return (MobileLibraryGUI_MemberWindowController)this.initialPropertyValues.objectForKey("memberControl");
		}
		/* ==================================================
	 * MobileLibraryGUI::MemberWindowController::create()
	 * ================================================== */
	
	MobileLibraryGUI_MemberWindowController v0 = MobileLibraryGUI_MemberWindowController.newInstance(this.context);
	
		return v0;
	}

	public MobileLibraryGUI_MemberWindowController get_memberControl(){
		if (this._memberControl_isInitialized) {
			return _memberControl;
		} else { 
			this.set_memberControl(this.initial_memberControl());
		}
		this._memberControl_isInitialized = true;
		return this._memberControl;
	}
	public MobileLibraryGUI_LoginWindowController initial_loginControl() {
		if (this.initialPropertyValues.containsKey("loginControl")) {
			return (MobileLibraryGUI_LoginWindowController)this.initialPropertyValues.objectForKey("loginControl");
		}
		/* ==================================================
	 * MobileLibraryGUI::LoginWindowController::create()
	 * ================================================== */
	
	MobileLibraryGUI_LoginWindowController v0 = MobileLibraryGUI_LoginWindowController.newInstance(this.context);
	
		return v0;
	}

	public MobileLibraryGUI_LoginWindowController get_loginControl(){
		if (this._loginControl_isInitialized) {
			return _loginControl;
		} else { 
			this.set_loginControl(this.initial_loginControl());
		}
		this._loginControl_isInitialized = true;
		return this._loginControl;
	}


	 
	public void set_memberViewMode(OCLString value) {
		 	
		this._memberViewMode = value;
		this._memberViewMode_isInitialized = true;

		this.onPropertyChange("memberViewMode",value);
	}


	public void set_library(Library_Library value) {
		 	
		if (this._library!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._library.Application_Main_library_back;
			backpointers.removeElement(this);
		}
		this._library = value;
		if (this._library!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._library.Application_Main_library_back;
			backpointers.addElement(this);
		}
		this._library_isInitialized = true;

		this.onPropertyChange("library",value);
	}
	public void set_libraryFileHandler(LibraryPersistence_LibraryLoader value) {
		 	
		if (this._libraryFileHandler!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._libraryFileHandler.Application_Main_libraryFileHandler_back;
			backpointers.removeElement(this);
		}
		this._libraryFileHandler = value;
		if (this._libraryFileHandler!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._libraryFileHandler.Application_Main_libraryFileHandler_back;
			backpointers.addElement(this);
		}
		this._libraryFileHandler_isInitialized = true;

		this.onPropertyChange("libraryFileHandler",value);
	}
	public void set_viewsControl(MobileLibraryGUI_ViewsWindowController value) {
		 	
		if (this._viewsControl!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._viewsControl.Application_Main_viewsControl_back;
			backpointers.removeElement(this);
		}
		this._viewsControl = value;
		if (this._viewsControl!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._viewsControl.Application_Main_viewsControl_back;
			backpointers.addElement(this);
		}
		this._viewsControl_isInitialized = true;

		this.onPropertyChange("viewsControl",value);
	}
	public void set_startWindowControl(MobileLibraryGUI_StartWindowController value) {
		 	
		if (this._startWindowControl!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._startWindowControl.Application_Main_startWindowControl_back;
			backpointers.removeElement(this);
		}
		this._startWindowControl = value;
		if (this._startWindowControl!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._startWindowControl.Application_Main_startWindowControl_back;
			backpointers.addElement(this);
		}
		this._startWindowControl_isInitialized = true;

		this.onPropertyChange("startWindowControl",value);
	}
	public void set_searchControl(MobileLibraryGUI_SearchWindowController value) {
		 	
		if (this._searchControl!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._searchControl.Application_Main_searchControl_back;
			backpointers.removeElement(this);
		}
		this._searchControl = value;
		if (this._searchControl!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._searchControl.Application_Main_searchControl_back;
			backpointers.addElement(this);
		}
		this._searchControl_isInitialized = true;

		this.onPropertyChange("searchControl",value);
	}
	public void set_memberControl(MobileLibraryGUI_MemberWindowController value) {
		 	
		if (this._memberControl!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._memberControl.Application_Main_memberControl_back;
			backpointers.removeElement(this);
		}
		this._memberControl = value;
		if (this._memberControl!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._memberControl.Application_Main_memberControl_back;
			backpointers.addElement(this);
		}
		this._memberControl_isInitialized = true;

		this.onPropertyChange("memberControl",value);
	}
	public void set_loginControl(MobileLibraryGUI_LoginWindowController value) {
		 	
		if (this._loginControl!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._loginControl.Application_Main_loginControl_back;
			backpointers.removeElement(this);
		}
		this._loginControl = value;
		if (this._loginControl!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._loginControl.Application_Main_loginControl_back;
			backpointers.addElement(this);
		}
		this._loginControl_isInitialized = true;

		this.onPropertyChange("loginControl",value);
	}




	 
 	public void event_searchFinished_pushed (PropertyChangeList changes  , OCLSet p_booksFound ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			parameterTuple.addItem("booksFound", p_booksFound);
			this.onEvent("searchFinished", parameterTuple);
			
			 		
			// Trigger Push edges


			if (this._searchControl != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._searchControl);
				for (Object o : edge0_values) {
					MobileLibraryGUI_SearchWindowController edge0_target = (MobileLibraryGUI_SearchWindowController)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * booksFound
				 * ================================================== */
				
				OCLSet v1 = p_booksFound;
				
						OCLSet parameter_p_booksFound = v1;

						edge0_target.event_searchFinished_pushed(changes ,parameter_p_booksFound );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_searchFinished_pulled_edge0(PropertyChangeList changes, Library_Library parentInstance ,OCLSet p_foundBooks  ) {
		System.out.println("event_searchFinished_pulled in model Application_Main from event _booksFound in model Library_Library");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {
			/* ==================================================
		 * foundBooks
		 * ================================================== */
		
		OCLSet v1 = p_foundBooks;
		
			OCLSet parameter_p_booksFound = v1;

			this.event_searchFinished_pushed(changes ,parameter_p_booksFound  );
		}
	}


 	public void event_searchBook_pushed (PropertyChangeList changes  , OCLString p_term , OCLString p_category ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			parameterTuple.addItem("term", p_term);parameterTuple.addItem("category", p_category);
			this.onEvent("searchBook", parameterTuple);
			
			 		
			// Trigger Push edges


			if (this._library != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._library);
				for (Object o : edge0_values) {
					Library_Library edge0_target = (Library_Library)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * term
				 * ================================================== */
				
				OCLString v1 = p_term;
				
						OCLString parameter_p_term = v1;
						/* ==================================================
				 * category
				 * ================================================== */
				
				OCLString v2 = p_category;
				
						OCLString parameter_p_category = v2;

						edge0_target.event_searchBook_pushed(changes ,parameter_p_term ,parameter_p_category );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_searchBook_pulled_edge0(PropertyChangeList changes, MobileLibraryGUI_SearchWindowController parentInstance ,OCLString p_term ,OCLString p_category  ) {
		System.out.println("event_searchBook_pulled in model Application_Main from event _searchBook in model MobileLibraryGUI_SearchWindowController");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {
			/* ==================================================
		 * term
		 * ================================================== */
		
		OCLString v1 = p_term;
		
			OCLString parameter_p_term = v1;
			/* ==================================================
		 * category
		 * ================================================== */
		
		OCLString v2 = p_category;
		
			OCLString parameter_p_category = v2;

			this.event_searchBook_pushed(changes ,parameter_p_term ,parameter_p_category  );
		}
	}


 	public void event_libraryBooksLoaded_pushed (PropertyChangeList changes  , Library_Library p_bookCollection ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			parameterTuple.addItem("bookCollection", p_bookCollection);
			this.onEvent("libraryBooksLoaded", parameterTuple);
			
			 		
			// Trigger Push edges


			if (this._viewsControl != null) {
			 	
				ArrayList<Object> edge1_values = new ArrayList<Object>();
				edge1_values.add(this._viewsControl);
				for (Object o : edge1_values) {
					MobileLibraryGUI_ViewsWindowController edge1_target = (MobileLibraryGUI_ViewsWindowController)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * getSearchFrame
				 * ================================================== */
				
				OCLAny v1 = this.get_getSearchFrame();
				
						OCLAny parameter_p_searchWindow = v1;
						/* ==================================================
				 * getLoginFrame
				 * ================================================== */
				
				OCLAny v2 = this.get_getLoginFrame();
				
						OCLAny parameter_p_loginWindow = v2;

						edge1_target.event_startViewsWindow_pushed(changes ,parameter_p_searchWindow ,parameter_p_loginWindow );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {
				/* ==================================================
			 * bookCollection
			 * ================================================== */
			
			Library_Library v1 = p_bookCollection;
			
				Library_Library parameter_p_completeBookCollection = v1;

				this.event_setCompleteBookCollection_pushed(changes , parameter_p_completeBookCollection );
			}
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v2 = new OCLBoolean(true);
		
			if (v2.value == true) {

				this.event_closeStartWindow_pushed(changes );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_libraryBooksLoaded_pulled_edge0(PropertyChangeList changes, LibraryPersistence_LibraryLoader parentInstance ,Library_Library p_library  ) {
		System.out.println("event_libraryBooksLoaded_pulled in model Application_Main from event _libraryLoaded in model LibraryPersistence_LibraryLoader");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {
			/* ==================================================
		 * library
		 * ================================================== */
		
		Library_Library v1 = p_library;
		
			Library_Library parameter_p_bookCollection = v1;

			this.event_libraryBooksLoaded_pushed(changes ,parameter_p_bookCollection  );
		}
	}


 	public void event_setCompleteBookCollection_pushed (PropertyChangeList changes  , Library_Library p_completeBookCollection ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			parameterTuple.addItem("completeBookCollection", p_completeBookCollection);
			this.onEvent("setCompleteBookCollection", parameterTuple);
			
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * -- Generated impacts relationship code:
		 * completeBookCollection
		 * ================================================== */
		
		Library_Library v0 = p_completeBookCollection;
		
			Library_Library _library_newValue = v0;
			changes.addChange("_library", this, _library_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_init_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			
			this.onEvent("init", parameterTuple);
			
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {

				this.event_loadLibrary_pushed(changes );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_loadLibrary_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			
			this.onEvent("loadLibrary", parameterTuple);
			
			 		
			// Trigger Push edges


			if (this._libraryFileHandler != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._libraryFileHandler);
				for (Object o : edge0_values) {
					LibraryPersistence_LibraryLoader edge0_target = (LibraryPersistence_LibraryLoader)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {

						edge0_target.event_load_pushed(changes );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_openSession_pushed (PropertyChangeList changes  , OCLString p_libNo , OCLString p_password ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			parameterTuple.addItem("libNo", p_libNo);parameterTuple.addItem("password", p_password);
			this.onEvent("openSession", parameterTuple);
			
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {
				/* ==================================================
			 * libNo
			 * ================================================== */
			
			OCLString v1 = p_libNo;
			
				OCLString parameter_p_libNo = v1;
				/* ==================================================
			 * password
			 * ================================================== */
			
			OCLString v2 = p_password;
			
				OCLString parameter_p_pw = v2;

				this.event_authenticateMember_pushed(changes , parameter_p_libNo , parameter_p_pw );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_openSession_pulled_edge0(PropertyChangeList changes, MobileLibraryGUI_LoginWindowController parentInstance ,OCLString p_libNo ,OCLString p_password  ) {
		System.out.println("event_openSession_pulled in model Application_Main from event _openSession in model MobileLibraryGUI_LoginWindowController");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {
			/* ==================================================
		 * libNo
		 * ================================================== */
		
		OCLString v1 = p_libNo;
		
			OCLString parameter_p_libNo = v1;
			/* ==================================================
		 * password
		 * ================================================== */
		
		OCLString v2 = p_password;
		
			OCLString parameter_p_password = v2;

			this.event_openSession_pushed(changes ,parameter_p_libNo ,parameter_p_password  );
		}
	}


 	public void event_authenticateMember_pushed (PropertyChangeList changes  , OCLString p_libNo , OCLString p_pw ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			parameterTuple.addItem("libNo", p_libNo);parameterTuple.addItem("pw", p_pw);
			this.onEvent("authenticateMember", parameterTuple);
			
			 		
			// Trigger Push edges


			if (this._library != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._library);
				for (Object o : edge0_values) {
					Library_Library edge0_target = (Library_Library)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * libNo
				 * ================================================== */
				
				OCLString v1 = p_libNo;
				
						OCLString parameter_p_libNo = v1;
						/* ==================================================
				 * pw
				 * ================================================== */
				
				OCLString v2 = p_pw;
				
						OCLString parameter_p_pw = v2;

						edge0_target.event_authenticateMember_pushed(changes ,parameter_p_libNo ,parameter_p_pw );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_sessionOpened_pushed (PropertyChangeList changes  , Library_Member p_m ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			parameterTuple.addItem("m", p_m);
			this.onEvent("sessionOpened", parameterTuple);
			
			 		
			// Trigger Push edges


			if (this._memberControl != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._memberControl);
				for (Object o : edge0_values) {
					MobileLibraryGUI_MemberWindowController edge0_target = (MobileLibraryGUI_MemberWindowController)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * m
				 * ================================================== */
				
				Library_Member v1 = p_m;
				
						Library_Member parameter_p_m = v1;

						edge0_target.event_sessionOpened_pushed(changes ,parameter_p_m );
					}
				}

			}
			if (this._loginControl != null) {
			 	
				ArrayList<Object> edge1_values = new ArrayList<Object>();
				edge1_values.add(this._loginControl);
				for (Object o : edge1_values) {
					MobileLibraryGUI_LoginWindowController edge1_target = (MobileLibraryGUI_LoginWindowController)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {

						edge1_target.event_sessionOpened_pushed(changes );
					}
				}

			}
			if (this._searchControl != null) {
			 	
				ArrayList<Object> edge2_values = new ArrayList<Object>();
				edge2_values.add(this._searchControl);
				for (Object o : edge2_values) {
					MobileLibraryGUI_SearchWindowController edge2_target = (MobileLibraryGUI_SearchWindowController)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * m
				 * ================================================== */
				
				Library_Member v1 = p_m;
				
						Library_Member parameter_p_m = v1;

						edge2_target.event_memberSessionStarted_pushed(changes ,parameter_p_m );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_sessionOpened_pulled_edge0(PropertyChangeList changes, Library_Library parentInstance ,Library_Member p_member  ) {
		System.out.println("event_sessionOpened_pulled in model Application_Main from event _sessionOpened in model Library_Library");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {
			/* ==================================================
		 * member
		 * ================================================== */
		
		Library_Member v1 = p_member;
		
			Library_Member parameter_p_m = v1;

			this.event_sessionOpened_pushed(changes ,parameter_p_m  );
		}
	}


 	public void event_saveLibrary_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			
			this.onEvent("saveLibrary", parameterTuple);
			
			 		
			// Trigger Push edges


			if (this._libraryFileHandler != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._libraryFileHandler);
				for (Object o : edge0_values) {
					LibraryPersistence_LibraryLoader edge0_target = (LibraryPersistence_LibraryLoader)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * library
				 * ================================================== */
				
				Library_Library v1 = this.get_library();
				
						Library_Library parameter_p_library = v1;

						edge0_target.event_saveLibrary_pushed(changes ,parameter_p_library );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_saveLibrary_pulled_edge0(PropertyChangeList changes, MobileLibraryGUI_MemberWindowController parentInstance  ) {
		System.out.println("event_saveLibrary_pulled in model Application_Main from event _saveData in model MobileLibraryGUI_MemberWindowController");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {

			this.event_saveLibrary_pushed(changes  );
		}
	}
	public void event_saveLibrary_pulled_edge1(PropertyChangeList changes, MobileLibraryGUI_SearchWindowController parentInstance  ) {
		System.out.println("event_saveLibrary_pulled in model Application_Main from event _refreshAndSave in model MobileLibraryGUI_SearchWindowController");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v1 = new OCLBoolean(true);
	
		if (v1.value == true) {

			this.event_saveLibrary_pushed(changes  );
		}
	}


 	public void event_loginFailed_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			
			this.onEvent("loginFailed", parameterTuple);
			
			 		
			// Trigger Push edges


			if (this._loginControl != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._loginControl);
				for (Object o : edge0_values) {
					MobileLibraryGUI_LoginWindowController edge0_target = (MobileLibraryGUI_LoginWindowController)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {

						edge0_target.event_loginFailed_pushed(changes );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_loginFailed_pulled_edge0(PropertyChangeList changes, Library_Library parentInstance  ) {
		System.out.println("event_loginFailed_pulled in model Application_Main from event _loginFailed in model Library_Library");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {

			this.event_loginFailed_pushed(changes  );
		}
	}


 	public void event_closeStartWindow_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			
			this.onEvent("closeStartWindow", parameterTuple);
			
			 		
			// Trigger Push edges


			if (this._startWindowControl != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._startWindowControl);
				for (Object o : edge0_values) {
					MobileLibraryGUI_StartWindowController edge0_target = (MobileLibraryGUI_StartWindowController)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {

						edge0_target.event_closeWIndow_pushed(changes );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * null
		 * ================================================== */
		
		MobileLibraryGUI_StartWindowController v0 = null;
		
			MobileLibraryGUI_StartWindowController _startWindowControl_newValue = v0;
			changes.addChange("_startWindowControl", this, _startWindowControl_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_refreshMemberWindow_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			
			this.onEvent("refreshMemberWindow", parameterTuple);
			
			 		
			// Trigger Push edges


			if (this._memberControl != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._memberControl);
				for (Object o : edge0_values) {
					MobileLibraryGUI_MemberWindowController edge0_target = (MobileLibraryGUI_MemberWindowController)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {

						edge0_target.event_refreshData_pushed(changes );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_refreshMemberWindow_pulled_edge0(PropertyChangeList changes, MobileLibraryGUI_SearchWindowController parentInstance  ) {
		System.out.println("event_refreshMemberWindow_pulled in model Application_Main from event _refreshAndSave in model MobileLibraryGUI_SearchWindowController");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {

			this.event_refreshMemberWindow_pushed(changes  );
		}
	}


 	public void event_loginConfirmed_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			
			this.onEvent("loginConfirmed", parameterTuple);
			
			 		
			// Trigger Push edges


			if (this._viewsControl != null) {
			 	
				ArrayList<Object> edge2_values = new ArrayList<Object>();
				edge2_values.add(this._viewsControl);
				for (Object o : edge2_values) {
					MobileLibraryGUI_ViewsWindowController edge2_target = (MobileLibraryGUI_ViewsWindowController)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * getMemberFrame
				 * ================================================== */
				
				OCLAny v1 = this.get_getMemberFrame();
				
						OCLAny parameter_p_memberFrame = v1;

						edge2_target.event_changeFromLoginToMember_pushed(changes ,parameter_p_memberFrame );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {

				this.event_setToMemberMode_pushed(changes );
			}
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v1 = new OCLBoolean(true);
		
			if (v1.value == true) {

				this.event_refreshMemberWindow_pushed(changes );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_loginConfirmed_pulled_edge0(PropertyChangeList changes, MobileLibraryGUI_LoginWindowController parentInstance  ) {
		System.out.println("event_loginConfirmed_pulled in model Application_Main from event _loginConfirmed in model MobileLibraryGUI_LoginWindowController");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {

			this.event_loginConfirmed_pushed(changes  );
		}
	}


 	public void event_setToMemberMode_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			
			this.onEvent("setToMemberMode", parameterTuple);
			
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * 'Member'
		 * ================================================== */
		
		OCLString v0 = new OCLString("Member");
		
			OCLString _memberViewMode_newValue = v0;
			changes.addChange("_memberViewMode", this, _memberViewMode_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 




	 
	public OCLAny get_getSearchFrame() {
		/* ==================================================
	 * searchControl.frame
	 * ================================================== */
	
	Application_Main v2 = this;
	MobileLibraryGUI_SearchWindowController v1 = v2.get_searchControl();
	OCLAny v0 = v1.get_frame();
	;
		return v0;
	}
	public OCLAny get_getLoginFrame() {
		/* ==================================================
	 * loginControl.frame
	 * ================================================== */
	
	Application_Main v2 = this;
	MobileLibraryGUI_LoginWindowController v1 = v2.get_loginControl();
	OCLAny v0 = v1.get_frame();
	;
		return v0;
	}
	public OCLAny get_getMemberFrame() {
		/* ==================================================
	 * memberControl.window
	 * ================================================== */
	
	Application_Main v2 = this;
	MobileLibraryGUI_MemberWindowController v1 = v2.get_memberControl();
	OCLAny v0 = v1.get_window();
	;
		return v0;
	}


	 
	public void onPropertyChange(String propertyName, Object value) {
	}

	 
	public void onEvent(String eventName, OCLTuple parameters) {
	}

	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

