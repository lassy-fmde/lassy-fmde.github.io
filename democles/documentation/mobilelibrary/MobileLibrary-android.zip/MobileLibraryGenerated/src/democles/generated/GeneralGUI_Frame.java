 
	  
package democles.generated;

import java.util.Vector;
import java.util.ArrayList;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
import android.content.Context;
import android.view.View;

	 
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;
import java.util.Collection;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import java.io.IOException;
import java.io.InputStream;

	 
public class GeneralGUI_Frame implements IViewWrapper, OCLAny {
	 
	private OCLSequence _seqGUIElements;
	private boolean _seqGUIElements_isInitialized;
	private OCLString _frameTitle;
	private boolean _frameTitle_isInitialized;
	private OCLString _iconFilename;
	private boolean _iconFilename_isInitialized;

	public Vector<OCLAny> MobileLibraryGUI_MemberWindowController_window_back = new Vector<OCLAny>();
	public Vector<OCLAny> MobileLibraryGUI_SearchWindowController_frame_back = new Vector<OCLAny>();
	public Vector<OCLAny> MobileLibraryGUI_LoginWindowController_frame_back = new Vector<OCLAny>();

	private Object context;
	private OCLTuple initialPropertyValues = new OCLTuple();
	

	  
	private LinearLayout layout;

	 
	private GeneralGUI_Frame(Object context) {
		super();
		this.context = context;
		 
		if (!this._seqGUIElements_isInitialized) this.set_seqGUIElements(this.initial_seqGUIElements()); 
		if (!this._frameTitle_isInitialized) this.set_frameTitle(this.initial_frameTitle()); 
		if (!this._iconFilename_isInitialized) this.set_iconFilename(this.initial_iconFilename()); 


	}
	
	static public GeneralGUI_Frame newInstance(Object context) {
		if (context == null) throw new NullPointerException();
		return new GeneralGUI_Frame(context);
	}
 
	 
	private GeneralGUI_Frame(Object context, OCLTuple values) {
		super();
		this.context = context;
		if (values != null) this.initialPropertyValues = values;

		 
		this._seqGUIElements_isInitialized = false; 
		this._frameTitle_isInitialized = false; 
		this._iconFilename_isInitialized = false; 

		if (values == null) values = new OCLTuple(); // Empty
        this.initialPropertyValues = values;
		
		if (values.containsKey("seqGUIElements")) {
			this.set_seqGUIElements((OCLSequence)values.objectForKey("seqGUIElements"));
		} else {
			if (!this._seqGUIElements_isInitialized) this.set_seqGUIElements(this.initial_seqGUIElements());
		}
		if (values.containsKey("frameTitle")) {
			this.set_frameTitle((OCLString)values.objectForKey("frameTitle"));
		} else {
			if (!this._frameTitle_isInitialized) this.set_frameTitle(this.initial_frameTitle());
		}
		if (values.containsKey("iconFilename")) {
			this.set_iconFilename((OCLString)values.objectForKey("iconFilename"));
		} else {
			if (!this._iconFilename_isInitialized) this.set_iconFilename(this.initial_iconFilename());
		}


	}

	static public GeneralGUI_Frame newInstance(Object context, OCLTuple values) {
		if (context == null) throw new NullPointerException();
		return new GeneralGUI_Frame(context, values);
	}

	 
	public OCLSequence initial_seqGUIElements() {
		if (this.initialPropertyValues.containsKey("seqGUIElements")) {
			return (OCLSequence)this.initialPropertyValues.objectForKey("seqGUIElements");
		}
		/* ==================================================
	 * Sequence {}
	 * ================================================== */
	
	OCLSequence v0 = new OCLSequence();
	
		return v0;
	}

	public OCLSequence get_seqGUIElements(){
		if (this._seqGUIElements_isInitialized) {
			return _seqGUIElements;
		} else { 
			this.set_seqGUIElements(this.initial_seqGUIElements());
		}
		this._seqGUIElements_isInitialized = true;
		return this._seqGUIElements;
	}
	public OCLString initial_frameTitle() {
		if (this.initialPropertyValues.containsKey("frameTitle")) {
			return (OCLString)this.initialPropertyValues.objectForKey("frameTitle");
		}
		/* ==================================================
	 * ''
	 * ================================================== */
	
	OCLString v0 = new OCLString("");
	
		return v0;
	}

	public OCLString get_frameTitle(){
		if (this._frameTitle_isInitialized) {
			return _frameTitle;
		} else { 
			this.set_frameTitle(this.initial_frameTitle());
		}
		this._frameTitle_isInitialized = true;
		return this._frameTitle;
	}
	public OCLString initial_iconFilename() {
		if (this.initialPropertyValues.containsKey("iconFilename")) {
			return (OCLString)this.initialPropertyValues.objectForKey("iconFilename");
		}
		/* ==================================================
	 * ''
	 * ================================================== */
	
	OCLString v0 = new OCLString("");
	
		return v0;
	}

	public OCLString get_iconFilename(){
		if (this._iconFilename_isInitialized) {
			return _iconFilename;
		} else { 
			this.set_iconFilename(this.initial_iconFilename());
		}
		this._iconFilename_isInitialized = true;
		return this._iconFilename;
	}


	 
	public void set_seqGUIElements(OCLSequence value) {
		 	
		this._seqGUIElements = value;
		this._seqGUIElements_isInitialized = true;

		this.onPropertyChange("seqGUIElements",value);
	}
	public void set_frameTitle(OCLString value) {
		 	
		this._frameTitle = value;
		this._frameTitle_isInitialized = true;

		this.onPropertyChange("frameTitle",value);
	}
	public void set_iconFilename(OCLString value) {
		 	
		this._iconFilename = value;
		this._iconFilename_isInitialized = true;

		this.onPropertyChange("iconFilename",value);
	}






	 


	 


	 

	private Drawable icon = null;

	public void updateIcon() {
		this.icon = null;
		OCLString iconFilenameProp = this._iconFilename;
		if (iconFilenameProp != null) {
		    try {
                InputStream iconStream = ((Context)this.context).getAssets().open(iconFilenameProp.string);
                this.icon = new BitmapDrawable(iconStream);
            } catch (IOException e) {
            }
		}
	}
	
	public Drawable getIcon() {
		return this.icon;	
	}

	public void onPropertyChange(String propertyName, Object value) {
		if (propertyName.equals("seqGUIElements")) {
			if (value != null) {
				updateLayout();
			}
		}
		if (propertyName.equals("iconFilename")) {
			this.updateIcon();
			// TODO if this LinearView is shown in a TabWidget, somehow
			// refresh the title and icon shown in the TabWidget.
		}
		if (propertyName.equals("frameTitle")) {
			this.updateIcon();
			// TODO if this LinearView is shown in a TabWidget, somehow
			// refresh the title and icon shown in the TabWidget.
		}
	}

	 
	public void onEvent(String eventName, OCLTuple parameters){
	}

	  
	@Override
    public String getTitle() {
        return this.get_frameTitle().string;
    }

    @Override
    public View createView(Context context) {
        this.context = context;
        this.layout = new LinearLayout(context);
        this.layout.setOrientation(LinearLayout.VERTICAL);
        
        this.updateLayout();
        return this.layout;
    }
    
    private Collection<IWidgetWrapper> getWidgets() {
    	return (Collection)this.get_seqGUIElements().values;
    }
    
    private void updateLayout() {
    	if (this.layout == null) return;
        this.layout.removeAllViews();

        for (IWidgetWrapper wrapper : this.getWidgets()) {
            View widget = wrapper.createWidget((Context)this.context);
            this.layout.addView(widget, new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
        }
    }

	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

