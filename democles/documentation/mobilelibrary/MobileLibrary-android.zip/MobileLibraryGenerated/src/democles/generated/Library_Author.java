 
	  
package democles.generated;

import java.util.Vector;
import java.util.ArrayList;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
public class Library_Author implements OCLAny {
	 
	private OCLString _name;
	private boolean _name_isInitialized;
	private OCLString _authorId;
	private boolean _authorId_isInitialized;

	public Vector<OCLAny> LibraryPersistence_LibraryLoader_authors_back = new Vector<OCLAny>();
	public Vector<OCLAny> Library_Book_authors_back = new Vector<OCLAny>();

	private Object context;
	private OCLTuple initialPropertyValues = new OCLTuple();
	

	 
	private Library_Author(Object context) {
		super();
		this.context = context;
		 
		if (!this._name_isInitialized) this.set_name(this.initial_name()); 
		if (!this._authorId_isInitialized) this.set_authorId(this.initial_authorId()); 


	}
	
	static public Library_Author newInstance(Object context) {
		if (context == null) throw new NullPointerException();
		return new Library_Author(context);
	}
 
	 
	private Library_Author(Object context, OCLTuple values) {
		super();
		this.context = context;
		if (values != null) this.initialPropertyValues = values;

		 
		this._name_isInitialized = false; 
		this._authorId_isInitialized = false; 

		if (values == null) values = new OCLTuple(); // Empty
        this.initialPropertyValues = values;
		
		if (values.containsKey("name")) {
			this.set_name((OCLString)values.objectForKey("name"));
		} else {
			if (!this._name_isInitialized) this.set_name(this.initial_name());
		}
		if (values.containsKey("authorId")) {
			this.set_authorId((OCLString)values.objectForKey("authorId"));
		} else {
			if (!this._authorId_isInitialized) this.set_authorId(this.initial_authorId());
		}


	}

	static public Library_Author newInstance(Object context, OCLTuple values) {
		if (context == null) throw new NullPointerException();
		return new Library_Author(context, values);
	}

	 
	public OCLString initial_name() {
		if (this.initialPropertyValues.containsKey("name")) {
			return (OCLString)this.initialPropertyValues.objectForKey("name");
		}
		/* ==================================================
	 * null
	 * ================================================== */
	
	OCLString v0 = null;
	
		return v0;
	}

	public OCLString get_name(){
		if (this._name_isInitialized) {
			return _name;
		} else { 
			this.set_name(this.initial_name());
		}
		this._name_isInitialized = true;
		return this._name;
	}
	public OCLString initial_authorId() {
		if (this.initialPropertyValues.containsKey("authorId")) {
			return (OCLString)this.initialPropertyValues.objectForKey("authorId");
		}
		/* ==================================================
	 * null
	 * ================================================== */
	
	OCLString v0 = null;
	
		return v0;
	}

	public OCLString get_authorId(){
		if (this._authorId_isInitialized) {
			return _authorId;
		} else { 
			this.set_authorId(this.initial_authorId());
		}
		this._authorId_isInitialized = true;
		return this._authorId;
	}


	 
	public void set_name(OCLString value) {
	 	
		this._name = value;
		this._name_isInitialized = true;

	}
	public void set_authorId(OCLString value) {
	 	
		this._authorId = value;
		this._authorId_isInitialized = true;

	}






	 


	 


	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

