 
	  
package democles.generated;

import java.util.Vector;
import java.util.ArrayList;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
import android.content.Context;
import android.view.View;

	 
public class GeneralGUI_Button implements IWidgetWrapper, OCLAny {
	 
	private OCLString _text;
	private boolean _text_isInitialized;

	public Vector<OCLAny> MobileLibraryGUI_SearchWindowController_searchButton_back = new Vector<OCLAny>();
	public Vector<OCLAny> MobileLibraryGUI_LoginWindowController_loginButton_back = new Vector<OCLAny>();

	private Object context;
	private OCLTuple initialPropertyValues = new OCLTuple();
	

	  
	private android.widget.Button button;

	 
	private GeneralGUI_Button(Object context) {
		super();
		this.context = context;
		 
		if (!this._text_isInitialized) this.set_text(this.initial_text()); 


	}
	
	static public GeneralGUI_Button newInstance(Object context) {
		if (context == null) throw new NullPointerException();
		return new GeneralGUI_Button(context);
	}
 
	 
	private GeneralGUI_Button(Object context, OCLTuple values) {
		super();
		this.context = context;
		if (values != null) this.initialPropertyValues = values;

		 
		this._text_isInitialized = false; 

		if (values == null) values = new OCLTuple(); // Empty
        this.initialPropertyValues = values;
		
		if (values.containsKey("text")) {
			this.set_text((OCLString)values.objectForKey("text"));
		} else {
			if (!this._text_isInitialized) this.set_text(this.initial_text());
		}


	}

	static public GeneralGUI_Button newInstance(Object context, OCLTuple values) {
		if (context == null) throw new NullPointerException();
		return new GeneralGUI_Button(context, values);
	}

	 
	public OCLString initial_text() {
		if (this.initialPropertyValues.containsKey("text")) {
			return (OCLString)this.initialPropertyValues.objectForKey("text");
		}
		/* ==================================================
	 * ''
	 * ================================================== */
	
	OCLString v0 = new OCLString("");
	
		return v0;
	}

	public OCLString get_text(){
		if (this._text_isInitialized) {
			return _text;
		} else { 
			this.set_text(this.initial_text());
		}
		this._text_isInitialized = true;
		return this._text;
	}


	 
	public void set_text(OCLString value) {
		 	
		this._text = value;
		this._text_isInitialized = true;

		this.onPropertyChange("text",value);
	}






	 
 	public void event_clicked_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			
			this.onEvent("clicked", parameterTuple);
			
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges
			for (OCLAny o : this.MobileLibraryGUI_LoginWindowController_loginButton_back) {
				((MobileLibraryGUI_LoginWindowController)o).event_openSession_pulled_edge0(changes, this );
			}
			for (OCLAny o : this.MobileLibraryGUI_SearchWindowController_searchButton_back) {
				((MobileLibraryGUI_SearchWindowController)o).event_searchButtonClicked_pulled_edge0(changes, this );
			}


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 




	 


	 
	public void onPropertyChange(String propertyName, Object value) {
		if (propertyName.equals("text")) {
			if (value != null) {
				updateButton();
			}
		}
	}

	 
	public void onEvent(String eventName, OCLTuple parameters) {
	}

	  
	@Override
    public View createWidget(final Context context) {
        this.button = new android.widget.Button(context, null, android.R.attr.buttonStyle);
        this.button.setTextAppearance(context, android.R.style.TextAppearance_Medium);
        this.updateButton();
        
        this.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread() { @Override public void run() {
	                event_clicked_pushed(null);
                }}.start();
            }
        });
        return this.button;
    }
    
    private void updateButton() {
    	if (this.button == null) return;
        this.button.setText(this.get_text().string);
    }

	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

