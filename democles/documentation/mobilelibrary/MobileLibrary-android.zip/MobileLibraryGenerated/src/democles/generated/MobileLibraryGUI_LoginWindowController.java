 
	  
package democles.generated;

import java.util.Vector;
import java.util.ArrayList;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
public class MobileLibraryGUI_LoginWindowController implements OCLAny {
	 
	private GeneralGUI_Label _libraryNoLabel;
	private boolean _libraryNoLabel_isInitialized;
	private GeneralGUI_Textfield _libraryNoField;
	private boolean _libraryNoField_isInitialized;
	private GeneralGUI_Label _passwordLabel;
	private boolean _passwordLabel_isInitialized;
	private GeneralGUI_Textfield _passwordField;
	private boolean _passwordField_isInitialized;
	private GeneralGUI_Button _loginButton;
	private boolean _loginButton_isInitialized;
	private OCLString _title;
	private boolean _title_isInitialized;
	private GeneralGUI_Frame _frame;
	private boolean _frame_isInitialized;
	private GeneralGUI_MsgDialog _currMsg;
	private boolean _currMsg_isInitialized;
	private OCLString _ackStatus;
	private boolean _ackStatus_isInitialized;

	public Vector<OCLAny> Application_Main_loginControl_back = new Vector<OCLAny>();

	private Object context;
	private OCLTuple initialPropertyValues = new OCLTuple();
	

	 
	private MobileLibraryGUI_LoginWindowController(Object context) {
		super();
		this.context = context;
		 
		if (!this._libraryNoLabel_isInitialized) this.set_libraryNoLabel(this.initial_libraryNoLabel()); 
		if (!this._libraryNoField_isInitialized) this.set_libraryNoField(this.initial_libraryNoField()); 
		if (!this._passwordLabel_isInitialized) this.set_passwordLabel(this.initial_passwordLabel()); 
		if (!this._passwordField_isInitialized) this.set_passwordField(this.initial_passwordField()); 
		if (!this._loginButton_isInitialized) this.set_loginButton(this.initial_loginButton()); 
		if (!this._title_isInitialized) this.set_title(this.initial_title()); 
		if (!this._frame_isInitialized) this.set_frame(this.initial_frame()); 
		if (!this._currMsg_isInitialized) this.set_currMsg(this.initial_currMsg()); 
		if (!this._ackStatus_isInitialized) this.set_ackStatus(this.initial_ackStatus()); 


	}
	
	static public MobileLibraryGUI_LoginWindowController newInstance(Object context) {
		if (context == null) throw new NullPointerException();
		return new MobileLibraryGUI_LoginWindowController(context);
	}
 
	 
	private MobileLibraryGUI_LoginWindowController(Object context, OCLTuple values) {
		super();
		this.context = context;
		if (values != null) this.initialPropertyValues = values;

		 
		this._libraryNoLabel_isInitialized = false; 
		this._libraryNoField_isInitialized = false; 
		this._passwordLabel_isInitialized = false; 
		this._passwordField_isInitialized = false; 
		this._loginButton_isInitialized = false; 
		this._title_isInitialized = false; 
		this._frame_isInitialized = false; 
		this._currMsg_isInitialized = false; 
		this._ackStatus_isInitialized = false; 

		if (values == null) values = new OCLTuple(); // Empty
        this.initialPropertyValues = values;
		
		if (values.containsKey("libraryNoLabel")) {
			this.set_libraryNoLabel((GeneralGUI_Label)values.objectForKey("libraryNoLabel"));
		} else {
			if (!this._libraryNoLabel_isInitialized) this.set_libraryNoLabel(this.initial_libraryNoLabel());
		}
		if (values.containsKey("libraryNoField")) {
			this.set_libraryNoField((GeneralGUI_Textfield)values.objectForKey("libraryNoField"));
		} else {
			if (!this._libraryNoField_isInitialized) this.set_libraryNoField(this.initial_libraryNoField());
		}
		if (values.containsKey("passwordLabel")) {
			this.set_passwordLabel((GeneralGUI_Label)values.objectForKey("passwordLabel"));
		} else {
			if (!this._passwordLabel_isInitialized) this.set_passwordLabel(this.initial_passwordLabel());
		}
		if (values.containsKey("passwordField")) {
			this.set_passwordField((GeneralGUI_Textfield)values.objectForKey("passwordField"));
		} else {
			if (!this._passwordField_isInitialized) this.set_passwordField(this.initial_passwordField());
		}
		if (values.containsKey("loginButton")) {
			this.set_loginButton((GeneralGUI_Button)values.objectForKey("loginButton"));
		} else {
			if (!this._loginButton_isInitialized) this.set_loginButton(this.initial_loginButton());
		}
		if (values.containsKey("title")) {
			this.set_title((OCLString)values.objectForKey("title"));
		} else {
			if (!this._title_isInitialized) this.set_title(this.initial_title());
		}
		if (values.containsKey("frame")) {
			this.set_frame((GeneralGUI_Frame)values.objectForKey("frame"));
		} else {
			if (!this._frame_isInitialized) this.set_frame(this.initial_frame());
		}
		if (values.containsKey("currMsg")) {
			this.set_currMsg((GeneralGUI_MsgDialog)values.objectForKey("currMsg"));
		} else {
			if (!this._currMsg_isInitialized) this.set_currMsg(this.initial_currMsg());
		}
		if (values.containsKey("ackStatus")) {
			this.set_ackStatus((OCLString)values.objectForKey("ackStatus"));
		} else {
			if (!this._ackStatus_isInitialized) this.set_ackStatus(this.initial_ackStatus());
		}


	}

	static public MobileLibraryGUI_LoginWindowController newInstance(Object context, OCLTuple values) {
		if (context == null) throw new NullPointerException();
		return new MobileLibraryGUI_LoginWindowController(context, values);
	}

	 
	public GeneralGUI_Label initial_libraryNoLabel() {
		if (this.initialPropertyValues.containsKey("libraryNoLabel")) {
			return (GeneralGUI_Label)this.initialPropertyValues.objectForKey("libraryNoLabel");
		}
		/* ==================================================
	 * GeneralGUI::Label::create(Tuple { text = 'Library No:' })
	 * ================================================== */
	
	OCLString v4 = new OCLString("Library No:");
	OCLString v3 = v4;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("text", v3);
	GeneralGUI_Label v0 = GeneralGUI_Label.newInstance(this.context, v2);
	
		return v0;
	}

	public GeneralGUI_Label get_libraryNoLabel(){
		if (this._libraryNoLabel_isInitialized) {
			return _libraryNoLabel;
		} else { 
			this.set_libraryNoLabel(this.initial_libraryNoLabel());
		}
		this._libraryNoLabel_isInitialized = true;
		return this._libraryNoLabel;
	}
	public GeneralGUI_Textfield initial_libraryNoField() {
		if (this.initialPropertyValues.containsKey("libraryNoField")) {
			return (GeneralGUI_Textfield)this.initialPropertyValues.objectForKey("libraryNoField");
		}
		/* ==================================================
	 * GeneralGUI::Textfield::create(Tuple { text = '' })
	 * ================================================== */
	
	OCLString v4 = new OCLString("");
	OCLString v3 = v4;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("text", v3);
	GeneralGUI_Textfield v0 = GeneralGUI_Textfield.newInstance(this.context, v2);
	
		return v0;
	}

	public GeneralGUI_Textfield get_libraryNoField(){
		if (this._libraryNoField_isInitialized) {
			return _libraryNoField;
		} else { 
			this.set_libraryNoField(this.initial_libraryNoField());
		}
		this._libraryNoField_isInitialized = true;
		return this._libraryNoField;
	}
	public GeneralGUI_Label initial_passwordLabel() {
		if (this.initialPropertyValues.containsKey("passwordLabel")) {
			return (GeneralGUI_Label)this.initialPropertyValues.objectForKey("passwordLabel");
		}
		/* ==================================================
	 * GeneralGUI::Label::create(Tuple { text = 'Password:' })
	 * ================================================== */
	
	OCLString v4 = new OCLString("Password:");
	OCLString v3 = v4;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("text", v3);
	GeneralGUI_Label v0 = GeneralGUI_Label.newInstance(this.context, v2);
	
		return v0;
	}

	public GeneralGUI_Label get_passwordLabel(){
		if (this._passwordLabel_isInitialized) {
			return _passwordLabel;
		} else { 
			this.set_passwordLabel(this.initial_passwordLabel());
		}
		this._passwordLabel_isInitialized = true;
		return this._passwordLabel;
	}
	public GeneralGUI_Textfield initial_passwordField() {
		if (this.initialPropertyValues.containsKey("passwordField")) {
			return (GeneralGUI_Textfield)this.initialPropertyValues.objectForKey("passwordField");
		}
		/* ==================================================
	 * GeneralGUI::Textfield::create(Tuple { text = '' })
	 * ================================================== */
	
	OCLString v4 = new OCLString("");
	OCLString v3 = v4;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("text", v3);
	GeneralGUI_Textfield v0 = GeneralGUI_Textfield.newInstance(this.context, v2);
	
		return v0;
	}

	public GeneralGUI_Textfield get_passwordField(){
		if (this._passwordField_isInitialized) {
			return _passwordField;
		} else { 
			this.set_passwordField(this.initial_passwordField());
		}
		this._passwordField_isInitialized = true;
		return this._passwordField;
	}
	public GeneralGUI_Button initial_loginButton() {
		if (this.initialPropertyValues.containsKey("loginButton")) {
			return (GeneralGUI_Button)this.initialPropertyValues.objectForKey("loginButton");
		}
		/* ==================================================
	 * GeneralGUI::Button::create(Tuple { text = 'Login' })
	 * ================================================== */
	
	OCLString v4 = new OCLString("Login");
	OCLString v3 = v4;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("text", v3);
	GeneralGUI_Button v0 = GeneralGUI_Button.newInstance(this.context, v2);
	
		return v0;
	}

	public GeneralGUI_Button get_loginButton(){
		if (this._loginButton_isInitialized) {
			return _loginButton;
		} else { 
			this.set_loginButton(this.initial_loginButton());
		}
		this._loginButton_isInitialized = true;
		return this._loginButton;
	}
	public OCLString initial_title() {
		if (this.initialPropertyValues.containsKey("title")) {
			return (OCLString)this.initialPropertyValues.objectForKey("title");
		}
		/* ==================================================
	 * 'Login'
	 * ================================================== */
	
	OCLString v0 = new OCLString("Login");
	
		return v0;
	}

	public OCLString get_title(){
		if (this._title_isInitialized) {
			return _title;
		} else { 
			this.set_title(this.initial_title());
		}
		this._title_isInitialized = true;
		return this._title;
	}
	public GeneralGUI_Frame initial_frame() {
		if (this.initialPropertyValues.containsKey("frame")) {
			return (GeneralGUI_Frame)this.initialPropertyValues.objectForKey("frame");
		}
		/* ==================================================
	 * GeneralGUI::Frame::create(
	 * 	Tuple { seqGUIElements = Sequence {libraryNoLabel, libraryNoField, passwordLabel, passwordField, loginButton }, 
	 * 	frameTitle = title,
	 * 	iconFilename = 'icon-house.png' })
	 * ================================================== */
	
	MobileLibraryGUI_LoginWindowController v7 = this;
	GeneralGUI_Label v6 = v7.get_libraryNoLabel();
	GeneralGUI_Label v5 = v6;
	MobileLibraryGUI_LoginWindowController v10 = this;
	GeneralGUI_Textfield v9 = v10.get_libraryNoField();
	GeneralGUI_Textfield v8 = v9;
	MobileLibraryGUI_LoginWindowController v13 = this;
	GeneralGUI_Label v12 = v13.get_passwordLabel();
	GeneralGUI_Label v11 = v12;
	MobileLibraryGUI_LoginWindowController v16 = this;
	GeneralGUI_Textfield v15 = v16.get_passwordField();
	GeneralGUI_Textfield v14 = v15;
	MobileLibraryGUI_LoginWindowController v19 = this;
	GeneralGUI_Button v18 = v19.get_loginButton();
	GeneralGUI_Button v17 = v18;
	OCLSequence v4 = new OCLSequence();
	v4.add(v5);
	v4.add(v8);
	v4.add(v11);
	v4.add(v14);
	v4.add(v17);
	OCLSequence v3 = v4;
	MobileLibraryGUI_LoginWindowController v22 = this;
	OCLString v21 = v22.get_title();
	OCLString v20 = v21;
	OCLString v24 = new OCLString("icon-house.png");
	OCLString v23 = v24;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("seqGUIElements", v3);
	v2.addItem("frameTitle", v20);
	v2.addItem("iconFilename", v23);
	GeneralGUI_Frame v0 = GeneralGUI_Frame.newInstance(this.context, v2);
	
		return v0;
	}

	public GeneralGUI_Frame get_frame(){
		if (this._frame_isInitialized) {
			return _frame;
		} else { 
			this.set_frame(this.initial_frame());
		}
		this._frame_isInitialized = true;
		return this._frame;
	}
	public GeneralGUI_MsgDialog initial_currMsg() {
		if (this.initialPropertyValues.containsKey("currMsg")) {
			return (GeneralGUI_MsgDialog)this.initialPropertyValues.objectForKey("currMsg");
		}
		/* ==================================================
	 * null
	 * ================================================== */
	
	GeneralGUI_MsgDialog v0 = null;
	
		return v0;
	}

	public GeneralGUI_MsgDialog get_currMsg(){
		if (this._currMsg_isInitialized) {
			return _currMsg;
		} else { 
			this.set_currMsg(this.initial_currMsg());
		}
		this._currMsg_isInitialized = true;
		return this._currMsg;
	}
	public OCLString initial_ackStatus() {
		if (this.initialPropertyValues.containsKey("ackStatus")) {
			return (OCLString)this.initialPropertyValues.objectForKey("ackStatus");
		}
		/* ==================================================
	 * 'NotWaiting'
	 * ================================================== */
	
	OCLString v0 = new OCLString("NotWaiting");
	
		return v0;
	}

	public OCLString get_ackStatus(){
		if (this._ackStatus_isInitialized) {
			return _ackStatus;
		} else { 
			this.set_ackStatus(this.initial_ackStatus());
		}
		this._ackStatus_isInitialized = true;
		return this._ackStatus;
	}


	 
	public void set_title(OCLString value) {
	 	
		this._title = value;
		this._title_isInitialized = true;

	}
	public void set_ackStatus(OCLString value) {
	 	
		this._ackStatus = value;
		this._ackStatus_isInitialized = true;

	}


	public void set_libraryNoLabel(GeneralGUI_Label value) {
	 	
		if (this._libraryNoLabel!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._libraryNoLabel.MobileLibraryGUI_LoginWindowController_libraryNoLabel_back;
			backpointers.removeElement(this);
		}
		this._libraryNoLabel = value;
		if (this._libraryNoLabel!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._libraryNoLabel.MobileLibraryGUI_LoginWindowController_libraryNoLabel_back;
			backpointers.addElement(this);
		}
		this._libraryNoLabel_isInitialized = true;

	}
	public void set_libraryNoField(GeneralGUI_Textfield value) {
	 	
		if (this._libraryNoField!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._libraryNoField.MobileLibraryGUI_LoginWindowController_libraryNoField_back;
			backpointers.removeElement(this);
		}
		this._libraryNoField = value;
		if (this._libraryNoField!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._libraryNoField.MobileLibraryGUI_LoginWindowController_libraryNoField_back;
			backpointers.addElement(this);
		}
		this._libraryNoField_isInitialized = true;

	}
	public void set_passwordLabel(GeneralGUI_Label value) {
	 	
		if (this._passwordLabel!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._passwordLabel.MobileLibraryGUI_LoginWindowController_passwordLabel_back;
			backpointers.removeElement(this);
		}
		this._passwordLabel = value;
		if (this._passwordLabel!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._passwordLabel.MobileLibraryGUI_LoginWindowController_passwordLabel_back;
			backpointers.addElement(this);
		}
		this._passwordLabel_isInitialized = true;

	}
	public void set_passwordField(GeneralGUI_Textfield value) {
	 	
		if (this._passwordField!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._passwordField.MobileLibraryGUI_LoginWindowController_passwordField_back;
			backpointers.removeElement(this);
		}
		this._passwordField = value;
		if (this._passwordField!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._passwordField.MobileLibraryGUI_LoginWindowController_passwordField_back;
			backpointers.addElement(this);
		}
		this._passwordField_isInitialized = true;

	}
	public void set_loginButton(GeneralGUI_Button value) {
	 	
		if (this._loginButton!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._loginButton.MobileLibraryGUI_LoginWindowController_loginButton_back;
			backpointers.removeElement(this);
		}
		this._loginButton = value;
		if (this._loginButton!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._loginButton.MobileLibraryGUI_LoginWindowController_loginButton_back;
			backpointers.addElement(this);
		}
		this._loginButton_isInitialized = true;

	}
	public void set_frame(GeneralGUI_Frame value) {
	 	
		if (this._frame!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._frame.MobileLibraryGUI_LoginWindowController_frame_back;
			backpointers.removeElement(this);
		}
		this._frame = value;
		if (this._frame!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._frame.MobileLibraryGUI_LoginWindowController_frame_back;
			backpointers.addElement(this);
		}
		this._frame_isInitialized = true;

	}
	public void set_currMsg(GeneralGUI_MsgDialog value) {
	 	
		if (this._currMsg!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._currMsg.MobileLibraryGUI_LoginWindowController_currMsg_back;
			backpointers.removeElement(this);
		}
		this._currMsg = value;
		if (this._currMsg!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._currMsg.MobileLibraryGUI_LoginWindowController_currMsg_back;
			backpointers.addElement(this);
		}
		this._currMsg_isInitialized = true;

	}




	 
 	public void event_openSession_pushed (PropertyChangeList changes  , OCLString p_libNo , OCLString p_password ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_openSession_pushed in model MobileLibraryGUI_LoginWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges
			for (OCLAny o : this.Application_Main_loginControl_back) {
				((Application_Main)o).event_openSession_pulled_edge0(changes, this , p_libNo, p_password);
			}


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_openSession_pulled_edge0(PropertyChangeList changes, GeneralGUI_Button parentInstance  ) {
		System.out.println("event_openSession_pulled in model MobileLibraryGUI_LoginWindowController from event _clicked in model GeneralGUI_Button");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {
			/* ==================================================
		 * libraryNoField.text
		 * ================================================== */
		
		MobileLibraryGUI_LoginWindowController v3 = this;
		GeneralGUI_Textfield v2 = v3.get_libraryNoField();
		OCLString v1 = v2.get_text();
		
			OCLString parameter_p_libNo = v1;
			/* ==================================================
		 * passwordField.text
		 * ================================================== */
		
		MobileLibraryGUI_LoginWindowController v6 = this;
		GeneralGUI_Textfield v5 = v6.get_passwordField();
		OCLString v4 = v5.get_text();
		
			OCLString parameter_p_password = v4;

			this.event_openSession_pushed(changes ,parameter_p_libNo ,parameter_p_password  );
		}
	}


 	public void event_sessionOpened_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_sessionOpened_pushed in model MobileLibraryGUI_LoginWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {

				this.event_showLoginSucessfulMsg_pushed(changes );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_showLoginSucessfulMsg_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_showLoginSucessfulMsg_pushed in model MobileLibraryGUI_LoginWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * GeneralGUI::MsgDialog::create(
		 * 	Tuple { 
		 * 	    msg = 'You are now logged into the library!', 
		 * 		viewTitle = 'Success!' })
		 * ================================================== */
		
		OCLString v4 = new OCLString("You are now logged into the library!");
		OCLString v3 = v4;
		OCLString v6 = new OCLString("Success!");
		OCLString v5 = v6;
		OCLTuple v2 = new OCLTuple();
		v2.addItem("msg", v3);
		v2.addItem("viewTitle", v5);
		GeneralGUI_MsgDialog v0 = GeneralGUI_MsgDialog.newInstance(this.context, v2);
		
			GeneralGUI_MsgDialog _currMsg_newValue = v0;
			changes.addChange("_currMsg", this, _currMsg_newValue);
			/* ==================================================
		 * 'WaitingLoginAck'
		 * ================================================== */
		
		OCLString v7 = new OCLString("WaitingLoginAck");
		
			OCLString _ackStatus_newValue = v7;
			changes.addChange("_ackStatus", this, _ackStatus_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_showInvalidLoginMsg_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_showInvalidLoginMsg_pushed in model MobileLibraryGUI_LoginWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * GeneralGUI::MsgDialog::create(
		 * 	Tuple { 
		 * 	    msg = 'Invalid Library Number  or wrong password!', 
		 * 		viewTitle = 'Error!' })
		 * ================================================== */
		
		OCLString v4 = new OCLString("Invalid Library Number  or wrong password!");
		OCLString v3 = v4;
		OCLString v6 = new OCLString("Error!");
		OCLString v5 = v6;
		OCLTuple v2 = new OCLTuple();
		v2.addItem("msg", v3);
		v2.addItem("viewTitle", v5);
		GeneralGUI_MsgDialog v0 = GeneralGUI_MsgDialog.newInstance(this.context, v2);
		
			GeneralGUI_MsgDialog _currMsg_newValue = v0;
			changes.addChange("_currMsg", this, _currMsg_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_setToNotWaiting_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_setToNotWaiting_pushed in model MobileLibraryGUI_LoginWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * 'NotWaiting'
		 * ================================================== */
		
		OCLString v0 = new OCLString("NotWaiting");
		
			OCLString _ackStatus_newValue = v0;
			changes.addChange("_ackStatus", this, _ackStatus_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_loginFailed_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_loginFailed_pushed in model MobileLibraryGUI_LoginWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {

				this.event_showInvalidLoginMsg_pushed(changes );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_loginAck_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * ackStatus='WaitingLoginAck'
             * ================================================== */
            
            MobileLibraryGUI_LoginWindowController v2 = this;
            OCLString v1 = v2.get_ackStatus();
            OCLString v3 = new OCLString("WaitingLoginAck");
            OCLBoolean v0;
            if (v1 == null || v3 == null) {
            		v0 = new OCLBoolean(v1 == v3);
            } else {
            		v0 = v1.eq(v3);
            }
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_loginAck_pushed in model MobileLibraryGUI_LoginWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {

				this.event_setToNotWaiting_pushed(changes );
			}
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v1 = new OCLBoolean(true);
		
			if (v1.value == true) {

				this.event_loginConfirmed_pushed(changes );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_loginAck_pulled_edge0(PropertyChangeList changes, GeneralGUI_MsgDialog parentInstance  ) {
		System.out.println("event_loginAck_pulled in model MobileLibraryGUI_LoginWindowController from event _okClicked in model GeneralGUI_MsgDialog");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {

			this.event_loginAck_pushed(changes  );
		}
	}


 	public void event_loginConfirmed_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_loginConfirmed_pushed in model MobileLibraryGUI_LoginWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges
			for (OCLAny o : this.Application_Main_loginControl_back) {
				((Application_Main)o).event_loginConfirmed_pulled_edge0(changes, this );
			}


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 




	 
	public OCLString get_getLibraryNo() {
		/* ==================================================
	 * libraryNoField.text
	 * ================================================== */
	
	MobileLibraryGUI_LoginWindowController v2 = this;
	GeneralGUI_Textfield v1 = v2.get_libraryNoField();
	OCLString v0 = v1.get_text();
	;
		return v0;
	}
	public OCLString get_getPassword() {
		/* ==================================================
	 * passwordField.text
	 * ================================================== */
	
	MobileLibraryGUI_LoginWindowController v2 = this;
	GeneralGUI_Textfield v1 = v2.get_passwordField();
	OCLString v0 = v1.get_text();
	;
		return v0;
	}


	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

