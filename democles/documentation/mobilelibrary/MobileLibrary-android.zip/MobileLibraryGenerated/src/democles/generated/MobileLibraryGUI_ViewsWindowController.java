 
	  
package democles.generated;

import java.util.Vector;
import java.util.ArrayList;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
public class MobileLibraryGUI_ViewsWindowController implements OCLAny {
	 
	private GeneralGUI_TabbedWindow _viewsWindow;
	private boolean _viewsWindow_isInitialized;

	public Vector<OCLAny> Application_Main_viewsControl_back = new Vector<OCLAny>();

	private Object context;
	private OCLTuple initialPropertyValues = new OCLTuple();
	

	 
	private MobileLibraryGUI_ViewsWindowController(Object context) {
		super();
		this.context = context;
		 
		if (!this._viewsWindow_isInitialized) this.set_viewsWindow(this.initial_viewsWindow()); 


	}
	
	static public MobileLibraryGUI_ViewsWindowController newInstance(Object context) {
		if (context == null) throw new NullPointerException();
		return new MobileLibraryGUI_ViewsWindowController(context);
	}
 
	 
	private MobileLibraryGUI_ViewsWindowController(Object context, OCLTuple values) {
		super();
		this.context = context;
		if (values != null) this.initialPropertyValues = values;

		 
		this._viewsWindow_isInitialized = false; 

		if (values == null) values = new OCLTuple(); // Empty
        this.initialPropertyValues = values;
		
		if (values.containsKey("viewsWindow")) {
			this.set_viewsWindow((GeneralGUI_TabbedWindow)values.objectForKey("viewsWindow"));
		} else {
			if (!this._viewsWindow_isInitialized) this.set_viewsWindow(this.initial_viewsWindow());
		}


	}

	static public MobileLibraryGUI_ViewsWindowController newInstance(Object context, OCLTuple values) {
		if (context == null) throw new NullPointerException();
		return new MobileLibraryGUI_ViewsWindowController(context, values);
	}

	 
	public GeneralGUI_TabbedWindow initial_viewsWindow() {
		if (this.initialPropertyValues.containsKey("viewsWindow")) {
			return (GeneralGUI_TabbedWindow)this.initialPropertyValues.objectForKey("viewsWindow");
		}
		/* ==================================================
	 * null
	 * ================================================== */
	
	GeneralGUI_TabbedWindow v0 = null;
	
		return v0;
	}

	public GeneralGUI_TabbedWindow get_viewsWindow(){
		if (this._viewsWindow_isInitialized) {
			return _viewsWindow;
		} else { 
			this.set_viewsWindow(this.initial_viewsWindow());
		}
		this._viewsWindow_isInitialized = true;
		return this._viewsWindow;
	}


	 


	public void set_viewsWindow(GeneralGUI_TabbedWindow value) {
	 	
		if (this._viewsWindow!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._viewsWindow.MobileLibraryGUI_ViewsWindowController_viewsWindow_back;
			backpointers.removeElement(this);
		}
		this._viewsWindow = value;
		if (this._viewsWindow!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._viewsWindow.MobileLibraryGUI_ViewsWindowController_viewsWindow_back;
			backpointers.addElement(this);
		}
		this._viewsWindow_isInitialized = true;

	}




	 
 	public void event_startViewsWindow_pushed (PropertyChangeList changes  , OCLAny p_searchWindow , OCLAny p_loginWindow ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_startViewsWindow_pushed in model MobileLibraryGUI_ViewsWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * GeneralGUI::TabbedWindow::create(
		 * 	Tuple { views = Sequence {searchWindow, 
		 * 		loginWindow } })
		 * ================================================== */
		
		OCLAny v6 = p_searchWindow;
		OCLAny v5 = v6;
		OCLAny v8 = p_loginWindow;
		OCLAny v7 = v8;
		OCLSequence v4 = new OCLSequence();
		v4.add(v5);
		v4.add(v7);
		OCLSequence v3 = v4;
		OCLTuple v2 = new OCLTuple();
		v2.addItem("views", v3);
		GeneralGUI_TabbedWindow v0 = GeneralGUI_TabbedWindow.newInstance(this.context, v2);
		
			GeneralGUI_TabbedWindow _viewsWindow_newValue = v0;
			changes.addChange("_viewsWindow", this, _viewsWindow_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_changeFromLoginToMember_pushed (PropertyChangeList changes  , OCLAny p_memberFrame ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_changeFromLoginToMember_pushed in model MobileLibraryGUI_ViewsWindowController");
			 		
			// Trigger Push edges


			if (this._viewsWindow != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._viewsWindow);
				for (Object o : edge0_values) {
					GeneralGUI_TabbedWindow edge0_target = (GeneralGUI_TabbedWindow)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * 2
				 * ================================================== */
				
				OCLInteger v1 = new OCLInteger(2);
				
						OCLInteger parameter_p_index = v1;
						/* ==================================================
				 * memberFrame
				 * ================================================== */
				
				OCLAny v2 = p_memberFrame;
				
						OCLAny parameter_p_view = v2;

						edge0_target.event_changeView_pushed(changes ,parameter_p_index ,parameter_p_view );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 




	 


	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

