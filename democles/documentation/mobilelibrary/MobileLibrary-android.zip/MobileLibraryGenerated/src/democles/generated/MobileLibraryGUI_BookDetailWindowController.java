 
	  
package democles.generated;

import java.util.Vector;
import java.util.ArrayList;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
public class MobileLibraryGUI_BookDetailWindowController implements OCLAny {
	 
	private GeneralGUI_Label _titleLabel;
	private boolean _titleLabel_isInitialized;
	private GeneralGUI_Label _bookTitleLabel;
	private boolean _bookTitleLabel_isInitialized;
	private GeneralGUI_Label _authorLabel;
	private boolean _authorLabel_isInitialized;
	private GeneralGUI_Label _bookAuthorLabel;
	private boolean _bookAuthorLabel_isInitialized;
	private GeneralGUI_Label _isbnLabel;
	private boolean _isbnLabel_isInitialized;
	private GeneralGUI_Label _bookIsbnLabel;
	private boolean _bookIsbnLabel_isInitialized;
	private OCLString _windowTitle;
	private boolean _windowTitle_isInitialized;
	private GeneralGUI_SelectionList _bookCopies;
	private boolean _bookCopies_isInitialized;
	private GeneralGUI_Label _bookCopiesLabel;
	private boolean _bookCopiesLabel_isInitialized;
	private GeneralGUI_Window _window;
	private boolean _window_isInitialized;
	private Library_Copy _selectedBookCopy;
	private boolean _selectedBookCopy_isInitialized;
	private Library_Book _currBook;
	private boolean _currBook_isInitialized;
	private GeneralGUI_ConfirmationDialog _yesNoMsg;
	private boolean _yesNoMsg_isInitialized;
	private Library_Member _currMember;
	private boolean _currMember_isInitialized;
	private OCLString _mode;
	private boolean _mode_isInitialized;
	private GeneralGUI_MsgDialog _msg;
	private boolean _msg_isInitialized;
	private OCLString _ackStatus;
	private boolean _ackStatus_isInitialized;

	public Vector<OCLAny> MobileLibraryGUI_BookListWindowController_detailsWindow_back = new Vector<OCLAny>();

	private Object context;
	private OCLTuple initialPropertyValues = new OCLTuple();
	

	 
	private MobileLibraryGUI_BookDetailWindowController(Object context) {
		super();
		this.context = context;
		 
		if (!this._titleLabel_isInitialized) this.set_titleLabel(this.initial_titleLabel()); 
		if (!this._bookTitleLabel_isInitialized) this.set_bookTitleLabel(this.initial_bookTitleLabel()); 
		if (!this._authorLabel_isInitialized) this.set_authorLabel(this.initial_authorLabel()); 
		if (!this._bookAuthorLabel_isInitialized) this.set_bookAuthorLabel(this.initial_bookAuthorLabel()); 
		if (!this._isbnLabel_isInitialized) this.set_isbnLabel(this.initial_isbnLabel()); 
		if (!this._bookIsbnLabel_isInitialized) this.set_bookIsbnLabel(this.initial_bookIsbnLabel()); 
		if (!this._windowTitle_isInitialized) this.set_windowTitle(this.initial_windowTitle()); 
		if (!this._bookCopies_isInitialized) this.set_bookCopies(this.initial_bookCopies()); 
		if (!this._bookCopiesLabel_isInitialized) this.set_bookCopiesLabel(this.initial_bookCopiesLabel()); 
		if (!this._window_isInitialized) this.set_window(this.initial_window()); 
		if (!this._selectedBookCopy_isInitialized) this.set_selectedBookCopy(this.initial_selectedBookCopy()); 
		if (!this._currBook_isInitialized) this.set_currBook(this.initial_currBook()); 
		if (!this._yesNoMsg_isInitialized) this.set_yesNoMsg(this.initial_yesNoMsg()); 
		if (!this._currMember_isInitialized) this.set_currMember(this.initial_currMember()); 
		if (!this._mode_isInitialized) this.set_mode(this.initial_mode()); 
		if (!this._msg_isInitialized) this.set_msg(this.initial_msg()); 
		if (!this._ackStatus_isInitialized) this.set_ackStatus(this.initial_ackStatus()); 


	}
	
	static public MobileLibraryGUI_BookDetailWindowController newInstance(Object context) {
		if (context == null) throw new NullPointerException();
		return new MobileLibraryGUI_BookDetailWindowController(context);
	}
 
	 
	private MobileLibraryGUI_BookDetailWindowController(Object context, OCLTuple values) {
		super();
		this.context = context;
		if (values != null) this.initialPropertyValues = values;

		 
		this._titleLabel_isInitialized = false; 
		this._bookTitleLabel_isInitialized = false; 
		this._authorLabel_isInitialized = false; 
		this._bookAuthorLabel_isInitialized = false; 
		this._isbnLabel_isInitialized = false; 
		this._bookIsbnLabel_isInitialized = false; 
		this._windowTitle_isInitialized = false; 
		this._bookCopies_isInitialized = false; 
		this._bookCopiesLabel_isInitialized = false; 
		this._window_isInitialized = false; 
		this._selectedBookCopy_isInitialized = false; 
		this._currBook_isInitialized = false; 
		this._yesNoMsg_isInitialized = false; 
		this._currMember_isInitialized = false; 
		this._mode_isInitialized = false; 
		this._msg_isInitialized = false; 
		this._ackStatus_isInitialized = false; 

		if (values == null) values = new OCLTuple(); // Empty
        this.initialPropertyValues = values;
		
		if (values.containsKey("titleLabel")) {
			this.set_titleLabel((GeneralGUI_Label)values.objectForKey("titleLabel"));
		} else {
			if (!this._titleLabel_isInitialized) this.set_titleLabel(this.initial_titleLabel());
		}
		if (values.containsKey("bookTitleLabel")) {
			this.set_bookTitleLabel((GeneralGUI_Label)values.objectForKey("bookTitleLabel"));
		} else {
			if (!this._bookTitleLabel_isInitialized) this.set_bookTitleLabel(this.initial_bookTitleLabel());
		}
		if (values.containsKey("authorLabel")) {
			this.set_authorLabel((GeneralGUI_Label)values.objectForKey("authorLabel"));
		} else {
			if (!this._authorLabel_isInitialized) this.set_authorLabel(this.initial_authorLabel());
		}
		if (values.containsKey("bookAuthorLabel")) {
			this.set_bookAuthorLabel((GeneralGUI_Label)values.objectForKey("bookAuthorLabel"));
		} else {
			if (!this._bookAuthorLabel_isInitialized) this.set_bookAuthorLabel(this.initial_bookAuthorLabel());
		}
		if (values.containsKey("isbnLabel")) {
			this.set_isbnLabel((GeneralGUI_Label)values.objectForKey("isbnLabel"));
		} else {
			if (!this._isbnLabel_isInitialized) this.set_isbnLabel(this.initial_isbnLabel());
		}
		if (values.containsKey("bookIsbnLabel")) {
			this.set_bookIsbnLabel((GeneralGUI_Label)values.objectForKey("bookIsbnLabel"));
		} else {
			if (!this._bookIsbnLabel_isInitialized) this.set_bookIsbnLabel(this.initial_bookIsbnLabel());
		}
		if (values.containsKey("windowTitle")) {
			this.set_windowTitle((OCLString)values.objectForKey("windowTitle"));
		} else {
			if (!this._windowTitle_isInitialized) this.set_windowTitle(this.initial_windowTitle());
		}
		if (values.containsKey("bookCopies")) {
			this.set_bookCopies((GeneralGUI_SelectionList)values.objectForKey("bookCopies"));
		} else {
			if (!this._bookCopies_isInitialized) this.set_bookCopies(this.initial_bookCopies());
		}
		if (values.containsKey("bookCopiesLabel")) {
			this.set_bookCopiesLabel((GeneralGUI_Label)values.objectForKey("bookCopiesLabel"));
		} else {
			if (!this._bookCopiesLabel_isInitialized) this.set_bookCopiesLabel(this.initial_bookCopiesLabel());
		}
		if (values.containsKey("window")) {
			this.set_window((GeneralGUI_Window)values.objectForKey("window"));
		} else {
			if (!this._window_isInitialized) this.set_window(this.initial_window());
		}
		if (values.containsKey("selectedBookCopy")) {
			this.set_selectedBookCopy((Library_Copy)values.objectForKey("selectedBookCopy"));
		} else {
			if (!this._selectedBookCopy_isInitialized) this.set_selectedBookCopy(this.initial_selectedBookCopy());
		}
		if (values.containsKey("currBook")) {
			this.set_currBook((Library_Book)values.objectForKey("currBook"));
		} else {
			if (!this._currBook_isInitialized) this.set_currBook(this.initial_currBook());
		}
		if (values.containsKey("yesNoMsg")) {
			this.set_yesNoMsg((GeneralGUI_ConfirmationDialog)values.objectForKey("yesNoMsg"));
		} else {
			if (!this._yesNoMsg_isInitialized) this.set_yesNoMsg(this.initial_yesNoMsg());
		}
		if (values.containsKey("currMember")) {
			this.set_currMember((Library_Member)values.objectForKey("currMember"));
		} else {
			if (!this._currMember_isInitialized) this.set_currMember(this.initial_currMember());
		}
		if (values.containsKey("mode")) {
			this.set_mode((OCLString)values.objectForKey("mode"));
		} else {
			if (!this._mode_isInitialized) this.set_mode(this.initial_mode());
		}
		if (values.containsKey("msg")) {
			this.set_msg((GeneralGUI_MsgDialog)values.objectForKey("msg"));
		} else {
			if (!this._msg_isInitialized) this.set_msg(this.initial_msg());
		}
		if (values.containsKey("ackStatus")) {
			this.set_ackStatus((OCLString)values.objectForKey("ackStatus"));
		} else {
			if (!this._ackStatus_isInitialized) this.set_ackStatus(this.initial_ackStatus());
		}


	}

	static public MobileLibraryGUI_BookDetailWindowController newInstance(Object context, OCLTuple values) {
		if (context == null) throw new NullPointerException();
		return new MobileLibraryGUI_BookDetailWindowController(context, values);
	}

	 
	public GeneralGUI_Label initial_titleLabel() {
		if (this.initialPropertyValues.containsKey("titleLabel")) {
			return (GeneralGUI_Label)this.initialPropertyValues.objectForKey("titleLabel");
		}
		/* ==================================================
	 * GeneralGUI::Label::create(Tuple { text = 'Title: ' })
	 * ================================================== */
	
	OCLString v4 = new OCLString("Title: ");
	OCLString v3 = v4;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("text", v3);
	GeneralGUI_Label v0 = GeneralGUI_Label.newInstance(this.context, v2);
	
		return v0;
	}

	public GeneralGUI_Label get_titleLabel(){
		if (this._titleLabel_isInitialized) {
			return _titleLabel;
		} else { 
			this.set_titleLabel(this.initial_titleLabel());
		}
		this._titleLabel_isInitialized = true;
		return this._titleLabel;
	}
	public GeneralGUI_Label initial_bookTitleLabel() {
		if (this.initialPropertyValues.containsKey("bookTitleLabel")) {
			return (GeneralGUI_Label)this.initialPropertyValues.objectForKey("bookTitleLabel");
		}
		/* ==================================================
	 * null
	 * ================================================== */
	
	GeneralGUI_Label v0 = null;
	
		return v0;
	}

	public GeneralGUI_Label get_bookTitleLabel(){
		if (this._bookTitleLabel_isInitialized) {
			return _bookTitleLabel;
		} else { 
			this.set_bookTitleLabel(this.initial_bookTitleLabel());
		}
		this._bookTitleLabel_isInitialized = true;
		return this._bookTitleLabel;
	}
	public GeneralGUI_Label initial_authorLabel() {
		if (this.initialPropertyValues.containsKey("authorLabel")) {
			return (GeneralGUI_Label)this.initialPropertyValues.objectForKey("authorLabel");
		}
		/* ==================================================
	 * GeneralGUI::Label::create(Tuple { text = 'Authors: ' })
	 * ================================================== */
	
	OCLString v4 = new OCLString("Authors: ");
	OCLString v3 = v4;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("text", v3);
	GeneralGUI_Label v0 = GeneralGUI_Label.newInstance(this.context, v2);
	
		return v0;
	}

	public GeneralGUI_Label get_authorLabel(){
		if (this._authorLabel_isInitialized) {
			return _authorLabel;
		} else { 
			this.set_authorLabel(this.initial_authorLabel());
		}
		this._authorLabel_isInitialized = true;
		return this._authorLabel;
	}
	public GeneralGUI_Label initial_bookAuthorLabel() {
		if (this.initialPropertyValues.containsKey("bookAuthorLabel")) {
			return (GeneralGUI_Label)this.initialPropertyValues.objectForKey("bookAuthorLabel");
		}
		/* ==================================================
	 * null
	 * ================================================== */
	
	GeneralGUI_Label v0 = null;
	
		return v0;
	}

	public GeneralGUI_Label get_bookAuthorLabel(){
		if (this._bookAuthorLabel_isInitialized) {
			return _bookAuthorLabel;
		} else { 
			this.set_bookAuthorLabel(this.initial_bookAuthorLabel());
		}
		this._bookAuthorLabel_isInitialized = true;
		return this._bookAuthorLabel;
	}
	public GeneralGUI_Label initial_isbnLabel() {
		if (this.initialPropertyValues.containsKey("isbnLabel")) {
			return (GeneralGUI_Label)this.initialPropertyValues.objectForKey("isbnLabel");
		}
		/* ==================================================
	 * GeneralGUI::Label::create(Tuple { text = 'ISBN: ' })
	 * ================================================== */
	
	OCLString v4 = new OCLString("ISBN: ");
	OCLString v3 = v4;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("text", v3);
	GeneralGUI_Label v0 = GeneralGUI_Label.newInstance(this.context, v2);
	
		return v0;
	}

	public GeneralGUI_Label get_isbnLabel(){
		if (this._isbnLabel_isInitialized) {
			return _isbnLabel;
		} else { 
			this.set_isbnLabel(this.initial_isbnLabel());
		}
		this._isbnLabel_isInitialized = true;
		return this._isbnLabel;
	}
	public GeneralGUI_Label initial_bookIsbnLabel() {
		if (this.initialPropertyValues.containsKey("bookIsbnLabel")) {
			return (GeneralGUI_Label)this.initialPropertyValues.objectForKey("bookIsbnLabel");
		}
		/* ==================================================
	 * null
	 * ================================================== */
	
	GeneralGUI_Label v0 = null;
	
		return v0;
	}

	public GeneralGUI_Label get_bookIsbnLabel(){
		if (this._bookIsbnLabel_isInitialized) {
			return _bookIsbnLabel;
		} else { 
			this.set_bookIsbnLabel(this.initial_bookIsbnLabel());
		}
		this._bookIsbnLabel_isInitialized = true;
		return this._bookIsbnLabel;
	}
	public OCLString initial_windowTitle() {
		if (this.initialPropertyValues.containsKey("windowTitle")) {
			return (OCLString)this.initialPropertyValues.objectForKey("windowTitle");
		}
		/* ==================================================
	 * 'Book Detail'
	 * ================================================== */
	
	OCLString v0 = new OCLString("Book Detail");
	
		return v0;
	}

	public OCLString get_windowTitle(){
		if (this._windowTitle_isInitialized) {
			return _windowTitle;
		} else { 
			this.set_windowTitle(this.initial_windowTitle());
		}
		this._windowTitle_isInitialized = true;
		return this._windowTitle;
	}
	public GeneralGUI_SelectionList initial_bookCopies() {
		if (this.initialPropertyValues.containsKey("bookCopies")) {
			return (GeneralGUI_SelectionList)this.initialPropertyValues.objectForKey("bookCopies");
		}
		/* ==================================================
	 * GeneralGUI::SelectionList::create(Tuple { items = Sequence { } })
	 * ================================================== */
	
	OCLSequence v4 = new OCLSequence();
	OCLSequence v3 = v4;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("items", v3);
	GeneralGUI_SelectionList v0 = GeneralGUI_SelectionList.newInstance(this.context, v2);
	
		return v0;
	}

	public GeneralGUI_SelectionList get_bookCopies(){
		if (this._bookCopies_isInitialized) {
			return _bookCopies;
		} else { 
			this.set_bookCopies(this.initial_bookCopies());
		}
		this._bookCopies_isInitialized = true;
		return this._bookCopies;
	}
	public GeneralGUI_Label initial_bookCopiesLabel() {
		if (this.initialPropertyValues.containsKey("bookCopiesLabel")) {
			return (GeneralGUI_Label)this.initialPropertyValues.objectForKey("bookCopiesLabel");
		}
		/* ==================================================
	 * GeneralGUI::Label::create(Tuple { text = 'Copies of books available in the library:' })
	 * ================================================== */
	
	OCLString v4 = new OCLString("Copies of books available in the library:");
	OCLString v3 = v4;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("text", v3);
	GeneralGUI_Label v0 = GeneralGUI_Label.newInstance(this.context, v2);
	
		return v0;
	}

	public GeneralGUI_Label get_bookCopiesLabel(){
		if (this._bookCopiesLabel_isInitialized) {
			return _bookCopiesLabel;
		} else { 
			this.set_bookCopiesLabel(this.initial_bookCopiesLabel());
		}
		this._bookCopiesLabel_isInitialized = true;
		return this._bookCopiesLabel;
	}
	public GeneralGUI_Window initial_window() {
		if (this.initialPropertyValues.containsKey("window")) {
			return (GeneralGUI_Window)this.initialPropertyValues.objectForKey("window");
		}
		/* ==================================================
	 * GeneralGUI::Window::create(
	 * 	Tuple { 
	 * 	seqGUIElements = Sequence { titleLabel, 
	 * 		bookTitleLabel, 
	 * 		authorLabel, 
	 * 		bookAuthorLabel, 
	 * 		isbnLabel, 
	 * 		bookIsbnLabel,
	 * 		bookCopiesLabel,
	 * 		bookCopies}, 
	 * 		title = windowTitle })
	 * ================================================== */
	
	MobileLibraryGUI_BookDetailWindowController v7 = this;
	GeneralGUI_Label v6 = v7.get_titleLabel();
	GeneralGUI_Label v5 = v6;
	MobileLibraryGUI_BookDetailWindowController v10 = this;
	GeneralGUI_Label v9 = v10.get_bookTitleLabel();
	GeneralGUI_Label v8 = v9;
	MobileLibraryGUI_BookDetailWindowController v13 = this;
	GeneralGUI_Label v12 = v13.get_authorLabel();
	GeneralGUI_Label v11 = v12;
	MobileLibraryGUI_BookDetailWindowController v16 = this;
	GeneralGUI_Label v15 = v16.get_bookAuthorLabel();
	GeneralGUI_Label v14 = v15;
	MobileLibraryGUI_BookDetailWindowController v19 = this;
	GeneralGUI_Label v18 = v19.get_isbnLabel();
	GeneralGUI_Label v17 = v18;
	MobileLibraryGUI_BookDetailWindowController v22 = this;
	GeneralGUI_Label v21 = v22.get_bookIsbnLabel();
	GeneralGUI_Label v20 = v21;
	MobileLibraryGUI_BookDetailWindowController v25 = this;
	GeneralGUI_Label v24 = v25.get_bookCopiesLabel();
	GeneralGUI_Label v23 = v24;
	MobileLibraryGUI_BookDetailWindowController v28 = this;
	GeneralGUI_SelectionList v27 = v28.get_bookCopies();
	GeneralGUI_SelectionList v26 = v27;
	OCLSequence v4 = new OCLSequence();
	v4.add(v5);
	v4.add(v8);
	v4.add(v11);
	v4.add(v14);
	v4.add(v17);
	v4.add(v20);
	v4.add(v23);
	v4.add(v26);
	OCLSequence v3 = v4;
	MobileLibraryGUI_BookDetailWindowController v31 = this;
	OCLString v30 = v31.get_windowTitle();
	OCLString v29 = v30;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("seqGUIElements", v3);
	v2.addItem("title", v29);
	GeneralGUI_Window v0 = GeneralGUI_Window.newInstance(this.context, v2);
	
		return v0;
	}

	public GeneralGUI_Window get_window(){
		if (this._window_isInitialized) {
			return _window;
		} else { 
			this.set_window(this.initial_window());
		}
		this._window_isInitialized = true;
		return this._window;
	}
	public Library_Copy initial_selectedBookCopy() {
		if (this.initialPropertyValues.containsKey("selectedBookCopy")) {
			return (Library_Copy)this.initialPropertyValues.objectForKey("selectedBookCopy");
		}
		/* ==================================================
	 * null
	 * ================================================== */
	
	Library_Copy v0 = null;
	
		return v0;
	}

	public Library_Copy get_selectedBookCopy(){
		if (this._selectedBookCopy_isInitialized) {
			return _selectedBookCopy;
		} else { 
			this.set_selectedBookCopy(this.initial_selectedBookCopy());
		}
		this._selectedBookCopy_isInitialized = true;
		return this._selectedBookCopy;
	}
	public Library_Book initial_currBook() {
		if (this.initialPropertyValues.containsKey("currBook")) {
			return (Library_Book)this.initialPropertyValues.objectForKey("currBook");
		}
		/* ==================================================
	 * null
	 * ================================================== */
	
	Library_Book v0 = null;
	
		return v0;
	}

	public Library_Book get_currBook(){
		if (this._currBook_isInitialized) {
			return _currBook;
		} else { 
			this.set_currBook(this.initial_currBook());
		}
		this._currBook_isInitialized = true;
		return this._currBook;
	}
	public GeneralGUI_ConfirmationDialog initial_yesNoMsg() {
		if (this.initialPropertyValues.containsKey("yesNoMsg")) {
			return (GeneralGUI_ConfirmationDialog)this.initialPropertyValues.objectForKey("yesNoMsg");
		}
		/* ==================================================
	 * null
	 * ================================================== */
	
	GeneralGUI_ConfirmationDialog v0 = null;
	
		return v0;
	}

	public GeneralGUI_ConfirmationDialog get_yesNoMsg(){
		if (this._yesNoMsg_isInitialized) {
			return _yesNoMsg;
		} else { 
			this.set_yesNoMsg(this.initial_yesNoMsg());
		}
		this._yesNoMsg_isInitialized = true;
		return this._yesNoMsg;
	}
	public Library_Member initial_currMember() {
		if (this.initialPropertyValues.containsKey("currMember")) {
			return (Library_Member)this.initialPropertyValues.objectForKey("currMember");
		}
		/* ==================================================
	 * null
	 * ================================================== */
	
	Library_Member v0 = null;
	
		return v0;
	}

	public Library_Member get_currMember(){
		if (this._currMember_isInitialized) {
			return _currMember;
		} else { 
			this.set_currMember(this.initial_currMember());
		}
		this._currMember_isInitialized = true;
		return this._currMember;
	}
	public OCLString initial_mode() {
		if (this.initialPropertyValues.containsKey("mode")) {
			return (OCLString)this.initialPropertyValues.objectForKey("mode");
		}
		/* ==================================================
	 * 'NotLoggedIn'
	 * ================================================== */
	
	OCLString v0 = new OCLString("NotLoggedIn");
	
		return v0;
	}

	public OCLString get_mode(){
		if (this._mode_isInitialized) {
			return _mode;
		} else { 
			this.set_mode(this.initial_mode());
		}
		this._mode_isInitialized = true;
		return this._mode;
	}
	public GeneralGUI_MsgDialog initial_msg() {
		if (this.initialPropertyValues.containsKey("msg")) {
			return (GeneralGUI_MsgDialog)this.initialPropertyValues.objectForKey("msg");
		}
		/* ==================================================
	 * null
	 * ================================================== */
	
	GeneralGUI_MsgDialog v0 = null;
	
		return v0;
	}

	public GeneralGUI_MsgDialog get_msg(){
		if (this._msg_isInitialized) {
			return _msg;
		} else { 
			this.set_msg(this.initial_msg());
		}
		this._msg_isInitialized = true;
		return this._msg;
	}
	public OCLString initial_ackStatus() {
		if (this.initialPropertyValues.containsKey("ackStatus")) {
			return (OCLString)this.initialPropertyValues.objectForKey("ackStatus");
		}
		/* ==================================================
	 * 'NotWaiting'
	 * ================================================== */
	
	OCLString v0 = new OCLString("NotWaiting");
	
		return v0;
	}

	public OCLString get_ackStatus(){
		if (this._ackStatus_isInitialized) {
			return _ackStatus;
		} else { 
			this.set_ackStatus(this.initial_ackStatus());
		}
		this._ackStatus_isInitialized = true;
		return this._ackStatus;
	}


	 
	public void set_windowTitle(OCLString value) {
	 	
		this._windowTitle = value;
		this._windowTitle_isInitialized = true;

	}
	public void set_mode(OCLString value) {
	 	
		this._mode = value;
		this._mode_isInitialized = true;

	}
	public void set_ackStatus(OCLString value) {
	 	
		this._ackStatus = value;
		this._ackStatus_isInitialized = true;

	}


	public void set_titleLabel(GeneralGUI_Label value) {
	 	
		if (this._titleLabel!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._titleLabel.MobileLibraryGUI_BookDetailWindowController_titleLabel_back;
			backpointers.removeElement(this);
		}
		this._titleLabel = value;
		if (this._titleLabel!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._titleLabel.MobileLibraryGUI_BookDetailWindowController_titleLabel_back;
			backpointers.addElement(this);
		}
		this._titleLabel_isInitialized = true;

	}
	public void set_bookTitleLabel(GeneralGUI_Label value) {
	 	
		if (this._bookTitleLabel!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._bookTitleLabel.MobileLibraryGUI_BookDetailWindowController_bookTitleLabel_back;
			backpointers.removeElement(this);
		}
		this._bookTitleLabel = value;
		if (this._bookTitleLabel!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._bookTitleLabel.MobileLibraryGUI_BookDetailWindowController_bookTitleLabel_back;
			backpointers.addElement(this);
		}
		this._bookTitleLabel_isInitialized = true;

	}
	public void set_authorLabel(GeneralGUI_Label value) {
	 	
		if (this._authorLabel!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._authorLabel.MobileLibraryGUI_BookDetailWindowController_authorLabel_back;
			backpointers.removeElement(this);
		}
		this._authorLabel = value;
		if (this._authorLabel!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._authorLabel.MobileLibraryGUI_BookDetailWindowController_authorLabel_back;
			backpointers.addElement(this);
		}
		this._authorLabel_isInitialized = true;

	}
	public void set_bookAuthorLabel(GeneralGUI_Label value) {
	 	
		if (this._bookAuthorLabel!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._bookAuthorLabel.MobileLibraryGUI_BookDetailWindowController_bookAuthorLabel_back;
			backpointers.removeElement(this);
		}
		this._bookAuthorLabel = value;
		if (this._bookAuthorLabel!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._bookAuthorLabel.MobileLibraryGUI_BookDetailWindowController_bookAuthorLabel_back;
			backpointers.addElement(this);
		}
		this._bookAuthorLabel_isInitialized = true;

	}
	public void set_isbnLabel(GeneralGUI_Label value) {
	 	
		if (this._isbnLabel!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._isbnLabel.MobileLibraryGUI_BookDetailWindowController_isbnLabel_back;
			backpointers.removeElement(this);
		}
		this._isbnLabel = value;
		if (this._isbnLabel!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._isbnLabel.MobileLibraryGUI_BookDetailWindowController_isbnLabel_back;
			backpointers.addElement(this);
		}
		this._isbnLabel_isInitialized = true;

	}
	public void set_bookIsbnLabel(GeneralGUI_Label value) {
	 	
		if (this._bookIsbnLabel!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._bookIsbnLabel.MobileLibraryGUI_BookDetailWindowController_bookIsbnLabel_back;
			backpointers.removeElement(this);
		}
		this._bookIsbnLabel = value;
		if (this._bookIsbnLabel!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._bookIsbnLabel.MobileLibraryGUI_BookDetailWindowController_bookIsbnLabel_back;
			backpointers.addElement(this);
		}
		this._bookIsbnLabel_isInitialized = true;

	}
	public void set_bookCopies(GeneralGUI_SelectionList value) {
	 	
		if (this._bookCopies!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._bookCopies.MobileLibraryGUI_BookDetailWindowController_bookCopies_back;
			backpointers.removeElement(this);
		}
		this._bookCopies = value;
		if (this._bookCopies!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._bookCopies.MobileLibraryGUI_BookDetailWindowController_bookCopies_back;
			backpointers.addElement(this);
		}
		this._bookCopies_isInitialized = true;

	}
	public void set_bookCopiesLabel(GeneralGUI_Label value) {
	 	
		if (this._bookCopiesLabel!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._bookCopiesLabel.MobileLibraryGUI_BookDetailWindowController_bookCopiesLabel_back;
			backpointers.removeElement(this);
		}
		this._bookCopiesLabel = value;
		if (this._bookCopiesLabel!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._bookCopiesLabel.MobileLibraryGUI_BookDetailWindowController_bookCopiesLabel_back;
			backpointers.addElement(this);
		}
		this._bookCopiesLabel_isInitialized = true;

	}
	public void set_window(GeneralGUI_Window value) {
	 	
		if (this._window!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._window.MobileLibraryGUI_BookDetailWindowController_window_back;
			backpointers.removeElement(this);
		}
		this._window = value;
		if (this._window!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._window.MobileLibraryGUI_BookDetailWindowController_window_back;
			backpointers.addElement(this);
		}
		this._window_isInitialized = true;

	}
	public void set_selectedBookCopy(Library_Copy value) {
	 	
		if (this._selectedBookCopy!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._selectedBookCopy.MobileLibraryGUI_BookDetailWindowController_selectedBookCopy_back;
			backpointers.removeElement(this);
		}
		this._selectedBookCopy = value;
		if (this._selectedBookCopy!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._selectedBookCopy.MobileLibraryGUI_BookDetailWindowController_selectedBookCopy_back;
			backpointers.addElement(this);
		}
		this._selectedBookCopy_isInitialized = true;

	}
	public void set_currBook(Library_Book value) {
	 	
		if (this._currBook!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._currBook.MobileLibraryGUI_BookDetailWindowController_currBook_back;
			backpointers.removeElement(this);
		}
		this._currBook = value;
		if (this._currBook!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._currBook.MobileLibraryGUI_BookDetailWindowController_currBook_back;
			backpointers.addElement(this);
		}
		this._currBook_isInitialized = true;

	}
	public void set_yesNoMsg(GeneralGUI_ConfirmationDialog value) {
	 	
		if (this._yesNoMsg!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._yesNoMsg.MobileLibraryGUI_BookDetailWindowController_yesNoMsg_back;
			backpointers.removeElement(this);
		}
		this._yesNoMsg = value;
		if (this._yesNoMsg!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._yesNoMsg.MobileLibraryGUI_BookDetailWindowController_yesNoMsg_back;
			backpointers.addElement(this);
		}
		this._yesNoMsg_isInitialized = true;

	}
	public void set_currMember(Library_Member value) {
	 	
		if (this._currMember!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._currMember.MobileLibraryGUI_BookDetailWindowController_currMember_back;
			backpointers.removeElement(this);
		}
		this._currMember = value;
		if (this._currMember!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._currMember.MobileLibraryGUI_BookDetailWindowController_currMember_back;
			backpointers.addElement(this);
		}
		this._currMember_isInitialized = true;

	}
	public void set_msg(GeneralGUI_MsgDialog value) {
	 	
		if (this._msg!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._msg.MobileLibraryGUI_BookDetailWindowController_msg_back;
			backpointers.removeElement(this);
		}
		this._msg = value;
		if (this._msg!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._msg.MobileLibraryGUI_BookDetailWindowController_msg_back;
			backpointers.addElement(this);
		}
		this._msg_isInitialized = true;

	}




	 
 	public void event_bookCopyItemSelected_pushed (PropertyChangeList changes  , OCLInteger p_index ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_bookCopyItemSelected_pushed in model MobileLibraryGUI_BookDetailWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {

				this.event_showConfirmReserveMsg_pushed(changes );
			}


			 		 
		// Process impacts relationships
			/* ==================================================
		 * currBook.copies->asSequence()->at(index)
		 * ================================================== */
		
		MobileLibraryGUI_BookDetailWindowController v5 = this;
		Library_Book v4 = v5.get_currBook();
		OCLSet v3 = v4.get_copies();
		OCLSequence v2 = v3.asSequence();
		OCLInteger v6 = p_index;
		Library_Copy v1 = ((Library_Copy)v2.at(v6));
		
			Library_Copy _selectedBookCopy_newValue = v1;
			changes.addChange("_selectedBookCopy", this, _selectedBookCopy_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_bookCopyItemSelected_pulled_edge0(PropertyChangeList changes, GeneralGUI_SelectionList parentInstance ,OCLInteger p_index  ) {
		System.out.println("event_bookCopyItemSelected_pulled in model MobileLibraryGUI_BookDetailWindowController from event _itemSelected in model GeneralGUI_SelectionList");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {
			/* ==================================================
		 * index
		 * ================================================== */
		
		OCLInteger v1 = p_index;
		
			OCLInteger parameter_p_index = v1;

			this.event_bookCopyItemSelected_pushed(changes ,parameter_p_index  );
		}
	}


 	public void event_refreshBookCopiesData_pushed (PropertyChangeList changes  , OCLSequence p_copiesData ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_refreshBookCopiesData_pushed in model MobileLibraryGUI_BookDetailWindowController");
			 		
			// Trigger Push edges


			if (this._bookCopies != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._bookCopies);
				for (Object o : edge0_values) {
					GeneralGUI_SelectionList edge0_target = (GeneralGUI_SelectionList)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * copiesData
				 * ================================================== */
				
				OCLSequence v1 = p_copiesData;
				
						OCLSequence parameter_p_items = v1;

						edge0_target.event_refreshItems_pushed(changes ,parameter_p_items );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_showConfirmReserveMsg_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_showConfirmReserveMsg_pushed in model MobileLibraryGUI_BookDetailWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * GeneralGUI::ConfirmationDialog::create(
		 * 	Tuple { title = 'Confirm', 
		 * 		message = 'Would you like to reserve the selected book copy?' })
		 * ================================================== */
		
		OCLString v4 = new OCLString("Confirm");
		OCLString v3 = v4;
		OCLString v6 = new OCLString("Would you like to reserve the selected book copy?");
		OCLString v5 = v6;
		OCLTuple v2 = new OCLTuple();
		v2.addItem("title", v3);
		v2.addItem("message", v5);
		GeneralGUI_ConfirmationDialog v0 = GeneralGUI_ConfirmationDialog.newInstance(this.context, v2);
		
			GeneralGUI_ConfirmationDialog _yesNoMsg_newValue = v0;
			changes.addChange("_yesNoMsg", this, _yesNoMsg_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_reserveConfAck_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_reserveConfAck_pushed in model MobileLibraryGUI_BookDetailWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {

				this.event_reserveBookCopyOk_pushed(changes );
			}
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v1 = new OCLBoolean(true);
		
			if (v1.value == true) {

				this.event_reserveBookCopyNotOk_pushed(changes );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_reserveConfAck_pulled_edge0(PropertyChangeList changes, GeneralGUI_ConfirmationDialog parentInstance  ) {
		System.out.println("event_reserveConfAck_pulled in model MobileLibraryGUI_BookDetailWindowController from event _okClicked in model GeneralGUI_ConfirmationDialog");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {

			this.event_reserveConfAck_pushed(changes  );
		}
	}


 	public void event_memberSessionStarted_pushed (PropertyChangeList changes  , Library_Member p_m ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_memberSessionStarted_pushed in model MobileLibraryGUI_BookDetailWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * m
		 * ================================================== */
		
		Library_Member v0 = p_m;
		
			Library_Member _currMember_newValue = v0;
			changes.addChange("_currMember", this, _currMember_newValue);
			/* ==================================================
		 * 'LoggedIn'
		 * ================================================== */
		
		OCLString v1 = new OCLString("LoggedIn");
		
			OCLString _mode_newValue = v1;
			changes.addChange("_mode", this, _mode_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_reserveBookCopyOk_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * mode = 'LoggedIn'
             * ================================================== */
            
            MobileLibraryGUI_BookDetailWindowController v2 = this;
            OCLString v1 = v2.get_mode();
            OCLString v3 = new OCLString("LoggedIn");
            OCLBoolean v0;
            if (v1 == null || v3 == null) {
            		v0 = new OCLBoolean(v1 == v3);
            } else {
            		v0 = v1.eq(v3);
            }
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_reserveBookCopyOk_pushed in model MobileLibraryGUI_BookDetailWindowController");
			 		
			// Trigger Push edges


			if (this._selectedBookCopy != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._selectedBookCopy);
				for (Object o : edge0_values) {
					Library_Copy edge0_target = (Library_Copy)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {

						edge0_target.event_reserve_pushed(changes );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_reserveBookCopyNotOk_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * mode = 'NotLoggedIn'
             * ================================================== */
            
            MobileLibraryGUI_BookDetailWindowController v2 = this;
            OCLString v1 = v2.get_mode();
            OCLString v3 = new OCLString("NotLoggedIn");
            OCLBoolean v0;
            if (v1 == null || v3 == null) {
            		v0 = new OCLBoolean(v1 == v3);
            } else {
            		v0 = v1.eq(v3);
            }
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_reserveBookCopyNotOk_pushed in model MobileLibraryGUI_BookDetailWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {

				this.event_showCannotReserveCopyMsg_pushed(changes );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_showCannotReserveCopyMsg_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_showCannotReserveCopyMsg_pushed in model MobileLibraryGUI_BookDetailWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {

				this.event_setToNotWaiting_pushed(changes );
			}


			 		 
		// Process impacts relationships
			/* ==================================================
		 * GeneralGUI::MsgDialog::create(
		 * 	Tuple { 
		 * 	    msg = 'Not possible to reserve the selected copy. No user is logged-in!', 
		 * 		viewTitle = 'Error!' })
		 * ================================================== */
		
		OCLString v5 = new OCLString("Not possible to reserve the selected copy. No user is logged-in!");
		OCLString v4 = v5;
		OCLString v7 = new OCLString("Error!");
		OCLString v6 = v7;
		OCLTuple v3 = new OCLTuple();
		v3.addItem("msg", v4);
		v3.addItem("viewTitle", v6);
		GeneralGUI_MsgDialog v1 = GeneralGUI_MsgDialog.newInstance(this.context, v3);
		
			GeneralGUI_MsgDialog _msg_newValue = v1;
			changes.addChange("_msg", this, _msg_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_copyReserved_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_copyReserved_pushed in model MobileLibraryGUI_BookDetailWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {

				this.event_showReserveOkMsg_pushed(changes );
			}
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v1 = new OCLBoolean(true);
		
			if (v1.value == true) {

				this.event_addReservedToMember_pushed(changes );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_copyReserved_pulled_edge0(PropertyChangeList changes, Library_Copy parentInstance  ) {
		System.out.println("event_copyReserved_pulled in model MobileLibraryGUI_BookDetailWindowController from event _reserveOk in model Library_Copy");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {

			this.event_copyReserved_pushed(changes  );
		}
	}


 	public void event_showReserveOkMsg_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_showReserveOkMsg_pushed in model MobileLibraryGUI_BookDetailWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * GeneralGUI::MsgDialog::create(
		 * 	Tuple { 
		 * 	    msg = 'A copy of book \''.concat(currBook.title).concat('\' has been reserved and is now awaiting collection at your library.'), 
		 * 		viewTitle = 'Success!' })
		 * ================================================== */
		
		OCLString v6 = new OCLString("A copy of book '");
		MobileLibraryGUI_BookDetailWindowController v9 = this;
		Library_Book v8 = v9.get_currBook();
		OCLString v7 = v8.get_title();
		OCLString v5 = v6.concat(v7);
		OCLString v10 = new OCLString("' has been reserved and is now awaiting collection at your library.");
		OCLString v4 = v5.concat(v10);
		OCLString v3 = v4;
		OCLString v12 = new OCLString("Success!");
		OCLString v11 = v12;
		OCLTuple v2 = new OCLTuple();
		v2.addItem("msg", v3);
		v2.addItem("viewTitle", v11);
		GeneralGUI_MsgDialog v0 = GeneralGUI_MsgDialog.newInstance(this.context, v2);
		
			GeneralGUI_MsgDialog _msg_newValue = v0;
			changes.addChange("_msg", this, _msg_newValue);
			/* ==================================================
		 * 'WaitingReserveAck'
		 * ================================================== */
		
		OCLString v13 = new OCLString("WaitingReserveAck");
		
			OCLString _ackStatus_newValue = v13;
			changes.addChange("_ackStatus", this, _ackStatus_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_reserveAck_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * ackStatus='WaitingReserveAck'
             * ================================================== */
            
            MobileLibraryGUI_BookDetailWindowController v2 = this;
            OCLString v1 = v2.get_ackStatus();
            OCLString v3 = new OCLString("WaitingReserveAck");
            OCLBoolean v0;
            if (v1 == null || v3 == null) {
            		v0 = new OCLBoolean(v1 == v3);
            } else {
            		v0 = v1.eq(v3);
            }
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_reserveAck_pushed in model MobileLibraryGUI_BookDetailWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {

				this.event_refreshAndSave_pushed(changes );
			}
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v1 = new OCLBoolean(true);
		
			if (v1.value == true) {

				this.event_setToNotWaiting_pushed(changes );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_reserveAck_pulled_edge0(PropertyChangeList changes, GeneralGUI_MsgDialog parentInstance  ) {
		System.out.println("event_reserveAck_pulled in model MobileLibraryGUI_BookDetailWindowController from event _okClicked in model GeneralGUI_MsgDialog");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {

			this.event_reserveAck_pushed(changes  );
		}
	}


 	public void event_addReservedToMember_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_addReservedToMember_pushed in model MobileLibraryGUI_BookDetailWindowController");
			 		
			// Trigger Push edges


			if (this._currMember != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._currMember);
				for (Object o : edge0_values) {
					Library_Member edge0_target = (Library_Member)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * selectedBookCopy
				 * ================================================== */
				
				Library_Copy v1 = this.get_selectedBookCopy();
				
						Library_Copy parameter_p_copy = v1;

						edge0_target.event_addCopyToCollect_pushed(changes ,parameter_p_copy );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_reserveFailed_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_reserveFailed_pushed in model MobileLibraryGUI_BookDetailWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {

				this.event_showReserveFailedMsg_pushed(changes );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_reserveFailed_pulled_edge0(PropertyChangeList changes, Library_Copy parentInstance  ) {
		System.out.println("event_reserveFailed_pulled in model MobileLibraryGUI_BookDetailWindowController from event _reserveFailed in model Library_Copy");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {

			this.event_reserveFailed_pushed(changes  );
		}
	}


 	public void event_showReserveFailedMsg_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_showReserveFailedMsg_pushed in model MobileLibraryGUI_BookDetailWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {

				this.event_setToNotWaiting_pushed(changes );
			}


			 		 
		// Process impacts relationships
			/* ==================================================
		 * GeneralGUI::MsgDialog::create(
		 * 	Tuple { 
		 * 	    msg = 'The selected copy of book \''.concat(currBook.title).concat('\' could not be reserved because it is not available for borrowing.'), 
		 * 		viewTitle = 'Copy Reservation Failed!' })
		 * ================================================== */
		
		OCLString v7 = new OCLString("The selected copy of book '");
		MobileLibraryGUI_BookDetailWindowController v10 = this;
		Library_Book v9 = v10.get_currBook();
		OCLString v8 = v9.get_title();
		OCLString v6 = v7.concat(v8);
		OCLString v11 = new OCLString("' could not be reserved because it is not available for borrowing.");
		OCLString v5 = v6.concat(v11);
		OCLString v4 = v5;
		OCLString v13 = new OCLString("Copy Reservation Failed!");
		OCLString v12 = v13;
		OCLTuple v3 = new OCLTuple();
		v3.addItem("msg", v4);
		v3.addItem("viewTitle", v12);
		GeneralGUI_MsgDialog v1 = GeneralGUI_MsgDialog.newInstance(this.context, v3);
		
			GeneralGUI_MsgDialog _msg_newValue = v1;
			changes.addChange("_msg", this, _msg_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_setToNotWaiting_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_setToNotWaiting_pushed in model MobileLibraryGUI_BookDetailWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * 'NotWaiting'
		 * ================================================== */
		
		OCLString v0 = new OCLString("NotWaiting");
		
			OCLString _ackStatus_newValue = v0;
			changes.addChange("_ackStatus", this, _ackStatus_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_refreshAndSave_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_refreshAndSave_pushed in model MobileLibraryGUI_BookDetailWindowController");
			 		
			// Trigger Push edges


			if (this._bookCopies != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._bookCopies);
				for (Object o : edge0_values) {
					GeneralGUI_SelectionList edge0_target = (GeneralGUI_SelectionList)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * getBookCopiesData
				 * ================================================== */
				
				OCLSequence v1 = this.get_getBookCopiesData();
				
						OCLSequence parameter_p_items = v1;

						edge0_target.event_refreshItems_pushed(changes ,parameter_p_items );
					}
				}

			}


			 		
			// Trigger Pull edges
			for (OCLAny o : this.MobileLibraryGUI_BookListWindowController_detailsWindow_back) {
				((MobileLibraryGUI_BookListWindowController)o).event_refreshAndSave_pulled_edge0(changes, this );
			}


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 




	 
	public OCLSequence get_getBookCopiesData() {
		/* ==================================================
	 * currBook.copies->collect(
	 * 	copyId.concat(' ').concat(state).concat(' ').concat(dueDate)
	 * )->asSequence()
	 * ================================================== */
	
	MobileLibraryGUI_BookDetailWindowController v4 = this;
	Library_Book v3 = v4.get_currBook();
	OCLSet v2 = v3.get_copies();
	OCLBag v1_nested = new OCLBag();
	Iterator<OCLAny> v1_iter = v2.iterator();
	while (v1_iter.hasNext()) {
			Library_Copy v5 = (Library_Copy)v1_iter.next();
			Library_Copy v11 = v5;
			OCLString v10 = v11.get_copyId();
			OCLString v12 = new OCLString(" ");
			OCLString v9 = v10.concat(v12);
			Library_Copy v14 = v5;
			OCLString v13 = v14.get_state();
			OCLString v8 = v9.concat(v13);
			OCLString v15 = new OCLString(" ");
			OCLString v7 = v8.concat(v15);
			Library_Copy v17 = v5;
			OCLString v16 = v17.get_dueDate();
			OCLString v6 = v7.concat(v16);
			v1_nested.add(v6);
	}
	OCLBag v1 = v1_nested.flatten();
	OCLSequence v0 = v1.asSequence();
	;
		return v0;
	}


	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

