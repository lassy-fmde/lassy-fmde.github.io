 
	  
package democles.generated;

import java.util.Vector;
import java.util.ArrayList;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
public class Library_Book implements OCLAny {
	 
	private OCLSet _authors;
	private boolean _authors_isInitialized;
	private OCLString _title;
	private boolean _title_isInitialized;
	private OCLString _isbn;
	private boolean _isbn_isInitialized;
	private OCLSet _copies;
	private boolean _copies_isInitialized;
	private OCLString _bookId;
	private boolean _bookId_isInitialized;

	public Vector<OCLAny> Library_Copy_book_back = new Vector<OCLAny>();
	public Vector<OCLAny> MobileLibraryGUI_BookDetailWindowController_currBook_back = new Vector<OCLAny>();
	public Vector<OCLAny> Library_Library_catalogue_back = new Vector<OCLAny>();
	public Vector<OCLAny> MobileLibraryGUI_SearchWindowController_booksFound_back = new Vector<OCLAny>();
	public Vector<OCLAny> LibraryPersistence_LibraryLoader_books_back = new Vector<OCLAny>();

	private Object context;
	private OCLTuple initialPropertyValues = new OCLTuple();
	

	 
	private Library_Book(Object context) {
		super();
		this.context = context;
		 
		if (!this._authors_isInitialized) this.set_authors(this.initial_authors()); 
		if (!this._title_isInitialized) this.set_title(this.initial_title()); 
		if (!this._isbn_isInitialized) this.set_isbn(this.initial_isbn()); 
		if (!this._copies_isInitialized) this.set_copies(this.initial_copies()); 
		if (!this._bookId_isInitialized) this.set_bookId(this.initial_bookId()); 


	}
	
	static public Library_Book newInstance(Object context) {
		if (context == null) throw new NullPointerException();
		return new Library_Book(context);
	}
 
	 
	private Library_Book(Object context, OCLTuple values) {
		super();
		this.context = context;
		if (values != null) this.initialPropertyValues = values;

		 
		this._authors_isInitialized = false; 
		this._title_isInitialized = false; 
		this._isbn_isInitialized = false; 
		this._copies_isInitialized = false; 
		this._bookId_isInitialized = false; 

		if (values == null) values = new OCLTuple(); // Empty
        this.initialPropertyValues = values;
		
		if (values.containsKey("authors")) {
			this.set_authors((OCLSet)values.objectForKey("authors"));
		} else {
			if (!this._authors_isInitialized) this.set_authors(this.initial_authors());
		}
		if (values.containsKey("title")) {
			this.set_title((OCLString)values.objectForKey("title"));
		} else {
			if (!this._title_isInitialized) this.set_title(this.initial_title());
		}
		if (values.containsKey("isbn")) {
			this.set_isbn((OCLString)values.objectForKey("isbn"));
		} else {
			if (!this._isbn_isInitialized) this.set_isbn(this.initial_isbn());
		}
		if (values.containsKey("copies")) {
			this.set_copies((OCLSet)values.objectForKey("copies"));
		} else {
			if (!this._copies_isInitialized) this.set_copies(this.initial_copies());
		}
		if (values.containsKey("bookId")) {
			this.set_bookId((OCLString)values.objectForKey("bookId"));
		} else {
			if (!this._bookId_isInitialized) this.set_bookId(this.initial_bookId());
		}


	}

	static public Library_Book newInstance(Object context, OCLTuple values) {
		if (context == null) throw new NullPointerException();
		return new Library_Book(context, values);
	}

	 
	public OCLSet initial_authors() {
		if (this.initialPropertyValues.containsKey("authors")) {
			return (OCLSet)this.initialPropertyValues.objectForKey("authors");
		}
		/* ==================================================
	 * Set {}
	 * ================================================== */
	
	OCLSet v0 = new OCLSet();
	
		return v0;
	}

	public OCLSet get_authors(){
		if (this._authors_isInitialized) {
			return _authors;
		} else { 
			this.set_authors(this.initial_authors());
		}
		this._authors_isInitialized = true;
		return this._authors;
	}
	public OCLString initial_title() {
		if (this.initialPropertyValues.containsKey("title")) {
			return (OCLString)this.initialPropertyValues.objectForKey("title");
		}
		/* ==================================================
	 * null
	 * ================================================== */
	
	OCLString v0 = null;
	
		return v0;
	}

	public OCLString get_title(){
		if (this._title_isInitialized) {
			return _title;
		} else { 
			this.set_title(this.initial_title());
		}
		this._title_isInitialized = true;
		return this._title;
	}
	public OCLString initial_isbn() {
		if (this.initialPropertyValues.containsKey("isbn")) {
			return (OCLString)this.initialPropertyValues.objectForKey("isbn");
		}
		/* ==================================================
	 * null
	 * ================================================== */
	
	OCLString v0 = null;
	
		return v0;
	}

	public OCLString get_isbn(){
		if (this._isbn_isInitialized) {
			return _isbn;
		} else { 
			this.set_isbn(this.initial_isbn());
		}
		this._isbn_isInitialized = true;
		return this._isbn;
	}
	public OCLSet initial_copies() {
		if (this.initialPropertyValues.containsKey("copies")) {
			return (OCLSet)this.initialPropertyValues.objectForKey("copies");
		}
		/* ==================================================
	 * Set {}
	 * ================================================== */
	
	OCLSet v0 = new OCLSet();
	
		return v0;
	}

	public OCLSet get_copies(){
		if (this._copies_isInitialized) {
			return _copies;
		} else { 
			this.set_copies(this.initial_copies());
		}
		this._copies_isInitialized = true;
		return this._copies;
	}
	public OCLString initial_bookId() {
		if (this.initialPropertyValues.containsKey("bookId")) {
			return (OCLString)this.initialPropertyValues.objectForKey("bookId");
		}
		/* ==================================================
	 * null
	 * ================================================== */
	
	OCLString v0 = null;
	
		return v0;
	}

	public OCLString get_bookId(){
		if (this._bookId_isInitialized) {
			return _bookId;
		} else { 
			this.set_bookId(this.initial_bookId());
		}
		this._bookId_isInitialized = true;
		return this._bookId;
	}


	 
	public void set_title(OCLString value) {
	 	
		this._title = value;
		this._title_isInitialized = true;

	}
	public void set_isbn(OCLString value) {
	 	
		this._isbn = value;
		this._isbn_isInitialized = true;

	}
	public void set_bookId(OCLString value) {
	 	
		this._bookId = value;
		this._bookId_isInitialized = true;

	}




 	public void set_authors(OCLSet value) {
	 	
		if (this._authors!= null) {
			// Clear back pointer on old instance
			for (OCLAny object : this._authors) {
				Library_Author o = (Library_Author)object;
				Vector<OCLAny> backpointers = o.Library_Book_authors_back;
				backpointers.removeElement(this);
			}
		}
		this._authors = value;
		if (this._authors!= null) {
			// Add back pointer on new instance
			for (OCLAny object : this._authors) {
				Library_Author o = (Library_Author)object;
				Vector<OCLAny> backpointers = o.Library_Book_authors_back;
				backpointers.addElement(this);
			}
		}
		this._authors_isInitialized = true;

	}
 	public void set_copies(OCLSet value) {
	 	
		if (this._copies!= null) {
			// Clear back pointer on old instance
			for (OCLAny object : this._copies) {
				Library_Copy o = (Library_Copy)object;
				Vector<OCLAny> backpointers = o.Library_Book_copies_back;
				backpointers.removeElement(this);
			}
		}
		this._copies = value;
		if (this._copies!= null) {
			// Add back pointer on new instance
			for (OCLAny object : this._copies) {
				Library_Copy o = (Library_Copy)object;
				Vector<OCLAny> backpointers = o.Library_Book_copies_back;
				backpointers.addElement(this);
			}
		}
		this._copies_isInitialized = true;

	}


	 
 	public void event_setCopies_pushed (PropertyChangeList changes  , OCLSet p_copies ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_setCopies_pushed in model Library_Book");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * -- Generated impacts relationship code:
		 * copies
		 * ================================================== */
		
		OCLSet v0 = p_copies;
		
			OCLSet _copies_newValue = v0;
			changes.addChange("_copies", this, _copies_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 




	 


	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

