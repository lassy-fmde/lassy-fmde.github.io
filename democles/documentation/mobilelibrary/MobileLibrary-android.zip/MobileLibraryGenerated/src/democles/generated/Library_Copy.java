 
	  
package democles.generated;

import java.util.Vector;
import java.util.ArrayList;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
public class Library_Copy implements OCLAny {
	 
	private Library_Book _book;
	private boolean _book_isInitialized;
	private OCLString _dueDate;
	private boolean _dueDate_isInitialized;
	private OCLInteger _renewals;
	private boolean _renewals_isInitialized;
	private OCLString _state;
	private boolean _state_isInitialized;
	private OCLString _copyId;
	private boolean _copyId_isInitialized;

	public Vector<OCLAny> MobileLibraryGUI_MemberWindowController_selectedBorrowing_back = new Vector<OCLAny>();
	public Vector<OCLAny> LibraryPersistence_LibraryLoader_copies_back = new Vector<OCLAny>();
	public Vector<OCLAny> Library_Member_borrows_back = new Vector<OCLAny>();
	public Vector<OCLAny> Library_Book_copies_back = new Vector<OCLAny>();
	public Vector<OCLAny> Library_Member_toCollect_back = new Vector<OCLAny>();
	public Vector<OCLAny> MobileLibraryGUI_BookDetailWindowController_selectedBookCopy_back = new Vector<OCLAny>();

	private Object context;
	private OCLTuple initialPropertyValues = new OCLTuple();
	

	 
	private Library_Copy(Object context) {
		super();
		this.context = context;
		 
		if (!this._book_isInitialized) this.set_book(this.initial_book()); 
		if (!this._dueDate_isInitialized) this.set_dueDate(this.initial_dueDate()); 
		if (!this._renewals_isInitialized) this.set_renewals(this.initial_renewals()); 
		if (!this._state_isInitialized) this.set_state(this.initial_state()); 
		if (!this._copyId_isInitialized) this.set_copyId(this.initial_copyId()); 


	}
	
	static public Library_Copy newInstance(Object context) {
		if (context == null) throw new NullPointerException();
		return new Library_Copy(context);
	}
 
	 
	private Library_Copy(Object context, OCLTuple values) {
		super();
		this.context = context;
		if (values != null) this.initialPropertyValues = values;

		 
		this._book_isInitialized = false; 
		this._dueDate_isInitialized = false; 
		this._renewals_isInitialized = false; 
		this._state_isInitialized = false; 
		this._copyId_isInitialized = false; 

		if (values == null) values = new OCLTuple(); // Empty
        this.initialPropertyValues = values;
		
		if (values.containsKey("book")) {
			this.set_book((Library_Book)values.objectForKey("book"));
		} else {
			if (!this._book_isInitialized) this.set_book(this.initial_book());
		}
		if (values.containsKey("dueDate")) {
			this.set_dueDate((OCLString)values.objectForKey("dueDate"));
		} else {
			if (!this._dueDate_isInitialized) this.set_dueDate(this.initial_dueDate());
		}
		if (values.containsKey("renewals")) {
			this.set_renewals((OCLInteger)values.objectForKey("renewals"));
		} else {
			if (!this._renewals_isInitialized) this.set_renewals(this.initial_renewals());
		}
		if (values.containsKey("state")) {
			this.set_state((OCLString)values.objectForKey("state"));
		} else {
			if (!this._state_isInitialized) this.set_state(this.initial_state());
		}
		if (values.containsKey("copyId")) {
			this.set_copyId((OCLString)values.objectForKey("copyId"));
		} else {
			if (!this._copyId_isInitialized) this.set_copyId(this.initial_copyId());
		}


	}

	static public Library_Copy newInstance(Object context, OCLTuple values) {
		if (context == null) throw new NullPointerException();
		return new Library_Copy(context, values);
	}

	 
	public Library_Book initial_book() {
		if (this.initialPropertyValues.containsKey("book")) {
			return (Library_Book)this.initialPropertyValues.objectForKey("book");
		}
		/* ==================================================
	 * null
	 * ================================================== */
	
	Library_Book v0 = null;
	
		return v0;
	}

	public Library_Book get_book(){
		if (this._book_isInitialized) {
			return _book;
		} else { 
			this.set_book(this.initial_book());
		}
		this._book_isInitialized = true;
		return this._book;
	}
	public OCLString initial_dueDate() {
		if (this.initialPropertyValues.containsKey("dueDate")) {
			return (OCLString)this.initialPropertyValues.objectForKey("dueDate");
		}
		/* ==================================================
	 * null
	 * ================================================== */
	
	OCLString v0 = null;
	
		return v0;
	}

	public OCLString get_dueDate(){
		if (this._dueDate_isInitialized) {
			return _dueDate;
		} else { 
			this.set_dueDate(this.initial_dueDate());
		}
		this._dueDate_isInitialized = true;
		return this._dueDate;
	}
	public OCLInteger initial_renewals() {
		if (this.initialPropertyValues.containsKey("renewals")) {
			return (OCLInteger)this.initialPropertyValues.objectForKey("renewals");
		}
		/* ==================================================
	 * 0
	 * ================================================== */
	
	OCLInteger v0 = new OCLInteger(0);
	
		return v0;
	}

	public OCLInteger get_renewals(){
		if (this._renewals_isInitialized) {
			return _renewals;
		} else { 
			this.set_renewals(this.initial_renewals());
		}
		this._renewals_isInitialized = true;
		return this._renewals;
	}
	public OCLString initial_state() {
		if (this.initialPropertyValues.containsKey("state")) {
			return (OCLString)this.initialPropertyValues.objectForKey("state");
		}
		/* ==================================================
	 * 'Borrowable'
	 * ================================================== */
	
	OCLString v0 = new OCLString("Borrowable");
	
		return v0;
	}

	public OCLString get_state(){
		if (this._state_isInitialized) {
			return _state;
		} else { 
			this.set_state(this.initial_state());
		}
		this._state_isInitialized = true;
		return this._state;
	}
	public OCLString initial_copyId() {
		if (this.initialPropertyValues.containsKey("copyId")) {
			return (OCLString)this.initialPropertyValues.objectForKey("copyId");
		}
		/* ==================================================
	 * null
	 * ================================================== */
	
	OCLString v0 = null;
	
		return v0;
	}

	public OCLString get_copyId(){
		if (this._copyId_isInitialized) {
			return _copyId;
		} else { 
			this.set_copyId(this.initial_copyId());
		}
		this._copyId_isInitialized = true;
		return this._copyId;
	}


	 
	public void set_dueDate(OCLString value) {
	 	
		this._dueDate = value;
		this._dueDate_isInitialized = true;

	}
	public void set_renewals(OCLInteger value) {
	 	
		this._renewals = value;
		this._renewals_isInitialized = true;

	}
	public void set_state(OCLString value) {
	 	
		this._state = value;
		this._state_isInitialized = true;

	}
	public void set_copyId(OCLString value) {
	 	
		this._copyId = value;
		this._copyId_isInitialized = true;

	}


	public void set_book(Library_Book value) {
	 	
		if (this._book!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._book.Library_Copy_book_back;
			backpointers.removeElement(this);
		}
		this._book = value;
		if (this._book!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._book.Library_Copy_book_back;
			backpointers.addElement(this);
		}
		this._book_isInitialized = true;

	}




	 
 	public void event_renewOk_pushed (PropertyChangeList changes  , OCLString p_newDueDate ){
		{ // New scope for following guard expression:
			/* ==================================================
             * renewals < maxRenewals
             * ================================================== */
            
            Library_Copy v2 = this;
            OCLInteger v1 = v2.get_renewals();
            Library_Copy v4 = this;
            OCLInteger v3 = v4.get_maxRenewals();
            OCLBoolean v0 = v1.lt(v3);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_renewOk_pushed in model Library_Copy");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges
			for (OCLAny o : this.MobileLibraryGUI_MemberWindowController_selectedBorrowing_back) {
				((MobileLibraryGUI_MemberWindowController)o).event_copyRenewed_pulled_edge0(changes, this , p_newDueDate);
			}


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * renewals+1
		 * ================================================== */
		
		Library_Copy v2 = this;
		OCLInteger v1 = v2.get_renewals();
		OCLInteger v3 = new OCLInteger(1);
		OCLInteger v0 = v1.plus(v3);
		
			OCLInteger _renewals_newValue = v0;
			changes.addChange("_renewals", this, _renewals_newValue);
			/* ==================================================
		 * newDueDate
		 * ================================================== */
		
		OCLString v4 = p_newDueDate;
		
			OCLString _dueDate_newValue = v4;
			changes.addChange("_dueDate", this, _dueDate_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_renewFailed_pushed (PropertyChangeList changes  , Library_Copy p_copy ){
		{ // New scope for following guard expression:
			/* ==================================================
             * renewals >= maxRenewals
             * ================================================== */
            
            Library_Copy v2 = this;
            OCLInteger v1 = v2.get_renewals();
            Library_Copy v4 = this;
            OCLInteger v3 = v4.get_maxRenewals();
            OCLBoolean v0 = v1.gte(v3);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_renewFailed_pushed in model Library_Copy");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges
			for (OCLAny o : this.MobileLibraryGUI_MemberWindowController_selectedBorrowing_back) {
				((MobileLibraryGUI_MemberWindowController)o).event_renewFailed_pulled_edge0(changes, this , p_copy);
			}


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_renew_pushed (PropertyChangeList changes  , OCLString p_newDueDate ){
		{ // New scope for following guard expression:
			/* ==================================================
             * state = 'Onloan'
             * ================================================== */
            
            Library_Copy v2 = this;
            OCLString v1 = v2.get_state();
            OCLString v3 = new OCLString("Onloan");
            OCLBoolean v0;
            if (v1 == null || v3 == null) {
            		v0 = new OCLBoolean(v1 == v3);
            } else {
            		v0 = v1.eq(v3);
            }
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_renew_pushed in model Library_Copy");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {
				/* ==================================================
			 * newDueDate
			 * ================================================== */
			
			OCLString v1 = p_newDueDate;
			
				OCLString parameter_p_newDueDate = v1;

				this.event_renewOk_pushed(changes , parameter_p_newDueDate );
			}
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v2 = new OCLBoolean(true);
		
			if (v2.value == true) {
				/* ==================================================
			 * self
			 * ================================================== */
			
			Library_Copy v3 = this;
			
				Library_Copy parameter_p_copy = v3;

				this.event_renewFailed_pushed(changes , parameter_p_copy );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_reserve_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_reserve_pushed in model Library_Copy");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {

				this.event_reserveOk_pushed(changes );
			}
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v1 = new OCLBoolean(true);
		
			if (v1.value == true) {

				this.event_reserveFailed_pushed(changes );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_reserveOk_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * state = 'Borrowable'
             * ================================================== */
            
            Library_Copy v2 = this;
            OCLString v1 = v2.get_state();
            OCLString v3 = new OCLString("Borrowable");
            OCLBoolean v0;
            if (v1 == null || v3 == null) {
            		v0 = new OCLBoolean(v1 == v3);
            } else {
            		v0 = v1.eq(v3);
            }
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_reserveOk_pushed in model Library_Copy");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges
			for (OCLAny o : this.MobileLibraryGUI_BookDetailWindowController_selectedBookCopy_back) {
				((MobileLibraryGUI_BookDetailWindowController)o).event_copyReserved_pulled_edge0(changes, this );
			}


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * 'ToCollect'
		 * ================================================== */
		
		OCLString v0 = new OCLString("ToCollect");
		
			OCLString _state_newValue = v0;
			changes.addChange("_state", this, _state_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_reserveFailed_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * state <> 'Borrowable'
             * ================================================== */
            
            Library_Copy v2 = this;
            OCLString v1 = v2.get_state();
            OCLString v3 = new OCLString("Borrowable");
            OCLBoolean v0;
            if (v1 == null || v3 == null) {
            		v0 = new OCLBoolean(v1 != v3);
            } else {
            		v0 = v1.neq(v3);
            }
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_reserveFailed_pushed in model Library_Copy");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges
			for (OCLAny o : this.MobileLibraryGUI_BookDetailWindowController_selectedBookCopy_back) {
				((MobileLibraryGUI_BookDetailWindowController)o).event_reserveFailed_pulled_edge0(changes, this );
			}


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 




	 
	public OCLInteger get_maxRenewals() {
		/* ==================================================
	 * 3
	 * ================================================== */
	
	OCLInteger v0 = new OCLInteger(3);
	;
		return v0;
	}


	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

