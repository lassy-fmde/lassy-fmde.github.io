 
	  
package democles.generated;

import java.util.Vector;
import java.util.ArrayList;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
public class MobileLibraryGUI_MemberWindowController implements OCLAny {
	 
	private OCLString _title;
	private boolean _title_isInitialized;
	private GeneralGUI_Label _memberNameLabel;
	private boolean _memberNameLabel_isInitialized;
	private GeneralGUI_Label _memberLabel;
	private boolean _memberLabel_isInitialized;
	private GeneralGUI_SelectionList _borrowItems;
	private boolean _borrowItems_isInitialized;
	private GeneralGUI_SelectionList _collectItems;
	private boolean _collectItems_isInitialized;
	private GeneralGUI_Label _borrowedItemsLabel;
	private boolean _borrowedItemsLabel_isInitialized;
	private GeneralGUI_Label _itemsToCollectLabel;
	private boolean _itemsToCollectLabel_isInitialized;
	private GeneralGUI_Frame _window;
	private boolean _window_isInitialized;
	private Library_Copy _selectedBorrowing;
	private boolean _selectedBorrowing_isInitialized;
	private Library_Member _currMember;
	private boolean _currMember_isInitialized;
	private GeneralGUI_ConfirmationDialog _yesNoMsg;
	private boolean _yesNoMsg_isInitialized;
	private DateProcessing_DateHandler _dateHandler;
	private boolean _dateHandler_isInitialized;
	private GeneralGUI_MsgDialog _currMsg;
	private boolean _currMsg_isInitialized;
	private OCLString _ackStatus;
	private boolean _ackStatus_isInitialized;

	public Vector<OCLAny> Application_Main_memberControl_back = new Vector<OCLAny>();

	private Object context;
	private OCLTuple initialPropertyValues = new OCLTuple();
	

	 
	private MobileLibraryGUI_MemberWindowController(Object context) {
		super();
		this.context = context;
		 
		if (!this._title_isInitialized) this.set_title(this.initial_title()); 
		if (!this._memberNameLabel_isInitialized) this.set_memberNameLabel(this.initial_memberNameLabel()); 
		if (!this._memberLabel_isInitialized) this.set_memberLabel(this.initial_memberLabel()); 
		if (!this._borrowItems_isInitialized) this.set_borrowItems(this.initial_borrowItems()); 
		if (!this._collectItems_isInitialized) this.set_collectItems(this.initial_collectItems()); 
		if (!this._borrowedItemsLabel_isInitialized) this.set_borrowedItemsLabel(this.initial_borrowedItemsLabel()); 
		if (!this._itemsToCollectLabel_isInitialized) this.set_itemsToCollectLabel(this.initial_itemsToCollectLabel()); 
		if (!this._window_isInitialized) this.set_window(this.initial_window()); 
		if (!this._selectedBorrowing_isInitialized) this.set_selectedBorrowing(this.initial_selectedBorrowing()); 
		if (!this._currMember_isInitialized) this.set_currMember(this.initial_currMember()); 
		if (!this._yesNoMsg_isInitialized) this.set_yesNoMsg(this.initial_yesNoMsg()); 
		if (!this._dateHandler_isInitialized) this.set_dateHandler(this.initial_dateHandler()); 
		if (!this._currMsg_isInitialized) this.set_currMsg(this.initial_currMsg()); 
		if (!this._ackStatus_isInitialized) this.set_ackStatus(this.initial_ackStatus()); 


	}
	
	static public MobileLibraryGUI_MemberWindowController newInstance(Object context) {
		if (context == null) throw new NullPointerException();
		return new MobileLibraryGUI_MemberWindowController(context);
	}
 
	 
	private MobileLibraryGUI_MemberWindowController(Object context, OCLTuple values) {
		super();
		this.context = context;
		if (values != null) this.initialPropertyValues = values;

		 
		this._title_isInitialized = false; 
		this._memberNameLabel_isInitialized = false; 
		this._memberLabel_isInitialized = false; 
		this._borrowItems_isInitialized = false; 
		this._collectItems_isInitialized = false; 
		this._borrowedItemsLabel_isInitialized = false; 
		this._itemsToCollectLabel_isInitialized = false; 
		this._window_isInitialized = false; 
		this._selectedBorrowing_isInitialized = false; 
		this._currMember_isInitialized = false; 
		this._yesNoMsg_isInitialized = false; 
		this._dateHandler_isInitialized = false; 
		this._currMsg_isInitialized = false; 
		this._ackStatus_isInitialized = false; 

		if (values == null) values = new OCLTuple(); // Empty
        this.initialPropertyValues = values;
		
		if (values.containsKey("title")) {
			this.set_title((OCLString)values.objectForKey("title"));
		} else {
			if (!this._title_isInitialized) this.set_title(this.initial_title());
		}
		if (values.containsKey("memberNameLabel")) {
			this.set_memberNameLabel((GeneralGUI_Label)values.objectForKey("memberNameLabel"));
		} else {
			if (!this._memberNameLabel_isInitialized) this.set_memberNameLabel(this.initial_memberNameLabel());
		}
		if (values.containsKey("memberLabel")) {
			this.set_memberLabel((GeneralGUI_Label)values.objectForKey("memberLabel"));
		} else {
			if (!this._memberLabel_isInitialized) this.set_memberLabel(this.initial_memberLabel());
		}
		if (values.containsKey("borrowItems")) {
			this.set_borrowItems((GeneralGUI_SelectionList)values.objectForKey("borrowItems"));
		} else {
			if (!this._borrowItems_isInitialized) this.set_borrowItems(this.initial_borrowItems());
		}
		if (values.containsKey("collectItems")) {
			this.set_collectItems((GeneralGUI_SelectionList)values.objectForKey("collectItems"));
		} else {
			if (!this._collectItems_isInitialized) this.set_collectItems(this.initial_collectItems());
		}
		if (values.containsKey("borrowedItemsLabel")) {
			this.set_borrowedItemsLabel((GeneralGUI_Label)values.objectForKey("borrowedItemsLabel"));
		} else {
			if (!this._borrowedItemsLabel_isInitialized) this.set_borrowedItemsLabel(this.initial_borrowedItemsLabel());
		}
		if (values.containsKey("itemsToCollectLabel")) {
			this.set_itemsToCollectLabel((GeneralGUI_Label)values.objectForKey("itemsToCollectLabel"));
		} else {
			if (!this._itemsToCollectLabel_isInitialized) this.set_itemsToCollectLabel(this.initial_itemsToCollectLabel());
		}
		if (values.containsKey("window")) {
			this.set_window((GeneralGUI_Frame)values.objectForKey("window"));
		} else {
			if (!this._window_isInitialized) this.set_window(this.initial_window());
		}
		if (values.containsKey("selectedBorrowing")) {
			this.set_selectedBorrowing((Library_Copy)values.objectForKey("selectedBorrowing"));
		} else {
			if (!this._selectedBorrowing_isInitialized) this.set_selectedBorrowing(this.initial_selectedBorrowing());
		}
		if (values.containsKey("currMember")) {
			this.set_currMember((Library_Member)values.objectForKey("currMember"));
		} else {
			if (!this._currMember_isInitialized) this.set_currMember(this.initial_currMember());
		}
		if (values.containsKey("yesNoMsg")) {
			this.set_yesNoMsg((GeneralGUI_ConfirmationDialog)values.objectForKey("yesNoMsg"));
		} else {
			if (!this._yesNoMsg_isInitialized) this.set_yesNoMsg(this.initial_yesNoMsg());
		}
		if (values.containsKey("dateHandler")) {
			this.set_dateHandler((DateProcessing_DateHandler)values.objectForKey("dateHandler"));
		} else {
			if (!this._dateHandler_isInitialized) this.set_dateHandler(this.initial_dateHandler());
		}
		if (values.containsKey("currMsg")) {
			this.set_currMsg((GeneralGUI_MsgDialog)values.objectForKey("currMsg"));
		} else {
			if (!this._currMsg_isInitialized) this.set_currMsg(this.initial_currMsg());
		}
		if (values.containsKey("ackStatus")) {
			this.set_ackStatus((OCLString)values.objectForKey("ackStatus"));
		} else {
			if (!this._ackStatus_isInitialized) this.set_ackStatus(this.initial_ackStatus());
		}


	}

	static public MobileLibraryGUI_MemberWindowController newInstance(Object context, OCLTuple values) {
		if (context == null) throw new NullPointerException();
		return new MobileLibraryGUI_MemberWindowController(context, values);
	}

	 
	public OCLString initial_title() {
		if (this.initialPropertyValues.containsKey("title")) {
			return (OCLString)this.initialPropertyValues.objectForKey("title");
		}
		/* ==================================================
	 * 'Member'
	 * ================================================== */
	
	OCLString v0 = new OCLString("Member");
	
		return v0;
	}

	public OCLString get_title(){
		if (this._title_isInitialized) {
			return _title;
		} else { 
			this.set_title(this.initial_title());
		}
		this._title_isInitialized = true;
		return this._title;
	}
	public GeneralGUI_Label initial_memberNameLabel() {
		if (this.initialPropertyValues.containsKey("memberNameLabel")) {
			return (GeneralGUI_Label)this.initialPropertyValues.objectForKey("memberNameLabel");
		}
		/* ==================================================
	 * GeneralGUI::Label::create()
	 * ================================================== */
	
	GeneralGUI_Label v0 = GeneralGUI_Label.newInstance(this.context);
	
		return v0;
	}

	public GeneralGUI_Label get_memberNameLabel(){
		if (this._memberNameLabel_isInitialized) {
			return _memberNameLabel;
		} else { 
			this.set_memberNameLabel(this.initial_memberNameLabel());
		}
		this._memberNameLabel_isInitialized = true;
		return this._memberNameLabel;
	}
	public GeneralGUI_Label initial_memberLabel() {
		if (this.initialPropertyValues.containsKey("memberLabel")) {
			return (GeneralGUI_Label)this.initialPropertyValues.objectForKey("memberLabel");
		}
		/* ==================================================
	 * GeneralGUI::Label::create(Tuple { text = 'Member' })
	 * ================================================== */
	
	OCLString v4 = new OCLString("Member");
	OCLString v3 = v4;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("text", v3);
	GeneralGUI_Label v0 = GeneralGUI_Label.newInstance(this.context, v2);
	
		return v0;
	}

	public GeneralGUI_Label get_memberLabel(){
		if (this._memberLabel_isInitialized) {
			return _memberLabel;
		} else { 
			this.set_memberLabel(this.initial_memberLabel());
		}
		this._memberLabel_isInitialized = true;
		return this._memberLabel;
	}
	public GeneralGUI_SelectionList initial_borrowItems() {
		if (this.initialPropertyValues.containsKey("borrowItems")) {
			return (GeneralGUI_SelectionList)this.initialPropertyValues.objectForKey("borrowItems");
		}
		/* ==================================================
	 * GeneralGUI::SelectionList::create(Tuple { items = Sequence { } })
	 * ================================================== */
	
	OCLSequence v4 = new OCLSequence();
	OCLSequence v3 = v4;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("items", v3);
	GeneralGUI_SelectionList v0 = GeneralGUI_SelectionList.newInstance(this.context, v2);
	
		return v0;
	}

	public GeneralGUI_SelectionList get_borrowItems(){
		if (this._borrowItems_isInitialized) {
			return _borrowItems;
		} else { 
			this.set_borrowItems(this.initial_borrowItems());
		}
		this._borrowItems_isInitialized = true;
		return this._borrowItems;
	}
	public GeneralGUI_SelectionList initial_collectItems() {
		if (this.initialPropertyValues.containsKey("collectItems")) {
			return (GeneralGUI_SelectionList)this.initialPropertyValues.objectForKey("collectItems");
		}
		/* ==================================================
	 * GeneralGUI::SelectionList::create(Tuple { items = Sequence { } })
	 * ================================================== */
	
	OCLSequence v4 = new OCLSequence();
	OCLSequence v3 = v4;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("items", v3);
	GeneralGUI_SelectionList v0 = GeneralGUI_SelectionList.newInstance(this.context, v2);
	
		return v0;
	}

	public GeneralGUI_SelectionList get_collectItems(){
		if (this._collectItems_isInitialized) {
			return _collectItems;
		} else { 
			this.set_collectItems(this.initial_collectItems());
		}
		this._collectItems_isInitialized = true;
		return this._collectItems;
	}
	public GeneralGUI_Label initial_borrowedItemsLabel() {
		if (this.initialPropertyValues.containsKey("borrowedItemsLabel")) {
			return (GeneralGUI_Label)this.initialPropertyValues.objectForKey("borrowedItemsLabel");
		}
		/* ==================================================
	 * GeneralGUI::Label::create(Tuple { text = 'Books on loan:' })
	 * ================================================== */
	
	OCLString v4 = new OCLString("Books on loan:");
	OCLString v3 = v4;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("text", v3);
	GeneralGUI_Label v0 = GeneralGUI_Label.newInstance(this.context, v2);
	
		return v0;
	}

	public GeneralGUI_Label get_borrowedItemsLabel(){
		if (this._borrowedItemsLabel_isInitialized) {
			return _borrowedItemsLabel;
		} else { 
			this.set_borrowedItemsLabel(this.initial_borrowedItemsLabel());
		}
		this._borrowedItemsLabel_isInitialized = true;
		return this._borrowedItemsLabel;
	}
	public GeneralGUI_Label initial_itemsToCollectLabel() {
		if (this.initialPropertyValues.containsKey("itemsToCollectLabel")) {
			return (GeneralGUI_Label)this.initialPropertyValues.objectForKey("itemsToCollectLabel");
		}
		/* ==================================================
	 * GeneralGUI::Label::create(Tuple { text = 'Reserved Books awaiting collection:' })
	 * ================================================== */
	
	OCLString v4 = new OCLString("Reserved Books awaiting collection:");
	OCLString v3 = v4;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("text", v3);
	GeneralGUI_Label v0 = GeneralGUI_Label.newInstance(this.context, v2);
	
		return v0;
	}

	public GeneralGUI_Label get_itemsToCollectLabel(){
		if (this._itemsToCollectLabel_isInitialized) {
			return _itemsToCollectLabel;
		} else { 
			this.set_itemsToCollectLabel(this.initial_itemsToCollectLabel());
		}
		this._itemsToCollectLabel_isInitialized = true;
		return this._itemsToCollectLabel;
	}
	public GeneralGUI_Frame initial_window() {
		if (this.initialPropertyValues.containsKey("window")) {
			return (GeneralGUI_Frame)this.initialPropertyValues.objectForKey("window");
		}
		/* ==================================================
	 * GeneralGUI::Frame::create(
	 * 	Tuple { seqGUIElements = Sequence {memberLabel, memberNameLabel, borrowedItemsLabel, borrowItems, itemsToCollectLabel, collectItems }, 
	 * 	frameTitle = title,
	 * 	iconFilename = 'icon-house.png' })
	 * ================================================== */
	
	MobileLibraryGUI_MemberWindowController v7 = this;
	GeneralGUI_Label v6 = v7.get_memberLabel();
	GeneralGUI_Label v5 = v6;
	MobileLibraryGUI_MemberWindowController v10 = this;
	GeneralGUI_Label v9 = v10.get_memberNameLabel();
	GeneralGUI_Label v8 = v9;
	MobileLibraryGUI_MemberWindowController v13 = this;
	GeneralGUI_Label v12 = v13.get_borrowedItemsLabel();
	GeneralGUI_Label v11 = v12;
	MobileLibraryGUI_MemberWindowController v16 = this;
	GeneralGUI_SelectionList v15 = v16.get_borrowItems();
	GeneralGUI_SelectionList v14 = v15;
	MobileLibraryGUI_MemberWindowController v19 = this;
	GeneralGUI_Label v18 = v19.get_itemsToCollectLabel();
	GeneralGUI_Label v17 = v18;
	MobileLibraryGUI_MemberWindowController v22 = this;
	GeneralGUI_SelectionList v21 = v22.get_collectItems();
	GeneralGUI_SelectionList v20 = v21;
	OCLSequence v4 = new OCLSequence();
	v4.add(v5);
	v4.add(v8);
	v4.add(v11);
	v4.add(v14);
	v4.add(v17);
	v4.add(v20);
	OCLSequence v3 = v4;
	MobileLibraryGUI_MemberWindowController v25 = this;
	OCLString v24 = v25.get_title();
	OCLString v23 = v24;
	OCLString v27 = new OCLString("icon-house.png");
	OCLString v26 = v27;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("seqGUIElements", v3);
	v2.addItem("frameTitle", v23);
	v2.addItem("iconFilename", v26);
	GeneralGUI_Frame v0 = GeneralGUI_Frame.newInstance(this.context, v2);
	
		return v0;
	}

	public GeneralGUI_Frame get_window(){
		if (this._window_isInitialized) {
			return _window;
		} else { 
			this.set_window(this.initial_window());
		}
		this._window_isInitialized = true;
		return this._window;
	}
	public Library_Copy initial_selectedBorrowing() {
		if (this.initialPropertyValues.containsKey("selectedBorrowing")) {
			return (Library_Copy)this.initialPropertyValues.objectForKey("selectedBorrowing");
		}
		/* ==================================================
	 * null
	 * ================================================== */
	
	Library_Copy v0 = null;
	
		return v0;
	}

	public Library_Copy get_selectedBorrowing(){
		if (this._selectedBorrowing_isInitialized) {
			return _selectedBorrowing;
		} else { 
			this.set_selectedBorrowing(this.initial_selectedBorrowing());
		}
		this._selectedBorrowing_isInitialized = true;
		return this._selectedBorrowing;
	}
	public Library_Member initial_currMember() {
		if (this.initialPropertyValues.containsKey("currMember")) {
			return (Library_Member)this.initialPropertyValues.objectForKey("currMember");
		}
		/* ==================================================
	 * null
	 * ================================================== */
	
	Library_Member v0 = null;
	
		return v0;
	}

	public Library_Member get_currMember(){
		if (this._currMember_isInitialized) {
			return _currMember;
		} else { 
			this.set_currMember(this.initial_currMember());
		}
		this._currMember_isInitialized = true;
		return this._currMember;
	}
	public GeneralGUI_ConfirmationDialog initial_yesNoMsg() {
		if (this.initialPropertyValues.containsKey("yesNoMsg")) {
			return (GeneralGUI_ConfirmationDialog)this.initialPropertyValues.objectForKey("yesNoMsg");
		}
		/* ==================================================
	 * null
	 * ================================================== */
	
	GeneralGUI_ConfirmationDialog v0 = null;
	
		return v0;
	}

	public GeneralGUI_ConfirmationDialog get_yesNoMsg(){
		if (this._yesNoMsg_isInitialized) {
			return _yesNoMsg;
		} else { 
			this.set_yesNoMsg(this.initial_yesNoMsg());
		}
		this._yesNoMsg_isInitialized = true;
		return this._yesNoMsg;
	}
	public DateProcessing_DateHandler initial_dateHandler() {
		if (this.initialPropertyValues.containsKey("dateHandler")) {
			return (DateProcessing_DateHandler)this.initialPropertyValues.objectForKey("dateHandler");
		}
		/* ==================================================
	 * DateProcessing::DateHandler::create()
	 * ================================================== */
	
	DateProcessing_DateHandler v0 = DateProcessing_DateHandler.newInstance(this.context);
	
		return v0;
	}

	public DateProcessing_DateHandler get_dateHandler(){
		if (this._dateHandler_isInitialized) {
			return _dateHandler;
		} else { 
			this.set_dateHandler(this.initial_dateHandler());
		}
		this._dateHandler_isInitialized = true;
		return this._dateHandler;
	}
	public GeneralGUI_MsgDialog initial_currMsg() {
		if (this.initialPropertyValues.containsKey("currMsg")) {
			return (GeneralGUI_MsgDialog)this.initialPropertyValues.objectForKey("currMsg");
		}
		/* ==================================================
	 * null
	 * ================================================== */
	
	GeneralGUI_MsgDialog v0 = null;
	
		return v0;
	}

	public GeneralGUI_MsgDialog get_currMsg(){
		if (this._currMsg_isInitialized) {
			return _currMsg;
		} else { 
			this.set_currMsg(this.initial_currMsg());
		}
		this._currMsg_isInitialized = true;
		return this._currMsg;
	}
	public OCLString initial_ackStatus() {
		if (this.initialPropertyValues.containsKey("ackStatus")) {
			return (OCLString)this.initialPropertyValues.objectForKey("ackStatus");
		}
		/* ==================================================
	 * 'NotWaiting'
	 * ================================================== */
	
	OCLString v0 = new OCLString("NotWaiting");
	
		return v0;
	}

	public OCLString get_ackStatus(){
		if (this._ackStatus_isInitialized) {
			return _ackStatus;
		} else { 
			this.set_ackStatus(this.initial_ackStatus());
		}
		this._ackStatus_isInitialized = true;
		return this._ackStatus;
	}


	 
	public void set_title(OCLString value) {
	 	
		this._title = value;
		this._title_isInitialized = true;

	}
	public void set_ackStatus(OCLString value) {
	 	
		this._ackStatus = value;
		this._ackStatus_isInitialized = true;

	}


	public void set_memberNameLabel(GeneralGUI_Label value) {
	 	
		if (this._memberNameLabel!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._memberNameLabel.MobileLibraryGUI_MemberWindowController_memberNameLabel_back;
			backpointers.removeElement(this);
		}
		this._memberNameLabel = value;
		if (this._memberNameLabel!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._memberNameLabel.MobileLibraryGUI_MemberWindowController_memberNameLabel_back;
			backpointers.addElement(this);
		}
		this._memberNameLabel_isInitialized = true;

	}
	public void set_memberLabel(GeneralGUI_Label value) {
	 	
		if (this._memberLabel!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._memberLabel.MobileLibraryGUI_MemberWindowController_memberLabel_back;
			backpointers.removeElement(this);
		}
		this._memberLabel = value;
		if (this._memberLabel!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._memberLabel.MobileLibraryGUI_MemberWindowController_memberLabel_back;
			backpointers.addElement(this);
		}
		this._memberLabel_isInitialized = true;

	}
	public void set_borrowItems(GeneralGUI_SelectionList value) {
	 	
		if (this._borrowItems!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._borrowItems.MobileLibraryGUI_MemberWindowController_borrowItems_back;
			backpointers.removeElement(this);
		}
		this._borrowItems = value;
		if (this._borrowItems!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._borrowItems.MobileLibraryGUI_MemberWindowController_borrowItems_back;
			backpointers.addElement(this);
		}
		this._borrowItems_isInitialized = true;

	}
	public void set_collectItems(GeneralGUI_SelectionList value) {
	 	
		if (this._collectItems!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._collectItems.MobileLibraryGUI_MemberWindowController_collectItems_back;
			backpointers.removeElement(this);
		}
		this._collectItems = value;
		if (this._collectItems!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._collectItems.MobileLibraryGUI_MemberWindowController_collectItems_back;
			backpointers.addElement(this);
		}
		this._collectItems_isInitialized = true;

	}
	public void set_borrowedItemsLabel(GeneralGUI_Label value) {
	 	
		if (this._borrowedItemsLabel!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._borrowedItemsLabel.MobileLibraryGUI_MemberWindowController_borrowedItemsLabel_back;
			backpointers.removeElement(this);
		}
		this._borrowedItemsLabel = value;
		if (this._borrowedItemsLabel!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._borrowedItemsLabel.MobileLibraryGUI_MemberWindowController_borrowedItemsLabel_back;
			backpointers.addElement(this);
		}
		this._borrowedItemsLabel_isInitialized = true;

	}
	public void set_itemsToCollectLabel(GeneralGUI_Label value) {
	 	
		if (this._itemsToCollectLabel!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._itemsToCollectLabel.MobileLibraryGUI_MemberWindowController_itemsToCollectLabel_back;
			backpointers.removeElement(this);
		}
		this._itemsToCollectLabel = value;
		if (this._itemsToCollectLabel!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._itemsToCollectLabel.MobileLibraryGUI_MemberWindowController_itemsToCollectLabel_back;
			backpointers.addElement(this);
		}
		this._itemsToCollectLabel_isInitialized = true;

	}
	public void set_window(GeneralGUI_Frame value) {
	 	
		if (this._window!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._window.MobileLibraryGUI_MemberWindowController_window_back;
			backpointers.removeElement(this);
		}
		this._window = value;
		if (this._window!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._window.MobileLibraryGUI_MemberWindowController_window_back;
			backpointers.addElement(this);
		}
		this._window_isInitialized = true;

	}
	public void set_selectedBorrowing(Library_Copy value) {
	 	
		if (this._selectedBorrowing!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._selectedBorrowing.MobileLibraryGUI_MemberWindowController_selectedBorrowing_back;
			backpointers.removeElement(this);
		}
		this._selectedBorrowing = value;
		if (this._selectedBorrowing!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._selectedBorrowing.MobileLibraryGUI_MemberWindowController_selectedBorrowing_back;
			backpointers.addElement(this);
		}
		this._selectedBorrowing_isInitialized = true;

	}
	public void set_currMember(Library_Member value) {
	 	
		if (this._currMember!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._currMember.MobileLibraryGUI_MemberWindowController_currMember_back;
			backpointers.removeElement(this);
		}
		this._currMember = value;
		if (this._currMember!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._currMember.MobileLibraryGUI_MemberWindowController_currMember_back;
			backpointers.addElement(this);
		}
		this._currMember_isInitialized = true;

	}
	public void set_yesNoMsg(GeneralGUI_ConfirmationDialog value) {
	 	
		if (this._yesNoMsg!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._yesNoMsg.MobileLibraryGUI_MemberWindowController_yesNoMsg_back;
			backpointers.removeElement(this);
		}
		this._yesNoMsg = value;
		if (this._yesNoMsg!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._yesNoMsg.MobileLibraryGUI_MemberWindowController_yesNoMsg_back;
			backpointers.addElement(this);
		}
		this._yesNoMsg_isInitialized = true;

	}
	public void set_dateHandler(DateProcessing_DateHandler value) {
	 	
		if (this._dateHandler!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._dateHandler.MobileLibraryGUI_MemberWindowController_dateHandler_back;
			backpointers.removeElement(this);
		}
		this._dateHandler = value;
		if (this._dateHandler!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._dateHandler.MobileLibraryGUI_MemberWindowController_dateHandler_back;
			backpointers.addElement(this);
		}
		this._dateHandler_isInitialized = true;

	}
	public void set_currMsg(GeneralGUI_MsgDialog value) {
	 	
		if (this._currMsg!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._currMsg.MobileLibraryGUI_MemberWindowController_currMsg_back;
			backpointers.removeElement(this);
		}
		this._currMsg = value;
		if (this._currMsg!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._currMsg.MobileLibraryGUI_MemberWindowController_currMsg_back;
			backpointers.addElement(this);
		}
		this._currMsg_isInitialized = true;

	}




	 
 	public void event_borrowItemSelected_pushed (PropertyChangeList changes  , OCLInteger p_index ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_borrowItemSelected_pushed in model MobileLibraryGUI_MemberWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {

				this.event_showConfirmRenewMsg_pushed(changes );
			}


			 		 
		// Process impacts relationships
			/* ==================================================
		 * currMember.borrows->asSequence()->at(index)
		 * ================================================== */
		
		MobileLibraryGUI_MemberWindowController v5 = this;
		Library_Member v4 = v5.get_currMember();
		OCLSet v3 = v4.get_borrows();
		OCLSequence v2 = v3.asSequence();
		OCLInteger v6 = p_index;
		Library_Copy v1 = ((Library_Copy)v2.at(v6));
		
			Library_Copy _selectedBorrowing_newValue = v1;
			changes.addChange("_selectedBorrowing", this, _selectedBorrowing_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_borrowItemSelected_pulled_edge0(PropertyChangeList changes, GeneralGUI_SelectionList parentInstance ,OCLInteger p_index  ) {
		System.out.println("event_borrowItemSelected_pulled in model MobileLibraryGUI_MemberWindowController from event _itemSelected in model GeneralGUI_SelectionList");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {
			/* ==================================================
		 * index
		 * ================================================== */
		
		OCLInteger v1 = p_index;
		
			OCLInteger parameter_p_index = v1;

			this.event_borrowItemSelected_pushed(changes ,parameter_p_index  );
		}
	}


 	public void event_refreshData_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_refreshData_pushed in model MobileLibraryGUI_MemberWindowController");
			 		
			// Trigger Push edges


			if (this._borrowItems != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._borrowItems);
				for (Object o : edge0_values) {
					GeneralGUI_SelectionList edge0_target = (GeneralGUI_SelectionList)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * getBorrowItemsToDisplay
				 * ================================================== */
				
				OCLSequence v1 = this.get_getBorrowItemsToDisplay();
				
						OCLSequence parameter_p_items = v1;

						edge0_target.event_refreshItems_pushed(changes ,parameter_p_items );
					}
				}

			}
			if (this._memberNameLabel != null) {
			 	
				ArrayList<Object> edge1_values = new ArrayList<Object>();
				edge1_values.add(this._memberNameLabel);
				for (Object o : edge1_values) {
					GeneralGUI_Label edge1_target = (GeneralGUI_Label)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * currMember.name
				 * ================================================== */
				
				Library_Member v2 = this.get_currMember();
				OCLString v1 = v2.get_name();
				
						OCLString parameter_p_text = v1;

						edge1_target.event_setText_pushed(changes ,parameter_p_text );
					}
				}

			}
			if (this._collectItems != null) {
			 	
				ArrayList<Object> edge2_values = new ArrayList<Object>();
				edge2_values.add(this._collectItems);
				for (Object o : edge2_values) {
					GeneralGUI_SelectionList edge2_target = (GeneralGUI_SelectionList)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * getToCollectItemsToDisplay
				 * ================================================== */
				
				OCLSequence v1 = this.get_getToCollectItemsToDisplay();
				
						OCLSequence parameter_p_items = v1;

						edge2_target.event_refreshItems_pushed(changes ,parameter_p_items );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_sessionOpened_pushed (PropertyChangeList changes  , Library_Member p_m ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_sessionOpened_pushed in model MobileLibraryGUI_MemberWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * m
		 * ================================================== */
		
		Library_Member v0 = p_m;
		
			Library_Member _currMember_newValue = v0;
			changes.addChange("_currMember", this, _currMember_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_showConfirmRenewMsg_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_showConfirmRenewMsg_pushed in model MobileLibraryGUI_MemberWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * GeneralGUI::ConfirmationDialog::create(Tuple { title = 'Confirm', message = 'Would you like to renew the selected book?' })
		 * ================================================== */
		
		OCLString v4 = new OCLString("Confirm");
		OCLString v3 = v4;
		OCLString v6 = new OCLString("Would you like to renew the selected book?");
		OCLString v5 = v6;
		OCLTuple v2 = new OCLTuple();
		v2.addItem("title", v3);
		v2.addItem("message", v5);
		GeneralGUI_ConfirmationDialog v0 = GeneralGUI_ConfirmationDialog.newInstance(this.context, v2);
		
			GeneralGUI_ConfirmationDialog _yesNoMsg_newValue = v0;
			changes.addChange("_yesNoMsg", this, _yesNoMsg_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_renewConfAck_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_renewConfAck_pushed in model MobileLibraryGUI_MemberWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {

				this.event_renewBorrowing_pushed(changes );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_renewConfAck_pulled_edge0(PropertyChangeList changes, GeneralGUI_ConfirmationDialog parentInstance  ) {
		System.out.println("event_renewConfAck_pulled in model MobileLibraryGUI_MemberWindowController from event _okClicked in model GeneralGUI_ConfirmationDialog");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {

			this.event_renewConfAck_pushed(changes  );
		}
	}


 	public void event_renewBorrowing_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_renewBorrowing_pushed in model MobileLibraryGUI_MemberWindowController");
			 		
			// Trigger Push edges


			if (this._selectedBorrowing != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._selectedBorrowing);
				for (Object o : edge0_values) {
					Library_Copy edge0_target = (Library_Copy)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * dateHandler.calcAfterOneMonth(selectedBorrowing.dueDate)
				 * ================================================== */
				
				DateProcessing_DateHandler v2 = this.get_dateHandler();
				Library_Copy v4 = this.get_selectedBorrowing();
				OCLString v3 = v4.get_dueDate();
				OCLString v1 = v2.get_calcAfterOneMonth(v3);
				
						OCLString parameter_p_newDueDate = v1;

						edge0_target.event_renew_pushed(changes ,parameter_p_newDueDate );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_copyRenewed_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_copyRenewed_pushed in model MobileLibraryGUI_MemberWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {

				this.event_showRenewOkMsg_pushed(changes );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_copyRenewed_pulled_edge0(PropertyChangeList changes, Library_Copy parentInstance ,OCLString p_newDueDate  ) {
		System.out.println("event_copyRenewed_pulled in model MobileLibraryGUI_MemberWindowController from event _renewOk in model Library_Copy");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {

			this.event_copyRenewed_pushed(changes  );
		}
	}


 	public void event_showRenewOkMsg_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_showRenewOkMsg_pushed in model MobileLibraryGUI_MemberWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * GeneralGUI::MsgDialog::create(
		 * 	Tuple { 
		 * 	    msg = 'Book '.concat(selectedBorrowing.book.title).concat(' renewed sucessfully.'), 
		 * 		viewTitle = 'Success!' })
		 * ================================================== */
		
		OCLString v6 = new OCLString("Book ");
		MobileLibraryGUI_MemberWindowController v10 = this;
		Library_Copy v9 = v10.get_selectedBorrowing();
		Library_Book v8 = v9.get_book();
		OCLString v7 = v8.get_title();
		OCLString v5 = v6.concat(v7);
		OCLString v11 = new OCLString(" renewed sucessfully.");
		OCLString v4 = v5.concat(v11);
		OCLString v3 = v4;
		OCLString v13 = new OCLString("Success!");
		OCLString v12 = v13;
		OCLTuple v2 = new OCLTuple();
		v2.addItem("msg", v3);
		v2.addItem("viewTitle", v12);
		GeneralGUI_MsgDialog v0 = GeneralGUI_MsgDialog.newInstance(this.context, v2);
		
			GeneralGUI_MsgDialog _currMsg_newValue = v0;
			changes.addChange("_currMsg", this, _currMsg_newValue);
			/* ==================================================
		 * 'WaitingRenewAck'
		 * ================================================== */
		
		OCLString v14 = new OCLString("WaitingRenewAck");
		
			OCLString _ackStatus_newValue = v14;
			changes.addChange("_ackStatus", this, _ackStatus_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_renewAck_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * ackStatus='WaitingRenewAck'
             * ================================================== */
            
            MobileLibraryGUI_MemberWindowController v2 = this;
            OCLString v1 = v2.get_ackStatus();
            OCLString v3 = new OCLString("WaitingRenewAck");
            OCLBoolean v0;
            if (v1 == null || v3 == null) {
            		v0 = new OCLBoolean(v1 == v3);
            } else {
            		v0 = v1.eq(v3);
            }
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_renewAck_pushed in model MobileLibraryGUI_MemberWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {

				this.event_refreshData_pushed(changes );
			}
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v1 = new OCLBoolean(true);
		
			if (v1.value == true) {

				this.event_saveData_pushed(changes );
			}
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v2 = new OCLBoolean(true);
		
			if (v2.value == true) {

				this.event_setToNotWaiting_pushed(changes );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_renewAck_pulled_edge0(PropertyChangeList changes, GeneralGUI_MsgDialog parentInstance  ) {
		System.out.println("event_renewAck_pulled in model MobileLibraryGUI_MemberWindowController from event _okClicked in model GeneralGUI_MsgDialog");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {

			this.event_renewAck_pushed(changes  );
		}
	}


 	public void event_saveData_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_saveData_pushed in model MobileLibraryGUI_MemberWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges
			for (OCLAny o : this.Application_Main_memberControl_back) {
				((Application_Main)o).event_saveLibrary_pulled_edge0(changes, this );
			}


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_renewFailed_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_renewFailed_pushed in model MobileLibraryGUI_MemberWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {

				this.event_showRenewFailedMsg_pushed(changes );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_renewFailed_pulled_edge0(PropertyChangeList changes, Library_Copy parentInstance ,Library_Copy p_copy  ) {
		System.out.println("event_renewFailed_pulled in model MobileLibraryGUI_MemberWindowController from event _renewFailed in model Library_Copy");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {

			this.event_renewFailed_pushed(changes  );
		}
	}


 	public void event_showRenewFailedMsg_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_showRenewFailedMsg_pushed in model MobileLibraryGUI_MemberWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * GeneralGUI::MsgDialog::create(
		 * 	Tuple { 
		 * 	    msg = 'Could not renew  borrowing of book '.concat(selectedBorrowing.book.title).concat('. You have reached the limit of renewals for this borrowing.'), 
		 * 		viewTitle = 'Error!' })
		 * ================================================== */
		
		OCLString v6 = new OCLString("Could not renew  borrowing of book ");
		MobileLibraryGUI_MemberWindowController v10 = this;
		Library_Copy v9 = v10.get_selectedBorrowing();
		Library_Book v8 = v9.get_book();
		OCLString v7 = v8.get_title();
		OCLString v5 = v6.concat(v7);
		OCLString v11 = new OCLString(". You have reached the limit of renewals for this borrowing.");
		OCLString v4 = v5.concat(v11);
		OCLString v3 = v4;
		OCLString v13 = new OCLString("Error!");
		OCLString v12 = v13;
		OCLTuple v2 = new OCLTuple();
		v2.addItem("msg", v3);
		v2.addItem("viewTitle", v12);
		GeneralGUI_MsgDialog v0 = GeneralGUI_MsgDialog.newInstance(this.context, v2);
		
			GeneralGUI_MsgDialog _currMsg_newValue = v0;
			changes.addChange("_currMsg", this, _currMsg_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_setToNotWaiting_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_setToNotWaiting_pushed in model MobileLibraryGUI_MemberWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * 'NotWaiting'
		 * ================================================== */
		
		OCLString v0 = new OCLString("NotWaiting");
		
			OCLString _ackStatus_newValue = v0;
			changes.addChange("_ackStatus", this, _ackStatus_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 




	 
	public OCLSequence get_getBorrowItemsToDisplay() {
		/* ==================================================
	 * if currMember <> null 
	 * 	then 
	 * 		currMember.borrows->asSequence()->collect(c:Library::Copy | c.book.title.concat(' ').concat(c.dueDate))
	 * 	else 
	 * 		Sequence {}
	 * endif
	 * ================================================== */
	
	MobileLibraryGUI_MemberWindowController v3 = this;
	Library_Member v2 = v3.get_currMember();
	OCLAny v4 = null;
	OCLBoolean v1;
	if (v2 == null || v4 == null) {
			v1 = new OCLBoolean(v2 != v4);
	} else {
			v1 = v2.neq(v4);
	}
	OCLSequence v0;
	if (v1.value == true) {
			MobileLibraryGUI_MemberWindowController v9 = this;
			Library_Member v8 = v9.get_currMember();
			OCLSet v7 = v8.get_borrows();
			OCLSequence v6 = v7.asSequence();
			OCLSequence v5_nested = new OCLSequence();
			Iterator<OCLAny> v5_iter = v6.iterator();
			while (v5_iter.hasNext()) {
					Library_Copy v10 = (Library_Copy)v5_iter.next();
					Library_Copy v15 = v10;
					Library_Book v14 = v15.get_book();
					OCLString v13 = v14.get_title();
					OCLString v16 = new OCLString(" ");
					OCLString v12 = v13.concat(v16);
					Library_Copy v18 = v10;
					OCLString v17 = v18.get_dueDate();
					OCLString v11 = v12.concat(v17);
					v5_nested.add(v11);
			}
			OCLSequence v5 = v5_nested.flatten();
			v0 = (OCLSequence)v5;
	} else {
			OCLSequence v19 = new OCLSequence();
			v0 = (OCLSequence)v19;
	}
	;
		return v0;
	}
	public OCLSequence get_getToCollectItemsToDisplay() {
		/* ==================================================
	 * if currMember <> null 
	 * 	then 
	 * 		currMember.toCollect->asSequence()->collect(c:Library::Copy | c.book.title)
	 * 	else 
	 * 		Sequence {}
	 * endif
	 * ================================================== */
	
	MobileLibraryGUI_MemberWindowController v3 = this;
	Library_Member v2 = v3.get_currMember();
	OCLAny v4 = null;
	OCLBoolean v1;
	if (v2 == null || v4 == null) {
			v1 = new OCLBoolean(v2 != v4);
	} else {
			v1 = v2.neq(v4);
	}
	OCLSequence v0;
	if (v1.value == true) {
			MobileLibraryGUI_MemberWindowController v9 = this;
			Library_Member v8 = v9.get_currMember();
			OCLSet v7 = v8.get_toCollect();
			OCLSequence v6 = v7.asSequence();
			OCLSequence v5_nested = new OCLSequence();
			Iterator<OCLAny> v5_iter = v6.iterator();
			while (v5_iter.hasNext()) {
					Library_Copy v10 = (Library_Copy)v5_iter.next();
					Library_Copy v13 = v10;
					Library_Book v12 = v13.get_book();
					OCLString v11 = v12.get_title();
					v5_nested.add(v11);
			}
			OCLSequence v5 = v5_nested.flatten();
			v0 = (OCLSequence)v5;
	} else {
			OCLSequence v14 = new OCLSequence();
			v0 = (OCLSequence)v14;
	}
	;
		return v0;
	}


	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

