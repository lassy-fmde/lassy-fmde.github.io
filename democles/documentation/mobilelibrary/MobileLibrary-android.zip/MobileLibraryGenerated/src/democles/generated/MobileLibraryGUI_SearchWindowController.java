 
	  
package democles.generated;

import java.util.Vector;
import java.util.ArrayList;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
public class MobileLibraryGUI_SearchWindowController implements OCLAny {
	 
	private GeneralGUI_Label _searchLabel;
	private boolean _searchLabel_isInitialized;
	private GeneralGUI_Textfield _searchField;
	private boolean _searchField_isInitialized;
	private GeneralGUI_SelectionBox _categorySelect;
	private boolean _categorySelect_isInitialized;
	private GeneralGUI_Button _searchButton;
	private boolean _searchButton_isInitialized;
	private MobileLibraryGUI_BookListWindowController _resultWindow;
	private boolean _resultWindow_isInitialized;
	private OCLString _title;
	private boolean _title_isInitialized;
	private GeneralGUI_Frame _frame;
	private boolean _frame_isInitialized;
	private OCLString _mode;
	private boolean _mode_isInitialized;
	private Library_Member _currMember;
	private boolean _currMember_isInitialized;
	private OCLSequence _booksFound;
	private boolean _booksFound_isInitialized;

	public Vector<OCLAny> Application_Main_searchControl_back = new Vector<OCLAny>();

	private Object context;
	private OCLTuple initialPropertyValues = new OCLTuple();
	

	 
	private MobileLibraryGUI_SearchWindowController(Object context) {
		super();
		this.context = context;
		 
		if (!this._searchLabel_isInitialized) this.set_searchLabel(this.initial_searchLabel()); 
		if (!this._searchField_isInitialized) this.set_searchField(this.initial_searchField()); 
		if (!this._categorySelect_isInitialized) this.set_categorySelect(this.initial_categorySelect()); 
		if (!this._searchButton_isInitialized) this.set_searchButton(this.initial_searchButton()); 
		if (!this._resultWindow_isInitialized) this.set_resultWindow(this.initial_resultWindow()); 
		if (!this._title_isInitialized) this.set_title(this.initial_title()); 
		if (!this._frame_isInitialized) this.set_frame(this.initial_frame()); 
		if (!this._mode_isInitialized) this.set_mode(this.initial_mode()); 
		if (!this._currMember_isInitialized) this.set_currMember(this.initial_currMember()); 
		if (!this._booksFound_isInitialized) this.set_booksFound(this.initial_booksFound()); 


	}
	
	static public MobileLibraryGUI_SearchWindowController newInstance(Object context) {
		if (context == null) throw new NullPointerException();
		return new MobileLibraryGUI_SearchWindowController(context);
	}
 
	 
	private MobileLibraryGUI_SearchWindowController(Object context, OCLTuple values) {
		super();
		this.context = context;
		if (values != null) this.initialPropertyValues = values;

		 
		this._searchLabel_isInitialized = false; 
		this._searchField_isInitialized = false; 
		this._categorySelect_isInitialized = false; 
		this._searchButton_isInitialized = false; 
		this._resultWindow_isInitialized = false; 
		this._title_isInitialized = false; 
		this._frame_isInitialized = false; 
		this._mode_isInitialized = false; 
		this._currMember_isInitialized = false; 
		this._booksFound_isInitialized = false; 

		if (values == null) values = new OCLTuple(); // Empty
        this.initialPropertyValues = values;
		
		if (values.containsKey("searchLabel")) {
			this.set_searchLabel((GeneralGUI_Label)values.objectForKey("searchLabel"));
		} else {
			if (!this._searchLabel_isInitialized) this.set_searchLabel(this.initial_searchLabel());
		}
		if (values.containsKey("searchField")) {
			this.set_searchField((GeneralGUI_Textfield)values.objectForKey("searchField"));
		} else {
			if (!this._searchField_isInitialized) this.set_searchField(this.initial_searchField());
		}
		if (values.containsKey("categorySelect")) {
			this.set_categorySelect((GeneralGUI_SelectionBox)values.objectForKey("categorySelect"));
		} else {
			if (!this._categorySelect_isInitialized) this.set_categorySelect(this.initial_categorySelect());
		}
		if (values.containsKey("searchButton")) {
			this.set_searchButton((GeneralGUI_Button)values.objectForKey("searchButton"));
		} else {
			if (!this._searchButton_isInitialized) this.set_searchButton(this.initial_searchButton());
		}
		if (values.containsKey("resultWindow")) {
			this.set_resultWindow((MobileLibraryGUI_BookListWindowController)values.objectForKey("resultWindow"));
		} else {
			if (!this._resultWindow_isInitialized) this.set_resultWindow(this.initial_resultWindow());
		}
		if (values.containsKey("title")) {
			this.set_title((OCLString)values.objectForKey("title"));
		} else {
			if (!this._title_isInitialized) this.set_title(this.initial_title());
		}
		if (values.containsKey("frame")) {
			this.set_frame((GeneralGUI_Frame)values.objectForKey("frame"));
		} else {
			if (!this._frame_isInitialized) this.set_frame(this.initial_frame());
		}
		if (values.containsKey("mode")) {
			this.set_mode((OCLString)values.objectForKey("mode"));
		} else {
			if (!this._mode_isInitialized) this.set_mode(this.initial_mode());
		}
		if (values.containsKey("currMember")) {
			this.set_currMember((Library_Member)values.objectForKey("currMember"));
		} else {
			if (!this._currMember_isInitialized) this.set_currMember(this.initial_currMember());
		}
		if (values.containsKey("booksFound")) {
			this.set_booksFound((OCLSequence)values.objectForKey("booksFound"));
		} else {
			if (!this._booksFound_isInitialized) this.set_booksFound(this.initial_booksFound());
		}


	}

	static public MobileLibraryGUI_SearchWindowController newInstance(Object context, OCLTuple values) {
		if (context == null) throw new NullPointerException();
		return new MobileLibraryGUI_SearchWindowController(context, values);
	}

	 
	public GeneralGUI_Label initial_searchLabel() {
		if (this.initialPropertyValues.containsKey("searchLabel")) {
			return (GeneralGUI_Label)this.initialPropertyValues.objectForKey("searchLabel");
		}
		/* ==================================================
	 * GeneralGUI::Label::create(Tuple { text = 'Search by:' })
	 * ================================================== */
	
	OCLString v4 = new OCLString("Search by:");
	OCLString v3 = v4;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("text", v3);
	GeneralGUI_Label v0 = GeneralGUI_Label.newInstance(this.context, v2);
	
		return v0;
	}

	public GeneralGUI_Label get_searchLabel(){
		if (this._searchLabel_isInitialized) {
			return _searchLabel;
		} else { 
			this.set_searchLabel(this.initial_searchLabel());
		}
		this._searchLabel_isInitialized = true;
		return this._searchLabel;
	}
	public GeneralGUI_Textfield initial_searchField() {
		if (this.initialPropertyValues.containsKey("searchField")) {
			return (GeneralGUI_Textfield)this.initialPropertyValues.objectForKey("searchField");
		}
		/* ==================================================
	 * GeneralGUI::Textfield::create()
	 * ================================================== */
	
	GeneralGUI_Textfield v0 = GeneralGUI_Textfield.newInstance(this.context);
	
		return v0;
	}

	public GeneralGUI_Textfield get_searchField(){
		if (this._searchField_isInitialized) {
			return _searchField;
		} else { 
			this.set_searchField(this.initial_searchField());
		}
		this._searchField_isInitialized = true;
		return this._searchField;
	}
	public GeneralGUI_SelectionBox initial_categorySelect() {
		if (this.initialPropertyValues.containsKey("categorySelect")) {
			return (GeneralGUI_SelectionBox)this.initialPropertyValues.objectForKey("categorySelect");
		}
		/* ==================================================
	 * GeneralGUI::SelectionBox::create(Tuple { choices = Sequence { 'Author', 'Title', 'ISBN' }})
	 * ================================================== */
	
	OCLString v6 = new OCLString("Author");
	OCLString v5 = v6;
	OCLString v8 = new OCLString("Title");
	OCLString v7 = v8;
	OCLString v10 = new OCLString("ISBN");
	OCLString v9 = v10;
	OCLSequence v4 = new OCLSequence();
	v4.add(v5);
	v4.add(v7);
	v4.add(v9);
	OCLSequence v3 = v4;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("choices", v3);
	GeneralGUI_SelectionBox v0 = GeneralGUI_SelectionBox.newInstance(this.context, v2);
	
		return v0;
	}

	public GeneralGUI_SelectionBox get_categorySelect(){
		if (this._categorySelect_isInitialized) {
			return _categorySelect;
		} else { 
			this.set_categorySelect(this.initial_categorySelect());
		}
		this._categorySelect_isInitialized = true;
		return this._categorySelect;
	}
	public GeneralGUI_Button initial_searchButton() {
		if (this.initialPropertyValues.containsKey("searchButton")) {
			return (GeneralGUI_Button)this.initialPropertyValues.objectForKey("searchButton");
		}
		/* ==================================================
	 * GeneralGUI::Button::create(Tuple { text = 'Search' })
	 * ================================================== */
	
	OCLString v4 = new OCLString("Search");
	OCLString v3 = v4;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("text", v3);
	GeneralGUI_Button v0 = GeneralGUI_Button.newInstance(this.context, v2);
	
		return v0;
	}

	public GeneralGUI_Button get_searchButton(){
		if (this._searchButton_isInitialized) {
			return _searchButton;
		} else { 
			this.set_searchButton(this.initial_searchButton());
		}
		this._searchButton_isInitialized = true;
		return this._searchButton;
	}
	public MobileLibraryGUI_BookListWindowController initial_resultWindow() {
		if (this.initialPropertyValues.containsKey("resultWindow")) {
			return (MobileLibraryGUI_BookListWindowController)this.initialPropertyValues.objectForKey("resultWindow");
		}
		/* ==================================================
	 * null
	 * ================================================== */
	
	MobileLibraryGUI_BookListWindowController v0 = null;
	
		return v0;
	}

	public MobileLibraryGUI_BookListWindowController get_resultWindow(){
		if (this._resultWindow_isInitialized) {
			return _resultWindow;
		} else { 
			this.set_resultWindow(this.initial_resultWindow());
		}
		this._resultWindow_isInitialized = true;
		return this._resultWindow;
	}
	public OCLString initial_title() {
		if (this.initialPropertyValues.containsKey("title")) {
			return (OCLString)this.initialPropertyValues.objectForKey("title");
		}
		/* ==================================================
	 * 'Search'
	 * ================================================== */
	
	OCLString v0 = new OCLString("Search");
	
		return v0;
	}

	public OCLString get_title(){
		if (this._title_isInitialized) {
			return _title;
		} else { 
			this.set_title(this.initial_title());
		}
		this._title_isInitialized = true;
		return this._title;
	}
	public GeneralGUI_Frame initial_frame() {
		if (this.initialPropertyValues.containsKey("frame")) {
			return (GeneralGUI_Frame)this.initialPropertyValues.objectForKey("frame");
		}
		/* ==================================================
	 * GeneralGUI::Frame::create(
	 * 	Tuple { seqGUIElements = Sequence {searchLabel, categorySelect, searchField, searchButton }, 
	 * 	frameTitle = title,
	 * 	iconFilename = 'icon-search.png' })
	 * ================================================== */
	
	MobileLibraryGUI_SearchWindowController v7 = this;
	GeneralGUI_Label v6 = v7.get_searchLabel();
	GeneralGUI_Label v5 = v6;
	MobileLibraryGUI_SearchWindowController v10 = this;
	GeneralGUI_SelectionBox v9 = v10.get_categorySelect();
	GeneralGUI_SelectionBox v8 = v9;
	MobileLibraryGUI_SearchWindowController v13 = this;
	GeneralGUI_Textfield v12 = v13.get_searchField();
	GeneralGUI_Textfield v11 = v12;
	MobileLibraryGUI_SearchWindowController v16 = this;
	GeneralGUI_Button v15 = v16.get_searchButton();
	GeneralGUI_Button v14 = v15;
	OCLSequence v4 = new OCLSequence();
	v4.add(v5);
	v4.add(v8);
	v4.add(v11);
	v4.add(v14);
	OCLSequence v3 = v4;
	MobileLibraryGUI_SearchWindowController v19 = this;
	OCLString v18 = v19.get_title();
	OCLString v17 = v18;
	OCLString v21 = new OCLString("icon-search.png");
	OCLString v20 = v21;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("seqGUIElements", v3);
	v2.addItem("frameTitle", v17);
	v2.addItem("iconFilename", v20);
	GeneralGUI_Frame v0 = GeneralGUI_Frame.newInstance(this.context, v2);
	
		return v0;
	}

	public GeneralGUI_Frame get_frame(){
		if (this._frame_isInitialized) {
			return _frame;
		} else { 
			this.set_frame(this.initial_frame());
		}
		this._frame_isInitialized = true;
		return this._frame;
	}
	public OCLString initial_mode() {
		if (this.initialPropertyValues.containsKey("mode")) {
			return (OCLString)this.initialPropertyValues.objectForKey("mode");
		}
		/* ==================================================
	 * 'NotLoggedIn'
	 * ================================================== */
	
	OCLString v0 = new OCLString("NotLoggedIn");
	
		return v0;
	}

	public OCLString get_mode(){
		if (this._mode_isInitialized) {
			return _mode;
		} else { 
			this.set_mode(this.initial_mode());
		}
		this._mode_isInitialized = true;
		return this._mode;
	}
	public Library_Member initial_currMember() {
		if (this.initialPropertyValues.containsKey("currMember")) {
			return (Library_Member)this.initialPropertyValues.objectForKey("currMember");
		}
		/* ==================================================
	 * null
	 * ================================================== */
	
	Library_Member v0 = null;
	
		return v0;
	}

	public Library_Member get_currMember(){
		if (this._currMember_isInitialized) {
			return _currMember;
		} else { 
			this.set_currMember(this.initial_currMember());
		}
		this._currMember_isInitialized = true;
		return this._currMember;
	}
	public OCLSequence initial_booksFound() {
		if (this.initialPropertyValues.containsKey("booksFound")) {
			return (OCLSequence)this.initialPropertyValues.objectForKey("booksFound");
		}
		/* ==================================================
	 * Sequence {}
	 * ================================================== */
	
	OCLSequence v0 = new OCLSequence();
	
		return v0;
	}

	public OCLSequence get_booksFound(){
		if (this._booksFound_isInitialized) {
			return _booksFound;
		} else { 
			this.set_booksFound(this.initial_booksFound());
		}
		this._booksFound_isInitialized = true;
		return this._booksFound;
	}


	 
	public void set_title(OCLString value) {
	 	
		this._title = value;
		this._title_isInitialized = true;

	}
	public void set_mode(OCLString value) {
	 	
		this._mode = value;
		this._mode_isInitialized = true;

	}


	public void set_searchLabel(GeneralGUI_Label value) {
	 	
		if (this._searchLabel!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._searchLabel.MobileLibraryGUI_SearchWindowController_searchLabel_back;
			backpointers.removeElement(this);
		}
		this._searchLabel = value;
		if (this._searchLabel!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._searchLabel.MobileLibraryGUI_SearchWindowController_searchLabel_back;
			backpointers.addElement(this);
		}
		this._searchLabel_isInitialized = true;

	}
	public void set_searchField(GeneralGUI_Textfield value) {
	 	
		if (this._searchField!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._searchField.MobileLibraryGUI_SearchWindowController_searchField_back;
			backpointers.removeElement(this);
		}
		this._searchField = value;
		if (this._searchField!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._searchField.MobileLibraryGUI_SearchWindowController_searchField_back;
			backpointers.addElement(this);
		}
		this._searchField_isInitialized = true;

	}
	public void set_categorySelect(GeneralGUI_SelectionBox value) {
	 	
		if (this._categorySelect!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._categorySelect.MobileLibraryGUI_SearchWindowController_categorySelect_back;
			backpointers.removeElement(this);
		}
		this._categorySelect = value;
		if (this._categorySelect!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._categorySelect.MobileLibraryGUI_SearchWindowController_categorySelect_back;
			backpointers.addElement(this);
		}
		this._categorySelect_isInitialized = true;

	}
	public void set_searchButton(GeneralGUI_Button value) {
	 	
		if (this._searchButton!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._searchButton.MobileLibraryGUI_SearchWindowController_searchButton_back;
			backpointers.removeElement(this);
		}
		this._searchButton = value;
		if (this._searchButton!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._searchButton.MobileLibraryGUI_SearchWindowController_searchButton_back;
			backpointers.addElement(this);
		}
		this._searchButton_isInitialized = true;

	}
	public void set_resultWindow(MobileLibraryGUI_BookListWindowController value) {
	 	
		if (this._resultWindow!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._resultWindow.MobileLibraryGUI_SearchWindowController_resultWindow_back;
			backpointers.removeElement(this);
		}
		this._resultWindow = value;
		if (this._resultWindow!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._resultWindow.MobileLibraryGUI_SearchWindowController_resultWindow_back;
			backpointers.addElement(this);
		}
		this._resultWindow_isInitialized = true;

	}
	public void set_frame(GeneralGUI_Frame value) {
	 	
		if (this._frame!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._frame.MobileLibraryGUI_SearchWindowController_frame_back;
			backpointers.removeElement(this);
		}
		this._frame = value;
		if (this._frame!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._frame.MobileLibraryGUI_SearchWindowController_frame_back;
			backpointers.addElement(this);
		}
		this._frame_isInitialized = true;

	}
	public void set_currMember(Library_Member value) {
	 	
		if (this._currMember!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._currMember.MobileLibraryGUI_SearchWindowController_currMember_back;
			backpointers.removeElement(this);
		}
		this._currMember = value;
		if (this._currMember!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._currMember.MobileLibraryGUI_SearchWindowController_currMember_back;
			backpointers.addElement(this);
		}
		this._currMember_isInitialized = true;

	}


 	public void set_booksFound(OCLSequence value) {
	 	
		if (this._booksFound!= null) {
			// Clear back pointer on old instance
			for (OCLAny object : this._booksFound) {
				Library_Book o = (Library_Book)object;
				Vector<OCLAny> backpointers = o.MobileLibraryGUI_SearchWindowController_booksFound_back;
				backpointers.removeElement(this);
			}
		}
		this._booksFound = value;
		if (this._booksFound!= null) {
			// Add back pointer on new instance
			for (OCLAny object : this._booksFound) {
				Library_Book o = (Library_Book)object;
				Vector<OCLAny> backpointers = o.MobileLibraryGUI_SearchWindowController_booksFound_back;
				backpointers.addElement(this);
			}
		}
		this._booksFound_isInitialized = true;

	}


	 
 	public void event_searchButtonClicked_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_searchButtonClicked_pushed in model MobileLibraryGUI_SearchWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {
				/* ==================================================
			 * searchField.text
			 * ================================================== */
			
			GeneralGUI_Textfield v2 = this.get_searchField();
			OCLString v1 = v2.get_text();
			
				OCLString parameter_p_term = v1;
				/* ==================================================
			 * categorySelect.selectedChoice
			 * ================================================== */
			
			GeneralGUI_SelectionBox v4 = this.get_categorySelect();
			OCLString v3 = v4.get_selectedChoice();
			
				OCLString parameter_p_category = v3;

				this.event_searchBook_pushed(changes , parameter_p_term , parameter_p_category );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_searchButtonClicked_pulled_edge0(PropertyChangeList changes, GeneralGUI_Button parentInstance  ) {
		System.out.println("event_searchButtonClicked_pulled in model MobileLibraryGUI_SearchWindowController from event _clicked in model GeneralGUI_Button");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {

			this.event_searchButtonClicked_pushed(changes  );
		}
	}


 	public void event_searchFinished_pushed (PropertyChangeList changes  , OCLSet p_booksFound ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_searchFinished_pushed in model MobileLibraryGUI_SearchWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * BookListWindowController::create(
		 * 	Tuple { 
		 * 		bookListTable = GeneralGUI::SelectionList::create(Tuple { items = getBooksFoundData(booksFound) }),
		 * 		mode = mode,
		 * 		currMember = currMember
		 * 	})
		 * ================================================== */
		
		MobileLibraryGUI_SearchWindowController v9 = this;
		OCLSet v10 = p_booksFound;
		OCLSequence v8 = v9.get_getBooksFoundData(v10);
		OCLSequence v7 = v8;
		OCLTuple v6 = new OCLTuple();
		v6.addItem("items", v7);
		GeneralGUI_SelectionList v4 = GeneralGUI_SelectionList.newInstance(this.context, v6);
		GeneralGUI_SelectionList v3 = v4;
		MobileLibraryGUI_SearchWindowController v13 = this;
		OCLString v12 = v13.get_mode();
		OCLString v11 = v12;
		MobileLibraryGUI_SearchWindowController v16 = this;
		Library_Member v15 = v16.get_currMember();
		Library_Member v14 = v15;
		OCLTuple v2 = new OCLTuple();
		v2.addItem("bookListTable", v3);
		v2.addItem("mode", v11);
		v2.addItem("currMember", v14);
		MobileLibraryGUI_BookListWindowController v0 = MobileLibraryGUI_BookListWindowController.newInstance(this.context, v2);
		
			MobileLibraryGUI_BookListWindowController _resultWindow_newValue = v0;
			changes.addChange("_resultWindow", this, _resultWindow_newValue);
			/* ==================================================
		 * booksFound->asSequence()
		 * ================================================== */
		
		OCLSet v18 = p_booksFound;
		OCLSequence v17 = v18.asSequence();
		
			OCLSequence _booksFound_newValue = v17;
			changes.addChange("_booksFound", this, _booksFound_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_bookSelected_pushed (PropertyChangeList changes  , OCLInteger p_index ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_bookSelected_pushed in model MobileLibraryGUI_SearchWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {
				/* ==================================================
			 * booksFound->at(index)
			 * ================================================== */
			
			OCLSequence v2 = this.get_booksFound();
			OCLInteger v3 = p_index;
			Library_Book v1 = ((Library_Book)v2.at(v3));
			
				Library_Book parameter_p_book = v1;

				this.event_selectedBook_pushed(changes , parameter_p_book );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_bookSelected_pulled_edge0(PropertyChangeList changes, MobileLibraryGUI_BookListWindowController parentInstance ,OCLInteger p_index  ) {
		System.out.println("event_bookSelected_pulled in model MobileLibraryGUI_SearchWindowController from event _bookSelected in model MobileLibraryGUI_BookListWindowController");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {
			/* ==================================================
		 * index
		 * ================================================== */
		
		OCLInteger v1 = p_index;
		
			OCLInteger parameter_p_index = v1;

			this.event_bookSelected_pushed(changes ,parameter_p_index  );
		}
	}


 	public void event_searchBook_pushed (PropertyChangeList changes  , OCLString p_term , OCLString p_category ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_searchBook_pushed in model MobileLibraryGUI_SearchWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges
			for (OCLAny o : this.Application_Main_searchControl_back) {
				((Application_Main)o).event_searchBook_pulled_edge0(changes, this , p_term, p_category);
			}


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_refreshAndSave_pushed (PropertyChangeList changes   ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_refreshAndSave_pushed in model MobileLibraryGUI_SearchWindowController");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges
			for (OCLAny o : this.Application_Main_searchControl_back) {
				((Application_Main)o).event_saveLibrary_pulled_edge1(changes, this );
			}
			for (OCLAny o : this.Application_Main_searchControl_back) {
				((Application_Main)o).event_refreshMemberWindow_pulled_edge0(changes, this );
			}


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_refreshAndSave_pulled_edge0(PropertyChangeList changes, MobileLibraryGUI_BookListWindowController parentInstance  ) {
		System.out.println("event_refreshAndSave_pulled in model MobileLibraryGUI_SearchWindowController from event _refreshAndSave in model MobileLibraryGUI_BookListWindowController");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {

			this.event_refreshAndSave_pushed(changes  );
		}
	}


 	public void event_memberSessionStarted_pushed (PropertyChangeList changes  , Library_Member p_m ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_memberSessionStarted_pushed in model MobileLibraryGUI_SearchWindowController");
			 		
			// Trigger Push edges


			if (this._resultWindow != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._resultWindow);
				for (Object o : edge0_values) {
					MobileLibraryGUI_BookListWindowController edge0_target = (MobileLibraryGUI_BookListWindowController)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * m
				 * ================================================== */
				
				Library_Member v1 = p_m;
				
						Library_Member parameter_p_m = v1;

						edge0_target.event_memberSessionStarted_pushed(changes ,parameter_p_m );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * 'LoggedIn'
		 * ================================================== */
		
		OCLString v0 = new OCLString("LoggedIn");
		
			OCLString _mode_newValue = v0;
			changes.addChange("_mode", this, _mode_newValue);
			/* ==================================================
		 * m
		 * ================================================== */
		
		Library_Member v1 = p_m;
		
			Library_Member _currMember_newValue = v1;
			changes.addChange("_currMember", this, _currMember_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_selectedBook_pushed (PropertyChangeList changes  , Library_Book p_book ){
		{ // New scope for following guard expression:
			/* ==================================================
             * true
             * ================================================== */
            
            OCLBoolean v0 = new OCLBoolean(true);
            			
			if (!v0.value) {
				return;
			}
		}
		
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_selectedBook_pushed in model MobileLibraryGUI_SearchWindowController");
			 		
			// Trigger Push edges


			if (this._resultWindow != null) {
			 	
				ArrayList<Object> edge0_values = new ArrayList<Object>();
				edge0_values.add(this._resultWindow);
				for (Object o : edge0_values) {
					MobileLibraryGUI_BookListWindowController edge0_target = (MobileLibraryGUI_BookListWindowController)o;					
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * book
				 * ================================================== */
				
				Library_Book v1 = p_book;
				
						Library_Book parameter_p_book = v1;

						edge0_target.event_selectedBook_pushed(changes ,parameter_p_book );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 




	 
	public OCLSequence get_getBooksFoundData(OCLSet p_books) {
		/* ==================================================
	 * books->asSequence()->collect(b:Library::Book | b.title)->asSequence()
	 * ================================================== */
	
	OCLSet v3 = p_books;
	OCLSequence v2 = v3.asSequence();
	OCLSequence v1_nested = new OCLSequence();
	Iterator<OCLAny> v1_iter = v2.iterator();
	while (v1_iter.hasNext()) {
			Library_Book v4 = (Library_Book)v1_iter.next();
			Library_Book v6 = v4;
			OCLString v5 = v6.get_title();
			v1_nested.add(v5);
	}
	OCLSequence v1 = v1_nested.flatten();
	OCLSequence v0 = v1.asSequence();
	;
		return v0;
	}


	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

