 
 
 
#import <Foundation/Foundation.h>
#import "OCLTypes.h"

@class PropertyChangeList;
@class GeneralGUI_Image;
@class GeneralGUI_Window;
@class GeneralGUI_Label;
@class Application_Main;


 
 
@interface MobileLibraryGUI_StartController : OCLAny  
 {
	 
	GeneralGUI_Label* _msgLabel;
	BOOL _msgLabel_initialized;
	OCLString* _windowTitle;
	BOOL _windowTitle_initialized;
	GeneralGUI_Window* _window;
	BOOL _window_initialized;
	GeneralGUI_Image* _logo;
	BOOL _logo_initialized;


@public
	NSMutableArray *Application_Main_startControl_back;


}

 
-(MobileLibraryGUI_StartController*)init;
-(MobileLibraryGUI_StartController*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(GeneralGUI_Label*) _msgLabel;
-(GeneralGUI_Label*) initial_msgLabel;
-(void) set_msgLabel:(GeneralGUI_Label*) value;
-(OCLString*) _windowTitle;
-(OCLString*) initial_windowTitle;
-(void) set_windowTitle:(OCLString*) value;
-(GeneralGUI_Window*) _window;
-(GeneralGUI_Window*) initial_window;
-(void) set_window:(GeneralGUI_Window*) value;
-(GeneralGUI_Image*) _logo;
-(GeneralGUI_Image*) initial_logo;
-(void) set_logo:(GeneralGUI_Image*) value;

-(void) event_closeWIndow_pushed:(PropertyChangeList*) changes ;


@end


