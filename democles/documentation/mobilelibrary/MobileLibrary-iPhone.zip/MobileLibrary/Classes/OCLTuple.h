#include <Foundation/Foundation.h>
#import "OCLAny.h"

@interface OCLTuple : OCLAny {
	@private
	NSMutableDictionary* dict;
}

-(OCLTuple*)init;
-(void)dealloc;

-(void)addItemNamed:(NSString*)name withValue:(OCLAny*)value;
-(OCLAny*)remove:(NSString*)name;
-(NSEnumerator*)keyEnumerator;
-(OCLAny*)objectForKey:(NSString*)key;


// NSObject methods
-(NSString*)description;
-(BOOL)isEqual:(id)other;

@end

