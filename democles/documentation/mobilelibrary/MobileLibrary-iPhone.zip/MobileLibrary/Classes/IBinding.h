#import <Foundation/Foundation.h>

@class OCLAny;
@class OCLTuple;
@protocol OCLAny;

@protocol IBinding <NSObject>

/*
-(id)init:(OCLAny*)instance;
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters;	// TODO need sequence nr?
-(void)onPropertyChange:(NSString*)propertyName newValue:(id<OCLAny>)value;
-(OCLAny*)getInstance;
*/

// For FTL strategy
-(id) getBinding;
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value;
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters;
-(void) onPropertyChange: (NSString*)propertyName newValue:(id<OCLAny>)value;

@end
