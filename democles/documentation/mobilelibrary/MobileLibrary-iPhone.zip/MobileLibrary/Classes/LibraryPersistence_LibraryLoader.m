 
 
 
#import "LibraryPersistence_LibraryLoader.h"
#import "PropertyChangeList.h"
#import "Library_Library.h"
#import "Library_Author.h"
#import "LibraryPersistence_LibraryLoader.h"
#import "Library_Member.h"
#import "StringUtils_StringTokenizer.h"
#import "Library_Book.h"
#import "Persistence_FileHandler.h"
#import "Library_Copy.h"
#import "Application_Main.h"


 
@implementation LibraryPersistence_LibraryLoader

 
- (LibraryPersistence_LibraryLoader*) init {
	self = [super init];
	 
	self->Application_Main_libraryFileHandler_back = [[NSMutableArray alloc] init];

	[self set_books: [self _books]];
	[self set_bookFileHandler: [self _bookFileHandler]];
	[self set_bookStringTokenizer: [self _bookStringTokenizer]];
	[self set_authors: [self _authors]];
	[self set_authorStringTokenizer: [self _authorStringTokenizer]];
	[self set_authorFileHandler: [self _authorFileHandler]];
	[self set_copyFileHandler: [self _copyFileHandler]];
	[self set_copyStringTokenizer: [self _copyStringTokenizer]];
	[self set_copies: [self _copies]];
	[self set_memberFileHandler: [self _memberFileHandler]];
	[self set_memberStringTokenizer: [self _memberStringTokenizer]];
	[self set_members: [self _members]];
	[self set_saveCopiesFileHandler: [self _saveCopiesFileHandler]];
	[self set_borrowsFileHandler: [self _borrowsFileHandler]];
	[self set_borrowsStringTokenizer: [self _borrowsStringTokenizer]];
	[self set_toCollectFileHandler: [self _toCollectFileHandler]];
	[self set_toCollectStringTokenizer: [self _toCollectStringTokenizer]];
	[self set_saveBorrowsFileHandler: [self _saveBorrowsFileHandler]];
	[self set_saveToCollectFileHandler: [self _saveToCollectFileHandler]];

	return self;
}

 
- (LibraryPersistence_LibraryLoader*) initWithValues: (OCLTuple*) values {
	self = [super init];
	 
	self->_books_initialized = NO;
	self->_bookFileHandler_initialized = NO;
	self->_bookStringTokenizer_initialized = NO;
	self->_authors_initialized = NO;
	self->_authorStringTokenizer_initialized = NO;
	self->_authorFileHandler_initialized = NO;
	self->_copyFileHandler_initialized = NO;
	self->_copyStringTokenizer_initialized = NO;
	self->_copies_initialized = NO;
	self->_memberFileHandler_initialized = NO;
	self->_memberStringTokenizer_initialized = NO;
	self->_members_initialized = NO;
	self->_saveCopiesFileHandler_initialized = NO;
	self->_borrowsFileHandler_initialized = NO;
	self->_borrowsStringTokenizer_initialized = NO;
	self->_toCollectFileHandler_initialized = NO;
	self->_toCollectStringTokenizer_initialized = NO;
	self->_saveBorrowsFileHandler_initialized = NO;
	self->_saveToCollectFileHandler_initialized = NO;

	self->Application_Main_libraryFileHandler_back = [[NSMutableArray alloc] init];

	OCLSet* _books_initialValue = (OCLSet*) [values objectForKey:@"books"];
	if (_books_initialValue == nil) {
		_books_initialValue = [self _books];
	}
	[self set_books:_books_initialValue];
	Persistence_FileHandler* _bookFileHandler_initialValue = (Persistence_FileHandler*) [values objectForKey:@"bookFileHandler"];
	if (_bookFileHandler_initialValue == nil) {
		_bookFileHandler_initialValue = [self _bookFileHandler];
	}
	[self set_bookFileHandler:_bookFileHandler_initialValue];
	StringUtils_StringTokenizer* _bookStringTokenizer_initialValue = (StringUtils_StringTokenizer*) [values objectForKey:@"bookStringTokenizer"];
	if (_bookStringTokenizer_initialValue == nil) {
		_bookStringTokenizer_initialValue = [self _bookStringTokenizer];
	}
	[self set_bookStringTokenizer:_bookStringTokenizer_initialValue];
	OCLSet* _authors_initialValue = (OCLSet*) [values objectForKey:@"authors"];
	if (_authors_initialValue == nil) {
		_authors_initialValue = [self _authors];
	}
	[self set_authors:_authors_initialValue];
	StringUtils_StringTokenizer* _authorStringTokenizer_initialValue = (StringUtils_StringTokenizer*) [values objectForKey:@"authorStringTokenizer"];
	if (_authorStringTokenizer_initialValue == nil) {
		_authorStringTokenizer_initialValue = [self _authorStringTokenizer];
	}
	[self set_authorStringTokenizer:_authorStringTokenizer_initialValue];
	Persistence_FileHandler* _authorFileHandler_initialValue = (Persistence_FileHandler*) [values objectForKey:@"authorFileHandler"];
	if (_authorFileHandler_initialValue == nil) {
		_authorFileHandler_initialValue = [self _authorFileHandler];
	}
	[self set_authorFileHandler:_authorFileHandler_initialValue];
	Persistence_FileHandler* _copyFileHandler_initialValue = (Persistence_FileHandler*) [values objectForKey:@"copyFileHandler"];
	if (_copyFileHandler_initialValue == nil) {
		_copyFileHandler_initialValue = [self _copyFileHandler];
	}
	[self set_copyFileHandler:_copyFileHandler_initialValue];
	StringUtils_StringTokenizer* _copyStringTokenizer_initialValue = (StringUtils_StringTokenizer*) [values objectForKey:@"copyStringTokenizer"];
	if (_copyStringTokenizer_initialValue == nil) {
		_copyStringTokenizer_initialValue = [self _copyStringTokenizer];
	}
	[self set_copyStringTokenizer:_copyStringTokenizer_initialValue];
	OCLSet* _copies_initialValue = (OCLSet*) [values objectForKey:@"copies"];
	if (_copies_initialValue == nil) {
		_copies_initialValue = [self _copies];
	}
	[self set_copies:_copies_initialValue];
	Persistence_FileHandler* _memberFileHandler_initialValue = (Persistence_FileHandler*) [values objectForKey:@"memberFileHandler"];
	if (_memberFileHandler_initialValue == nil) {
		_memberFileHandler_initialValue = [self _memberFileHandler];
	}
	[self set_memberFileHandler:_memberFileHandler_initialValue];
	StringUtils_StringTokenizer* _memberStringTokenizer_initialValue = (StringUtils_StringTokenizer*) [values objectForKey:@"memberStringTokenizer"];
	if (_memberStringTokenizer_initialValue == nil) {
		_memberStringTokenizer_initialValue = [self _memberStringTokenizer];
	}
	[self set_memberStringTokenizer:_memberStringTokenizer_initialValue];
	OCLSet* _members_initialValue = (OCLSet*) [values objectForKey:@"members"];
	if (_members_initialValue == nil) {
		_members_initialValue = [self _members];
	}
	[self set_members:_members_initialValue];
	Persistence_FileHandler* _saveCopiesFileHandler_initialValue = (Persistence_FileHandler*) [values objectForKey:@"saveCopiesFileHandler"];
	if (_saveCopiesFileHandler_initialValue == nil) {
		_saveCopiesFileHandler_initialValue = [self _saveCopiesFileHandler];
	}
	[self set_saveCopiesFileHandler:_saveCopiesFileHandler_initialValue];
	Persistence_FileHandler* _borrowsFileHandler_initialValue = (Persistence_FileHandler*) [values objectForKey:@"borrowsFileHandler"];
	if (_borrowsFileHandler_initialValue == nil) {
		_borrowsFileHandler_initialValue = [self _borrowsFileHandler];
	}
	[self set_borrowsFileHandler:_borrowsFileHandler_initialValue];
	StringUtils_StringTokenizer* _borrowsStringTokenizer_initialValue = (StringUtils_StringTokenizer*) [values objectForKey:@"borrowsStringTokenizer"];
	if (_borrowsStringTokenizer_initialValue == nil) {
		_borrowsStringTokenizer_initialValue = [self _borrowsStringTokenizer];
	}
	[self set_borrowsStringTokenizer:_borrowsStringTokenizer_initialValue];
	Persistence_FileHandler* _toCollectFileHandler_initialValue = (Persistence_FileHandler*) [values objectForKey:@"toCollectFileHandler"];
	if (_toCollectFileHandler_initialValue == nil) {
		_toCollectFileHandler_initialValue = [self _toCollectFileHandler];
	}
	[self set_toCollectFileHandler:_toCollectFileHandler_initialValue];
	StringUtils_StringTokenizer* _toCollectStringTokenizer_initialValue = (StringUtils_StringTokenizer*) [values objectForKey:@"toCollectStringTokenizer"];
	if (_toCollectStringTokenizer_initialValue == nil) {
		_toCollectStringTokenizer_initialValue = [self _toCollectStringTokenizer];
	}
	[self set_toCollectStringTokenizer:_toCollectStringTokenizer_initialValue];
	Persistence_FileHandler* _saveBorrowsFileHandler_initialValue = (Persistence_FileHandler*) [values objectForKey:@"saveBorrowsFileHandler"];
	if (_saveBorrowsFileHandler_initialValue == nil) {
		_saveBorrowsFileHandler_initialValue = [self _saveBorrowsFileHandler];
	}
	[self set_saveBorrowsFileHandler:_saveBorrowsFileHandler_initialValue];
	Persistence_FileHandler* _saveToCollectFileHandler_initialValue = (Persistence_FileHandler*) [values objectForKey:@"saveToCollectFileHandler"];
	if (_saveToCollectFileHandler_initialValue == nil) {
		_saveToCollectFileHandler_initialValue = [self _saveToCollectFileHandler];
	}
	[self set_saveToCollectFileHandler:_saveToCollectFileHandler_initialValue];

	
	return self;
}

 
- (void) dealloc {
	if (self->_books != nil && self->_books != (OCLSet*) [NSNull null]) [self->_books release];
	if (self->_bookFileHandler != nil && self->_bookFileHandler != (Persistence_FileHandler*) [NSNull null]) [self->_bookFileHandler release];
	if (self->_bookStringTokenizer != nil && self->_bookStringTokenizer != (StringUtils_StringTokenizer*) [NSNull null]) [self->_bookStringTokenizer release];
	if (self->_authors != nil && self->_authors != (OCLSet*) [NSNull null]) [self->_authors release];
	if (self->_authorStringTokenizer != nil && self->_authorStringTokenizer != (StringUtils_StringTokenizer*) [NSNull null]) [self->_authorStringTokenizer release];
	if (self->_authorFileHandler != nil && self->_authorFileHandler != (Persistence_FileHandler*) [NSNull null]) [self->_authorFileHandler release];
	if (self->_copyFileHandler != nil && self->_copyFileHandler != (Persistence_FileHandler*) [NSNull null]) [self->_copyFileHandler release];
	if (self->_copyStringTokenizer != nil && self->_copyStringTokenizer != (StringUtils_StringTokenizer*) [NSNull null]) [self->_copyStringTokenizer release];
	if (self->_copies != nil && self->_copies != (OCLSet*) [NSNull null]) [self->_copies release];
	if (self->_memberFileHandler != nil && self->_memberFileHandler != (Persistence_FileHandler*) [NSNull null]) [self->_memberFileHandler release];
	if (self->_memberStringTokenizer != nil && self->_memberStringTokenizer != (StringUtils_StringTokenizer*) [NSNull null]) [self->_memberStringTokenizer release];
	if (self->_members != nil && self->_members != (OCLSet*) [NSNull null]) [self->_members release];
	if (self->_saveCopiesFileHandler != nil && self->_saveCopiesFileHandler != (Persistence_FileHandler*) [NSNull null]) [self->_saveCopiesFileHandler release];
	if (self->_borrowsFileHandler != nil && self->_borrowsFileHandler != (Persistence_FileHandler*) [NSNull null]) [self->_borrowsFileHandler release];
	if (self->_borrowsStringTokenizer != nil && self->_borrowsStringTokenizer != (StringUtils_StringTokenizer*) [NSNull null]) [self->_borrowsStringTokenizer release];
	if (self->_toCollectFileHandler != nil && self->_toCollectFileHandler != (Persistence_FileHandler*) [NSNull null]) [self->_toCollectFileHandler release];
	if (self->_toCollectStringTokenizer != nil && self->_toCollectStringTokenizer != (StringUtils_StringTokenizer*) [NSNull null]) [self->_toCollectStringTokenizer release];
	if (self->_saveBorrowsFileHandler != nil && self->_saveBorrowsFileHandler != (Persistence_FileHandler*) [NSNull null]) [self->_saveBorrowsFileHandler release];
	if (self->_saveToCollectFileHandler != nil && self->_saveToCollectFileHandler != (Persistence_FileHandler*) [NSNull null]) [self->_saveToCollectFileHandler release];

	[self->Application_Main_libraryFileHandler_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"LibraryPersistence::LibraryLoader\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"books\" type=\"Set\">\n"];
	[res appendFormat:@"%@\n", [self _books]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"bookFileHandler\" type=\"Persistence::FileHandler\">\n"];
	[res appendFormat:@"%@\n", [self _bookFileHandler]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"bookStringTokenizer\" type=\"StringUtils::StringTokenizer\">\n"];
	[res appendFormat:@"%@\n", [self _bookStringTokenizer]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"authors\" type=\"Set\">\n"];
	[res appendFormat:@"%@\n", [self _authors]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"authorStringTokenizer\" type=\"StringUtils::StringTokenizer\">\n"];
	[res appendFormat:@"%@\n", [self _authorStringTokenizer]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"authorFileHandler\" type=\"Persistence::FileHandler\">\n"];
	[res appendFormat:@"%@\n", [self _authorFileHandler]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"copyFileHandler\" type=\"Persistence::FileHandler\">\n"];
	[res appendFormat:@"%@\n", [self _copyFileHandler]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"copyStringTokenizer\" type=\"StringUtils::StringTokenizer\">\n"];
	[res appendFormat:@"%@\n", [self _copyStringTokenizer]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"copies\" type=\"Set\">\n"];
	[res appendFormat:@"%@\n", [self _copies]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"memberFileHandler\" type=\"Persistence::FileHandler\">\n"];
	[res appendFormat:@"%@\n", [self _memberFileHandler]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"memberStringTokenizer\" type=\"StringUtils::StringTokenizer\">\n"];
	[res appendFormat:@"%@\n", [self _memberStringTokenizer]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"members\" type=\"Set\">\n"];
	[res appendFormat:@"%@\n", [self _members]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"saveCopiesFileHandler\" type=\"Persistence::FileHandler\">\n"];
	[res appendFormat:@"%@\n", [self _saveCopiesFileHandler]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"borrowsFileHandler\" type=\"Persistence::FileHandler\">\n"];
	[res appendFormat:@"%@\n", [self _borrowsFileHandler]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"borrowsStringTokenizer\" type=\"StringUtils::StringTokenizer\">\n"];
	[res appendFormat:@"%@\n", [self _borrowsStringTokenizer]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"toCollectFileHandler\" type=\"Persistence::FileHandler\">\n"];
	[res appendFormat:@"%@\n", [self _toCollectFileHandler]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"toCollectStringTokenizer\" type=\"StringUtils::StringTokenizer\">\n"];
	[res appendFormat:@"%@\n", [self _toCollectStringTokenizer]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"saveBorrowsFileHandler\" type=\"Persistence::FileHandler\">\n"];
	[res appendFormat:@"%@\n", [self _saveBorrowsFileHandler]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"saveToCollectFileHandler\" type=\"Persistence::FileHandler\">\n"];
	[res appendFormat:@"%@\n", [self _saveToCollectFileHandler]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
-(OCLSet*) initial_books {
	/* ==================================================
	 * Set { }
	 * ================================================== */
	
	OCLSet* v0 = [(OCLSet*)[OCLSet alloc] init];
	
	return v0;
}

-(OCLSet*) _books {
	if (self->_books_initialized == YES) {
		return _books;
	} else { 
		[self set_books:[self initial_books]];
	}

	self->_books_initialized = YES;
	return _books;
}
-(Persistence_FileHandler*) initial_bookFileHandler {
	/* ==================================================
	 * Persistence::FileHandler::create()
	 * ================================================== */
	
	Persistence_FileHandler* v0 = [(Persistence_FileHandler*)[Persistence_FileHandler alloc] init];
	
	return v0;
}

-(Persistence_FileHandler*) _bookFileHandler {
	if (self->_bookFileHandler_initialized == YES) {
		return _bookFileHandler;
	} else { 
		[self set_bookFileHandler:[self initial_bookFileHandler]];
	}

	self->_bookFileHandler_initialized = YES;
	return _bookFileHandler;
}
-(StringUtils_StringTokenizer*) initial_bookStringTokenizer {
	/* ==================================================
	 * StringUtils::StringTokenizer::create()
	 * ================================================== */
	
	StringUtils_StringTokenizer* v0 = [(StringUtils_StringTokenizer*)[StringUtils_StringTokenizer alloc] init];
	
	return v0;
}

-(StringUtils_StringTokenizer*) _bookStringTokenizer {
	if (self->_bookStringTokenizer_initialized == YES) {
		return _bookStringTokenizer;
	} else { 
		[self set_bookStringTokenizer:[self initial_bookStringTokenizer]];
	}

	self->_bookStringTokenizer_initialized = YES;
	return _bookStringTokenizer;
}
-(OCLSet*) initial_authors {
	/* ==================================================
	 * Set {}
	 * ================================================== */
	
	OCLSet* v0 = [(OCLSet*)[OCLSet alloc] init];
	
	return v0;
}

-(OCLSet*) _authors {
	if (self->_authors_initialized == YES) {
		return _authors;
	} else { 
		[self set_authors:[self initial_authors]];
	}

	self->_authors_initialized = YES;
	return _authors;
}
-(StringUtils_StringTokenizer*) initial_authorStringTokenizer {
	/* ==================================================
	 * StringUtils::StringTokenizer::create()
	 * ================================================== */
	
	StringUtils_StringTokenizer* v0 = [(StringUtils_StringTokenizer*)[StringUtils_StringTokenizer alloc] init];
	
	return v0;
}

-(StringUtils_StringTokenizer*) _authorStringTokenizer {
	if (self->_authorStringTokenizer_initialized == YES) {
		return _authorStringTokenizer;
	} else { 
		[self set_authorStringTokenizer:[self initial_authorStringTokenizer]];
	}

	self->_authorStringTokenizer_initialized = YES;
	return _authorStringTokenizer;
}
-(Persistence_FileHandler*) initial_authorFileHandler {
	/* ==================================================
	 * Persistence::FileHandler::create()
	 * ================================================== */
	
	Persistence_FileHandler* v0 = [(Persistence_FileHandler*)[Persistence_FileHandler alloc] init];
	
	return v0;
}

-(Persistence_FileHandler*) _authorFileHandler {
	if (self->_authorFileHandler_initialized == YES) {
		return _authorFileHandler;
	} else { 
		[self set_authorFileHandler:[self initial_authorFileHandler]];
	}

	self->_authorFileHandler_initialized = YES;
	return _authorFileHandler;
}
-(Persistence_FileHandler*) initial_copyFileHandler {
	/* ==================================================
	 * Persistence::FileHandler::create()
	 * ================================================== */
	
	Persistence_FileHandler* v0 = [(Persistence_FileHandler*)[Persistence_FileHandler alloc] init];
	
	return v0;
}

-(Persistence_FileHandler*) _copyFileHandler {
	if (self->_copyFileHandler_initialized == YES) {
		return _copyFileHandler;
	} else { 
		[self set_copyFileHandler:[self initial_copyFileHandler]];
	}

	self->_copyFileHandler_initialized = YES;
	return _copyFileHandler;
}
-(StringUtils_StringTokenizer*) initial_copyStringTokenizer {
	/* ==================================================
	 * StringUtils::StringTokenizer::create()
	 * ================================================== */
	
	StringUtils_StringTokenizer* v0 = [(StringUtils_StringTokenizer*)[StringUtils_StringTokenizer alloc] init];
	
	return v0;
}

-(StringUtils_StringTokenizer*) _copyStringTokenizer {
	if (self->_copyStringTokenizer_initialized == YES) {
		return _copyStringTokenizer;
	} else { 
		[self set_copyStringTokenizer:[self initial_copyStringTokenizer]];
	}

	self->_copyStringTokenizer_initialized = YES;
	return _copyStringTokenizer;
}
-(OCLSet*) initial_copies {
	/* ==================================================
	 * Set { }
	 * ================================================== */
	
	OCLSet* v0 = [(OCLSet*)[OCLSet alloc] init];
	
	return v0;
}

-(OCLSet*) _copies {
	if (self->_copies_initialized == YES) {
		return _copies;
	} else { 
		[self set_copies:[self initial_copies]];
	}

	self->_copies_initialized = YES;
	return _copies;
}
-(Persistence_FileHandler*) initial_memberFileHandler {
	/* ==================================================
	 * Persistence::FileHandler::create()
	 * ================================================== */
	
	Persistence_FileHandler* v0 = [(Persistence_FileHandler*)[Persistence_FileHandler alloc] init];
	
	return v0;
}

-(Persistence_FileHandler*) _memberFileHandler {
	if (self->_memberFileHandler_initialized == YES) {
		return _memberFileHandler;
	} else { 
		[self set_memberFileHandler:[self initial_memberFileHandler]];
	}

	self->_memberFileHandler_initialized = YES;
	return _memberFileHandler;
}
-(StringUtils_StringTokenizer*) initial_memberStringTokenizer {
	/* ==================================================
	 * StringUtils::StringTokenizer::create()
	 * ================================================== */
	
	StringUtils_StringTokenizer* v0 = [(StringUtils_StringTokenizer*)[StringUtils_StringTokenizer alloc] init];
	
	return v0;
}

-(StringUtils_StringTokenizer*) _memberStringTokenizer {
	if (self->_memberStringTokenizer_initialized == YES) {
		return _memberStringTokenizer;
	} else { 
		[self set_memberStringTokenizer:[self initial_memberStringTokenizer]];
	}

	self->_memberStringTokenizer_initialized = YES;
	return _memberStringTokenizer;
}
-(OCLSet*) initial_members {
	/* ==================================================
	 * Set { }
	 * ================================================== */
	
	OCLSet* v0 = [(OCLSet*)[OCLSet alloc] init];
	
	return v0;
}

-(OCLSet*) _members {
	if (self->_members_initialized == YES) {
		return _members;
	} else { 
		[self set_members:[self initial_members]];
	}

	self->_members_initialized = YES;
	return _members;
}
-(Persistence_FileHandler*) initial_saveCopiesFileHandler {
	/* ==================================================
	 * Persistence::FileHandler::create()
	 * ================================================== */
	
	Persistence_FileHandler* v0 = [(Persistence_FileHandler*)[Persistence_FileHandler alloc] init];
	
	return v0;
}

-(Persistence_FileHandler*) _saveCopiesFileHandler {
	if (self->_saveCopiesFileHandler_initialized == YES) {
		return _saveCopiesFileHandler;
	} else { 
		[self set_saveCopiesFileHandler:[self initial_saveCopiesFileHandler]];
	}

	self->_saveCopiesFileHandler_initialized = YES;
	return _saveCopiesFileHandler;
}
-(Persistence_FileHandler*) initial_borrowsFileHandler {
	/* ==================================================
	 * Persistence::FileHandler::create()
	 * ================================================== */
	
	Persistence_FileHandler* v0 = [(Persistence_FileHandler*)[Persistence_FileHandler alloc] init];
	
	return v0;
}

-(Persistence_FileHandler*) _borrowsFileHandler {
	if (self->_borrowsFileHandler_initialized == YES) {
		return _borrowsFileHandler;
	} else { 
		[self set_borrowsFileHandler:[self initial_borrowsFileHandler]];
	}

	self->_borrowsFileHandler_initialized = YES;
	return _borrowsFileHandler;
}
-(StringUtils_StringTokenizer*) initial_borrowsStringTokenizer {
	/* ==================================================
	 * StringUtils::StringTokenizer::create()
	 * ================================================== */
	
	StringUtils_StringTokenizer* v0 = [(StringUtils_StringTokenizer*)[StringUtils_StringTokenizer alloc] init];
	
	return v0;
}

-(StringUtils_StringTokenizer*) _borrowsStringTokenizer {
	if (self->_borrowsStringTokenizer_initialized == YES) {
		return _borrowsStringTokenizer;
	} else { 
		[self set_borrowsStringTokenizer:[self initial_borrowsStringTokenizer]];
	}

	self->_borrowsStringTokenizer_initialized = YES;
	return _borrowsStringTokenizer;
}
-(Persistence_FileHandler*) initial_toCollectFileHandler {
	/* ==================================================
	 * Persistence::FileHandler::create()
	 * ================================================== */
	
	Persistence_FileHandler* v0 = [(Persistence_FileHandler*)[Persistence_FileHandler alloc] init];
	
	return v0;
}

-(Persistence_FileHandler*) _toCollectFileHandler {
	if (self->_toCollectFileHandler_initialized == YES) {
		return _toCollectFileHandler;
	} else { 
		[self set_toCollectFileHandler:[self initial_toCollectFileHandler]];
	}

	self->_toCollectFileHandler_initialized = YES;
	return _toCollectFileHandler;
}
-(StringUtils_StringTokenizer*) initial_toCollectStringTokenizer {
	/* ==================================================
	 * StringUtils::StringTokenizer::create()
	 * ================================================== */
	
	StringUtils_StringTokenizer* v0 = [(StringUtils_StringTokenizer*)[StringUtils_StringTokenizer alloc] init];
	
	return v0;
}

-(StringUtils_StringTokenizer*) _toCollectStringTokenizer {
	if (self->_toCollectStringTokenizer_initialized == YES) {
		return _toCollectStringTokenizer;
	} else { 
		[self set_toCollectStringTokenizer:[self initial_toCollectStringTokenizer]];
	}

	self->_toCollectStringTokenizer_initialized = YES;
	return _toCollectStringTokenizer;
}
-(Persistence_FileHandler*) initial_saveBorrowsFileHandler {
	/* ==================================================
	 * Persistence::FileHandler::create()
	 * ================================================== */
	
	Persistence_FileHandler* v0 = [(Persistence_FileHandler*)[Persistence_FileHandler alloc] init];
	
	return v0;
}

-(Persistence_FileHandler*) _saveBorrowsFileHandler {
	if (self->_saveBorrowsFileHandler_initialized == YES) {
		return _saveBorrowsFileHandler;
	} else { 
		[self set_saveBorrowsFileHandler:[self initial_saveBorrowsFileHandler]];
	}

	self->_saveBorrowsFileHandler_initialized = YES;
	return _saveBorrowsFileHandler;
}
-(Persistence_FileHandler*) initial_saveToCollectFileHandler {
	/* ==================================================
	 * Persistence::FileHandler::create()
	 * ================================================== */
	
	Persistence_FileHandler* v0 = [(Persistence_FileHandler*)[Persistence_FileHandler alloc] init];
	
	return v0;
}

-(Persistence_FileHandler*) _saveToCollectFileHandler {
	if (self->_saveToCollectFileHandler_initialized == YES) {
		return _saveToCollectFileHandler;
	} else { 
		[self set_saveToCollectFileHandler:[self initial_saveToCollectFileHandler]];
	}

	self->_saveToCollectFileHandler_initialized = YES;
	return _saveToCollectFileHandler;
}


 


-(void) set_bookFileHandler:(Persistence_FileHandler*) value {
	 
	if (self->_bookFileHandler!= nil && self->_bookFileHandler!= (Persistence_FileHandler*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_bookFileHandler valueForKey:@"LibraryPersistence_LibraryLoader_bookFileHandler_back"];
		[backpointers removeObject:self];
		[self->_bookFileHandler release];
	}
	self->_bookFileHandler = value;
	if (self->_bookFileHandler!= nil && self->_bookFileHandler!= (Persistence_FileHandler*) [NSNull null]) {
		[self->_bookFileHandler retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_bookFileHandler valueForKey:@"LibraryPersistence_LibraryLoader_bookFileHandler_back"];
		[backpointers addObject:self];
	}
	self->_bookFileHandler_initialized = YES;

}
-(void) set_bookStringTokenizer:(StringUtils_StringTokenizer*) value {
	 
	if (self->_bookStringTokenizer!= nil && self->_bookStringTokenizer!= (StringUtils_StringTokenizer*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_bookStringTokenizer valueForKey:@"LibraryPersistence_LibraryLoader_bookStringTokenizer_back"];
		[backpointers removeObject:self];
		[self->_bookStringTokenizer release];
	}
	self->_bookStringTokenizer = value;
	if (self->_bookStringTokenizer!= nil && self->_bookStringTokenizer!= (StringUtils_StringTokenizer*) [NSNull null]) {
		[self->_bookStringTokenizer retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_bookStringTokenizer valueForKey:@"LibraryPersistence_LibraryLoader_bookStringTokenizer_back"];
		[backpointers addObject:self];
	}
	self->_bookStringTokenizer_initialized = YES;

}
-(void) set_authorStringTokenizer:(StringUtils_StringTokenizer*) value {
	 
	if (self->_authorStringTokenizer!= nil && self->_authorStringTokenizer!= (StringUtils_StringTokenizer*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_authorStringTokenizer valueForKey:@"LibraryPersistence_LibraryLoader_authorStringTokenizer_back"];
		[backpointers removeObject:self];
		[self->_authorStringTokenizer release];
	}
	self->_authorStringTokenizer = value;
	if (self->_authorStringTokenizer!= nil && self->_authorStringTokenizer!= (StringUtils_StringTokenizer*) [NSNull null]) {
		[self->_authorStringTokenizer retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_authorStringTokenizer valueForKey:@"LibraryPersistence_LibraryLoader_authorStringTokenizer_back"];
		[backpointers addObject:self];
	}
	self->_authorStringTokenizer_initialized = YES;

}
-(void) set_authorFileHandler:(Persistence_FileHandler*) value {
	 
	if (self->_authorFileHandler!= nil && self->_authorFileHandler!= (Persistence_FileHandler*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_authorFileHandler valueForKey:@"LibraryPersistence_LibraryLoader_authorFileHandler_back"];
		[backpointers removeObject:self];
		[self->_authorFileHandler release];
	}
	self->_authorFileHandler = value;
	if (self->_authorFileHandler!= nil && self->_authorFileHandler!= (Persistence_FileHandler*) [NSNull null]) {
		[self->_authorFileHandler retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_authorFileHandler valueForKey:@"LibraryPersistence_LibraryLoader_authorFileHandler_back"];
		[backpointers addObject:self];
	}
	self->_authorFileHandler_initialized = YES;

}
-(void) set_copyFileHandler:(Persistence_FileHandler*) value {
	 
	if (self->_copyFileHandler!= nil && self->_copyFileHandler!= (Persistence_FileHandler*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_copyFileHandler valueForKey:@"LibraryPersistence_LibraryLoader_copyFileHandler_back"];
		[backpointers removeObject:self];
		[self->_copyFileHandler release];
	}
	self->_copyFileHandler = value;
	if (self->_copyFileHandler!= nil && self->_copyFileHandler!= (Persistence_FileHandler*) [NSNull null]) {
		[self->_copyFileHandler retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_copyFileHandler valueForKey:@"LibraryPersistence_LibraryLoader_copyFileHandler_back"];
		[backpointers addObject:self];
	}
	self->_copyFileHandler_initialized = YES;

}
-(void) set_copyStringTokenizer:(StringUtils_StringTokenizer*) value {
	 
	if (self->_copyStringTokenizer!= nil && self->_copyStringTokenizer!= (StringUtils_StringTokenizer*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_copyStringTokenizer valueForKey:@"LibraryPersistence_LibraryLoader_copyStringTokenizer_back"];
		[backpointers removeObject:self];
		[self->_copyStringTokenizer release];
	}
	self->_copyStringTokenizer = value;
	if (self->_copyStringTokenizer!= nil && self->_copyStringTokenizer!= (StringUtils_StringTokenizer*) [NSNull null]) {
		[self->_copyStringTokenizer retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_copyStringTokenizer valueForKey:@"LibraryPersistence_LibraryLoader_copyStringTokenizer_back"];
		[backpointers addObject:self];
	}
	self->_copyStringTokenizer_initialized = YES;

}
-(void) set_memberFileHandler:(Persistence_FileHandler*) value {
	 
	if (self->_memberFileHandler!= nil && self->_memberFileHandler!= (Persistence_FileHandler*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_memberFileHandler valueForKey:@"LibraryPersistence_LibraryLoader_memberFileHandler_back"];
		[backpointers removeObject:self];
		[self->_memberFileHandler release];
	}
	self->_memberFileHandler = value;
	if (self->_memberFileHandler!= nil && self->_memberFileHandler!= (Persistence_FileHandler*) [NSNull null]) {
		[self->_memberFileHandler retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_memberFileHandler valueForKey:@"LibraryPersistence_LibraryLoader_memberFileHandler_back"];
		[backpointers addObject:self];
	}
	self->_memberFileHandler_initialized = YES;

}
-(void) set_memberStringTokenizer:(StringUtils_StringTokenizer*) value {
	 
	if (self->_memberStringTokenizer!= nil && self->_memberStringTokenizer!= (StringUtils_StringTokenizer*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_memberStringTokenizer valueForKey:@"LibraryPersistence_LibraryLoader_memberStringTokenizer_back"];
		[backpointers removeObject:self];
		[self->_memberStringTokenizer release];
	}
	self->_memberStringTokenizer = value;
	if (self->_memberStringTokenizer!= nil && self->_memberStringTokenizer!= (StringUtils_StringTokenizer*) [NSNull null]) {
		[self->_memberStringTokenizer retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_memberStringTokenizer valueForKey:@"LibraryPersistence_LibraryLoader_memberStringTokenizer_back"];
		[backpointers addObject:self];
	}
	self->_memberStringTokenizer_initialized = YES;

}
-(void) set_saveCopiesFileHandler:(Persistence_FileHandler*) value {
	 
	if (self->_saveCopiesFileHandler!= nil && self->_saveCopiesFileHandler!= (Persistence_FileHandler*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_saveCopiesFileHandler valueForKey:@"LibraryPersistence_LibraryLoader_saveCopiesFileHandler_back"];
		[backpointers removeObject:self];
		[self->_saveCopiesFileHandler release];
	}
	self->_saveCopiesFileHandler = value;
	if (self->_saveCopiesFileHandler!= nil && self->_saveCopiesFileHandler!= (Persistence_FileHandler*) [NSNull null]) {
		[self->_saveCopiesFileHandler retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_saveCopiesFileHandler valueForKey:@"LibraryPersistence_LibraryLoader_saveCopiesFileHandler_back"];
		[backpointers addObject:self];
	}
	self->_saveCopiesFileHandler_initialized = YES;

}
-(void) set_borrowsFileHandler:(Persistence_FileHandler*) value {
	 
	if (self->_borrowsFileHandler!= nil && self->_borrowsFileHandler!= (Persistence_FileHandler*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_borrowsFileHandler valueForKey:@"LibraryPersistence_LibraryLoader_borrowsFileHandler_back"];
		[backpointers removeObject:self];
		[self->_borrowsFileHandler release];
	}
	self->_borrowsFileHandler = value;
	if (self->_borrowsFileHandler!= nil && self->_borrowsFileHandler!= (Persistence_FileHandler*) [NSNull null]) {
		[self->_borrowsFileHandler retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_borrowsFileHandler valueForKey:@"LibraryPersistence_LibraryLoader_borrowsFileHandler_back"];
		[backpointers addObject:self];
	}
	self->_borrowsFileHandler_initialized = YES;

}
-(void) set_borrowsStringTokenizer:(StringUtils_StringTokenizer*) value {
	 
	if (self->_borrowsStringTokenizer!= nil && self->_borrowsStringTokenizer!= (StringUtils_StringTokenizer*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_borrowsStringTokenizer valueForKey:@"LibraryPersistence_LibraryLoader_borrowsStringTokenizer_back"];
		[backpointers removeObject:self];
		[self->_borrowsStringTokenizer release];
	}
	self->_borrowsStringTokenizer = value;
	if (self->_borrowsStringTokenizer!= nil && self->_borrowsStringTokenizer!= (StringUtils_StringTokenizer*) [NSNull null]) {
		[self->_borrowsStringTokenizer retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_borrowsStringTokenizer valueForKey:@"LibraryPersistence_LibraryLoader_borrowsStringTokenizer_back"];
		[backpointers addObject:self];
	}
	self->_borrowsStringTokenizer_initialized = YES;

}
-(void) set_toCollectFileHandler:(Persistence_FileHandler*) value {
	 
	if (self->_toCollectFileHandler!= nil && self->_toCollectFileHandler!= (Persistence_FileHandler*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_toCollectFileHandler valueForKey:@"LibraryPersistence_LibraryLoader_toCollectFileHandler_back"];
		[backpointers removeObject:self];
		[self->_toCollectFileHandler release];
	}
	self->_toCollectFileHandler = value;
	if (self->_toCollectFileHandler!= nil && self->_toCollectFileHandler!= (Persistence_FileHandler*) [NSNull null]) {
		[self->_toCollectFileHandler retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_toCollectFileHandler valueForKey:@"LibraryPersistence_LibraryLoader_toCollectFileHandler_back"];
		[backpointers addObject:self];
	}
	self->_toCollectFileHandler_initialized = YES;

}
-(void) set_toCollectStringTokenizer:(StringUtils_StringTokenizer*) value {
	 
	if (self->_toCollectStringTokenizer!= nil && self->_toCollectStringTokenizer!= (StringUtils_StringTokenizer*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_toCollectStringTokenizer valueForKey:@"LibraryPersistence_LibraryLoader_toCollectStringTokenizer_back"];
		[backpointers removeObject:self];
		[self->_toCollectStringTokenizer release];
	}
	self->_toCollectStringTokenizer = value;
	if (self->_toCollectStringTokenizer!= nil && self->_toCollectStringTokenizer!= (StringUtils_StringTokenizer*) [NSNull null]) {
		[self->_toCollectStringTokenizer retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_toCollectStringTokenizer valueForKey:@"LibraryPersistence_LibraryLoader_toCollectStringTokenizer_back"];
		[backpointers addObject:self];
	}
	self->_toCollectStringTokenizer_initialized = YES;

}
-(void) set_saveBorrowsFileHandler:(Persistence_FileHandler*) value {
	 
	if (self->_saveBorrowsFileHandler!= nil && self->_saveBorrowsFileHandler!= (Persistence_FileHandler*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_saveBorrowsFileHandler valueForKey:@"LibraryPersistence_LibraryLoader_saveBorrowsFileHandler_back"];
		[backpointers removeObject:self];
		[self->_saveBorrowsFileHandler release];
	}
	self->_saveBorrowsFileHandler = value;
	if (self->_saveBorrowsFileHandler!= nil && self->_saveBorrowsFileHandler!= (Persistence_FileHandler*) [NSNull null]) {
		[self->_saveBorrowsFileHandler retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_saveBorrowsFileHandler valueForKey:@"LibraryPersistence_LibraryLoader_saveBorrowsFileHandler_back"];
		[backpointers addObject:self];
	}
	self->_saveBorrowsFileHandler_initialized = YES;

}
-(void) set_saveToCollectFileHandler:(Persistence_FileHandler*) value {
	 
	if (self->_saveToCollectFileHandler!= nil && self->_saveToCollectFileHandler!= (Persistence_FileHandler*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_saveToCollectFileHandler valueForKey:@"LibraryPersistence_LibraryLoader_saveToCollectFileHandler_back"];
		[backpointers removeObject:self];
		[self->_saveToCollectFileHandler release];
	}
	self->_saveToCollectFileHandler = value;
	if (self->_saveToCollectFileHandler!= nil && self->_saveToCollectFileHandler!= (Persistence_FileHandler*) [NSNull null]) {
		[self->_saveToCollectFileHandler retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_saveToCollectFileHandler valueForKey:@"LibraryPersistence_LibraryLoader_saveToCollectFileHandler_back"];
		[backpointers addObject:self];
	}
	self->_saveToCollectFileHandler_initialized = YES;

}


-(void) set_books:(OCLSet*) value {
	 
	if (self->_books!= nil && self->_books!= (OCLSet*) [NSNull null]) {
		// Clear back pointer on old instance
		NSEnumerator* e = [self->_books objectEnumerator];
		Library_Book* o;
		while ((o = [e nextObject]) != nil) {
			if (o != (Library_Book*)[NSNull null]) {
				NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)o valueForKey:@"LibraryPersistence_LibraryLoader_books_back"];
				[backpointers removeObject:self];
			}
		}
		[self->_books release];
	}
	self->_books = value;
	if (self->_books!= nil && self->_books!= (OCLSet*) [NSNull null]) {
		[self->_books retain];
		// Add back pointer on new instance
		NSEnumerator* e = [self->_books objectEnumerator];
		Library_Book* o;
		while ((o = [e nextObject]) != nil) {
			if (o != (Library_Book*)[NSNull null]) {
				NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)o valueForKey:@"LibraryPersistence_LibraryLoader_books_back"];
				[backpointers addObject:self];
			}
		}
	}
	self->_books_initialized = YES;

}
-(void) set_authors:(OCLSet*) value {
	 
	if (self->_authors!= nil && self->_authors!= (OCLSet*) [NSNull null]) {
		// Clear back pointer on old instance
		NSEnumerator* e = [self->_authors objectEnumerator];
		Library_Author* o;
		while ((o = [e nextObject]) != nil) {
			if (o != (Library_Author*)[NSNull null]) {
				NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)o valueForKey:@"LibraryPersistence_LibraryLoader_authors_back"];
				[backpointers removeObject:self];
			}
		}
		[self->_authors release];
	}
	self->_authors = value;
	if (self->_authors!= nil && self->_authors!= (OCLSet*) [NSNull null]) {
		[self->_authors retain];
		// Add back pointer on new instance
		NSEnumerator* e = [self->_authors objectEnumerator];
		Library_Author* o;
		while ((o = [e nextObject]) != nil) {
			if (o != (Library_Author*)[NSNull null]) {
				NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)o valueForKey:@"LibraryPersistence_LibraryLoader_authors_back"];
				[backpointers addObject:self];
			}
		}
	}
	self->_authors_initialized = YES;

}
-(void) set_copies:(OCLSet*) value {
	 
	if (self->_copies!= nil && self->_copies!= (OCLSet*) [NSNull null]) {
		// Clear back pointer on old instance
		NSEnumerator* e = [self->_copies objectEnumerator];
		Library_Copy* o;
		while ((o = [e nextObject]) != nil) {
			if (o != (Library_Copy*)[NSNull null]) {
				NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)o valueForKey:@"LibraryPersistence_LibraryLoader_copies_back"];
				[backpointers removeObject:self];
			}
		}
		[self->_copies release];
	}
	self->_copies = value;
	if (self->_copies!= nil && self->_copies!= (OCLSet*) [NSNull null]) {
		[self->_copies retain];
		// Add back pointer on new instance
		NSEnumerator* e = [self->_copies objectEnumerator];
		Library_Copy* o;
		while ((o = [e nextObject]) != nil) {
			if (o != (Library_Copy*)[NSNull null]) {
				NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)o valueForKey:@"LibraryPersistence_LibraryLoader_copies_back"];
				[backpointers addObject:self];
			}
		}
	}
	self->_copies_initialized = YES;

}
-(void) set_members:(OCLSet*) value {
	 
	if (self->_members!= nil && self->_members!= (OCLSet*) [NSNull null]) {
		// Clear back pointer on old instance
		NSEnumerator* e = [self->_members objectEnumerator];
		Library_Member* o;
		while ((o = [e nextObject]) != nil) {
			if (o != (Library_Member*)[NSNull null]) {
				NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)o valueForKey:@"LibraryPersistence_LibraryLoader_members_back"];
				[backpointers removeObject:self];
			}
		}
		[self->_members release];
	}
	self->_members = value;
	if (self->_members!= nil && self->_members!= (OCLSet*) [NSNull null]) {
		[self->_members retain];
		// Add back pointer on new instance
		NSEnumerator* e = [self->_members objectEnumerator];
		Library_Member* o;
		while ((o = [e nextObject]) != nil) {
			if (o != (Library_Member*)[NSNull null]) {
				NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)o valueForKey:@"LibraryPersistence_LibraryLoader_members_back"];
				[backpointers addObject:self];
			}
		}
	}
	self->_members_initialized = YES;

}


 
-(void) event_loadBooks_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_loadBooks", @"LibraryPersistence_LibraryLoader");

		 
		// Trigger Push edges

		if (self->_bookFileHandler != nil && self->_bookFileHandler != (Persistence_FileHandler*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_bookFileHandler];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			Persistence_FileHandler* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * 'BookData.dat'
				 * ================================================== */
				
				OCLString* v1 = [(OCLString*)[OCLString alloc] initWithString:@"BookData.dat"];
				
					OCLString* parameter_p_filename = v1;

					[edge0_target event_openFile_pushed:changes p_filename:parameter_p_filename ];
					[v1 release];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_bookLineRead_pushed:(PropertyChangeList*) changes  p_line: (OCLString*) p_line{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_bookLineRead", @"LibraryPersistence_LibraryLoader");

		 
		// Trigger Push edges

		if (self->_bookStringTokenizer != nil && self->_bookStringTokenizer != (StringUtils_StringTokenizer*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_bookStringTokenizer];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			StringUtils_StringTokenizer* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * line
				 * ================================================== */
				
				OCLString* v1 = p_line;
				
					OCLString* parameter_p_string = v1;
					/* ==================================================
				 * ';'
				 * ================================================== */
				
				OCLString* v2 = [(OCLString*)[OCLString alloc] initWithString:@";"];
				
					OCLString* parameter_p_separator = v2;

					[edge0_target event_tokenizeString_pushed:changes p_string:parameter_p_string p_separator:parameter_p_separator ];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_bookLineRead_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Persistence_FileHandler*)parentInstance p_line:(OCLString*)p_line  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_bookLineRead", @"LibraryPersistence_LibraryLoader", @"_lineread", @"Persistence_FileHandler");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {
		/* ==================================================
		 * line
		 * ================================================== */
		
		OCLString* v1 = p_line;
		
		OCLString* parameter_p_line = v1;

		[self event_bookLineRead_pushed:changes p_line:parameter_p_line ];

	}
	[v0 release];
}


-(void) event_bookFileClosed_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_bookFileClosed", @"LibraryPersistence_LibraryLoader");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {

			[self event_loadCopies_pushed:changes ];
		}
		[v0 release];


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_bookFileClosed_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Persistence_FileHandler*)parentInstance  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_bookFileClosed", @"LibraryPersistence_LibraryLoader", @"_fileClosed", @"Persistence_FileHandler");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {

		[self event_bookFileClosed_pushed:changes ];

	}
	[v0 release];
}


-(void) event_bookLineTokenized_pushed:(PropertyChangeList*) changes  p_tokens: (OCLSequence*) p_tokens{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_bookLineTokenized", @"LibraryPersistence_LibraryLoader");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * books->including(
		 *     Library::Book::create(Tuple {
		 *     	bookId = tokens->at(1),
		 *     	title = tokens->at(2),
		 *     	isbn = tokens->at(3),
		 *     	authors = findAuthors(tokens->subSequence(4, tokens->size())->asSet()),
		 *     	copies = Set { } -- updated later, after copies are loaded
		 *     })
		 * )
		 * 
		 * ================================================== */
		
		LibraryPersistence_LibraryLoader* v2 = self;
		OCLSet* v1 = [v2 _books];
		OCLSequence* v8 = p_tokens;
		OCLInteger* v9 = [(OCLInteger*)[OCLInteger alloc] initWithValue:1];
		OCLString* v7 = ((OCLString*)[v8 at:v9]);
		OCLString* v6 = v7;
		OCLSequence* v12 = p_tokens;
		OCLInteger* v13 = [(OCLInteger*)[OCLInteger alloc] initWithValue:2];
		OCLString* v11 = ((OCLString*)[v12 at:v13]);
		OCLString* v10 = v11;
		OCLSequence* v16 = p_tokens;
		OCLInteger* v17 = [(OCLInteger*)[OCLInteger alloc] initWithValue:3];
		OCLString* v15 = ((OCLString*)[v16 at:v17]);
		OCLString* v14 = v15;
		LibraryPersistence_LibraryLoader* v20 = self;
		OCLSequence* v23 = p_tokens;
		OCLInteger* v24 = [(OCLInteger*)[OCLInteger alloc] initWithValue:4];
		OCLSequence* v26 = p_tokens;
		OCLInteger* v25 = [v26 size];
		OCLSequence* v22 = [v23 subSequence:v24 upper:v25];
		OCLSet* v21 = [v22 asSet];
		OCLSet* v19 = [v20 findAuthors:v21];
		OCLSet* v18 = v19;
		OCLSet* v28 = [(OCLSet*)[OCLSet alloc] init];
		OCLSet* v27 = v28;
		OCLTuple* v5 = [(OCLTuple*)[OCLTuple alloc] init];
		[v5 addItemNamed:@"bookId" withValue:v6];
		[v5 addItemNamed:@"title" withValue:v10];
		[v5 addItemNamed:@"isbn" withValue:v14];
		[v5 addItemNamed:@"authors" withValue:v18];
		[v5 addItemNamed:@"copies" withValue:v27];
		Library_Book* v3 = [(Library_Book*)[Library_Book alloc] initWithValues:v5];
		OCLSet* v0 = [v1 including:v3];
		[v25 release];
		[v17 release];
		[v13 release];
		[v9 release];
		[v3 release];
		[v21 release];
		[v22 release];
		[v28 release];
		[v24 release];
		[v5 release];
		
		OCLSet* _books_newValue = v0;
		[changes addChange:@selector(set_books:) instance:self value:_books_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_bookLineTokenized_pulled_edge0:(PropertyChangeList*)changes parentInstance:(StringUtils_StringTokenizer*)parentInstance p_tokens:(OCLSequence*)p_tokens  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_bookLineTokenized", @"LibraryPersistence_LibraryLoader", @"_stringTokenized", @"StringUtils_StringTokenizer");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {
		/* ==================================================
		 * tokens
		 * ================================================== */
		
		OCLSequence* v1 = p_tokens;
		
		OCLSequence* parameter_p_tokens = v1;

		[self event_bookLineTokenized_pushed:changes p_tokens:parameter_p_tokens ];

	}
	[v0 release];
}


-(void) event_load_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_load", @"LibraryPersistence_LibraryLoader");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {

			[self event_loadAuthors_pushed:changes ];
		}
		[v0 release];


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_loadAuthors_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_loadAuthors", @"LibraryPersistence_LibraryLoader");

		 
		// Trigger Push edges

		if (self->_authorFileHandler != nil && self->_authorFileHandler != (Persistence_FileHandler*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_authorFileHandler];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			Persistence_FileHandler* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * 'AuthorData.dat'
				 * ================================================== */
				
				OCLString* v1 = [(OCLString*)[OCLString alloc] initWithString:@"AuthorData.dat"];
				
					OCLString* parameter_p_filename = v1;

					[edge0_target event_openFile_pushed:changes p_filename:parameter_p_filename ];
					[v1 release];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_authorsLineRead_pushed:(PropertyChangeList*) changes  p_line: (OCLString*) p_line{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_authorsLineRead", @"LibraryPersistence_LibraryLoader");

		 
		// Trigger Push edges

		if (self->_authorStringTokenizer != nil && self->_authorStringTokenizer != (StringUtils_StringTokenizer*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_authorStringTokenizer];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			StringUtils_StringTokenizer* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * line
				 * ================================================== */
				
				OCLString* v1 = p_line;
				
					OCLString* parameter_p_string = v1;
					/* ==================================================
				 * ';'
				 * ================================================== */
				
				OCLString* v2 = [(OCLString*)[OCLString alloc] initWithString:@";"];
				
					OCLString* parameter_p_separator = v2;

					[edge0_target event_tokenizeString_pushed:changes p_string:parameter_p_string p_separator:parameter_p_separator ];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_authorsLineRead_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Persistence_FileHandler*)parentInstance p_line:(OCLString*)p_line  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_authorsLineRead", @"LibraryPersistence_LibraryLoader", @"_lineread", @"Persistence_FileHandler");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {
		/* ==================================================
		 * line
		 * ================================================== */
		
		OCLString* v1 = p_line;
		
		OCLString* parameter_p_line = v1;

		[self event_authorsLineRead_pushed:changes p_line:parameter_p_line ];

	}
	[v0 release];
}


-(void) event_authorsLineTokenized_pushed:(PropertyChangeList*) changes  p_tokens: (OCLSequence*) p_tokens{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_authorsLineTokenized", @"LibraryPersistence_LibraryLoader");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * authors->including(
		 * 	Library::Author::create(Tuple { name = tokens->at(2), authorId = tokens->at(1) })
		 * )
		 * 
		 * ================================================== */
		
		LibraryPersistence_LibraryLoader* v2 = self;
		OCLSet* v1 = [v2 _authors];
		OCLSequence* v8 = p_tokens;
		OCLInteger* v9 = [(OCLInteger*)[OCLInteger alloc] initWithValue:2];
		OCLString* v7 = ((OCLString*)[v8 at:v9]);
		OCLString* v6 = v7;
		OCLSequence* v12 = p_tokens;
		OCLInteger* v13 = [(OCLInteger*)[OCLInteger alloc] initWithValue:1];
		OCLString* v11 = ((OCLString*)[v12 at:v13]);
		OCLString* v10 = v11;
		OCLTuple* v5 = [(OCLTuple*)[OCLTuple alloc] init];
		[v5 addItemNamed:@"name" withValue:v6];
		[v5 addItemNamed:@"authorId" withValue:v10];
		Library_Author* v3 = [(Library_Author*)[Library_Author alloc] initWithValues:v5];
		OCLSet* v0 = [v1 including:v3];
		[v3 release];
		[v5 release];
		[v13 release];
		[v9 release];
		
		OCLSet* _authors_newValue = v0;
		[changes addChange:@selector(set_authors:) instance:self value:_authors_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_authorsLineTokenized_pulled_edge0:(PropertyChangeList*)changes parentInstance:(StringUtils_StringTokenizer*)parentInstance p_tokens:(OCLSequence*)p_tokens  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_authorsLineTokenized", @"LibraryPersistence_LibraryLoader", @"_stringTokenized", @"StringUtils_StringTokenizer");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {
		/* ==================================================
		 * tokens
		 * ================================================== */
		
		OCLSequence* v1 = p_tokens;
		
		OCLSequence* parameter_p_tokens = v1;

		[self event_authorsLineTokenized_pushed:changes p_tokens:parameter_p_tokens ];

	}
	[v0 release];
}


-(void) event_authorsFileClosed_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_authorsFileClosed", @"LibraryPersistence_LibraryLoader");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {

			[self event_loadBooks_pushed:changes ];
		}
		[v0 release];


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_authorsFileClosed_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Persistence_FileHandler*)parentInstance  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_authorsFileClosed", @"LibraryPersistence_LibraryLoader", @"_fileClosed", @"Persistence_FileHandler");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {

		[self event_authorsFileClosed_pushed:changes ];

	}
	[v0 release];
}


-(void) event_copyLineRead_pushed:(PropertyChangeList*) changes  p_line: (OCLString*) p_line{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_copyLineRead", @"LibraryPersistence_LibraryLoader");

		 
		// Trigger Push edges

		if (self->_copyStringTokenizer != nil && self->_copyStringTokenizer != (StringUtils_StringTokenizer*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_copyStringTokenizer];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			StringUtils_StringTokenizer* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * line
				 * ================================================== */
				
				OCLString* v1 = p_line;
				
					OCLString* parameter_p_string = v1;
					/* ==================================================
				 * ';'
				 * ================================================== */
				
				OCLString* v2 = [(OCLString*)[OCLString alloc] initWithString:@";"];
				
					OCLString* parameter_p_separator = v2;

					[edge0_target event_tokenizeString_pushed:changes p_string:parameter_p_string p_separator:parameter_p_separator ];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_copyLineRead_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Persistence_FileHandler*)parentInstance p_line:(OCLString*)p_line  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_copyLineRead", @"LibraryPersistence_LibraryLoader", @"_lineread", @"Persistence_FileHandler");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {
		/* ==================================================
		 * line
		 * ================================================== */
		
		OCLString* v1 = p_line;
		
		OCLString* parameter_p_line = v1;

		[self event_copyLineRead_pushed:changes p_line:parameter_p_line ];

	}
	[v0 release];
}


-(void) event_loadCopies_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_loadCopies", @"LibraryPersistence_LibraryLoader");

		 
		// Trigger Push edges

		if (self->_copyFileHandler != nil && self->_copyFileHandler != (Persistence_FileHandler*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_copyFileHandler];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			Persistence_FileHandler* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * 'CopyData.dat'
				 * ================================================== */
				
				OCLString* v1 = [(OCLString*)[OCLString alloc] initWithString:@"CopyData.dat"];
				
					OCLString* parameter_p_filename = v1;

					[edge0_target event_openFile_pushed:changes p_filename:parameter_p_filename ];
					[v1 release];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_copyLineTokenized_pushed:(PropertyChangeList*) changes  p_tokens: (OCLSequence*) p_tokens{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_copyLineTokenized", @"LibraryPersistence_LibraryLoader");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * copies->including(
		 * 	Library::Copy::create(Tuple {
		 * 		copyId = tokens->at(1),
		 * 		book = findBook(tokens->at(5)), 
		 * 		dueDate = tokens->at(3),
		 * 		renewals = tokens->at(4).toInteger(),
		 * 		state = tokens->at(2) }
		 * 	)
		 * )
		 * ================================================== */
		
		LibraryPersistence_LibraryLoader* v2 = self;
		OCLSet* v1 = [v2 _copies];
		OCLSequence* v8 = p_tokens;
		OCLInteger* v9 = [(OCLInteger*)[OCLInteger alloc] initWithValue:1];
		OCLString* v7 = ((OCLString*)[v8 at:v9]);
		OCLString* v6 = v7;
		LibraryPersistence_LibraryLoader* v12 = self;
		OCLSequence* v14 = p_tokens;
		OCLInteger* v15 = [(OCLInteger*)[OCLInteger alloc] initWithValue:5];
		OCLString* v13 = ((OCLString*)[v14 at:v15]);
		Library_Book* v11 = [v12 findBook:v13];
		Library_Book* v10 = v11;
		OCLSequence* v18 = p_tokens;
		OCLInteger* v19 = [(OCLInteger*)[OCLInteger alloc] initWithValue:3];
		OCLString* v17 = ((OCLString*)[v18 at:v19]);
		OCLString* v16 = v17;
		OCLSequence* v23 = p_tokens;
		OCLInteger* v24 = [(OCLInteger*)[OCLInteger alloc] initWithValue:4];
		OCLString* v22 = ((OCLString*)[v23 at:v24]);
		OCLInteger* v21 = [v22 toInteger];
		OCLInteger* v20 = v21;
		OCLSequence* v27 = p_tokens;
		OCLInteger* v28 = [(OCLInteger*)[OCLInteger alloc] initWithValue:2];
		OCLString* v26 = ((OCLString*)[v27 at:v28]);
		OCLString* v25 = v26;
		OCLTuple* v5 = [(OCLTuple*)[OCLTuple alloc] init];
		[v5 addItemNamed:@"copyId" withValue:v6];
		[v5 addItemNamed:@"book" withValue:v10];
		[v5 addItemNamed:@"dueDate" withValue:v16];
		[v5 addItemNamed:@"renewals" withValue:v20];
		[v5 addItemNamed:@"state" withValue:v25];
		Library_Copy* v3 = [(Library_Copy*)[Library_Copy alloc] initWithValues:v5];
		OCLSet* v0 = [v1 including:v3];
		[v15 release];
		[v9 release];
		[v19 release];
		[v3 release];
		[v28 release];
		[v24 release];
		[v21 release];
		[v5 release];
		
		OCLSet* _copies_newValue = v0;
		[changes addChange:@selector(set_copies:) instance:self value:_copies_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_copyLineTokenized_pulled_edge0:(PropertyChangeList*)changes parentInstance:(StringUtils_StringTokenizer*)parentInstance p_tokens:(OCLSequence*)p_tokens  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_copyLineTokenized", @"LibraryPersistence_LibraryLoader", @"_stringTokenized", @"StringUtils_StringTokenizer");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {
		/* ==================================================
		 * tokens
		 * ================================================== */
		
		OCLSequence* v1 = p_tokens;
		
		OCLSequence* parameter_p_tokens = v1;

		[self event_copyLineTokenized_pushed:changes p_tokens:parameter_p_tokens ];

	}
	[v0 release];
}


-(void) event_copyFileClosed_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_copyFileClosed", @"LibraryPersistence_LibraryLoader");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {

			[self event_updateBookCopies_pushed:changes ];
		}
		[v0 release];


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_copyFileClosed_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Persistence_FileHandler*)parentInstance  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_copyFileClosed", @"LibraryPersistence_LibraryLoader", @"_fileClosed", @"Persistence_FileHandler");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {

		[self event_copyFileClosed_pushed:changes ];

	}
	[v0 release];
}


-(void) event_updateBookCopies_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_updateBookCopies", @"LibraryPersistence_LibraryLoader");

		 
		// Trigger Push edges
		if (self->_books != nil && self->_books != (OCLSet*)[NSNull null]) {
			 
			NSArray* edge0_values = [[self->_books objectEnumerator] allObjects];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			Library_Book* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * copies->select(book = _iter)
				 * 
				 * ================================================== */
				
				OCLSet* v2 = [self _copies];
				OCLSet* v1 = [(OCLSet*)[OCLSet alloc] init];
				NSEnumerator* v1_enum = [v2 objectEnumerator];
				Library_Copy* v3;
				while ((v3 = [v1_enum nextObject]) != nil) {
					Library_Copy* v6 = v3;
					Library_Book* v5 = [v6 _book];
					Library_Book* v7 = edge0_target;
					OCLBoolean* v4 = [v5 eq:v7];
					if (v4->value == YES) { [v1 add: v3]; }
					[v4 release];
				}
				
					OCLSet* parameter_p_copies = v1;

					[edge0_target event_setCopies_pushed:changes p_copies:parameter_p_copies ];
					[v1 release];

				}
				[v0 release];
			}

		}



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {

			[self event_loadMembers_pushed:changes ];
		}
		[v0 release];


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_loadMembers_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_loadMembers", @"LibraryPersistence_LibraryLoader");

		 
		// Trigger Push edges

		if (self->_memberFileHandler != nil && self->_memberFileHandler != (Persistence_FileHandler*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_memberFileHandler];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			Persistence_FileHandler* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * 'MemberData.dat'
				 * ================================================== */
				
				OCLString* v1 = [(OCLString*)[OCLString alloc] initWithString:@"MemberData.dat"];
				
					OCLString* parameter_p_filename = v1;

					[edge0_target event_openFile_pushed:changes p_filename:parameter_p_filename ];
					[v1 release];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_memberLineRead_pushed:(PropertyChangeList*) changes  p_line: (OCLString*) p_line{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_memberLineRead", @"LibraryPersistence_LibraryLoader");

		 
		// Trigger Push edges

		if (self->_memberStringTokenizer != nil && self->_memberStringTokenizer != (StringUtils_StringTokenizer*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_memberStringTokenizer];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			StringUtils_StringTokenizer* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * line
				 * ================================================== */
				
				OCLString* v1 = p_line;
				
					OCLString* parameter_p_string = v1;
					/* ==================================================
				 * ';'
				 * ================================================== */
				
				OCLString* v2 = [(OCLString*)[OCLString alloc] initWithString:@";"];
				
					OCLString* parameter_p_separator = v2;

					[edge0_target event_tokenizeString_pushed:changes p_string:parameter_p_string p_separator:parameter_p_separator ];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_memberLineRead_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Persistence_FileHandler*)parentInstance p_line:(OCLString*)p_line  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_memberLineRead", @"LibraryPersistence_LibraryLoader", @"_lineread", @"Persistence_FileHandler");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {
		/* ==================================================
		 * line
		 * ================================================== */
		
		OCLString* v1 = p_line;
		
		OCLString* parameter_p_line = v1;

		[self event_memberLineRead_pushed:changes p_line:parameter_p_line ];

	}
	[v0 release];
}


-(void) event_memberLineTokenized_pushed:(PropertyChangeList*) changes  p_tokens: (OCLSequence*) p_tokens{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_memberLineTokenized", @"LibraryPersistence_LibraryLoader");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * members->including(
		 * 	Library::Member::create(Tuple {
		 * 		libraryNo = tokens->at(1),
		 * 		password = tokens->at(3),
		 * 		name = tokens->at(2),
		 * 		borrows = Set { },
		 * 		toCollect = Set { }
		 * 	})
		 * )
		 * ================================================== */
		
		LibraryPersistence_LibraryLoader* v2 = self;
		OCLSet* v1 = [v2 _members];
		OCLSequence* v8 = p_tokens;
		OCLInteger* v9 = [(OCLInteger*)[OCLInteger alloc] initWithValue:1];
		OCLString* v7 = ((OCLString*)[v8 at:v9]);
		OCLString* v6 = v7;
		OCLSequence* v12 = p_tokens;
		OCLInteger* v13 = [(OCLInteger*)[OCLInteger alloc] initWithValue:3];
		OCLString* v11 = ((OCLString*)[v12 at:v13]);
		OCLString* v10 = v11;
		OCLSequence* v16 = p_tokens;
		OCLInteger* v17 = [(OCLInteger*)[OCLInteger alloc] initWithValue:2];
		OCLString* v15 = ((OCLString*)[v16 at:v17]);
		OCLString* v14 = v15;
		OCLSet* v19 = [(OCLSet*)[OCLSet alloc] init];
		OCLSet* v18 = v19;
		OCLSet* v21 = [(OCLSet*)[OCLSet alloc] init];
		OCLSet* v20 = v21;
		OCLTuple* v5 = [(OCLTuple*)[OCLTuple alloc] init];
		[v5 addItemNamed:@"libraryNo" withValue:v6];
		[v5 addItemNamed:@"password" withValue:v10];
		[v5 addItemNamed:@"name" withValue:v14];
		[v5 addItemNamed:@"borrows" withValue:v18];
		[v5 addItemNamed:@"toCollect" withValue:v20];
		Library_Member* v3 = [(Library_Member*)[Library_Member alloc] initWithValues:v5];
		OCLSet* v0 = [v1 including:v3];
		[v17 release];
		[v3 release];
		[v19 release];
		[v13 release];
		[v9 release];
		[v5 release];
		[v21 release];
		
		OCLSet* _members_newValue = v0;
		[changes addChange:@selector(set_members:) instance:self value:_members_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_memberLineTokenized_pulled_edge0:(PropertyChangeList*)changes parentInstance:(StringUtils_StringTokenizer*)parentInstance p_tokens:(OCLSequence*)p_tokens  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_memberLineTokenized", @"LibraryPersistence_LibraryLoader", @"_stringTokenized", @"StringUtils_StringTokenizer");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {
		/* ==================================================
		 * tokens
		 * ================================================== */
		
		OCLSequence* v1 = p_tokens;
		
		OCLSequence* parameter_p_tokens = v1;

		[self event_memberLineTokenized_pushed:changes p_tokens:parameter_p_tokens ];

	}
	[v0 release];
}


-(void) event_memberFileClosed_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_memberFileClosed", @"LibraryPersistence_LibraryLoader");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {

			[self event_loadBorrows_pushed:changes ];
		}
		[v0 release];


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_memberFileClosed_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Persistence_FileHandler*)parentInstance  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_memberFileClosed", @"LibraryPersistence_LibraryLoader", @"_fileClosed", @"Persistence_FileHandler");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {

		[self event_memberFileClosed_pushed:changes ];

	}
	[v0 release];
}


-(void) event_libraryLoaded_pushed:(PropertyChangeList*) changes  p_library: (Library_Library*) p_library{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_libraryLoaded", @"LibraryPersistence_LibraryLoader");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges
		NSEnumerator* Application_Main_libraryBooksLoaded_edge0_enum = [self->Application_Main_libraryFileHandler_back objectEnumerator];
		Application_Main* Application_Main_libraryBooksLoaded_edge0_target;
		while ((Application_Main_libraryBooksLoaded_edge0_target = [Application_Main_libraryBooksLoaded_edge0_enum nextObject]) != nil) {
		    [Application_Main_libraryBooksLoaded_edge0_target event_libraryBooksLoaded_pulled_edge0:changes parentInstance:self p_library:p_library ];
		}



		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_saveCopies_pushed:(PropertyChangeList*) changes  p_copies: (OCLSequence*) p_copies{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_saveCopies", @"LibraryPersistence_LibraryLoader");

		 
		// Trigger Push edges

		if (self->_saveCopiesFileHandler != nil && self->_saveCopiesFileHandler != (Persistence_FileHandler*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_saveCopiesFileHandler];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			Persistence_FileHandler* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * 'CopyData.dat'
				 * ================================================== */
				
				OCLString* v1 = [(OCLString*)[OCLString alloc] initWithString:@"CopyData.dat"];
				
					OCLString* parameter_p_filename = v1;
					/* ==================================================
				 * let copyStrings: Sequence(String) =	copies->collect(
				 * 	copyId.concat(';').concat(state).concat(';').concat(dueDate).concat(';').concat(intToString(renewals)).concat(';').concat(book.bookId)
				 * ) in
				 * copyStrings->iterate(line: String; output: String = '' |
				 * 	output.concat(line).concat('\n')
				 * )
				 * 
				 * ================================================== */
				
				OCLSequence* v5 = p_copies;
				OCLSequence* v4_nested = [(OCLSequence*)[OCLSequence alloc] init];
				NSEnumerator* v4_enum = [v5 objectEnumerator];
				Library_Copy* v6;
				while ((v6 = [v4_enum nextObject]) != nil) {
					Library_Copy* v16 = v6;
					OCLString* v15 = [v16 _copyId];
					OCLString* v17 = [(OCLString*)[OCLString alloc] initWithString:@";"];
					OCLString* v14 = [v15 concat:v17];
					Library_Copy* v19 = v6;
					OCLString* v18 = [v19 _state];
					OCLString* v13 = [v14 concat:v18];
					OCLString* v20 = [(OCLString*)[OCLString alloc] initWithString:@";"];
					OCLString* v12 = [v13 concat:v20];
					Library_Copy* v22 = v6;
					OCLString* v21 = [v22 _dueDate];
					OCLString* v11 = [v12 concat:v21];
					OCLString* v23 = [(OCLString*)[OCLString alloc] initWithString:@";"];
					OCLString* v10 = [v11 concat:v23];
					LibraryPersistence_LibraryLoader* v25 = self;
					Library_Copy* v27 = v6;
					OCLInteger* v26 = [v27 _renewals];
					OCLString* v24 = [v25 intToString:v26];
					OCLString* v9 = [v10 concat:v24];
					OCLString* v28 = [(OCLString*)[OCLString alloc] initWithString:@";"];
					OCLString* v8 = [v9 concat:v28];
					Library_Copy* v31 = v6;
					Library_Book* v30 = [v31 _book];
					OCLString* v29 = [v30 _bookId];
					OCLString* v7 = [v8 concat:v29];
					[v4_nested add: v7];
					[v11 release];
					[v12 release];
					[v7 release];
					[v28 release];
					[v8 release];
					[v20 release];
					[v13 release];
					[v9 release];
					[v23 release];
					[v14 release];
					[v10 release];
					[v17 release];
				}
				OCLSequence* v4 = [v4_nested flatten];
				[v4_nested release];
				OCLSequence* v3 = v4;
				OCLSequence* v33 = v3;
				OCLString* v36 = [(OCLString*)[OCLString alloc] initWithString:@""];
				OCLString* v35 = v36;
				NSEnumerator* v32_enum = [v33 objectEnumerator];
				OCLString* v34;
				while ((v34 = [v32_enum nextObject]) != nil) {
					OCLString* v39 = v35;
					OCLString* v40 = v34;
					OCLString* v38 = [v39 concat:v40];
					OCLString* v41 = [(OCLString*)[OCLString alloc] initWithString:@"\n"];
					OCLString* v37 = [v38 concat:v41];
					v35 = v37;
					[v38 release];
					[v41 release];
				}
				OCLString* v32 = v35;
				OCLString* v2 = v32;
				
					OCLString* parameter_p_content = v2;

					[edge0_target event_saveString_pushed:changes p_filename:parameter_p_filename p_content:parameter_p_content ];
					[v1 release];
					[v2 release];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_loadBorrows_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_loadBorrows", @"LibraryPersistence_LibraryLoader");

		 
		// Trigger Push edges

		if (self->_borrowsFileHandler != nil && self->_borrowsFileHandler != (Persistence_FileHandler*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_borrowsFileHandler];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			Persistence_FileHandler* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * 'BorrowsData.dat'
				 * ================================================== */
				
				OCLString* v1 = [(OCLString*)[OCLString alloc] initWithString:@"BorrowsData.dat"];
				
					OCLString* parameter_p_filename = v1;

					[edge0_target event_openFile_pushed:changes p_filename:parameter_p_filename ];
					[v1 release];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_borrowsLineRead_pushed:(PropertyChangeList*) changes  p_line: (OCLString*) p_line{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_borrowsLineRead", @"LibraryPersistence_LibraryLoader");

		 
		// Trigger Push edges

		if (self->_borrowsStringTokenizer != nil && self->_borrowsStringTokenizer != (StringUtils_StringTokenizer*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_borrowsStringTokenizer];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			StringUtils_StringTokenizer* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * line
				 * ================================================== */
				
				OCLString* v1 = p_line;
				
					OCLString* parameter_p_string = v1;
					/* ==================================================
				 * ';'
				 * ================================================== */
				
				OCLString* v2 = [(OCLString*)[OCLString alloc] initWithString:@";"];
				
					OCLString* parameter_p_separator = v2;

					[edge0_target event_tokenizeString_pushed:changes p_string:parameter_p_string p_separator:parameter_p_separator ];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_borrowsLineRead_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Persistence_FileHandler*)parentInstance p_line:(OCLString*)p_line  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_borrowsLineRead", @"LibraryPersistence_LibraryLoader", @"_lineread", @"Persistence_FileHandler");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {
		/* ==================================================
		 * line
		 * ================================================== */
		
		OCLString* v1 = p_line;
		
		OCLString* parameter_p_line = v1;

		[self event_borrowsLineRead_pushed:changes p_line:parameter_p_line ];

	}
	[v0 release];
}


-(void) event_borrowsLineTokenized_pushed:(PropertyChangeList*) changes  p_tokens: (OCLSequence*) p_tokens{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_borrowsLineTokenized", @"LibraryPersistence_LibraryLoader");

		 
		// Trigger Push edges
		if (self->_members != nil && self->_members != (OCLSet*)[NSNull null]) {
			 
			NSArray* edge0_values = [[self->_members objectEnumerator] allObjects];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			Library_Member* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * _iter.libraryNo = tokens->at(1)
			 * ================================================== */
			
			Library_Member* v2 = edge0_target;
			OCLString* v1 = [v2 _libraryNo];
			OCLSequence* v4 = p_tokens;
			OCLInteger* v5 = [(OCLInteger*)[OCLInteger alloc] initWithValue:1];
			OCLString* v3 = ((OCLString*)[v4 at:v5]);
			OCLBoolean* v0 = [v1 eq:v3];
			[v5 release];
			
				if (v0->value == YES) {
					/* ==================================================
				 * _iter.borrows->including(findCopy(tokens->at(2)))
				 * ================================================== */
				
				Library_Member* v8 = edge0_target;
				OCLSet* v7 = [v8 _borrows];
				LibraryPersistence_LibraryLoader* v10 = self;
				OCLSequence* v12 = p_tokens;
				OCLInteger* v13 = [(OCLInteger*)[OCLInteger alloc] initWithValue:2];
				OCLString* v11 = ((OCLString*)[v12 at:v13]);
				Library_Copy* v9 = [v10 findCopy:v11];
				OCLSet* v6 = [v7 including:v9];
				[v13 release];
				
					OCLSet* parameter_p_borrows = v6;

					[edge0_target event_setBorrows_pushed:changes p_borrows:parameter_p_borrows ];
					[v6 release];

				}
				[v0 release];
			}

		}



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_borrowsLineTokenized_pulled_edge0:(PropertyChangeList*)changes parentInstance:(StringUtils_StringTokenizer*)parentInstance p_tokens:(OCLSequence*)p_tokens  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_borrowsLineTokenized", @"LibraryPersistence_LibraryLoader", @"_stringTokenized", @"StringUtils_StringTokenizer");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {
		/* ==================================================
		 * tokens
		 * ================================================== */
		
		OCLSequence* v1 = p_tokens;
		
		OCLSequence* parameter_p_tokens = v1;

		[self event_borrowsLineTokenized_pushed:changes p_tokens:parameter_p_tokens ];

	}
	[v0 release];
}


-(void) event_borrowsFileClosed_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_borrowsFileClosed", @"LibraryPersistence_LibraryLoader");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {

			[self event_loadToCollect_pushed:changes ];
		}
		[v0 release];


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_borrowsFileClosed_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Persistence_FileHandler*)parentInstance  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_borrowsFileClosed", @"LibraryPersistence_LibraryLoader", @"_fileClosed", @"Persistence_FileHandler");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {

		[self event_borrowsFileClosed_pushed:changes ];

	}
	[v0 release];
}


-(void) event_loadToCollect_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_loadToCollect", @"LibraryPersistence_LibraryLoader");

		 
		// Trigger Push edges

		if (self->_toCollectFileHandler != nil && self->_toCollectFileHandler != (Persistence_FileHandler*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_toCollectFileHandler];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			Persistence_FileHandler* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * 'ToCollectData.dat'
				 * ================================================== */
				
				OCLString* v1 = [(OCLString*)[OCLString alloc] initWithString:@"ToCollectData.dat"];
				
					OCLString* parameter_p_filename = v1;

					[edge0_target event_openFile_pushed:changes p_filename:parameter_p_filename ];
					[v1 release];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_toCollectLineTokenized_pushed:(PropertyChangeList*) changes  p_tokens: (OCLSequence*) p_tokens{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_toCollectLineTokenized", @"LibraryPersistence_LibraryLoader");

		 
		// Trigger Push edges
		if (self->_members != nil && self->_members != (OCLSet*)[NSNull null]) {
			 
			NSArray* edge0_values = [[self->_members objectEnumerator] allObjects];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			Library_Member* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * _iter.libraryNo = tokens->at(1)
			 * ================================================== */
			
			Library_Member* v2 = edge0_target;
			OCLString* v1 = [v2 _libraryNo];
			OCLSequence* v4 = p_tokens;
			OCLInteger* v5 = [(OCLInteger*)[OCLInteger alloc] initWithValue:1];
			OCLString* v3 = ((OCLString*)[v4 at:v5]);
			OCLBoolean* v0 = [v1 eq:v3];
			[v5 release];
			
				if (v0->value == YES) {
					/* ==================================================
				 * _iter.toCollect->including(findCopy(tokens->at(2)))
				 * ================================================== */
				
				Library_Member* v8 = edge0_target;
				OCLSet* v7 = [v8 _toCollect];
				LibraryPersistence_LibraryLoader* v10 = self;
				OCLSequence* v12 = p_tokens;
				OCLInteger* v13 = [(OCLInteger*)[OCLInteger alloc] initWithValue:2];
				OCLString* v11 = ((OCLString*)[v12 at:v13]);
				Library_Copy* v9 = [v10 findCopy:v11];
				OCLSet* v6 = [v7 including:v9];
				[v13 release];
				
					OCLSet* parameter_p_toCollect = v6;

					[edge0_target event_setToCollect_pushed:changes p_toCollect:parameter_p_toCollect ];
					[v6 release];

				}
				[v0 release];
			}

		}



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_toCollectLineTokenized_pulled_edge0:(PropertyChangeList*)changes parentInstance:(StringUtils_StringTokenizer*)parentInstance p_tokens:(OCLSequence*)p_tokens  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_toCollectLineTokenized", @"LibraryPersistence_LibraryLoader", @"_stringTokenized", @"StringUtils_StringTokenizer");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {
		/* ==================================================
		 * tokens
		 * ================================================== */
		
		OCLSequence* v1 = p_tokens;
		
		OCLSequence* parameter_p_tokens = v1;

		[self event_toCollectLineTokenized_pushed:changes p_tokens:parameter_p_tokens ];

	}
	[v0 release];
}


-(void) event_toCollectFileClosed_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_toCollectFileClosed", @"LibraryPersistence_LibraryLoader");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {
			/* ==================================================
			 * Library::Library::create(Tuple { catalogue = books, members = members })
			 * ================================================== */
			
			OCLSet* v5 = [self _books];
			OCLSet* v4 = v5;
			OCLSet* v7 = [self _members];
			OCLSet* v6 = v7;
			OCLTuple* v3 = [(OCLTuple*)[OCLTuple alloc] init];
			[v3 addItemNamed:@"catalogue" withValue:v4];
			[v3 addItemNamed:@"members" withValue:v6];
			Library_Library* v1 = [(Library_Library*)[Library_Library alloc] initWithValues:v3];
			[v3 release];
			
			Library_Library* parameter_p_library = v1;

			[self event_libraryLoaded_pushed:changes p_library:parameter_p_library ];
		}
		[v0 release];


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_toCollectFileClosed_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Persistence_FileHandler*)parentInstance  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_toCollectFileClosed", @"LibraryPersistence_LibraryLoader", @"_fileClosed", @"Persistence_FileHandler");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {

		[self event_toCollectFileClosed_pushed:changes ];

	}
	[v0 release];
}


-(void) event_toCollectLineRead_pushed:(PropertyChangeList*) changes  p_line: (OCLString*) p_line{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_toCollectLineRead", @"LibraryPersistence_LibraryLoader");

		 
		// Trigger Push edges

		if (self->_toCollectStringTokenizer != nil && self->_toCollectStringTokenizer != (StringUtils_StringTokenizer*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_toCollectStringTokenizer];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			StringUtils_StringTokenizer* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * line
				 * ================================================== */
				
				OCLString* v1 = p_line;
				
					OCLString* parameter_p_string = v1;
					/* ==================================================
				 * ';'
				 * ================================================== */
				
				OCLString* v2 = [(OCLString*)[OCLString alloc] initWithString:@";"];
				
					OCLString* parameter_p_separator = v2;

					[edge0_target event_tokenizeString_pushed:changes p_string:parameter_p_string p_separator:parameter_p_separator ];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_toCollectLineRead_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Persistence_FileHandler*)parentInstance p_line:(OCLString*)p_line  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_toCollectLineRead", @"LibraryPersistence_LibraryLoader", @"_lineread", @"Persistence_FileHandler");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {
		/* ==================================================
		 * line
		 * ================================================== */
		
		OCLString* v1 = p_line;
		
		OCLString* parameter_p_line = v1;

		[self event_toCollectLineRead_pushed:changes p_line:parameter_p_line ];

	}
	[v0 release];
}


-(void) event_saveBorrows_pushed:(PropertyChangeList*) changes  p_members: (OCLSequence*) p_members{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_saveBorrows", @"LibraryPersistence_LibraryLoader");

		 
		// Trigger Push edges

		if (self->_saveBorrowsFileHandler != nil && self->_saveBorrowsFileHandler != (Persistence_FileHandler*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_saveBorrowsFileHandler];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			Persistence_FileHandler* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * 'BorrowsData.dat'
				 * ================================================== */
				
				OCLString* v1 = [(OCLString*)[OCLString alloc] initWithString:@"BorrowsData.dat"];
				
					OCLString* parameter_p_filename = v1;
					/* ==================================================
				 * members->collect(m: Library::Member |
				 * 	m.borrows->collect(c: Library::Copy |
				 * 		m.libraryNo.concat(';').concat(c.copyId)
				 * 	)
				 * )->iterate(line: String; result: String = '' | 
				 * 	result.concat(line).concat('\n')
				 * )
				 * 
				 * ================================================== */
				
				OCLSequence* v4 = p_members;
				OCLSequence* v3_nested = [(OCLSequence*)[OCLSequence alloc] init];
				NSEnumerator* v3_enum = [v4 objectEnumerator];
				Library_Member* v5;
				while ((v5 = [v3_enum nextObject]) != nil) {
					Library_Member* v8 = v5;
					OCLSet* v7 = [v8 _borrows];
					OCLBag* v6_nested = [(OCLBag*)[OCLBag alloc] init];
					NSEnumerator* v6_enum = [v7 objectEnumerator];
					Library_Copy* v9;
					while ((v9 = [v6_enum nextObject]) != nil) {
						Library_Member* v13 = v5;
						OCLString* v12 = [v13 _libraryNo];
						OCLString* v14 = [(OCLString*)[OCLString alloc] initWithString:@";"];
						OCLString* v11 = [v12 concat:v14];
						Library_Copy* v16 = v9;
						OCLString* v15 = [v16 _copyId];
						OCLString* v10 = [v11 concat:v15];
						[v6_nested add: v10];
						[v11 release];
						[v14 release];
						[v10 release];
					}
					OCLBag* v6 = [v6_nested flatten];
					[v6_nested release];
					[v3_nested add: v6];
				}
				OCLSequence* v3 = [v3_nested flatten];
				[v3_nested release];
				OCLString* v19 = [(OCLString*)[OCLString alloc] initWithString:@""];
				OCLString* v18 = v19;
				NSEnumerator* v2_enum = [v3 objectEnumerator];
				OCLString* v17;
				while ((v17 = [v2_enum nextObject]) != nil) {
					OCLString* v22 = v18;
					OCLString* v23 = v17;
					OCLString* v21 = [v22 concat:v23];
					OCLString* v24 = [(OCLString*)[OCLString alloc] initWithString:@"\n"];
					OCLString* v20 = [v21 concat:v24];
					v18 = v20;
					[v24 release];
					[v21 release];
				}
				OCLString* v2 = v18;
				
					OCLString* parameter_p_content = v2;

					[edge0_target event_saveString_pushed:changes p_filename:parameter_p_filename p_content:parameter_p_content ];
					[v1 release];
					[v2 release];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_saveLibrary_pushed:(PropertyChangeList*) changes  p_library: (Library_Library*) p_library{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_saveLibrary", @"LibraryPersistence_LibraryLoader");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {
			/* ==================================================
			 * library.copies->asSequence()
			 * ================================================== */
			
			Library_Library* v3 = p_library;
			OCLSet* v2 = [v3 copies];
			OCLSequence* v1 = [v2 asSequence];
			
			OCLSequence* parameter_p_copies = v1;

			[self event_saveCopies_pushed:changes p_copies:parameter_p_copies ];
		}
		[v0 release];
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v4 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v4->value == YES) {
			/* ==================================================
			 * library.members->asSequence()
			 * ================================================== */
			
			Library_Library* v7 = p_library;
			OCLSet* v6 = [v7 _members];
			OCLSequence* v5 = [v6 asSequence];
			
			OCLSequence* parameter_p_members = v5;

			[self event_saveBorrows_pushed:changes p_members:parameter_p_members ];
		}
		[v4 release];
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v8 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v8->value == YES) {
			/* ==================================================
			 * library.members->asSequence()
			 * ================================================== */
			
			Library_Library* v11 = p_library;
			OCLSet* v10 = [v11 _members];
			OCLSequence* v9 = [v10 asSequence];
			
			OCLSequence* parameter_p_members = v9;

			[self event_saveToCollect_pushed:changes p_members:parameter_p_members ];
		}
		[v8 release];


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_saveToCollect_pushed:(PropertyChangeList*) changes  p_members: (OCLSequence*) p_members{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_saveToCollect", @"LibraryPersistence_LibraryLoader");

		 
		// Trigger Push edges

		if (self->_saveToCollectFileHandler != nil && self->_saveToCollectFileHandler != (Persistence_FileHandler*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_saveToCollectFileHandler];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			Persistence_FileHandler* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * 'ToCollectData.dat'
				 * ================================================== */
				
				OCLString* v1 = [(OCLString*)[OCLString alloc] initWithString:@"ToCollectData.dat"];
				
					OCLString* parameter_p_filename = v1;
					/* ==================================================
				 * members->collect(m: Library::Member |
				 * 	m.toCollect->collect(c: Library::Copy |
				 * 		m.libraryNo.concat(';').concat(c.copyId)
				 * 	)
				 * )->iterate(line: String; result: String = '' | 
				 * 	result.concat(line).concat('\n')
				 * )
				 * 
				 * ================================================== */
				
				OCLSequence* v4 = p_members;
				OCLSequence* v3_nested = [(OCLSequence*)[OCLSequence alloc] init];
				NSEnumerator* v3_enum = [v4 objectEnumerator];
				Library_Member* v5;
				while ((v5 = [v3_enum nextObject]) != nil) {
					Library_Member* v8 = v5;
					OCLSet* v7 = [v8 _toCollect];
					OCLBag* v6_nested = [(OCLBag*)[OCLBag alloc] init];
					NSEnumerator* v6_enum = [v7 objectEnumerator];
					Library_Copy* v9;
					while ((v9 = [v6_enum nextObject]) != nil) {
						Library_Member* v13 = v5;
						OCLString* v12 = [v13 _libraryNo];
						OCLString* v14 = [(OCLString*)[OCLString alloc] initWithString:@";"];
						OCLString* v11 = [v12 concat:v14];
						Library_Copy* v16 = v9;
						OCLString* v15 = [v16 _copyId];
						OCLString* v10 = [v11 concat:v15];
						[v6_nested add: v10];
						[v11 release];
						[v10 release];
						[v14 release];
					}
					OCLBag* v6 = [v6_nested flatten];
					[v6_nested release];
					[v3_nested add: v6];
				}
				OCLSequence* v3 = [v3_nested flatten];
				[v3_nested release];
				OCLString* v19 = [(OCLString*)[OCLString alloc] initWithString:@""];
				OCLString* v18 = v19;
				NSEnumerator* v2_enum = [v3 objectEnumerator];
				OCLString* v17;
				while ((v17 = [v2_enum nextObject]) != nil) {
					OCLString* v22 = v18;
					OCLString* v23 = v17;
					OCLString* v21 = [v22 concat:v23];
					OCLString* v24 = [(OCLString*)[OCLString alloc] initWithString:@"\n"];
					OCLString* v20 = [v21 concat:v24];
					v18 = v20;
					[v21 release];
					[v24 release];
				}
				OCLString* v2 = v18;
				
					OCLString* parameter_p_content = v2;

					[edge0_target event_saveString_pushed:changes p_filename:parameter_p_filename p_content:parameter_p_content ];
					[v1 release];
					[v2 release];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 




 
-(OCLSet*) findAuthors:p_authorIds {
	/* ==================================================
	 * authors->select(a: Library::Author | authorIds->includes(a.authorId))
	 * ================================================== */
	
	LibraryPersistence_LibraryLoader* v2 = self;
	OCLSet* v1 = [v2 _authors];
	OCLSet* v0 = [(OCLSet*)[OCLSet alloc] init];
	NSEnumerator* v0_enum = [v1 objectEnumerator];
	Library_Author* v3;
	while ((v3 = [v0_enum nextObject]) != nil) {
		OCLSet* v5 = p_authorIds;
		Library_Author* v7 = v3;
		OCLString* v6 = [v7 _authorId];
		OCLBoolean* v4 = [v5 includes:v6];
		if (v4->value == YES) { [v0 add: v3]; }
		[v4 release];
	}
	;
	return v0;
}
-(Library_Book*) findBook:p_bookId {
	/* ==================================================
	 * books->any(b: Library::Book | b.bookId = bookId)
	 * ================================================== */
	
	LibraryPersistence_LibraryLoader* v2 = self;
	OCLSet* v1 = [v2 _books];
	Library_Book* v0 = nil;
	NSEnumerator* v0_enum = [v1 objectEnumerator];
	Library_Book* v3;
	while ((v3 = [v0_enum nextObject]) != nil) {
		Library_Book* v6 = v3;
		OCLString* v5 = [v6 _bookId];
		OCLString* v7 = p_bookId;
		OCLBoolean* v4 = [v5 eq:v7];
		if (v4->value == YES) {
			v0 = v3;
		}
		[v4 release];
		if (v0 != nil) { break; }
	}
	;
	return v0;
}
-(OCLSet*) findCopies:p_copyIds {
	/* ==================================================
	 * copies->select(c: Library::Copy | copyIds->includes(c.copyId))
	 * ================================================== */
	
	LibraryPersistence_LibraryLoader* v2 = self;
	OCLSet* v1 = [v2 _copies];
	OCLSet* v0 = [(OCLSet*)[OCLSet alloc] init];
	NSEnumerator* v0_enum = [v1 objectEnumerator];
	Library_Copy* v3;
	while ((v3 = [v0_enum nextObject]) != nil) {
		OCLSet* v5 = p_copyIds;
		Library_Copy* v7 = v3;
		OCLString* v6 = [v7 _copyId];
		OCLBoolean* v4 = [v5 includes:v6];
		if (v4->value == YES) { [v0 add: v3]; }
		[v4 release];
	}
	;
	return v0;
}
-(OCLString*) intToString:p_int {
	/* ==================================================
	 * if int > 0 then
	 * 	OrderedSet{1000000, 10000, 1000, 100, 10, 1}->iterate(
	 *             denominator : Integer;
	 *             s : String = ''|
	 *             let numberAsString : String = OrderedSet{
	 *                     '0','1','2','3','4','5','6','7','8','9'
	 *                 }->at(int.div(denominator).mod(10) + 1)
	 *             in
	 *                 if s='' and numberAsString = '0' then
	 *                     s
	 *                 else
	 *                     s.concat(numberAsString)
	 *                 endif
	 *         )
	 * else
	 * 	'0'
	 * endif
	 * 
	 * ================================================== */
	
	OCLInteger* v2 = p_int;
	OCLInteger* v3 = [(OCLInteger*)[OCLInteger alloc] initWithValue:0];
	OCLBoolean* v1 = [v2 gt:v3];
	OCLString* v0;
	if (v1->value == YES) {
		OCLInteger* v7 = [(OCLInteger*)[OCLInteger alloc] initWithValue:1000000];
		OCLInteger* v6 = v7;
		OCLInteger* v9 = [(OCLInteger*)[OCLInteger alloc] initWithValue:10000];
		OCLInteger* v8 = v9;
		OCLInteger* v11 = [(OCLInteger*)[OCLInteger alloc] initWithValue:1000];
		OCLInteger* v10 = v11;
		OCLInteger* v13 = [(OCLInteger*)[OCLInteger alloc] initWithValue:100];
		OCLInteger* v12 = v13;
		OCLInteger* v15 = [(OCLInteger*)[OCLInteger alloc] initWithValue:10];
		OCLInteger* v14 = v15;
		OCLInteger* v17 = [(OCLInteger*)[OCLInteger alloc] initWithValue:1];
		OCLInteger* v16 = v17;
		OCLOrderedSet* v5 = [(OCLOrderedSet*)[OCLOrderedSet alloc] init];
		[v5 add:v6];
		[v5 add:v8];
		[v5 add:v10];
		[v5 add:v12];
		[v5 add:v14];
		[v5 add:v16];
		OCLString* v20 = [(OCLString*)[OCLString alloc] initWithString:@""];
		OCLString* v19 = v20;
		NSEnumerator* v4_enum = [v5 objectEnumerator];
		OCLInteger* v18;
		while ((v18 = [v4_enum nextObject]) != nil) {
			OCLString* v26 = [(OCLString*)[OCLString alloc] initWithString:@"0"];
			OCLString* v25 = v26;
			OCLString* v28 = [(OCLString*)[OCLString alloc] initWithString:@"1"];
			OCLString* v27 = v28;
			OCLString* v30 = [(OCLString*)[OCLString alloc] initWithString:@"2"];
			OCLString* v29 = v30;
			OCLString* v32 = [(OCLString*)[OCLString alloc] initWithString:@"3"];
			OCLString* v31 = v32;
			OCLString* v34 = [(OCLString*)[OCLString alloc] initWithString:@"4"];
			OCLString* v33 = v34;
			OCLString* v36 = [(OCLString*)[OCLString alloc] initWithString:@"5"];
			OCLString* v35 = v36;
			OCLString* v38 = [(OCLString*)[OCLString alloc] initWithString:@"6"];
			OCLString* v37 = v38;
			OCLString* v40 = [(OCLString*)[OCLString alloc] initWithString:@"7"];
			OCLString* v39 = v40;
			OCLString* v42 = [(OCLString*)[OCLString alloc] initWithString:@"8"];
			OCLString* v41 = v42;
			OCLString* v44 = [(OCLString*)[OCLString alloc] initWithString:@"9"];
			OCLString* v43 = v44;
			OCLOrderedSet* v24 = [(OCLOrderedSet*)[OCLOrderedSet alloc] init];
			[v24 add:v25];
			[v24 add:v27];
			[v24 add:v29];
			[v24 add:v31];
			[v24 add:v33];
			[v24 add:v35];
			[v24 add:v37];
			[v24 add:v39];
			[v24 add:v41];
			[v24 add:v43];
			OCLInteger* v48 = p_int;
			OCLInteger* v49 = v18;
			OCLInteger* v47 = [v48 idiv:v49];
			OCLInteger* v50 = [(OCLInteger*)[OCLInteger alloc] initWithValue:10];
			OCLInteger* v46 = [v47 mod:v50];
			OCLInteger* v51 = [(OCLInteger*)[OCLInteger alloc] initWithValue:1];
			OCLInteger* v45 = [v46 plus:v51];
			OCLString* v23 = ((OCLString*)[v24 at:v45]);
			OCLString* v22 = v23;
			OCLString* v55 = v19;
			OCLString* v56 = [(OCLString*)[OCLString alloc] initWithString:@""];
			OCLBoolean* v54 = [v55 eq:v56];
			OCLString* v58 = v22;
			OCLString* v59 = [(OCLString*)[OCLString alloc] initWithString:@"0"];
			OCLBoolean* v57 = [v58 eq:v59];
			OCLBoolean* v53 = [v54 and:v57];
			OCLString* v52;
			if (v53->value == YES) {
				OCLString* v60 = v19;
				v52 = v60;
			} else {
				OCLString* v62 = v19;
				OCLString* v63 = v22;
				OCLString* v61 = [v62 concat:v63];
				v52 = v61;
			}
			OCLString* v21 = v52;
			v19 = v21;
			[v32 release];
			[v45 release];
			[v28 release];
			[v59 release];
			[v57 release];
			[v46 release];
			[v50 release];
			[v56 release];
			[v42 release];
			[v54 release];
			[v38 release];
			[v51 release];
			[v47 release];
			[v26 release];
			[v44 release];
			[v24 release];
			[v53 release];
			[v36 release];
			[v30 release];
			[v40 release];
			[v34 release];
		}
		OCLString* v4 = v19;
		v0 = v4;
		[v17 release];
		[v9 release];
		[v7 release];
		[v15 release];
		[v13 release];
		[v5 release];
		[v11 release];
	} else {
		OCLString* v64 = [(OCLString*)[OCLString alloc] initWithString:@"0"];
		v0 = v64;
	}
	[v3 release];
	[v1 release];
	;
	return v0;
}
-(Library_Copy*) findCopy:p_copyId {
	/* ==================================================
	 * copies->any(c: Library::Copy | copyId = c.copyId)
	 * ================================================== */
	
	LibraryPersistence_LibraryLoader* v2 = self;
	OCLSet* v1 = [v2 _copies];
	Library_Copy* v0 = nil;
	NSEnumerator* v0_enum = [v1 objectEnumerator];
	Library_Copy* v3;
	while ((v3 = [v0_enum nextObject]) != nil) {
		OCLString* v5 = p_copyId;
		Library_Copy* v7 = v3;
		OCLString* v6 = [v7 _copyId];
		OCLBoolean* v4 = [v5 eq:v6];
		if (v4->value == YES) {
			v0 = v3;
		}
		[v4 release];
		if (v0 != nil) { break; }
	}
	;
	return v0;
}


@end 


