#import <Foundation/Foundation.h>
#import "OCLAny.h"

@class OCLInteger;
@class OCLReal;
@class OCLBoolean;

@interface OCLString : OCLAny {
	@public
	NSString* string;
}

-(OCLString*)initWithString:(NSString*)string;
-(void)dealloc;

// String methods
-(OCLInteger*)size;
-(OCLString*)concat:(OCLString*)string;
-(OCLString*)substring:(OCLInteger*)lower upper:(OCLInteger*)upper;
-(OCLInteger*)toInteger;
-(OCLReal*)toReal;

// NSObject methods
-(NSUInteger)hash;
-(NSString*)description;
-(BOOL)isEqual:(id)other;

@end
