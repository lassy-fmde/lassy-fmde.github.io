 
 
 
#import "MobileLibraryGUI_ViewsController.h"
#import "PropertyChangeList.h"
#import "GeneralGUI_TabbedWindow.h"
#import "Application_Main.h"


 
@implementation MobileLibraryGUI_ViewsController

 
- (MobileLibraryGUI_ViewsController*) init {
	self = [super init];
	 
	self->Application_Main_viewsControl_back = [[NSMutableArray alloc] init];

	[self set_viewsWindow: [self _viewsWindow]];

	return self;
}

 
- (MobileLibraryGUI_ViewsController*) initWithValues: (OCLTuple*) values {
	self = [super init];
	 
	self->_viewsWindow_initialized = NO;

	self->Application_Main_viewsControl_back = [[NSMutableArray alloc] init];

	GeneralGUI_TabbedWindow* _viewsWindow_initialValue = (GeneralGUI_TabbedWindow*) [values objectForKey:@"viewsWindow"];
	if (_viewsWindow_initialValue == nil) {
		_viewsWindow_initialValue = [self _viewsWindow];
	}
	[self set_viewsWindow:_viewsWindow_initialValue];

	
	return self;
}

 
- (void) dealloc {
	if (self->_viewsWindow != nil && self->_viewsWindow != (GeneralGUI_TabbedWindow*) [NSNull null]) [self->_viewsWindow release];

	[self->Application_Main_viewsControl_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"MobileLibraryGUI::ViewsController\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"viewsWindow\" type=\"GeneralGUI::TabbedWindow\">\n"];
	[res appendFormat:@"%@\n", [self _viewsWindow]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
-(GeneralGUI_TabbedWindow*) initial_viewsWindow {
	/* ==================================================
	 * null
	 * ================================================== */
	
	GeneralGUI_TabbedWindow* v0 = [NSNull null];
	
	return v0;
}

-(GeneralGUI_TabbedWindow*) _viewsWindow {
	if (self->_viewsWindow_initialized == YES) {
		return _viewsWindow;
	} else { 
		[self set_viewsWindow:[self initial_viewsWindow]];
	}

	self->_viewsWindow_initialized = YES;
	return _viewsWindow;
}


 


-(void) set_viewsWindow:(GeneralGUI_TabbedWindow*) value {
	 
	if (self->_viewsWindow!= nil && self->_viewsWindow!= (GeneralGUI_TabbedWindow*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_viewsWindow valueForKey:@"MobileLibraryGUI_ViewsController_viewsWindow_back"];
		[backpointers removeObject:self];
		[self->_viewsWindow release];
	}
	self->_viewsWindow = value;
	if (self->_viewsWindow!= nil && self->_viewsWindow!= (GeneralGUI_TabbedWindow*) [NSNull null]) {
		[self->_viewsWindow retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_viewsWindow valueForKey:@"MobileLibraryGUI_ViewsController_viewsWindow_back"];
		[backpointers addObject:self];
	}
	self->_viewsWindow_initialized = YES;

}




 
-(void) event_startViewsWindow_pushed:(PropertyChangeList*) changes  p_searchWindow: (OCLAny*) p_searchWindow p_loginWindow: (OCLAny*) p_loginWindow{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_startViewsWindow", @"MobileLibraryGUI_ViewsController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * GeneralGUI::TabbedWindow::create(
		 * 	Tuple { views = Sequence {searchWindow, 
		 * 		loginWindow } })
		 * ================================================== */
		
		OCLAny* v6 = p_searchWindow;
		OCLAny* v5 = v6;
		OCLAny* v8 = p_loginWindow;
		OCLAny* v7 = v8;
		OCLSequence* v4 = [(OCLSequence*)[OCLSequence alloc] init];
		[v4 add:v5];
		[v4 add:v7];
		OCLSequence* v3 = v4;
		OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
		[v2 addItemNamed:@"views" withValue:v3];
		GeneralGUI_TabbedWindow* v0 = [(GeneralGUI_TabbedWindow*)[GeneralGUI_TabbedWindow alloc] initWithValues:v2];
		[v2 release];
		[v4 release];
		
		GeneralGUI_TabbedWindow* _viewsWindow_newValue = v0;
		[changes addChange:@selector(set_viewsWindow:) instance:self value:_viewsWindow_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_changeFromLoginToMember_pushed:(PropertyChangeList*) changes  p_memberFrame: (OCLAny*) p_memberFrame{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_changeFromLoginToMember", @"MobileLibraryGUI_ViewsController");

		 
		// Trigger Push edges

		if (self->_viewsWindow != nil && self->_viewsWindow != (GeneralGUI_TabbedWindow*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_viewsWindow];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			GeneralGUI_TabbedWindow* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * 2
				 * ================================================== */
				
				OCLInteger* v1 = [(OCLInteger*)[OCLInteger alloc] initWithValue:2];
				
					OCLInteger* parameter_p_index = v1;
					/* ==================================================
				 * memberFrame
				 * ================================================== */
				
				OCLAny* v2 = p_memberFrame;
				
					OCLAny* parameter_p_view = v2;

					[edge0_target event_changeView_pushed:changes p_index:parameter_p_index p_view:parameter_p_view ];
					[v1 release];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 




 


@end 


