#import "PropertyChangeList.h"

@interface PropertyChangeListEntry : NSObject {
    @private
    SEL selector;
    OCLAny* instance;
    OCLAny* newValue;
}
-(PropertyChangeListEntry*)init:(SEL)selector instance:(OCLAny*)instance newValue:(OCLAny*)newValue;
-(void)dealloc;
-(void)apply;
-(BOOL)isEqual:(id)other;
-(NSString*)description;
@end

@implementation PropertyChangeListEntry
-(PropertyChangeListEntry*)init:(SEL)selectr instance:(OCLAny*)inst newValue:(OCLAny*)newVal {
    self = [super init];
    self->selector = selectr;
    self->instance = inst;
    self->newValue = newVal;
    [self->instance retain];
    [self->newValue retain];
    return self;
}

-(void)dealloc {
    [self->instance release];
    [self->newValue release];
    [super dealloc];
}

-(void)apply {
    if ([self->instance respondsToSelector:self->selector] == YES) {
        [self->instance performSelector:self->selector withObject:self->newValue];
    } else {
        [NSException raise:@"Applying changed property values" format:@"Instance %p does not respond to selector %@", self->instance, NSStringFromSelector(self->selector)];
    }
}

-(BOOL)isEqual:(id)other {
	if (other == nil) return NO;

	if ([self isKindOfClass:[other class]]) {
		PropertyChangeListEntry* otherEntry = (PropertyChangeListEntry*)other;
		return (self->selector == otherEntry->selector) && [self->instance isEqual:otherEntry->instance];
	} else {
		return NO;
	}
}

-(NSString*)description {
    NSMutableString* res = [[NSMutableString alloc] init];
    [res appendFormat:@"<PropertyChange selector=\"%@\" instance=\"%p\" newValue=\"%p\"/>\n", NSStringFromSelector(self->selector), self->instance, self->newValue];
    return res;
}
@end

// ------------------------------------------------------------------------

@implementation PropertyChangeList

-(PropertyChangeList*)init {
    self = [super init];
    self->depth = 0;
    self->changes = [[NSMutableArray alloc] init];
    return self;
}

-(void)dealloc {
    [self->changes release];
    [super dealloc];
}

-(void)enter {
    self->depth++;
}

-(void)leave {
    if (self->depth == 0) {
        [NSException raise:@"Can not leave PropertyChangeList because depth is already 0" format:@"%p", self];
    } else if (self->depth == 1) {
        NSLog(@"Applying Changes\n%@\n", self);
    
        NSEnumerator* e = [self->changes objectEnumerator];
        PropertyChangeListEntry* entry;
        while ((entry = [e nextObject]) != nil) {
            [entry apply];
        }
    }
    
    self->depth--;
}

-(void)addChange:(SEL)propertySelector instance:(OCLAny*)instance value:(OCLAny*)newValue {
    PropertyChangeListEntry* entry = [[PropertyChangeListEntry alloc] init:propertySelector instance:instance newValue:newValue];
    if ([self->changes containsObject:entry]) {
    	// Entry with same selector and instance is already present.
    	// TODO create own exception type.
    	[entry release];
        [NSException raise:@"MultipleModification: Property Change List already has entry for property" format:@"%p", entry];
    }
    [self->changes addObject:entry];
    [entry release];
}

-(NSString*)description {
    NSMutableString* res = [[NSMutableString alloc] init];
    [res appendString:@"<PropertyChangeList>\n"];
    
    NSEnumerator* e = [self->changes objectEnumerator];
    PropertyChangeListEntry* entry;
    while ((entry = [e nextObject]) != nil) {
        [res appendString:[entry description]];
    }
    
    [res appendString:@"</PropertyChangeList>\n"];
    return res;
}

@end
