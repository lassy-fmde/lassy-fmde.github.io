 
 
 
#import "Library_Library.h"
#import "PropertyChangeList.h"
#import "Library_Library.h"
#import "Library_Author.h"
#import "Library_Member.h"
#import "Library_Book.h"
#import "Library_Copy.h"
#import "Application_Main.h"


 
@implementation Library_Library

 
- (Library_Library*) init {
	self = [super init];
	 
	self->Application_Main_library_back = [[NSMutableArray alloc] init];

	[self set_catalogue: [self _catalogue]];
	[self set_members: [self _members]];

	return self;
}

 
- (Library_Library*) initWithValues: (OCLTuple*) values {
	self = [super init];
	 
	self->_catalogue_initialized = NO;
	self->_members_initialized = NO;

	self->Application_Main_library_back = [[NSMutableArray alloc] init];

	OCLSet* _catalogue_initialValue = (OCLSet*) [values objectForKey:@"catalogue"];
	if (_catalogue_initialValue == nil) {
		_catalogue_initialValue = [self _catalogue];
	}
	[self set_catalogue:_catalogue_initialValue];
	OCLSet* _members_initialValue = (OCLSet*) [values objectForKey:@"members"];
	if (_members_initialValue == nil) {
		_members_initialValue = [self _members];
	}
	[self set_members:_members_initialValue];

	
	return self;
}

 
- (void) dealloc {
	if (self->_catalogue != nil && self->_catalogue != (OCLSet*) [NSNull null]) [self->_catalogue release];
	if (self->_members != nil && self->_members != (OCLSet*) [NSNull null]) [self->_members release];

	[self->Application_Main_library_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"Library::Library\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"catalogue\" type=\"Set\">\n"];
	[res appendFormat:@"%@\n", [self _catalogue]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"members\" type=\"Set\">\n"];
	[res appendFormat:@"%@\n", [self _members]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
-(OCLSet*) initial_catalogue {
	/* ==================================================
	 * Set {}
	 * ================================================== */
	
	OCLSet* v0 = [(OCLSet*)[OCLSet alloc] init];
	
	return v0;
}

-(OCLSet*) _catalogue {
	if (self->_catalogue_initialized == YES) {
		return _catalogue;
	} else { 
		[self set_catalogue:[self initial_catalogue]];
	}

	self->_catalogue_initialized = YES;
	return _catalogue;
}
-(OCLSet*) initial_members {
	/* ==================================================
	 * Set {}
	 * ================================================== */
	
	OCLSet* v0 = [(OCLSet*)[OCLSet alloc] init];
	
	return v0;
}

-(OCLSet*) _members {
	if (self->_members_initialized == YES) {
		return _members;
	} else { 
		[self set_members:[self initial_members]];
	}

	self->_members_initialized = YES;
	return _members;
}


 




-(void) set_catalogue:(OCLSet*) value {
	 
	if (self->_catalogue!= nil && self->_catalogue!= (OCLSet*) [NSNull null]) {
		// Clear back pointer on old instance
		NSEnumerator* e = [self->_catalogue objectEnumerator];
		Library_Book* o;
		while ((o = [e nextObject]) != nil) {
			if (o != (Library_Book*)[NSNull null]) {
				NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)o valueForKey:@"Library_Library_catalogue_back"];
				[backpointers removeObject:self];
			}
		}
		[self->_catalogue release];
	}
	self->_catalogue = value;
	if (self->_catalogue!= nil && self->_catalogue!= (OCLSet*) [NSNull null]) {
		[self->_catalogue retain];
		// Add back pointer on new instance
		NSEnumerator* e = [self->_catalogue objectEnumerator];
		Library_Book* o;
		while ((o = [e nextObject]) != nil) {
			if (o != (Library_Book*)[NSNull null]) {
				NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)o valueForKey:@"Library_Library_catalogue_back"];
				[backpointers addObject:self];
			}
		}
	}
	self->_catalogue_initialized = YES;

}
-(void) set_members:(OCLSet*) value {
	 
	if (self->_members!= nil && self->_members!= (OCLSet*) [NSNull null]) {
		// Clear back pointer on old instance
		NSEnumerator* e = [self->_members objectEnumerator];
		Library_Member* o;
		while ((o = [e nextObject]) != nil) {
			if (o != (Library_Member*)[NSNull null]) {
				NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)o valueForKey:@"Library_Library_members_back"];
				[backpointers removeObject:self];
			}
		}
		[self->_members release];
	}
	self->_members = value;
	if (self->_members!= nil && self->_members!= (OCLSet*) [NSNull null]) {
		[self->_members retain];
		// Add back pointer on new instance
		NSEnumerator* e = [self->_members objectEnumerator];
		Library_Member* o;
		while ((o = [e nextObject]) != nil) {
			if (o != (Library_Member*)[NSNull null]) {
				NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)o valueForKey:@"Library_Library_members_back"];
				[backpointers addObject:self];
			}
		}
	}
	self->_members_initialized = YES;

}


 
-(void) event_searchBook_pushed:(PropertyChangeList*) changes  p_term: (OCLString*) p_term p_category: (OCLString*) p_category{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_searchBook", @"Library_Library");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {
			/* ==================================================
			 * findBooks (term, category)
			 * ================================================== */
			
			Library_Library* v2 = self;
			OCLString* v3 = p_term;
			OCLString* v4 = p_category;
			OCLSet* v1 = [v2 findBooks:v3 p_category:v4];
			
			OCLSet* parameter_p_foundBooks = v1;

			[self event_booksFound_pushed:changes p_foundBooks:parameter_p_foundBooks ];
		}
		[v0 release];


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_booksFound_pushed:(PropertyChangeList*) changes  p_foundBooks: (OCLSet*) p_foundBooks{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_booksFound", @"Library_Library");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges
		NSEnumerator* Application_Main_searchFinished_edge0_enum = [self->Application_Main_library_back objectEnumerator];
		Application_Main* Application_Main_searchFinished_edge0_target;
		while ((Application_Main_searchFinished_edge0_target = [Application_Main_searchFinished_edge0_enum nextObject]) != nil) {
		    [Application_Main_searchFinished_edge0_target event_searchFinished_pulled_edge0:changes parentInstance:self p_foundBooks:p_foundBooks ];
		}



		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_authenticate_pushed:(PropertyChangeList*) changes  p_libNo: (OCLString*) p_libNo p_pw: (OCLString*) p_pw{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_authenticate", @"Library_Library");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * existsMember (libNo, pw)
		 * ================================================== */
		
		Library_Library* v1 = self;
		OCLString* v2 = p_libNo;
		OCLString* v3 = p_pw;
		OCLBoolean* v0 = [v1 existsMember:v2 p_pw:v3];
		
		if (v0->value == YES) {
			/* ==================================================
			 * findMember (libNo)
			 * ================================================== */
			
			Library_Library* v5 = self;
			OCLString* v6 = p_libNo;
			Library_Member* v4 = [v5 findMember:v6];
			
			Library_Member* parameter_p_member = v4;

			[self event_loginOk_pushed:changes p_member:parameter_p_member ];
		}
		[v0 release];
		/* ==================================================
		 * not existsMember (libNo, pw)
		 * ================================================== */
		
		Library_Library* v9 = self;
		OCLString* v10 = p_libNo;
		OCLString* v11 = p_pw;
		OCLBoolean* v8 = [v9 existsMember:v10 p_pw:v11];
		OCLBoolean* v7 = [v8 not];
		
		if (v7->value == YES) {

			[self event_loginFailed_pushed:changes ];
		}
		[v7 release];


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_loginOk_pushed:(PropertyChangeList*) changes  p_member: (Library_Member*) p_member{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_loginOk", @"Library_Library");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges
		NSEnumerator* Application_Main_loginOk_edge0_enum = [self->Application_Main_library_back objectEnumerator];
		Application_Main* Application_Main_loginOk_edge0_target;
		while ((Application_Main_loginOk_edge0_target = [Application_Main_loginOk_edge0_enum nextObject]) != nil) {
		    [Application_Main_loginOk_edge0_target event_loginOk_pulled_edge0:changes parentInstance:self p_member:p_member ];
		}



		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_loginFailed_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_loginFailed", @"Library_Library");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges
		NSEnumerator* Application_Main_loginFailed_edge0_enum = [self->Application_Main_library_back objectEnumerator];
		Application_Main* Application_Main_loginFailed_edge0_target;
		while ((Application_Main_loginFailed_edge0_target = [Application_Main_loginFailed_edge0_enum nextObject]) != nil) {
		    [Application_Main_loginFailed_edge0_target event_loginFailed_pulled_edge0:changes parentInstance:self ];
		}



		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 




 
-(OCLSet*) findBooks:p_term p_category: (OCLString*) p_category{
	/* ==================================================
	 * catalogue->select(b:Book | 
	 *    (category='Title' and b.title=term)
	 *    or (category = 'ISBN' and b.isbn = term)
	 *    or (category ='Author' and b.authors->exists(a : Author | a.name = term)))
	 * ================================================== */
	
	Library_Library* v2 = self;
	OCLSet* v1 = [v2 _catalogue];
	OCLSet* v0 = [(OCLSet*)[OCLSet alloc] init];
	NSEnumerator* v0_enum = [v1 objectEnumerator];
	Library_Book* v3;
	while ((v3 = [v0_enum nextObject]) != nil) {
		OCLString* v8 = p_category;
		OCLString* v9 = [(OCLString*)[OCLString alloc] initWithString:@"Title"];
		OCLBoolean* v7 = [v8 eq:v9];
		Library_Book* v12 = v3;
		OCLString* v11 = [v12 _title];
		OCLString* v13 = p_term;
		OCLBoolean* v10 = [v11 eq:v13];
		OCLBoolean* v6 = [v7 and:v10];
		OCLString* v16 = p_category;
		OCLString* v17 = [(OCLString*)[OCLString alloc] initWithString:@"ISBN"];
		OCLBoolean* v15 = [v16 eq:v17];
		Library_Book* v20 = v3;
		OCLString* v19 = [v20 _isbn];
		OCLString* v21 = p_term;
		OCLBoolean* v18 = [v19 eq:v21];
		OCLBoolean* v14 = [v15 and:v18];
		OCLBoolean* v5 = [v6 or:v14];
		OCLString* v24 = p_category;
		OCLString* v25 = [(OCLString*)[OCLString alloc] initWithString:@"Author"];
		OCLBoolean* v23 = [v24 eq:v25];
		Library_Book* v28 = v3;
		OCLSet* v27 = [v28 _authors];
		OCLBoolean* v26 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue: NO];
		NSEnumerator* v26_enum = [v27 objectEnumerator];
		Library_Author* v29;
		while ((v29 = [v26_enum nextObject]) != nil) {
			Library_Author* v32 = v29;
			OCLString* v31 = [v32 _name];
			OCLString* v33 = p_term;
			OCLBoolean* v30 = [v31 eq:v33];
			if (v30->value == YES) {
				[v26 release];
				v26 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue: YES];
			}
			[v30 release];
			if (v26->value == YES) { break; }
		}
		OCLBoolean* v22 = [v23 and:v26];
		OCLBoolean* v4 = [v5 or:v22];
		if (v4->value == YES) { [v0 add: v3]; }
		[v14 release];
		[v22 release];
		[v9 release];
		[v7 release];
		[v18 release];
		[v5 release];
		[v6 release];
		[v25 release];
		[v4 release];
		[v17 release];
		[v15 release];
		[v23 release];
		[v10 release];
	}
	;
	return v0;
}
-(Library_Member*) findMember:p_libNo {
	/* ==================================================
	 * members->any (m: Library::Member | m.libraryNo = libNo) 
	 * ================================================== */
	
	Library_Library* v2 = self;
	OCLSet* v1 = [v2 _members];
	Library_Member* v0 = nil;
	NSEnumerator* v0_enum = [v1 objectEnumerator];
	Library_Member* v3;
	while ((v3 = [v0_enum nextObject]) != nil) {
		Library_Member* v6 = v3;
		OCLString* v5 = [v6 _libraryNo];
		OCLString* v7 = p_libNo;
		OCLBoolean* v4 = [v5 eq:v7];
		if (v4->value == YES) {
			v0 = v3;
		}
		[v4 release];
		if (v0 != nil) { break; }
	}
	;
	return v0;
}
-(OCLSet*) copies{
	/* ==================================================
	 * catalogue->collect(copies)->asSet()
	 * ================================================== */
	
	Library_Library* v3 = self;
	OCLSet* v2 = [v3 _catalogue];
	OCLBag* v1_nested = [(OCLBag*)[OCLBag alloc] init];
	NSEnumerator* v1_enum = [v2 objectEnumerator];
	Library_Book* v4;
	while ((v4 = [v1_enum nextObject]) != nil) {
		Library_Book* v6 = v4;
		OCLSet* v5 = [v6 _copies];
		[v1_nested add: v5];
	}
	OCLBag* v1 = [v1_nested flatten];
	[v1_nested release];
	OCLSet* v0 = [v1 asSet];
	;
	return v0;
}
-(OCLBoolean*) existsMember:p_libNo p_pw: (OCLString*) p_pw{
	/* ==================================================
	 * members->exists (m: Library::Member | m.libraryNo = libNo and m.password = pw) 
	 * ================================================== */
	
	Library_Library* v2 = self;
	OCLSet* v1 = [v2 _members];
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue: NO];
	NSEnumerator* v0_enum = [v1 objectEnumerator];
	Library_Member* v3;
	while ((v3 = [v0_enum nextObject]) != nil) {
		Library_Member* v7 = v3;
		OCLString* v6 = [v7 _libraryNo];
		OCLString* v8 = p_libNo;
		OCLBoolean* v5 = [v6 eq:v8];
		Library_Member* v11 = v3;
		OCLString* v10 = [v11 _password];
		OCLString* v12 = p_pw;
		OCLBoolean* v9 = [v10 eq:v12];
		OCLBoolean* v4 = [v5 and:v9];
		if (v4->value == YES) {
			[v0 release];
			v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue: YES];
		}
		[v9 release];
		[v5 release];
		[v4 release];
		if (v0->value == YES) { break; }
	}
	;
	return v0;
}


@end 


