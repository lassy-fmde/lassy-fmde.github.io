 
 
 
#import <Foundation/Foundation.h>
#import "OCLTypes.h"

@class PropertyChangeList;
@class Library_Book;
@class Library_Copy;
@class LibraryPersistence_LibraryLoader;
@class MobileLibraryGUI_MemberController;
@class Library_Member;
@class MobileLibraryGUI_BookDetailController;


 
 
@interface Library_Copy : OCLAny  
 {
	 
	Library_Book* _book;
	BOOL _book_initialized;
	OCLString* _dueDate;
	BOOL _dueDate_initialized;
	OCLInteger* _renewals;
	BOOL _renewals_initialized;
	OCLString* _state;
	BOOL _state_initialized;
	OCLString* _copyId;
	BOOL _copyId_initialized;


@public
	NSMutableArray *Library_Book_copies_back;
	NSMutableArray *LibraryPersistence_LibraryLoader_copies_back;
	NSMutableArray *MobileLibraryGUI_MemberController_selectedBorrowing_back;
	NSMutableArray *Library_Member_borrows_back;
	NSMutableArray *Library_Member_toCollect_back;
	NSMutableArray *MobileLibraryGUI_BookDetailController_selectedCopy_back;


}

 
-(Library_Copy*)init;
-(Library_Copy*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(Library_Book*) _book;
-(Library_Book*) initial_book;
-(void) set_book:(Library_Book*) value;
-(OCLString*) _dueDate;
-(OCLString*) initial_dueDate;
-(void) set_dueDate:(OCLString*) value;
-(OCLInteger*) _renewals;
-(OCLInteger*) initial_renewals;
-(void) set_renewals:(OCLInteger*) value;
-(OCLString*) _state;
-(OCLString*) initial_state;
-(void) set_state:(OCLString*) value;
-(OCLString*) _copyId;
-(OCLString*) initial_copyId;
-(void) set_copyId:(OCLString*) value;

-(void) event_renewOk_pushed:(PropertyChangeList*) changes p_newDueDate: (OCLString*) p_newDueDate;
-(void) event_renewFailed_pushed:(PropertyChangeList*) changes p_copy: (Library_Copy*) p_copy;
-(void) event_renew_pushed:(PropertyChangeList*) changes p_newDueDate: (OCLString*) p_newDueDate;
-(void) event_reserve_pushed:(PropertyChangeList*) changes ;
-(void) event_reserveOk_pushed:(PropertyChangeList*) changes ;
-(void) event_reserveFailed_pushed:(PropertyChangeList*) changes ;


@end


