 
 
 
#import <Foundation/Foundation.h>
#import "OCLTypes.h"

@class PropertyChangeList;
@class Library_Author;
@class MobileLibraryGUI_BookDetailController;
@class Library_Member;
@class Library_Book;
@class GeneralGUI_SelectionList;
@class GeneralGUI_Window;
@class Library_Copy;
@class GeneralGUI_Label;
@class MobileLibraryGUI_SearchController;


 
 
@interface MobileLibraryGUI_SearchResultsController : OCLAny  
 {
	 
	GeneralGUI_SelectionList* _bookListTable;
	BOOL _bookListTable_initialized;
	MobileLibraryGUI_BookDetailController* _detailsWindow;
	BOOL _detailsWindow_initialized;
	OCLString* _title;
	BOOL _title_initialized;
	GeneralGUI_Window* _window;
	BOOL _window_initialized;
	OCLString* _mode;
	BOOL _mode_initialized;
	Library_Member* _currMember;
	BOOL _currMember_initialized;


@public
	NSMutableArray *MobileLibraryGUI_SearchController_searchResults_back;


}

 
-(MobileLibraryGUI_SearchResultsController*)init;
-(MobileLibraryGUI_SearchResultsController*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(GeneralGUI_SelectionList*) _bookListTable;
-(GeneralGUI_SelectionList*) initial_bookListTable;
-(void) set_bookListTable:(GeneralGUI_SelectionList*) value;
-(MobileLibraryGUI_BookDetailController*) _detailsWindow;
-(MobileLibraryGUI_BookDetailController*) initial_detailsWindow;
-(void) set_detailsWindow:(MobileLibraryGUI_BookDetailController*) value;
-(OCLString*) _title;
-(OCLString*) initial_title;
-(void) set_title:(OCLString*) value;
-(GeneralGUI_Window*) _window;
-(GeneralGUI_Window*) initial_window;
-(void) set_window:(GeneralGUI_Window*) value;
-(OCLString*) _mode;
-(OCLString*) initial_mode;
-(void) set_mode:(OCLString*) value;
-(Library_Member*) _currMember;
-(Library_Member*) initial_currMember;
-(void) set_currMember:(Library_Member*) value;

-(void) event_bookSelected_pushed:(PropertyChangeList*) changes p_index: (OCLInteger*) p_index;
-(void) event_bookSelected_pulled_edge0:(PropertyChangeList*)changes parentInstance:(GeneralGUI_SelectionList*)parentInstance p_index:(OCLInteger*)p_index ;
-(void) event_selectedBook_pushed:(PropertyChangeList*) changes p_book: (Library_Book*) p_book;
-(void) event_refreshAndSave_pushed:(PropertyChangeList*) changes ;
-(void) event_refreshAndSave_pulled_edge0:(PropertyChangeList*)changes parentInstance:(MobileLibraryGUI_BookDetailController*)parentInstance ;
-(void) event_sessionStarted_pushed:(PropertyChangeList*) changes p_m: (Library_Member*) p_m;


@end


