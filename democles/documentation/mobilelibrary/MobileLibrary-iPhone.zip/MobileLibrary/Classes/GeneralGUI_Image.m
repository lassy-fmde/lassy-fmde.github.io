 
 
 
#import "GeneralGUI_Image.h"
#import "PropertyChangeList.h"
#import "MobileLibraryGUI_StartController.h"


 
@implementation GeneralGUI_Image

 
-(void)create_binding {
	OCLString* filename = [self _imageFilename];	
	self->image = [UIImage imageNamed:filename->string];
	[self->image retain];
	self->binding = [[UIImageView alloc] initWithImage:self->image];
	[self->binding retain];
}

- (id) init {
	self = [super init];
	 
	self->MobileLibraryGUI_StartController_logo_back = [[NSMutableArray alloc] init];

	[self set_imageFilename: [self _imageFilename]];


	 
	[self performSelectorOnMainThread:@selector(create_binding) withObject:nil waitUntilDone:YES]; 	

	return self;
}

 
- (id) initWithValues: (OCLTuple*) values {
	self = [super init];
	 
	self->_imageFilename_initialized = NO;

	self->MobileLibraryGUI_StartController_logo_back = [[NSMutableArray alloc] init];

	OCLString* _imageFilename_initialValue = (OCLString*) [values objectForKey:@"imageFilename"];
	if (_imageFilename_initialValue == nil) {
		_imageFilename_initialValue = [self _imageFilename];
	}
	[self set_imageFilename:_imageFilename_initialValue];


	 
	[self performSelectorOnMainThread:@selector(create_binding) withObject:nil waitUntilDone:YES]; 	

	return self;
}

 
- (void) dealloc {
	if (self->_imageFilename != nil && self->_imageFilename != (OCLString*) [NSNull null]) [self->_imageFilename release];

	[self->MobileLibraryGUI_StartController_logo_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"GeneralGUI::Image\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"imageFilename\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _imageFilename]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
-(OCLString*) initial_imageFilename {
	/* ==================================================
	 * null
	 * ================================================== */
	
	OCLString* v0 = [NSNull null];
	
	return v0;
}

-(OCLString*) _imageFilename {
	if (self->_imageFilename_initialized == YES) {
		return _imageFilename;
	} else { 
		[self set_imageFilename:[self initial_imageFilename]];
	}

	self->_imageFilename_initialized = YES;
	return _imageFilename;
}


 
-(void) set_imageFilename:(OCLString*) value {
	 	if (self->_imageFilename!= nil && self->_imageFilename!= (OCLString*) [NSNull null]) {
		[self->_imageFilename release];
	}
	self->_imageFilename = value;
	if (self->_imageFilename!= nil && self->_imageFilename!= (OCLString*) [NSNull null]) {
		[self->_imageFilename retain];
	}
	self->_imageFilename_initialized = YES;
	
	[self onPropertyChange:@"imageFilename" newValue:value];
}






 

 


 
-(void)onPropertyChange:(NSString*)propertyName newValue:(id) value {
}

 
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters{
}

 
-(id) getBinding {
	return self->binding;
}


@end 


