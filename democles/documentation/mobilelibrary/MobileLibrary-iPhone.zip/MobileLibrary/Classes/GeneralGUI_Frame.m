 
 
 
#import "GeneralGUI_Frame.h"
#import "PropertyChangeList.h"
#import "MobileLibraryGUI_MemberController.h"
#import "MobileLibraryGUI_SearchController.h"
#import "MobileLibraryGUI_LoginController.h"


 
@implementation GeneralGUI_Frame


-(void)create_binding {
	self->binding = [[UIViewController alloc] init];
	[self->binding retain];
}
 
- (id) init {
	self = [super init];
	 
	[self performSelectorOnMainThread:@selector(create_binding) withObject:nil waitUntilDone:YES]; 	

	 
	self->MobileLibraryGUI_MemberController_window_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_SearchController_frame_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_LoginController_frame_back = [[NSMutableArray alloc] init];

	[self set_seqGUIElements: [self _seqGUIElements]];
	[self set_frameTitle: [self _frameTitle]];
	[self set_iconFilename: [self _iconFilename]];


	 
	[self performSelectorOnMainThread:@selector(updateWidgets:) withObject:self->binding.view waitUntilDone:NO]; 	

	return self;
}

 
- (id) initWithValues: (OCLTuple*) values {
	self = [super init];
	 
	[self performSelectorOnMainThread:@selector(create_binding) withObject:nil waitUntilDone:YES]; 	

	 
	self->_seqGUIElements_initialized = NO;
	self->_frameTitle_initialized = NO;
	self->_iconFilename_initialized = NO;

	self->MobileLibraryGUI_MemberController_window_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_SearchController_frame_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_LoginController_frame_back = [[NSMutableArray alloc] init];

	OCLSequence* _seqGUIElements_initialValue = (OCLSequence*) [values objectForKey:@"seqGUIElements"];
	if (_seqGUIElements_initialValue == nil) {
		_seqGUIElements_initialValue = [self _seqGUIElements];
	}
	[self set_seqGUIElements:_seqGUIElements_initialValue];
	OCLString* _frameTitle_initialValue = (OCLString*) [values objectForKey:@"frameTitle"];
	if (_frameTitle_initialValue == nil) {
		_frameTitle_initialValue = [self _frameTitle];
	}
	[self set_frameTitle:_frameTitle_initialValue];
	OCLString* _iconFilename_initialValue = (OCLString*) [values objectForKey:@"iconFilename"];
	if (_iconFilename_initialValue == nil) {
		_iconFilename_initialValue = [self _iconFilename];
	}
	[self set_iconFilename:_iconFilename_initialValue];


	 
	[self performSelectorOnMainThread:@selector(updateWidgets:) withObject:self->binding.view waitUntilDone:NO]; 	

	return self;
}

 
- (void) dealloc {
	if (self->_seqGUIElements != nil && self->_seqGUIElements != (OCLSequence*) [NSNull null]) [self->_seqGUIElements release];
	if (self->_frameTitle != nil && self->_frameTitle != (OCLString*) [NSNull null]) [self->_frameTitle release];
	if (self->_iconFilename != nil && self->_iconFilename != (OCLString*) [NSNull null]) [self->_iconFilename release];

	[self->MobileLibraryGUI_MemberController_window_back release];
	[self->MobileLibraryGUI_SearchController_frame_back release];
	[self->MobileLibraryGUI_LoginController_frame_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"GeneralGUI::Frame\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"seqGUIElements\" type=\"Sequence\">\n"];
	[res appendFormat:@"%@\n", [self _seqGUIElements]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"frameTitle\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _frameTitle]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"iconFilename\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _iconFilename]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
-(OCLSequence*) initial_seqGUIElements {
	/* ==================================================
	 * Sequence {}
	 * ================================================== */
	
	OCLSequence* v0 = [(OCLSequence*)[OCLSequence alloc] init];
	
	return v0;
}

-(OCLSequence*) _seqGUIElements {
	if (self->_seqGUIElements_initialized == YES) {
		return _seqGUIElements;
	} else { 
		[self set_seqGUIElements:[self initial_seqGUIElements]];
	}

	self->_seqGUIElements_initialized = YES;
	return _seqGUIElements;
}
-(OCLString*) initial_frameTitle {
	/* ==================================================
	 * ''
	 * ================================================== */
	
	OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@""];
	
	return v0;
}

-(OCLString*) _frameTitle {
	if (self->_frameTitle_initialized == YES) {
		return _frameTitle;
	} else { 
		[self set_frameTitle:[self initial_frameTitle]];
	}

	self->_frameTitle_initialized = YES;
	return _frameTitle;
}
-(OCLString*) initial_iconFilename {
	/* ==================================================
	 * ''
	 * ================================================== */
	
	OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@""];
	
	return v0;
}

-(OCLString*) _iconFilename {
	if (self->_iconFilename_initialized == YES) {
		return _iconFilename;
	} else { 
		[self set_iconFilename:[self initial_iconFilename]];
	}

	self->_iconFilename_initialized = YES;
	return _iconFilename;
}


 
-(void) set_seqGUIElements:(OCLSequence*) value {
	 	if (self->_seqGUIElements!= nil && self->_seqGUIElements!= (OCLSequence*) [NSNull null]) {
		[self->_seqGUIElements release];
	}
	self->_seqGUIElements = value;
	if (self->_seqGUIElements!= nil && self->_seqGUIElements!= (OCLSequence*) [NSNull null]) {
		[self->_seqGUIElements retain];
	}
	self->_seqGUIElements_initialized = YES;
	
	[self onPropertyChange:@"seqGUIElements" newValue:value];
}
-(void) set_frameTitle:(OCLString*) value {
	 	if (self->_frameTitle!= nil && self->_frameTitle!= (OCLString*) [NSNull null]) {
		[self->_frameTitle release];
	}
	self->_frameTitle = value;
	if (self->_frameTitle!= nil && self->_frameTitle!= (OCLString*) [NSNull null]) {
		[self->_frameTitle retain];
	}
	self->_frameTitle_initialized = YES;
	
	[self onPropertyChange:@"frameTitle" newValue:value];
}
-(void) set_iconFilename:(OCLString*) value {
	 	if (self->_iconFilename!= nil && self->_iconFilename!= (OCLString*) [NSNull null]) {
		[self->_iconFilename release];
	}
	self->_iconFilename = value;
	if (self->_iconFilename!= nil && self->_iconFilename!= (OCLString*) [NSNull null]) {
		[self->_iconFilename retain];
	}
	self->_iconFilename_initialized = YES;
	
	[self onPropertyChange:@"iconFilename" newValue:value];
}






 

 




-(void)updateTabBarItem {
	NSString* title = nil;
	UIImage* icon = nil;
	
	OCLString* oclTitle = [self _frameTitle];
	if (oclTitle != nil) {
		title = oclTitle->string;
	}
	
	OCLString* oclIcon = [self _iconFilename];
	if (oclIcon != nil) {
		NSString* iconFilename = oclIcon->string;
		icon = [UIImage imageNamed:iconFilename];
	}
	
	UITabBarItem* item = [[UITabBarItem alloc] initWithTitle:title image:icon tag:0];
	[self->binding setTabBarItem:item];
}
 
-(void)onPropertyChange_async:(NSDictionary*)parameters {
	NSString* propertyName = [parameters objectForKey:@"propertyName"];
	id value = [parameters objectForKey:@"value"];
	
	if ([propertyName isEqual:@"frameTitle"]) {
		if (value != nil && value != [NSNull null]) {
			[self->binding setTitle: ((OCLString *) value)->string ];
		}
		[self updateTabBarItem];
	}
	if ([propertyName isEqual:@"iconFilename"]) {
		[self updateTabBarItem];
	}
	[parameters release];	
}

-(void)onPropertyChange:(NSString*)propertyName newValue:(id) value {
	NSMutableDictionary* parameters = [[NSMutableDictionary alloc] init];
	[parameters setValue:propertyName forKey:@"propertyName"];
	[parameters setValue:value forKey:@"value"];
	[parameters retain];
	[self performSelectorOnMainThread:@selector(onPropertyChange_async:) withObject:parameters waitUntilDone:NO];
}

 
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters{
}

 
-(id) getBinding {
	return self->binding;
}

 
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value {
	if ([propertyName isEqual:@"navigationController"]) {
		if (value != nil && value != [NSNull null] && [value isKindOfClass: [UINavigationController class]]) 
			self->navigationController = (UINavigationController *) value;
	}
}

 
- (void) updateWidgets:(UIView*)destView {
	OCLSequence* widgets = [self _seqGUIElements];
	int y_pos = 0;
	NSEnumerator* e = [widgets objectEnumerator];
	id object;
	while ((object = [e nextObject])) {
		if ([object conformsToProtocol:@protocol(IBinding)]) {
			id<IBinding> propBinding = [object getBinding];
			UIView* view;
			if ([propBinding isKindOfClass: [UIViewController class]]) {
				view = ((UIViewController*)propBinding).view;
			} else if ([propBinding isKindOfClass: [UIView class]]) {
				view = (UIView*)propBinding;
			} else {
				NSLog(@"%@: Attempt to add incompatible object as UIView", self);
				view = NULL;
			}
			
			if ([view isKindOfClass: [UIPickerView class]]){
				view.frame  = CGRectMake(0,  y_pos, 320, 162);
				y_pos += 172;
			} else if ([view isKindOfClass: [UITableView class]]) {
				CGRect appFrame = [[UIScreen mainScreen] applicationFrame];
				
				OCLInteger* numWidgets = [widgets size];
				if (numWidgets->value == 1) {
					appFrame.origin.y = 0;
				} else {
					appFrame.origin.y = y_pos;
					appFrame.size.height = 80;
				}

				view.frame = appFrame;
				y_pos += appFrame.size.height;
				[numWidgets release];
			} else if ([view isKindOfClass: [UIImageView class]]) {
				CGRect appFrame = [[UIScreen mainScreen] applicationFrame];				
				CGSize imgSize = ((UIImageView*)view).image.size;
				int x = (appFrame.size.width - imgSize.width) / 2;
				view.frame = CGRectMake(x, y_pos, imgSize.width, imgSize.height);
				y_pos += imgSize.height + 10;
			} else {
				view.frame = CGRectMake(20, y_pos + 10, 280, 30);
				y_pos += 40;
			}
			[destView addSubview:view];
		}
	}
}


@end 


