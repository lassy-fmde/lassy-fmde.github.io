 
 
 
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "OCLTypes.h"
#import "IBinding.h"

@class PropertyChangeList;
@class MobileLibraryGUI_BookDetailController;
@class MobileLibraryGUI_MemberController;
@class MobileLibraryGUI_LoginController;
@class MobileLibraryGUI_SearchController;
@class MobileLibraryGUI_StartController;


 
 
@interface GeneralGUI_Label : OCLAny <IBinding>
{
	 
	OCLString* _text;
	BOOL _text_initialized;


@public
	NSMutableArray *MobileLibraryGUI_BookDetailController_bookAuthorLabel_back;
	NSMutableArray *MobileLibraryGUI_MemberController_memberLabel_back;
	NSMutableArray *MobileLibraryGUI_LoginController_passwordLabel_back;
	NSMutableArray *MobileLibraryGUI_MemberController_itemsToCollectLabel_back;
	NSMutableArray *MobileLibraryGUI_MemberController_borrowedItemsLabel_back;
	NSMutableArray *MobileLibraryGUI_BookDetailController_bookCopiesLabel_back;
	NSMutableArray *MobileLibraryGUI_BookDetailController_titleLabel_back;
	NSMutableArray *MobileLibraryGUI_SearchController_searchLabel_back;
	NSMutableArray *MobileLibraryGUI_BookDetailController_bookIsbnLabel_back;
	NSMutableArray *MobileLibraryGUI_BookDetailController_isbnLabel_back;
	NSMutableArray *MobileLibraryGUI_LoginController_libraryNoLabel_back;
	NSMutableArray *MobileLibraryGUI_BookDetailController_bookTitleLabel_back;
	NSMutableArray *MobileLibraryGUI_BookDetailController_authorLabel_back;
	NSMutableArray *MobileLibraryGUI_MemberController_memberNameLabel_back;
	NSMutableArray *MobileLibraryGUI_StartController_msgLabel_back;


	
	@protected
	UILabel* binding;
}

 
-(GeneralGUI_Label*)init;
-(GeneralGUI_Label*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(OCLString*) _text;
-(OCLString*) initial_text;
-(void) set_text:(OCLString*) value;

-(void) event_setText_pushed:(PropertyChangeList*) changes p_text: (OCLString*) p_text;

 
-(id) getBinding;
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value;
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters;
-(void) onPropertyChange: (NSString*)propertyName newValue:(id<OCLAny>)value;


@end


