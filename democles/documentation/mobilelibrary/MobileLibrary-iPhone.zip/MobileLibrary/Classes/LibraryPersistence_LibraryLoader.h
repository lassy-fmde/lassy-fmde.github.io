 
 
 
#import <Foundation/Foundation.h>
#import "OCLTypes.h"

@class PropertyChangeList;
@class Library_Library;
@class Library_Author;
@class LibraryPersistence_LibraryLoader;
@class Library_Member;
@class StringUtils_StringTokenizer;
@class Library_Book;
@class Persistence_FileHandler;
@class Library_Copy;
@class Application_Main;


 
 
@interface LibraryPersistence_LibraryLoader : OCLAny  
 {
	 
	OCLSet* _books;
	BOOL _books_initialized;
	Persistence_FileHandler* _bookFileHandler;
	BOOL _bookFileHandler_initialized;
	StringUtils_StringTokenizer* _bookStringTokenizer;
	BOOL _bookStringTokenizer_initialized;
	OCLSet* _authors;
	BOOL _authors_initialized;
	StringUtils_StringTokenizer* _authorStringTokenizer;
	BOOL _authorStringTokenizer_initialized;
	Persistence_FileHandler* _authorFileHandler;
	BOOL _authorFileHandler_initialized;
	Persistence_FileHandler* _copyFileHandler;
	BOOL _copyFileHandler_initialized;
	StringUtils_StringTokenizer* _copyStringTokenizer;
	BOOL _copyStringTokenizer_initialized;
	OCLSet* _copies;
	BOOL _copies_initialized;
	Persistence_FileHandler* _memberFileHandler;
	BOOL _memberFileHandler_initialized;
	StringUtils_StringTokenizer* _memberStringTokenizer;
	BOOL _memberStringTokenizer_initialized;
	OCLSet* _members;
	BOOL _members_initialized;
	Persistence_FileHandler* _saveCopiesFileHandler;
	BOOL _saveCopiesFileHandler_initialized;
	Persistence_FileHandler* _borrowsFileHandler;
	BOOL _borrowsFileHandler_initialized;
	StringUtils_StringTokenizer* _borrowsStringTokenizer;
	BOOL _borrowsStringTokenizer_initialized;
	Persistence_FileHandler* _toCollectFileHandler;
	BOOL _toCollectFileHandler_initialized;
	StringUtils_StringTokenizer* _toCollectStringTokenizer;
	BOOL _toCollectStringTokenizer_initialized;
	Persistence_FileHandler* _saveBorrowsFileHandler;
	BOOL _saveBorrowsFileHandler_initialized;
	Persistence_FileHandler* _saveToCollectFileHandler;
	BOOL _saveToCollectFileHandler_initialized;


@public
	NSMutableArray *Application_Main_libraryFileHandler_back;


}

 
-(LibraryPersistence_LibraryLoader*)init;
-(LibraryPersistence_LibraryLoader*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(OCLSet*) _books;
-(OCLSet*) initial_books;
-(void) set_books:(OCLSet*) value;
-(Persistence_FileHandler*) _bookFileHandler;
-(Persistence_FileHandler*) initial_bookFileHandler;
-(void) set_bookFileHandler:(Persistence_FileHandler*) value;
-(StringUtils_StringTokenizer*) _bookStringTokenizer;
-(StringUtils_StringTokenizer*) initial_bookStringTokenizer;
-(void) set_bookStringTokenizer:(StringUtils_StringTokenizer*) value;
-(OCLSet*) _authors;
-(OCLSet*) initial_authors;
-(void) set_authors:(OCLSet*) value;
-(StringUtils_StringTokenizer*) _authorStringTokenizer;
-(StringUtils_StringTokenizer*) initial_authorStringTokenizer;
-(void) set_authorStringTokenizer:(StringUtils_StringTokenizer*) value;
-(Persistence_FileHandler*) _authorFileHandler;
-(Persistence_FileHandler*) initial_authorFileHandler;
-(void) set_authorFileHandler:(Persistence_FileHandler*) value;
-(Persistence_FileHandler*) _copyFileHandler;
-(Persistence_FileHandler*) initial_copyFileHandler;
-(void) set_copyFileHandler:(Persistence_FileHandler*) value;
-(StringUtils_StringTokenizer*) _copyStringTokenizer;
-(StringUtils_StringTokenizer*) initial_copyStringTokenizer;
-(void) set_copyStringTokenizer:(StringUtils_StringTokenizer*) value;
-(OCLSet*) _copies;
-(OCLSet*) initial_copies;
-(void) set_copies:(OCLSet*) value;
-(Persistence_FileHandler*) _memberFileHandler;
-(Persistence_FileHandler*) initial_memberFileHandler;
-(void) set_memberFileHandler:(Persistence_FileHandler*) value;
-(StringUtils_StringTokenizer*) _memberStringTokenizer;
-(StringUtils_StringTokenizer*) initial_memberStringTokenizer;
-(void) set_memberStringTokenizer:(StringUtils_StringTokenizer*) value;
-(OCLSet*) _members;
-(OCLSet*) initial_members;
-(void) set_members:(OCLSet*) value;
-(Persistence_FileHandler*) _saveCopiesFileHandler;
-(Persistence_FileHandler*) initial_saveCopiesFileHandler;
-(void) set_saveCopiesFileHandler:(Persistence_FileHandler*) value;
-(Persistence_FileHandler*) _borrowsFileHandler;
-(Persistence_FileHandler*) initial_borrowsFileHandler;
-(void) set_borrowsFileHandler:(Persistence_FileHandler*) value;
-(StringUtils_StringTokenizer*) _borrowsStringTokenizer;
-(StringUtils_StringTokenizer*) initial_borrowsStringTokenizer;
-(void) set_borrowsStringTokenizer:(StringUtils_StringTokenizer*) value;
-(Persistence_FileHandler*) _toCollectFileHandler;
-(Persistence_FileHandler*) initial_toCollectFileHandler;
-(void) set_toCollectFileHandler:(Persistence_FileHandler*) value;
-(StringUtils_StringTokenizer*) _toCollectStringTokenizer;
-(StringUtils_StringTokenizer*) initial_toCollectStringTokenizer;
-(void) set_toCollectStringTokenizer:(StringUtils_StringTokenizer*) value;
-(Persistence_FileHandler*) _saveBorrowsFileHandler;
-(Persistence_FileHandler*) initial_saveBorrowsFileHandler;
-(void) set_saveBorrowsFileHandler:(Persistence_FileHandler*) value;
-(Persistence_FileHandler*) _saveToCollectFileHandler;
-(Persistence_FileHandler*) initial_saveToCollectFileHandler;
-(void) set_saveToCollectFileHandler:(Persistence_FileHandler*) value;

-(void) event_loadBooks_pushed:(PropertyChangeList*) changes ;
-(void) event_bookLineRead_pushed:(PropertyChangeList*) changes p_line: (OCLString*) p_line;
-(void) event_bookLineRead_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Persistence_FileHandler*)parentInstance p_line:(OCLString*)p_line ;
-(void) event_bookFileClosed_pushed:(PropertyChangeList*) changes ;
-(void) event_bookFileClosed_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Persistence_FileHandler*)parentInstance ;
-(void) event_bookLineTokenized_pushed:(PropertyChangeList*) changes p_tokens: (OCLSequence*) p_tokens;
-(void) event_bookLineTokenized_pulled_edge0:(PropertyChangeList*)changes parentInstance:(StringUtils_StringTokenizer*)parentInstance p_tokens:(OCLSequence*)p_tokens ;
-(void) event_load_pushed:(PropertyChangeList*) changes ;
-(void) event_loadAuthors_pushed:(PropertyChangeList*) changes ;
-(void) event_authorsLineRead_pushed:(PropertyChangeList*) changes p_line: (OCLString*) p_line;
-(void) event_authorsLineRead_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Persistence_FileHandler*)parentInstance p_line:(OCLString*)p_line ;
-(void) event_authorsLineTokenized_pushed:(PropertyChangeList*) changes p_tokens: (OCLSequence*) p_tokens;
-(void) event_authorsLineTokenized_pulled_edge0:(PropertyChangeList*)changes parentInstance:(StringUtils_StringTokenizer*)parentInstance p_tokens:(OCLSequence*)p_tokens ;
-(void) event_authorsFileClosed_pushed:(PropertyChangeList*) changes ;
-(void) event_authorsFileClosed_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Persistence_FileHandler*)parentInstance ;
-(void) event_copyLineRead_pushed:(PropertyChangeList*) changes p_line: (OCLString*) p_line;
-(void) event_copyLineRead_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Persistence_FileHandler*)parentInstance p_line:(OCLString*)p_line ;
-(void) event_loadCopies_pushed:(PropertyChangeList*) changes ;
-(void) event_copyLineTokenized_pushed:(PropertyChangeList*) changes p_tokens: (OCLSequence*) p_tokens;
-(void) event_copyLineTokenized_pulled_edge0:(PropertyChangeList*)changes parentInstance:(StringUtils_StringTokenizer*)parentInstance p_tokens:(OCLSequence*)p_tokens ;
-(void) event_copyFileClosed_pushed:(PropertyChangeList*) changes ;
-(void) event_copyFileClosed_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Persistence_FileHandler*)parentInstance ;
-(void) event_updateBookCopies_pushed:(PropertyChangeList*) changes ;
-(void) event_loadMembers_pushed:(PropertyChangeList*) changes ;
-(void) event_memberLineRead_pushed:(PropertyChangeList*) changes p_line: (OCLString*) p_line;
-(void) event_memberLineRead_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Persistence_FileHandler*)parentInstance p_line:(OCLString*)p_line ;
-(void) event_memberLineTokenized_pushed:(PropertyChangeList*) changes p_tokens: (OCLSequence*) p_tokens;
-(void) event_memberLineTokenized_pulled_edge0:(PropertyChangeList*)changes parentInstance:(StringUtils_StringTokenizer*)parentInstance p_tokens:(OCLSequence*)p_tokens ;
-(void) event_memberFileClosed_pushed:(PropertyChangeList*) changes ;
-(void) event_memberFileClosed_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Persistence_FileHandler*)parentInstance ;
-(void) event_libraryLoaded_pushed:(PropertyChangeList*) changes p_library: (Library_Library*) p_library;
-(void) event_saveCopies_pushed:(PropertyChangeList*) changes p_copies: (OCLSequence*) p_copies;
-(void) event_loadBorrows_pushed:(PropertyChangeList*) changes ;
-(void) event_borrowsLineRead_pushed:(PropertyChangeList*) changes p_line: (OCLString*) p_line;
-(void) event_borrowsLineRead_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Persistence_FileHandler*)parentInstance p_line:(OCLString*)p_line ;
-(void) event_borrowsLineTokenized_pushed:(PropertyChangeList*) changes p_tokens: (OCLSequence*) p_tokens;
-(void) event_borrowsLineTokenized_pulled_edge0:(PropertyChangeList*)changes parentInstance:(StringUtils_StringTokenizer*)parentInstance p_tokens:(OCLSequence*)p_tokens ;
-(void) event_borrowsFileClosed_pushed:(PropertyChangeList*) changes ;
-(void) event_borrowsFileClosed_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Persistence_FileHandler*)parentInstance ;
-(void) event_loadToCollect_pushed:(PropertyChangeList*) changes ;
-(void) event_toCollectLineTokenized_pushed:(PropertyChangeList*) changes p_tokens: (OCLSequence*) p_tokens;
-(void) event_toCollectLineTokenized_pulled_edge0:(PropertyChangeList*)changes parentInstance:(StringUtils_StringTokenizer*)parentInstance p_tokens:(OCLSequence*)p_tokens ;
-(void) event_toCollectFileClosed_pushed:(PropertyChangeList*) changes ;
-(void) event_toCollectFileClosed_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Persistence_FileHandler*)parentInstance ;
-(void) event_toCollectLineRead_pushed:(PropertyChangeList*) changes p_line: (OCLString*) p_line;
-(void) event_toCollectLineRead_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Persistence_FileHandler*)parentInstance p_line:(OCLString*)p_line ;
-(void) event_saveBorrows_pushed:(PropertyChangeList*) changes p_members: (OCLSequence*) p_members;
-(void) event_saveLibrary_pushed:(PropertyChangeList*) changes p_library: (Library_Library*) p_library;
-(void) event_saveToCollect_pushed:(PropertyChangeList*) changes p_members: (OCLSequence*) p_members;


@end


