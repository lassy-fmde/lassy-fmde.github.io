 
 
 
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "OCLTypes.h"
#import "IBinding.h"

@class PropertyChangeList;
@class MobileLibraryGUI_MemberController;
@class MobileLibraryGUI_SearchResultsController;
@class MobileLibraryGUI_BookDetailController;


 
 
@interface GeneralGUI_SelectionList : OCLAny <IBinding,UITableViewDelegate, UITableViewDataSource>
{
	 
	OCLSequence* _items;
	BOOL _items_initialized;


@public
	NSMutableArray *MobileLibraryGUI_MemberController_borrowItems_back;
	NSMutableArray *MobileLibraryGUI_MemberController_collectItems_back;
	NSMutableArray *MobileLibraryGUI_SearchResultsController_bookListTable_back;
	NSMutableArray *MobileLibraryGUI_BookDetailController_bookCopies_back;


	
	@protected
	UITableView* binding;
}

 
-(GeneralGUI_SelectionList*)init;
-(GeneralGUI_SelectionList*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(OCLSequence*) _items;
-(OCLSequence*) initial_items;
-(void) set_items:(OCLSequence*) value;

-(void) event_itemSelected_pushed:(PropertyChangeList*) changes p_index: (OCLInteger*) p_index;
-(void) event_refreshItems_pushed:(PropertyChangeList*) changes p_items: (OCLSequence*) p_items;

 
-(id) getBinding;
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value;
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters;
-(void) onPropertyChange: (NSString*)propertyName newValue:(id<OCLAny>)value;


@end


