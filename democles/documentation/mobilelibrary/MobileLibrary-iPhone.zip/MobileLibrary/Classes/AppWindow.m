#import "AppWindow.h"
 
@implementation AppWindow
 
static AppWindow* gInstance = NULL;

+(AppWindow*)instance {
	@synchronized(self) {
	    if (gInstance == NULL)
	        gInstance = [[self alloc] init];
	    }
		return(gInstance);
	}

-(id)init {
	self = [super init];
	self->window = nil;
	self->navController = nil;
	return self;
}

-(void)pushViewController_async:(UIViewController*)controller {
	NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
	@synchronized(self) {
		if (self->window == nil) {
			self->window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
			[self->window makeKeyAndVisible];
			[self->window retain];
		}
	}
	if (self->navController == nil) {
		self->navController = [[UINavigationController alloc] initWithRootViewController:controller];
		[self->navController.view setBackgroundColor:[UIColor whiteColor]];
		[self->window addSubview:self->navController.view];
	} else {
		[self->navController pushViewController:controller animated:YES];
	}
	[pool release];
}

-(void)pushViewController:(UIViewController*)controller {
	[self performSelectorOnMainThread:@selector(pushViewController_async:) withObject:controller waitUntilDone:NO];
}

-(void)popViewController_async:(UIViewController*)controller {
	@synchronized(self) {
		if (self->navController == nil) return;
		NSMutableArray *allViewControllers = [NSMutableArray arrayWithArray: self->navController.viewControllers];
		[allViewControllers removeObjectIdenticalTo: controller];
		self->navController.viewControllers = allViewControllers;
	}
}

-(void)popViewController:(UIViewController*)controller {
	[self performSelectorOnMainThread:@selector(popViewController_async:) withObject:controller waitUntilDone:NO];
}

@end 
