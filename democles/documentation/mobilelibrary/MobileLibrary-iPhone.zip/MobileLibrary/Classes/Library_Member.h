 
 
 
#import <Foundation/Foundation.h>
#import "OCLTypes.h"

@class PropertyChangeList;
@class Library_Copy;
@class LibraryPersistence_LibraryLoader;
@class MobileLibraryGUI_SearchController;
@class MobileLibraryGUI_MemberController;
@class MobileLibraryGUI_BookDetailController;
@class MobileLibraryGUI_SearchResultsController;
@class Library_Library;


 
 
@interface Library_Member : OCLAny  
 {
	 
	OCLString* _libraryNo;
	BOOL _libraryNo_initialized;
	OCLString* _name;
	BOOL _name_initialized;
	OCLSet* _borrows;
	BOOL _borrows_initialized;
	OCLSet* _toCollect;
	BOOL _toCollect_initialized;
	OCLString* _password;
	BOOL _password_initialized;


@public
	NSMutableArray *LibraryPersistence_LibraryLoader_members_back;
	NSMutableArray *MobileLibraryGUI_SearchController_currMember_back;
	NSMutableArray *MobileLibraryGUI_MemberController_currMember_back;
	NSMutableArray *MobileLibraryGUI_BookDetailController_currMember_back;
	NSMutableArray *MobileLibraryGUI_SearchResultsController_currMember_back;
	NSMutableArray *Library_Library_members_back;


}

 
-(Library_Member*)init;
-(Library_Member*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(OCLString*) _libraryNo;
-(OCLString*) initial_libraryNo;
-(void) set_libraryNo:(OCLString*) value;
-(OCLString*) _name;
-(OCLString*) initial_name;
-(void) set_name:(OCLString*) value;
-(OCLSet*) _borrows;
-(OCLSet*) initial_borrows;
-(void) set_borrows:(OCLSet*) value;
-(OCLSet*) _toCollect;
-(OCLSet*) initial_toCollect;
-(void) set_toCollect:(OCLSet*) value;
-(OCLString*) _password;
-(OCLString*) initial_password;
-(void) set_password:(OCLString*) value;

-(void) event_setBorrows_pushed:(PropertyChangeList*) changes p_borrows: (OCLSet*) p_borrows;
-(void) event_setToCollect_pushed:(PropertyChangeList*) changes p_toCollect: (OCLSet*) p_toCollect;
-(void) event_addCopyToCollect_pushed:(PropertyChangeList*) changes p_copy: (Library_Copy*) p_copy;


@end


