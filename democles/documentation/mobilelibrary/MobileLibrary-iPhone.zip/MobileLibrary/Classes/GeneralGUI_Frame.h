 
 
 
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "OCLTypes.h"
#import "IBinding.h"

@class PropertyChangeList;
@class MobileLibraryGUI_MemberController;
@class MobileLibraryGUI_SearchController;
@class MobileLibraryGUI_LoginController;


 
 
@interface GeneralGUI_Frame : OCLAny <IBinding>
{
	 
	OCLSequence* _seqGUIElements;
	BOOL _seqGUIElements_initialized;
	OCLString* _frameTitle;
	BOOL _frameTitle_initialized;
	OCLString* _iconFilename;
	BOOL _iconFilename_initialized;


@public
	NSMutableArray *MobileLibraryGUI_MemberController_window_back;
	NSMutableArray *MobileLibraryGUI_SearchController_frame_back;
	NSMutableArray *MobileLibraryGUI_LoginController_frame_back;


	
	@protected
	UIViewController* binding;
	UINavigationController* navigationController;
}

 
-(GeneralGUI_Frame*)init;
-(GeneralGUI_Frame*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(OCLSequence*) _seqGUIElements;
-(OCLSequence*) initial_seqGUIElements;
-(void) set_seqGUIElements:(OCLSequence*) value;
-(OCLString*) _frameTitle;
-(OCLString*) initial_frameTitle;
-(void) set_frameTitle:(OCLString*) value;
-(OCLString*) _iconFilename;
-(OCLString*) initial_iconFilename;
-(void) set_iconFilename:(OCLString*) value;


 
-(id) getBinding;
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value;
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters;
-(void) onPropertyChange: (NSString*)propertyName newValue:(id<OCLAny>)value;

 
-(void) updateWidgets:(UIView*)destView;


@end


