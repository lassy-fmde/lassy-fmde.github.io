#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "OCLTypes.h"
#import "IBinding.h"
 
@interface AppWindow : NSObject {
	 
	UIWindow* window;
	
	@private
	UINavigationController* navController;
}

-(id)init; 	
-(void)pushViewController:(UIViewController*)controller;
-(void)popViewController:(UIViewController*)controller;
+(id)instance;

@end
