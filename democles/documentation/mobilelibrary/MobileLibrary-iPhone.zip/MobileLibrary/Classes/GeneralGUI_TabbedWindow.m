 
 
 
#import "GeneralGUI_TabbedWindow.h"
#import "PropertyChangeList.h"
#import "MobileLibraryGUI_ViewsController.h"


 
@implementation GeneralGUI_TabbedWindow


-(void)create_binding {
	self->binding = [[UIViewController alloc] init];
	[self->binding retain];
	self->tabBar = [[UITabBar alloc] init];
	CGRect size = [[UIScreen mainScreen] applicationFrame];
	self->tabBar.frame = CGRectMake(0, size.size.height - 104, size.size.width, 60);
	self->tabBar.delegate = self;
	
	[self->binding.view addSubview:self->tabBar];
	
	[[AppWindow instance] pushViewController:self->binding];
}
 
- (id) init {
	self = [super init];
	 
	[self performSelectorOnMainThread:@selector(create_binding) withObject:nil waitUntilDone:YES]; 	
	
	 
	self->MobileLibraryGUI_ViewsController_viewsWindow_back = [[NSMutableArray alloc] init];

	[self set_views: [self _views]];


	return self;
}

 
- (id) initWithValues: (OCLTuple*) values {
	self = [super init];
	 
	[self performSelectorOnMainThread:@selector(create_binding) withObject:nil waitUntilDone:YES]; 	

	 
	self->_views_initialized = NO;

	self->MobileLibraryGUI_ViewsController_viewsWindow_back = [[NSMutableArray alloc] init];

	OCLSequence* _views_initialValue = (OCLSequence*) [values objectForKey:@"views"];
	if (_views_initialValue == nil) {
		_views_initialValue = [self _views];
	}
	[self set_views:_views_initialValue];


	return self;
}

 
- (void) dealloc {
	if (self->_views != nil && self->_views != (OCLSequence*) [NSNull null]) [self->_views release];

	[self->MobileLibraryGUI_ViewsController_viewsWindow_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"GeneralGUI::TabbedWindow\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"views\" type=\"Sequence\">\n"];
	[res appendFormat:@"%@\n", [self _views]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
-(OCLSequence*) initial_views {
	/* ==================================================
	 * Sequence {}
	 * ================================================== */
	
	OCLSequence* v0 = [(OCLSequence*)[OCLSequence alloc] init];
	
	return v0;
}

-(OCLSequence*) _views {
	if (self->_views_initialized == YES) {
		return _views;
	} else { 
		[self set_views:[self initial_views]];
	}

	self->_views_initialized = YES;
	return _views;
}


 
-(void) set_views:(OCLSequence*) value {
	 	if (self->_views!= nil && self->_views!= (OCLSequence*) [NSNull null]) {
		[self->_views release];
	}
	self->_views = value;
	if (self->_views!= nil && self->_views!= (OCLSequence*) [NSNull null]) {
		[self->_views retain];
	}
	self->_views_initialized = YES;
	
	[self onPropertyChange:@"views" newValue:value];
}






 

 
-(void) event_closeWindow_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_closeWindow", @"GeneralGUI_TabbedWindow");

		OCLTuple* parameters = [[OCLTuple alloc] init];

		[self onEvent:@"closeWindow" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_addView_pushed:(PropertyChangeList*) changes  p_view: (OCLAny*) p_view{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_addView", @"GeneralGUI_TabbedWindow");

		OCLTuple* parameters = [[OCLTuple alloc] init];
		[parameters addItemNamed:@"view" withValue:p_view]; 

		[self onEvent:@"addView" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * views->append(view)
		 * ================================================== */
		
		GeneralGUI_TabbedWindow* v2 = self;
		OCLSequence* v1 = [v2 _views];
		OCLAny* v3 = p_view;
		OCLSequence* v0 = [v1 append:v3];
		
		OCLSequence* _views_newValue = v0;
		[changes addChange:@selector(set_views:) instance:self value:_views_newValue];


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_changeView_pushed:(PropertyChangeList*) changes  p_index: (OCLInteger*) p_index p_view: (OCLAny*) p_view{
	{ // New scope for following guard code:
		/* ==================================================
		 * index>=1 and index <= views->size()
		 * ================================================== */
		
		OCLInteger* v2 = p_index;
		OCLInteger* v3 = [(OCLInteger*)[OCLInteger alloc] initWithValue:1];
		OCLBoolean* v1 = [v2 gte:v3];
		OCLInteger* v5 = p_index;
		GeneralGUI_TabbedWindow* v8 = self;
		OCLSequence* v7 = [v8 _views];
		OCLInteger* v6 = [v7 size];
		OCLBoolean* v4 = [v5 lte:v6];
		OCLBoolean* v0 = [v1 and:v4];
		[v4 release];
		[v3 release];
		[v6 release];
		[v1 release];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_changeView", @"GeneralGUI_TabbedWindow");

		OCLTuple* parameters = [[OCLTuple alloc] init];
		[parameters addItemNamed:@"index" withValue:p_index]; 
		[parameters addItemNamed:@"view" withValue:p_view]; 

		[self onEvent:@"changeView" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * views->subSequence(index+1, views->size())->iterate(
		 * 	elem : OclAny; 
		 * 	res : Sequence (OclAny) = views->subSequence(1, index-1)->append(view)
		 * 	| res->append(elem))
		 * ================================================== */
		
		GeneralGUI_TabbedWindow* v3 = self;
		OCLSequence* v2 = [v3 _views];
		OCLInteger* v5 = p_index;
		OCLInteger* v6 = [(OCLInteger*)[OCLInteger alloc] initWithValue:1];
		OCLInteger* v4 = [v5 plus:v6];
		GeneralGUI_TabbedWindow* v9 = self;
		OCLSequence* v8 = [v9 _views];
		OCLInteger* v7 = [v8 size];
		OCLSequence* v1 = [v2 subSequence:v4 upper:v7];
		GeneralGUI_TabbedWindow* v15 = self;
		OCLSequence* v14 = [v15 _views];
		OCLInteger* v16 = [(OCLInteger*)[OCLInteger alloc] initWithValue:1];
		OCLInteger* v18 = p_index;
		OCLInteger* v19 = [(OCLInteger*)[OCLInteger alloc] initWithValue:1];
		OCLInteger* v17 = [v18 minus:v19];
		OCLSequence* v13 = [v14 subSequence:v16 upper:v17];
		OCLAny* v20 = p_view;
		OCLSequence* v12 = [v13 append:v20];
		OCLSequence* v11 = v12;
		NSEnumerator* v0_enum = [v1 objectEnumerator];
		OCLAny* v10;
		while ((v10 = [v0_enum nextObject]) != nil) {
			OCLSequence* v22 = v11;
			OCLAny* v23 = v10;
			OCLSequence* v21 = [v22 append:v23];
			v11 = v21;
		}
		OCLSequence* v0 = v11;
		[v13 release];
		[v1 release];
		[v17 release];
		[v6 release];
		[v16 release];
		[v4 release];
		[v19 release];
		[v7 release];
		
		OCLSequence* _views_newValue = v0;
		[changes addChange:@selector(set_views:) instance:self value:_views_newValue];


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 




 
-(void)updateCurrentTab {
	for (UIView *view in [self->binding.view subviews]) {
		if (view != self->tabBar) {
			[view removeFromSuperview];
		}
	}
	
	CGRect size = [[UIScreen mainScreen] applicationFrame];
	int tabNr = self->tabBar.selectedItem.tag;
	id oclObject = [_views->coll objectAtIndex:tabNr];
	id binding = [oclObject getBinding];
	
	if ([binding isKindOfClass: [UIViewController class]]) {
		UIViewController* b = binding;
		UIView* v = b.view;
		v.frame = CGRectMake(0, 0, size.size.width, size.size.height - 164);
		[self->binding.view addSubview:v];
		self->binding.title = b.title;
	}
}

- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item {
	[self performSelectorOnMainThread:@selector(updateCurrentTab) withObject:nil waitUntilDone:YES]; 	
}

-(void)onPropertyChange_async:(NSDictionary*)parameters {
	NSString* propertyName = [parameters objectForKey:@"propertyName"];
	id value = [parameters objectForKey:@"value"];

	if ([propertyName isEqual:@"views"]) {
		UITabBarItem* selectedItem = self->tabBar.selectedItem;
		NSMutableArray* tabBarItems = [[NSMutableArray alloc] init]; 
		
		NSEnumerator* e = [((OCLSequence *) _views) objectEnumerator];
		id object;
		int tag = 0;
		while ((object = [e nextObject])) {
			UITabBarItem* item = nil;
		
			if ([object conformsToProtocol:@protocol(IBinding)]) {
				id<IBinding> b = (id<IBinding>)object;
				id bindingImpl = [b getBinding];
				if ([bindingImpl isKindOfClass:[UIViewController class]]) {
					UIViewController* uvc = (UIViewController*)bindingImpl;
					item = uvc.tabBarItem;
					if (item == nil) {
						item = [[UITabBarItem alloc] initWithTitle:uvc.title image:nil tag:tag++];
					} else {
						item.tag = tag++;
					}
				}	
			}
			if (item != nil) {
				[tabBarItems addObject:item];
			}
		}
		self->tabBar.items = tabBarItems;
		if (selectedItem == nil && [tabBarItems count] > 0) {
			selectedItem = [tabBarItems objectAtIndex:0];
		}
		if (selectedItem.tag >= 0 && selectedItem.tag < [tabBarItems count]) {
			selectedItem = [tabBarItems objectAtIndex:selectedItem.tag];			
		}
		self->tabBar.selectedItem = selectedItem;
		[self updateCurrentTab];
	}
	[parameters release];
}

-(void)onPropertyChange:(NSString*)propertyName newValue:(id) value {
	NSMutableDictionary* parameters = [[NSMutableDictionary alloc] init];
	[parameters setValue:propertyName forKey:@"propertyName"];
	[parameters setValue:value forKey:@"value"];
	[parameters retain];
	[self performSelectorOnMainThread:@selector(onPropertyChange_async:) withObject:parameters waitUntilDone:NO];
}

 
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters{
}

 
-(id) getBinding {
	return self->binding;
}

 
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value {
}


@end 


