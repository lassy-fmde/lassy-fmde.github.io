#import "OCLBoolean.h"

@implementation OCLBoolean

-(OCLBoolean*)initWithValue:(BOOL)v {
	self = [super init];
	value = v;
	return self;
}

-(BOOL)isEqual:(id)other {
	BOOL res;
	if ([self isCompatibleType:other]) {
		OCLBoolean* otherBool = (OCLBoolean*)other;
		res = self->value == otherBool->value; 
	} else {
		res = NO;
	}
	return res;
}

-(NSString*)description {
	return [NSString stringWithFormat:@"<Boolean id=\"%p\" retainCount=\"%i\" value=\"%@\"/>\n", self, [self retainCount], self->value ? @"YES" : @"NO"];
}

-(OCLBoolean*)or:(OCLBoolean*)other {
	return [(OCLBoolean*)[OCLBoolean alloc] initWithValue:self->value || other->value];
}

-(OCLBoolean*)xor:(OCLBoolean*)other {
	return [(OCLBoolean*)[OCLBoolean alloc] initWithValue:self->value ^ other->value];
}

-(OCLBoolean*)and:(OCLBoolean*)other {
	return [(OCLBoolean*)[OCLBoolean alloc] initWithValue:self->value && other->value];
}

-(OCLBoolean*)not {
	return [(OCLBoolean*)[OCLBoolean alloc] initWithValue:!self->value];
}

-(OCLBoolean*)implies:(OCLBoolean*)other {
	return [(OCLBoolean*)[OCLBoolean alloc] initWithValue:(!self->value) || (self->value && other->value)];
}


-(NSUInteger)hash {
	return value ? 1231 : 1237;
}

@end
