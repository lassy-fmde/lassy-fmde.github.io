 
 
 
#import <Foundation/Foundation.h>
#import "OCLTypes.h"

@class PropertyChangeList;
@class GeneralGUI_TabbedWindow;
@class Application_Main;


 
 
@interface MobileLibraryGUI_ViewsController : OCLAny  
 {
	 
	GeneralGUI_TabbedWindow* _viewsWindow;
	BOOL _viewsWindow_initialized;


@public
	NSMutableArray *Application_Main_viewsControl_back;


}

 
-(MobileLibraryGUI_ViewsController*)init;
-(MobileLibraryGUI_ViewsController*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(GeneralGUI_TabbedWindow*) _viewsWindow;
-(GeneralGUI_TabbedWindow*) initial_viewsWindow;
-(void) set_viewsWindow:(GeneralGUI_TabbedWindow*) value;

-(void) event_startViewsWindow_pushed:(PropertyChangeList*) changes p_searchWindow: (OCLAny*) p_searchWindow p_loginWindow: (OCLAny*) p_loginWindow;
-(void) event_changeFromLoginToMember_pushed:(PropertyChangeList*) changes p_memberFrame: (OCLAny*) p_memberFrame;


@end


