 
 
 
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "OCLTypes.h"
#import "IBinding.h"

@class PropertyChangeList;
@class MobileLibraryGUI_StartController;


 
 
@interface GeneralGUI_Image : OCLAny <IBinding>
{
	 
	OCLString* _imageFilename;
	BOOL _imageFilename_initialized;


@public
	NSMutableArray *MobileLibraryGUI_StartController_logo_back;


	
	@protected
	UIImage* image;
	UIImageView* binding;
}

 
-(GeneralGUI_Image*)init;
-(GeneralGUI_Image*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(OCLString*) _imageFilename;
-(OCLString*) initial_imageFilename;
-(void) set_imageFilename:(OCLString*) value;


 
-(id) getBinding;
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value;
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters;
-(void) onPropertyChange: (NSString*)propertyName newValue:(id<OCLAny>)value;


@end


