#import <Foundation/Foundation.h>
#import "OCLSet.h"
#import "OCLAny.h"
#import "OCLBoolean.h"
#import "OCLInteger.h"
#import "OCLBag.h"
#import "OCLOrderedSet.h"
#import "OCLSequence.h"

@implementation OCLSet

-(OCLSet*)init {
	self = [super init];
	set = [[NSMutableSet alloc] init];
	return self;
}

-(void)dealloc {
	[set release];
	[super dealloc];
}

-(BOOL)isEqual:(id)other {
	BOOL res;
	if ([self isCompatibleType:other]) {
		OCLSet* otherSet = (OCLSet*)other;
		// Assuming NSSet isEqual semantics match OCL semantics (ie. sets are equal if they contain the same elements).
		res = [self->set isEqual:otherSet->set]; 
	} else {
		res = NO;
	}
	return res;
}

-(OCLSet*)newCollection {
	return [(OCLSet*)[OCLSet alloc] init];
}

-(void)add:(OCLAny*)object {
	[set addObject:object];
}

-(OCLInteger*)size {
	return [(OCLInteger*)[OCLInteger alloc] initWithValue:[set count]];
}

-(OCLBoolean*)includes:(OCLAny*)object {
	BOOL res = [set containsObject:object];
	return [(OCLBoolean*)[OCLBoolean alloc] initWithValue:res];
}

-(NSEnumerator*)objectEnumerator {
	return [set objectEnumerator];
}

-(NSString*)collectionName {
	return [NSString stringWithString:@"Set"];
}

-(OCLSet*)unionWithSet:(OCLSet*)other {
	OCLSet* res = [[OCLSet alloc] init];
	[res->set unionSet:self->set]; // Adds elements of this set
	[res->set unionSet:other->set]; // Adds elements of other set
	return res;
}

-(OCLBag*)unionWithBag:(OCLBag*)other {
	OCLBag* res = [[OCLBag alloc] init];
	[res->bag addObjectsFromArray:other->bag];

	NSEnumerator* e = [self objectEnumerator];
	OCLAny* o;
	while ((o = [e nextObject]) != nil) {
		[res add:o];
	}
	
	return res;
}

-(OCLSet*)intersectionWithSet:(OCLSet*)other {
	OCLSet* res = [[OCLSet alloc] init];

	NSEnumerator* e = [self objectEnumerator];
	OCLAny* o;
	while ((o = [e nextObject]) != nil) {
		if ([other->set containsObject:o]) {
			[res add:o];
		}
	}

	return res;
}

-(OCLSet*)intersectionWithBag:(OCLBag*)other {
	OCLSet* res = [[OCLSet alloc] init];

	NSEnumerator* e = [self objectEnumerator];
	OCLAny* o;
	while ((o = [e nextObject]) != nil) {
		if ([other->bag containsObject:o]) {
			[res add:o];
		}
	}

	return res;
}

-(OCLSet*)n:(OCLSet*)other {
	OCLSet* res = [[OCLSet alloc] init];

	NSEnumerator* e = [self objectEnumerator];
	OCLAny* o;
	while ((o = [e nextObject]) != nil) {
		if (![other->set containsObject:o]) {
			[res add:o];
		}
	}

	return res;
}

-(OCLSet*)including:(OCLAny*)object {
	OCLSet* res = [[OCLSet alloc] init];	
	[res->set setSet:self->set]; // Make copy of set
	[res add:object];
	
	return res;
}

-(OCLSet*)excluding:(OCLAny*)object {
	OCLSet* res = [[OCLSet alloc] init];	
	[res->set setSet:self->set]; // Make copy of set
	[res->set removeObject:object];
	
	return res;
}

-(OCLSet*)symmetricDifference:(OCLSet*)other {
	OCLSet* is = [[OCLSet alloc] init];
	[is->set setSet:self->set];
	[is->set intersectSet:other->set];
	
	OCLSet* res = [self unionWithSet:other];
	
	[res->set minusSet:is->set];
	[is release];

	return res;
}

-(OCLSet*)flatten {
	return (OCLSet*)[super flatten];
}

@end
