 
 
 
#import "Application_Main.h"
#import "PropertyChangeList.h"
#import "MobileLibraryGUI_StartController.h"
#import "MobileLibraryGUI_LoginController.h"
#import "MobileLibraryGUI_MemberController.h"
#import "Library_Library.h"
#import "LibraryPersistence_LibraryLoader.h"
#import "Library_Author.h"
#import "Library_Member.h"
#import "Library_Book.h"
#import "Application_Main.h"
#import "MobileLibraryGUI_SearchController.h"
#import "MobileLibraryGUI_ViewsController.h"


 
@implementation Application_Main

 
- (Application_Main*) init {
	self = [super init];
	 

	[self set_library: [self _library]];
	[self set_libraryFileHandler: [self _libraryFileHandler]];
	[self set_viewsControl: [self _viewsControl]];
	[self set_startControl: [self _startControl]];
	[self set_searchControl: [self _searchControl]];
	[self set_memberViewMode: [self _memberViewMode]];
	[self set_memberControl: [self _memberControl]];
	[self set_loginControl: [self _loginControl]];

	return self;
}

 
- (Application_Main*) initWithValues: (OCLTuple*) values {
	self = [super init];
	 
	self->_library_initialized = NO;
	self->_libraryFileHandler_initialized = NO;
	self->_viewsControl_initialized = NO;
	self->_startControl_initialized = NO;
	self->_searchControl_initialized = NO;
	self->_memberViewMode_initialized = NO;
	self->_memberControl_initialized = NO;
	self->_loginControl_initialized = NO;


	Library_Library* _library_initialValue = (Library_Library*) [values objectForKey:@"library"];
	if (_library_initialValue == nil) {
		_library_initialValue = [self _library];
	}
	[self set_library:_library_initialValue];
	LibraryPersistence_LibraryLoader* _libraryFileHandler_initialValue = (LibraryPersistence_LibraryLoader*) [values objectForKey:@"libraryFileHandler"];
	if (_libraryFileHandler_initialValue == nil) {
		_libraryFileHandler_initialValue = [self _libraryFileHandler];
	}
	[self set_libraryFileHandler:_libraryFileHandler_initialValue];
	MobileLibraryGUI_ViewsController* _viewsControl_initialValue = (MobileLibraryGUI_ViewsController*) [values objectForKey:@"viewsControl"];
	if (_viewsControl_initialValue == nil) {
		_viewsControl_initialValue = [self _viewsControl];
	}
	[self set_viewsControl:_viewsControl_initialValue];
	MobileLibraryGUI_StartController* _startControl_initialValue = (MobileLibraryGUI_StartController*) [values objectForKey:@"startControl"];
	if (_startControl_initialValue == nil) {
		_startControl_initialValue = [self _startControl];
	}
	[self set_startControl:_startControl_initialValue];
	MobileLibraryGUI_SearchController* _searchControl_initialValue = (MobileLibraryGUI_SearchController*) [values objectForKey:@"searchControl"];
	if (_searchControl_initialValue == nil) {
		_searchControl_initialValue = [self _searchControl];
	}
	[self set_searchControl:_searchControl_initialValue];
	OCLString* _memberViewMode_initialValue = (OCLString*) [values objectForKey:@"memberViewMode"];
	if (_memberViewMode_initialValue == nil) {
		_memberViewMode_initialValue = [self _memberViewMode];
	}
	[self set_memberViewMode:_memberViewMode_initialValue];
	MobileLibraryGUI_MemberController* _memberControl_initialValue = (MobileLibraryGUI_MemberController*) [values objectForKey:@"memberControl"];
	if (_memberControl_initialValue == nil) {
		_memberControl_initialValue = [self _memberControl];
	}
	[self set_memberControl:_memberControl_initialValue];
	MobileLibraryGUI_LoginController* _loginControl_initialValue = (MobileLibraryGUI_LoginController*) [values objectForKey:@"loginControl"];
	if (_loginControl_initialValue == nil) {
		_loginControl_initialValue = [self _loginControl];
	}
	[self set_loginControl:_loginControl_initialValue];

	
	return self;
}

 
- (void) dealloc {
	if (self->_library != nil && self->_library != (Library_Library*) [NSNull null]) [self->_library release];
	if (self->_libraryFileHandler != nil && self->_libraryFileHandler != (LibraryPersistence_LibraryLoader*) [NSNull null]) [self->_libraryFileHandler release];
	if (self->_viewsControl != nil && self->_viewsControl != (MobileLibraryGUI_ViewsController*) [NSNull null]) [self->_viewsControl release];
	if (self->_startControl != nil && self->_startControl != (MobileLibraryGUI_StartController*) [NSNull null]) [self->_startControl release];
	if (self->_searchControl != nil && self->_searchControl != (MobileLibraryGUI_SearchController*) [NSNull null]) [self->_searchControl release];
	if (self->_memberViewMode != nil && self->_memberViewMode != (OCLString*) [NSNull null]) [self->_memberViewMode release];
	if (self->_memberControl != nil && self->_memberControl != (MobileLibraryGUI_MemberController*) [NSNull null]) [self->_memberControl release];
	if (self->_loginControl != nil && self->_loginControl != (MobileLibraryGUI_LoginController*) [NSNull null]) [self->_loginControl release];

	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"Application::Main\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"library\" type=\"Library::Library\">\n"];
	[res appendFormat:@"%@\n", [self _library]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"libraryFileHandler\" type=\"LibraryPersistence::LibraryLoader\">\n"];
	[res appendFormat:@"%@\n", [self _libraryFileHandler]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"viewsControl\" type=\"MobileLibraryGUI::ViewsController\">\n"];
	[res appendFormat:@"%@\n", [self _viewsControl]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"startControl\" type=\"MobileLibraryGUI::StartController\">\n"];
	[res appendFormat:@"%@\n", [self _startControl]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"searchControl\" type=\"MobileLibraryGUI::SearchController\">\n"];
	[res appendFormat:@"%@\n", [self _searchControl]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"memberViewMode\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _memberViewMode]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"memberControl\" type=\"MobileLibraryGUI::MemberController\">\n"];
	[res appendFormat:@"%@\n", [self _memberControl]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"loginControl\" type=\"MobileLibraryGUI::LoginController\">\n"];
	[res appendFormat:@"%@\n", [self _loginControl]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
-(Library_Library*) initial_library {
	/* ==================================================
	 * Library::Library::create(
	 * 	Tuple { 
	 * 		catalogue = Set {
	 * 			Library::Book::create(Tuple { title = 'Test', isbn = '1234', 
	 * 			    authors = Set {Library::Author::create (Tuple {name = 'John Doe'})}})
	 * 		},
	 * 		members = Set {}
	 * 	})
	 * ================================================== */
	
	OCLString* v10 = [(OCLString*)[OCLString alloc] initWithString:@"Test"];
	OCLString* v9 = v10;
	OCLString* v12 = [(OCLString*)[OCLString alloc] initWithString:@"1234"];
	OCLString* v11 = v12;
	OCLString* v20 = [(OCLString*)[OCLString alloc] initWithString:@"John Doe"];
	OCLString* v19 = v20;
	OCLTuple* v18 = [(OCLTuple*)[OCLTuple alloc] init];
	[v18 addItemNamed:@"name" withValue:v19];
	Library_Author* v16 = [(Library_Author*)[Library_Author alloc] initWithValues:v18];
	Library_Author* v15 = v16;
	OCLSet* v14 = [(OCLSet*)[OCLSet alloc] init];
	[v14 add:v15];
	OCLSet* v13 = v14;
	OCLTuple* v8 = [(OCLTuple*)[OCLTuple alloc] init];
	[v8 addItemNamed:@"title" withValue:v9];
	[v8 addItemNamed:@"isbn" withValue:v11];
	[v8 addItemNamed:@"authors" withValue:v13];
	Library_Book* v6 = [(Library_Book*)[Library_Book alloc] initWithValues:v8];
	Library_Book* v5 = v6;
	OCLSet* v4 = [(OCLSet*)[OCLSet alloc] init];
	[v4 add:v5];
	OCLSet* v3 = v4;
	OCLSet* v22 = [(OCLSet*)[OCLSet alloc] init];
	OCLSet* v21 = v22;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"catalogue" withValue:v3];
	[v2 addItemNamed:@"members" withValue:v21];
	Library_Library* v0 = [(Library_Library*)[Library_Library alloc] initWithValues:v2];
	[v8 release];
	[v18 release];
	[v4 release];
	[v14 release];
	[v16 release];
	[v12 release];
	[v6 release];
	[v22 release];
	[v2 release];
	[v10 release];
	[v20 release];
	
	return v0;
}

-(Library_Library*) _library {
	if (self->_library_initialized == YES) {
		return _library;
	} else { 
		[self set_library:[self initial_library]];
	}

	self->_library_initialized = YES;
	return _library;
}
-(LibraryPersistence_LibraryLoader*) initial_libraryFileHandler {
	/* ==================================================
	 * LibraryPersistence::LibraryLoader::create()
	 * ================================================== */
	
	LibraryPersistence_LibraryLoader* v0 = [(LibraryPersistence_LibraryLoader*)[LibraryPersistence_LibraryLoader alloc] init];
	
	return v0;
}

-(LibraryPersistence_LibraryLoader*) _libraryFileHandler {
	if (self->_libraryFileHandler_initialized == YES) {
		return _libraryFileHandler;
	} else { 
		[self set_libraryFileHandler:[self initial_libraryFileHandler]];
	}

	self->_libraryFileHandler_initialized = YES;
	return _libraryFileHandler;
}
-(MobileLibraryGUI_ViewsController*) initial_viewsControl {
	/* ==================================================
	 * MobileLibraryGUI::ViewsController::create()
	 * ================================================== */
	
	MobileLibraryGUI_ViewsController* v0 = [(MobileLibraryGUI_ViewsController*)[MobileLibraryGUI_ViewsController alloc] init];
	
	return v0;
}

-(MobileLibraryGUI_ViewsController*) _viewsControl {
	if (self->_viewsControl_initialized == YES) {
		return _viewsControl;
	} else { 
		[self set_viewsControl:[self initial_viewsControl]];
	}

	self->_viewsControl_initialized = YES;
	return _viewsControl;
}
-(MobileLibraryGUI_StartController*) initial_startControl {
	/* ==================================================
	 * MobileLibraryGUI::StartController::create()
	 * ================================================== */
	
	MobileLibraryGUI_StartController* v0 = [(MobileLibraryGUI_StartController*)[MobileLibraryGUI_StartController alloc] init];
	
	return v0;
}

-(MobileLibraryGUI_StartController*) _startControl {
	if (self->_startControl_initialized == YES) {
		return _startControl;
	} else { 
		[self set_startControl:[self initial_startControl]];
	}

	self->_startControl_initialized = YES;
	return _startControl;
}
-(MobileLibraryGUI_SearchController*) initial_searchControl {
	/* ==================================================
	 * MobileLibraryGUI::SearchController::create()
	 * ================================================== */
	
	MobileLibraryGUI_SearchController* v0 = [(MobileLibraryGUI_SearchController*)[MobileLibraryGUI_SearchController alloc] init];
	
	return v0;
}

-(MobileLibraryGUI_SearchController*) _searchControl {
	if (self->_searchControl_initialized == YES) {
		return _searchControl;
	} else { 
		[self set_searchControl:[self initial_searchControl]];
	}

	self->_searchControl_initialized = YES;
	return _searchControl;
}
-(OCLString*) initial_memberViewMode {
	/* ==================================================
	 * 'Login'
	 * ================================================== */
	
	OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@"Login"];
	
	return v0;
}

-(OCLString*) _memberViewMode {
	if (self->_memberViewMode_initialized == YES) {
		return _memberViewMode;
	} else { 
		[self set_memberViewMode:[self initial_memberViewMode]];
	}

	self->_memberViewMode_initialized = YES;
	return _memberViewMode;
}
-(MobileLibraryGUI_MemberController*) initial_memberControl {
	/* ==================================================
	 * MobileLibraryGUI::MemberController::create()
	 * ================================================== */
	
	MobileLibraryGUI_MemberController* v0 = [(MobileLibraryGUI_MemberController*)[MobileLibraryGUI_MemberController alloc] init];
	
	return v0;
}

-(MobileLibraryGUI_MemberController*) _memberControl {
	if (self->_memberControl_initialized == YES) {
		return _memberControl;
	} else { 
		[self set_memberControl:[self initial_memberControl]];
	}

	self->_memberControl_initialized = YES;
	return _memberControl;
}
-(MobileLibraryGUI_LoginController*) initial_loginControl {
	/* ==================================================
	 * MobileLibraryGUI::LoginController::create()
	 * ================================================== */
	
	MobileLibraryGUI_LoginController* v0 = [(MobileLibraryGUI_LoginController*)[MobileLibraryGUI_LoginController alloc] init];
	
	return v0;
}

-(MobileLibraryGUI_LoginController*) _loginControl {
	if (self->_loginControl_initialized == YES) {
		return _loginControl;
	} else { 
		[self set_loginControl:[self initial_loginControl]];
	}

	self->_loginControl_initialized = YES;
	return _loginControl;
}


 
-(void) set_memberViewMode:(OCLString*) value {
	 	if (self->_memberViewMode!= nil && self->_memberViewMode!= (OCLString*) [NSNull null]) {
		[self->_memberViewMode release];
	}
	self->_memberViewMode = value;
	if (self->_memberViewMode!= nil && self->_memberViewMode!= (OCLString*) [NSNull null]) {
		[self->_memberViewMode retain];
	}
	self->_memberViewMode_initialized = YES;

}


-(void) set_library:(Library_Library*) value {
	 
	if (self->_library!= nil && self->_library!= (Library_Library*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_library valueForKey:@"Application_Main_library_back"];
		[backpointers removeObject:self];
		[self->_library release];
	}
	self->_library = value;
	if (self->_library!= nil && self->_library!= (Library_Library*) [NSNull null]) {
		[self->_library retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_library valueForKey:@"Application_Main_library_back"];
		[backpointers addObject:self];
	}
	self->_library_initialized = YES;

}
-(void) set_libraryFileHandler:(LibraryPersistence_LibraryLoader*) value {
	 
	if (self->_libraryFileHandler!= nil && self->_libraryFileHandler!= (LibraryPersistence_LibraryLoader*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_libraryFileHandler valueForKey:@"Application_Main_libraryFileHandler_back"];
		[backpointers removeObject:self];
		[self->_libraryFileHandler release];
	}
	self->_libraryFileHandler = value;
	if (self->_libraryFileHandler!= nil && self->_libraryFileHandler!= (LibraryPersistence_LibraryLoader*) [NSNull null]) {
		[self->_libraryFileHandler retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_libraryFileHandler valueForKey:@"Application_Main_libraryFileHandler_back"];
		[backpointers addObject:self];
	}
	self->_libraryFileHandler_initialized = YES;

}
-(void) set_viewsControl:(MobileLibraryGUI_ViewsController*) value {
	 
	if (self->_viewsControl!= nil && self->_viewsControl!= (MobileLibraryGUI_ViewsController*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_viewsControl valueForKey:@"Application_Main_viewsControl_back"];
		[backpointers removeObject:self];
		[self->_viewsControl release];
	}
	self->_viewsControl = value;
	if (self->_viewsControl!= nil && self->_viewsControl!= (MobileLibraryGUI_ViewsController*) [NSNull null]) {
		[self->_viewsControl retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_viewsControl valueForKey:@"Application_Main_viewsControl_back"];
		[backpointers addObject:self];
	}
	self->_viewsControl_initialized = YES;

}
-(void) set_startControl:(MobileLibraryGUI_StartController*) value {
	 
	if (self->_startControl!= nil && self->_startControl!= (MobileLibraryGUI_StartController*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_startControl valueForKey:@"Application_Main_startControl_back"];
		[backpointers removeObject:self];
		[self->_startControl release];
	}
	self->_startControl = value;
	if (self->_startControl!= nil && self->_startControl!= (MobileLibraryGUI_StartController*) [NSNull null]) {
		[self->_startControl retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_startControl valueForKey:@"Application_Main_startControl_back"];
		[backpointers addObject:self];
	}
	self->_startControl_initialized = YES;

}
-(void) set_searchControl:(MobileLibraryGUI_SearchController*) value {
	 
	if (self->_searchControl!= nil && self->_searchControl!= (MobileLibraryGUI_SearchController*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_searchControl valueForKey:@"Application_Main_searchControl_back"];
		[backpointers removeObject:self];
		[self->_searchControl release];
	}
	self->_searchControl = value;
	if (self->_searchControl!= nil && self->_searchControl!= (MobileLibraryGUI_SearchController*) [NSNull null]) {
		[self->_searchControl retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_searchControl valueForKey:@"Application_Main_searchControl_back"];
		[backpointers addObject:self];
	}
	self->_searchControl_initialized = YES;

}
-(void) set_memberControl:(MobileLibraryGUI_MemberController*) value {
	 
	if (self->_memberControl!= nil && self->_memberControl!= (MobileLibraryGUI_MemberController*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_memberControl valueForKey:@"Application_Main_memberControl_back"];
		[backpointers removeObject:self];
		[self->_memberControl release];
	}
	self->_memberControl = value;
	if (self->_memberControl!= nil && self->_memberControl!= (MobileLibraryGUI_MemberController*) [NSNull null]) {
		[self->_memberControl retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_memberControl valueForKey:@"Application_Main_memberControl_back"];
		[backpointers addObject:self];
	}
	self->_memberControl_initialized = YES;

}
-(void) set_loginControl:(MobileLibraryGUI_LoginController*) value {
	 
	if (self->_loginControl!= nil && self->_loginControl!= (MobileLibraryGUI_LoginController*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_loginControl valueForKey:@"Application_Main_loginControl_back"];
		[backpointers removeObject:self];
		[self->_loginControl release];
	}
	self->_loginControl = value;
	if (self->_loginControl!= nil && self->_loginControl!= (MobileLibraryGUI_LoginController*) [NSNull null]) {
		[self->_loginControl retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_loginControl valueForKey:@"Application_Main_loginControl_back"];
		[backpointers addObject:self];
	}
	self->_loginControl_initialized = YES;

}




 
-(void) event_searchFinished_pushed:(PropertyChangeList*) changes  p_booksFound: (OCLSet*) p_booksFound{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_searchFinished", @"Application_Main");

		 
		// Trigger Push edges

		if (self->_searchControl != nil && self->_searchControl != (MobileLibraryGUI_SearchController*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_searchControl];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			MobileLibraryGUI_SearchController* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * booksFound
				 * ================================================== */
				
				OCLSet* v1 = p_booksFound;
				
					OCLSet* parameter_p_booksFound = v1;

					[edge0_target event_searchFinished_pushed:changes p_booksFound:parameter_p_booksFound ];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_searchFinished_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Library_Library*)parentInstance p_foundBooks:(OCLSet*)p_foundBooks  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_searchFinished", @"Application_Main", @"_booksFound", @"Library_Library");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {
		/* ==================================================
		 * foundBooks
		 * ================================================== */
		
		OCLSet* v1 = p_foundBooks;
		
		OCLSet* parameter_p_booksFound = v1;

		[self event_searchFinished_pushed:changes p_booksFound:parameter_p_booksFound ];

	}
	[v0 release];
}


-(void) event_searchBook_pushed:(PropertyChangeList*) changes  p_term: (OCLString*) p_term p_category: (OCLString*) p_category{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_searchBook", @"Application_Main");

		 
		// Trigger Push edges

		if (self->_library != nil && self->_library != (Library_Library*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_library];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			Library_Library* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * term
				 * ================================================== */
				
				OCLString* v1 = p_term;
				
					OCLString* parameter_p_term = v1;
					/* ==================================================
				 * category
				 * ================================================== */
				
				OCLString* v2 = p_category;
				
					OCLString* parameter_p_category = v2;

					[edge0_target event_searchBook_pushed:changes p_term:parameter_p_term p_category:parameter_p_category ];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_searchBook_pulled_edge0:(PropertyChangeList*)changes parentInstance:(MobileLibraryGUI_SearchController*)parentInstance p_term:(OCLString*)p_term p_category:(OCLString*)p_category  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_searchBook", @"Application_Main", @"_searchBook", @"MobileLibraryGUI_SearchController");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {
		/* ==================================================
		 * term
		 * ================================================== */
		
		OCLString* v1 = p_term;
		
		OCLString* parameter_p_term = v1;
		/* ==================================================
		 * category
		 * ================================================== */
		
		OCLString* v2 = p_category;
		
		OCLString* parameter_p_category = v2;

		[self event_searchBook_pushed:changes p_term:parameter_p_term p_category:parameter_p_category ];

	}
	[v0 release];
}


-(void) event_libraryBooksLoaded_pushed:(PropertyChangeList*) changes  p_bookCollection: (Library_Library*) p_bookCollection{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_libraryBooksLoaded", @"Application_Main");

		 
		// Trigger Push edges

		if (self->_viewsControl != nil && self->_viewsControl != (MobileLibraryGUI_ViewsController*)[NSNull null]) {
			 
			NSMutableArray* edge1_values = [[NSMutableArray alloc] init];
			[edge1_values addObject:self->_viewsControl];
			NSEnumerator* edge1_enum = [edge1_values objectEnumerator];
			MobileLibraryGUI_ViewsController* edge1_target;
			while ((edge1_target = [edge1_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * getSearchFrame
				 * ================================================== */
				
				OCLAny* v1 = [self getSearchFrame];
				
					OCLAny* parameter_p_searchWindow = v1;
					/* ==================================================
				 * getLoginFrame
				 * ================================================== */
				
				OCLAny* v2 = [self getLoginFrame];
				
					OCLAny* parameter_p_loginWindow = v2;

					[edge1_target event_startViewsWindow_pushed:changes p_searchWindow:parameter_p_searchWindow p_loginWindow:parameter_p_loginWindow ];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {
			/* ==================================================
			 * bookCollection
			 * ================================================== */
			
			Library_Library* v1 = p_bookCollection;
			
			Library_Library* parameter_p_completeBookCollection = v1;

			[self event_setCatalogue_pushed:changes p_completeBookCollection:parameter_p_completeBookCollection ];
		}
		[v0 release];
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v2 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v2->value == YES) {

			[self event_endStartWindow_pushed:changes ];
		}
		[v2 release];


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_libraryBooksLoaded_pulled_edge0:(PropertyChangeList*)changes parentInstance:(LibraryPersistence_LibraryLoader*)parentInstance p_library:(Library_Library*)p_library  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_libraryBooksLoaded", @"Application_Main", @"_libraryLoaded", @"LibraryPersistence_LibraryLoader");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {
		/* ==================================================
		 * library
		 * ================================================== */
		
		Library_Library* v1 = p_library;
		
		Library_Library* parameter_p_bookCollection = v1;

		[self event_libraryBooksLoaded_pushed:changes p_bookCollection:parameter_p_bookCollection ];

	}
	[v0 release];
}


-(void) event_setCatalogue_pushed:(PropertyChangeList*) changes  p_completeBookCollection: (Library_Library*) p_completeBookCollection{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_setCatalogue", @"Application_Main");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * -- Generated impacts relationship code:
		 * completeBookCollection
		 * ================================================== */
		
		Library_Library* v0 = p_completeBookCollection;
		
		Library_Library* _library_newValue = v0;
		[changes addChange:@selector(set_library:) instance:self value:_library_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_init_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_init", @"Application_Main");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {

			[self event_loadLibrary_pushed:changes ];
		}
		[v0 release];


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_loadLibrary_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_loadLibrary", @"Application_Main");

		 
		// Trigger Push edges

		if (self->_libraryFileHandler != nil && self->_libraryFileHandler != (LibraryPersistence_LibraryLoader*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_libraryFileHandler];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			LibraryPersistence_LibraryLoader* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {

					[edge0_target event_load_pushed:changes ];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_authenticate_pushed:(PropertyChangeList*) changes  p_libNo: (OCLString*) p_libNo p_pw: (OCLString*) p_pw{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_authenticate", @"Application_Main");

		 
		// Trigger Push edges

		if (self->_library != nil && self->_library != (Library_Library*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_library];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			Library_Library* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * libNo
				 * ================================================== */
				
				OCLString* v1 = p_libNo;
				
					OCLString* parameter_p_libNo = v1;
					/* ==================================================
				 * pw
				 * ================================================== */
				
				OCLString* v2 = p_pw;
				
					OCLString* parameter_p_pw = v2;

					[edge0_target event_authenticate_pushed:changes p_libNo:parameter_p_libNo p_pw:parameter_p_pw ];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_authenticate_pulled_edge0:(PropertyChangeList*)changes parentInstance:(MobileLibraryGUI_LoginController*)parentInstance p_libNo:(OCLString*)p_libNo p_password:(OCLString*)p_password  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_authenticate", @"Application_Main", @"_authenticate", @"MobileLibraryGUI_LoginController");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {
		/* ==================================================
		 * libNo
		 * ================================================== */
		
		OCLString* v1 = p_libNo;
		
		OCLString* parameter_p_libNo = v1;
		/* ==================================================
		 * password
		 * ================================================== */
		
		OCLString* v2 = p_password;
		
		OCLString* parameter_p_pw = v2;

		[self event_authenticate_pushed:changes p_libNo:parameter_p_libNo p_pw:parameter_p_pw ];

	}
	[v0 release];
}


-(void) event_loginOk_pushed:(PropertyChangeList*) changes  p_m: (Library_Member*) p_m{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_loginOk", @"Application_Main");

		 
		// Trigger Push edges

		if (self->_memberControl != nil && self->_memberControl != (MobileLibraryGUI_MemberController*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_memberControl];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			MobileLibraryGUI_MemberController* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * m
				 * ================================================== */
				
				Library_Member* v1 = p_m;
				
					Library_Member* parameter_p_m = v1;

					[edge0_target event_sessionStarted_pushed:changes p_m:parameter_p_m ];

				}
				[v0 release];
			}

		}
		if (self->_loginControl != nil && self->_loginControl != (MobileLibraryGUI_LoginController*)[NSNull null]) {
			 
			NSMutableArray* edge1_values = [[NSMutableArray alloc] init];
			[edge1_values addObject:self->_loginControl];
			NSEnumerator* edge1_enum = [edge1_values objectEnumerator];
			MobileLibraryGUI_LoginController* edge1_target;
			while ((edge1_target = [edge1_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {

					[edge1_target event_loginOk_pushed:changes ];

				}
				[v0 release];
			}

		}
		if (self->_searchControl != nil && self->_searchControl != (MobileLibraryGUI_SearchController*)[NSNull null]) {
			 
			NSMutableArray* edge2_values = [[NSMutableArray alloc] init];
			[edge2_values addObject:self->_searchControl];
			NSEnumerator* edge2_enum = [edge2_values objectEnumerator];
			MobileLibraryGUI_SearchController* edge2_target;
			while ((edge2_target = [edge2_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * m
				 * ================================================== */
				
				Library_Member* v1 = p_m;
				
					Library_Member* parameter_p_m = v1;

					[edge2_target event_sessionStarted_pushed:changes p_m:parameter_p_m ];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_loginOk_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Library_Library*)parentInstance p_member:(Library_Member*)p_member  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_loginOk", @"Application_Main", @"_loginOk", @"Library_Library");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {
		/* ==================================================
		 * member
		 * ================================================== */
		
		Library_Member* v1 = p_member;
		
		Library_Member* parameter_p_m = v1;

		[self event_loginOk_pushed:changes p_m:parameter_p_m ];

	}
	[v0 release];
}


-(void) event_saveLibrary_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_saveLibrary", @"Application_Main");

		 
		// Trigger Push edges

		if (self->_libraryFileHandler != nil && self->_libraryFileHandler != (LibraryPersistence_LibraryLoader*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_libraryFileHandler];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			LibraryPersistence_LibraryLoader* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * library
				 * ================================================== */
				
				Library_Library* v1 = [self _library];
				
					Library_Library* parameter_p_library = v1;

					[edge0_target event_saveLibrary_pushed:changes p_library:parameter_p_library ];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_saveLibrary_pulled_edge0:(PropertyChangeList*)changes parentInstance:(MobileLibraryGUI_MemberController*)parentInstance  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_saveLibrary", @"Application_Main", @"_saveData", @"MobileLibraryGUI_MemberController");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {

		[self event_saveLibrary_pushed:changes ];

	}
	[v0 release];
}
-(void)event_saveLibrary_pulled_edge1:(PropertyChangeList*)changes parentInstance:(MobileLibraryGUI_SearchController*)parentInstance  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_saveLibrary", @"Application_Main", @"_refreshAndSave", @"MobileLibraryGUI_SearchController");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v1 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v1->value == YES) {

		[self event_saveLibrary_pushed:changes ];

	}
	[v1 release];
}


-(void) event_loginFailed_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_loginFailed", @"Application_Main");

		 
		// Trigger Push edges

		if (self->_loginControl != nil && self->_loginControl != (MobileLibraryGUI_LoginController*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_loginControl];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			MobileLibraryGUI_LoginController* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {

					[edge0_target event_loginFailed_pushed:changes ];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_loginFailed_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Library_Library*)parentInstance  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_loginFailed", @"Application_Main", @"_loginFailed", @"Library_Library");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {

		[self event_loginFailed_pushed:changes ];

	}
	[v0 release];
}


-(void) event_endStartWindow_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_endStartWindow", @"Application_Main");

		 
		// Trigger Push edges

		if (self->_startControl != nil && self->_startControl != (MobileLibraryGUI_StartController*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_startControl];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			MobileLibraryGUI_StartController* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {

					[edge0_target event_closeWIndow_pushed:changes ];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * null
		 * ================================================== */
		
		MobileLibraryGUI_StartController* v0 = [NSNull null];
		
		MobileLibraryGUI_StartController* _startControl_newValue = v0;
		[changes addChange:@selector(set_startControl:) instance:self value:_startControl_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_refreshMemberWindow_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_refreshMemberWindow", @"Application_Main");

		 
		// Trigger Push edges

		if (self->_memberControl != nil && self->_memberControl != (MobileLibraryGUI_MemberController*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_memberControl];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			MobileLibraryGUI_MemberController* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {

					[edge0_target event_refreshData_pushed:changes ];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_refreshMemberWindow_pulled_edge0:(PropertyChangeList*)changes parentInstance:(MobileLibraryGUI_SearchController*)parentInstance  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_refreshMemberWindow", @"Application_Main", @"_refreshAndSave", @"MobileLibraryGUI_SearchController");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {

		[self event_refreshMemberWindow_pushed:changes ];

	}
	[v0 release];
}


-(void) event_loginConfirmed_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_loginConfirmed", @"Application_Main");

		 
		// Trigger Push edges

		if (self->_viewsControl != nil && self->_viewsControl != (MobileLibraryGUI_ViewsController*)[NSNull null]) {
			 
			NSMutableArray* edge2_values = [[NSMutableArray alloc] init];
			[edge2_values addObject:self->_viewsControl];
			NSEnumerator* edge2_enum = [edge2_values objectEnumerator];
			MobileLibraryGUI_ViewsController* edge2_target;
			while ((edge2_target = [edge2_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * getMemberFrame
				 * ================================================== */
				
				OCLAny* v1 = [self getMemberFrame];
				
					OCLAny* parameter_p_memberFrame = v1;

					[edge2_target event_changeFromLoginToMember_pushed:changes p_memberFrame:parameter_p_memberFrame ];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {

			[self event_setToMemberMode_pushed:changes ];
		}
		[v0 release];
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v1 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v1->value == YES) {

			[self event_refreshMemberWindow_pushed:changes ];
		}
		[v1 release];


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_loginConfirmed_pulled_edge0:(PropertyChangeList*)changes parentInstance:(MobileLibraryGUI_LoginController*)parentInstance  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_loginConfirmed", @"Application_Main", @"_loginConfirmed", @"MobileLibraryGUI_LoginController");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {

		[self event_loginConfirmed_pushed:changes ];

	}
	[v0 release];
}


-(void) event_setToMemberMode_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_setToMemberMode", @"Application_Main");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * 'Member'
		 * ================================================== */
		
		OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@"Member"];
		
		OCLString* _memberViewMode_newValue = v0;
		[changes addChange:@selector(set_memberViewMode:) instance:self value:_memberViewMode_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 




 
-(OCLAny*) getSearchFrame{
	/* ==================================================
	 * searchControl.frame
	 * ================================================== */
	
	Application_Main* v2 = self;
	MobileLibraryGUI_SearchController* v1 = [v2 _searchControl];
	OCLAny* v0 = [v1 _frame];
	;
	return v0;
}
-(OCLAny*) getLoginFrame{
	/* ==================================================
	 * loginControl.frame
	 * ================================================== */
	
	Application_Main* v2 = self;
	MobileLibraryGUI_LoginController* v1 = [v2 _loginControl];
	OCLAny* v0 = [v1 _frame];
	;
	return v0;
}
-(OCLAny*) getMemberFrame{
	/* ==================================================
	 * memberControl.window
	 * ================================================== */
	
	Application_Main* v2 = self;
	MobileLibraryGUI_MemberController* v1 = [v2 _memberControl];
	OCLAny* v0 = [v1 _window];
	;
	return v0;
}


@end 


