#import <Foundation/Foundation.h>

@class OCLAny;
@protocol IBinding;

@interface BindingFactory : NSObject {
}

+(id<IBinding>)createBinding:(OCLAny*)instance;

@end


/**************************************************************************

Dummy binding example:

#import "BindingFactory.h"
#import "IBinding.h"

@interface Application_MainBinding : NSObject <IBinding> {
    @private
    OCLAny* instance;
}
@end

@implementation Application_MainBinding
-(id)init:(OCLAny*)inst {
    self = [super init];
    self->instance = inst;
    return self;
}

-(void)onEvent:(NSString*)eventName {
}

-(void)onPropertyChange:(NSString*)propertyName newValue:(OCLAny*)value {
}

-(OCLAny*)getInstance {
    return self->instance;
}
@end

---------------------------------------------------------------------------

Instantiate binding using:
id<IBinding> binding = [BindingFactory createBinding:mainInstance];

***************************************************************************/
