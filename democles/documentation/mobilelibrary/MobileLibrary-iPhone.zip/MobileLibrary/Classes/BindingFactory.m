#import "BindingFactory.h"
#import "OCLAny.h"
#import "IBinding.h"

@implementation BindingFactory 

+(id<IBinding>)createBinding:(OCLAny*)instance {
	if (instance == NULL) {
		[NSException raise:@"Error creating IBinding" format:@"Could not create binding for NULL instance."];
	}
	
	Class c = [instance class];
	NSString* className = NSStringFromClass(c);
	
	NSString* bindingClassName = [className stringByAppendingString:@"Binding"];
	Class bindingClass = NSClassFromString(bindingClassName);

	id<IBinding> res = nil;
	if (bindingClass != nil) {
		res = (id<IBinding>)[[bindingClass alloc] init:instance];
		// TODO check result really implements IBinding protocol
	}

	// No need to release className and bindingClassName, as they are autoreleased by their methods/functions.
	
	return res;
}

@end
