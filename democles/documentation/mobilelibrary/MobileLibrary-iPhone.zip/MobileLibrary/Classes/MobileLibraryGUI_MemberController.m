 
 
 
#import "MobileLibraryGUI_MemberController.h"
#import "PropertyChangeList.h"
#import "GeneralGUI_MsgDialog.h"
#import "DateProcessing_DateHandler.h"
#import "GeneralGUI_ConfirmationDialog.h"
#import "MobileLibraryGUI_MemberController.h"
#import "Library_Member.h"
#import "GeneralGUI_SelectionList.h"
#import "GeneralGUI_Frame.h"
#import "Library_Copy.h"
#import "GeneralGUI_Label.h"
#import "Application_Main.h"


 
@implementation MobileLibraryGUI_MemberController

 
- (MobileLibraryGUI_MemberController*) init {
	self = [super init];
	 
	self->Application_Main_memberControl_back = [[NSMutableArray alloc] init];

	[self set_title: [self _title]];
	[self set_memberNameLabel: [self _memberNameLabel]];
	[self set_memberLabel: [self _memberLabel]];
	[self set_borrowItems: [self _borrowItems]];
	[self set_collectItems: [self _collectItems]];
	[self set_borrowedItemsLabel: [self _borrowedItemsLabel]];
	[self set_itemsToCollectLabel: [self _itemsToCollectLabel]];
	[self set_window: [self _window]];
	[self set_selectedBorrowing: [self _selectedBorrowing]];
	[self set_currMember: [self _currMember]];
	[self set_yesNoMsg: [self _yesNoMsg]];
	[self set_dateHandler: [self _dateHandler]];
	[self set_currMsg: [self _currMsg]];
	[self set_ackStatus: [self _ackStatus]];

	return self;
}

 
- (MobileLibraryGUI_MemberController*) initWithValues: (OCLTuple*) values {
	self = [super init];
	 
	self->_title_initialized = NO;
	self->_memberNameLabel_initialized = NO;
	self->_memberLabel_initialized = NO;
	self->_borrowItems_initialized = NO;
	self->_collectItems_initialized = NO;
	self->_borrowedItemsLabel_initialized = NO;
	self->_itemsToCollectLabel_initialized = NO;
	self->_window_initialized = NO;
	self->_selectedBorrowing_initialized = NO;
	self->_currMember_initialized = NO;
	self->_yesNoMsg_initialized = NO;
	self->_dateHandler_initialized = NO;
	self->_currMsg_initialized = NO;
	self->_ackStatus_initialized = NO;

	self->Application_Main_memberControl_back = [[NSMutableArray alloc] init];

	OCLString* _title_initialValue = (OCLString*) [values objectForKey:@"title"];
	if (_title_initialValue == nil) {
		_title_initialValue = [self _title];
	}
	[self set_title:_title_initialValue];
	GeneralGUI_Label* _memberNameLabel_initialValue = (GeneralGUI_Label*) [values objectForKey:@"memberNameLabel"];
	if (_memberNameLabel_initialValue == nil) {
		_memberNameLabel_initialValue = [self _memberNameLabel];
	}
	[self set_memberNameLabel:_memberNameLabel_initialValue];
	GeneralGUI_Label* _memberLabel_initialValue = (GeneralGUI_Label*) [values objectForKey:@"memberLabel"];
	if (_memberLabel_initialValue == nil) {
		_memberLabel_initialValue = [self _memberLabel];
	}
	[self set_memberLabel:_memberLabel_initialValue];
	GeneralGUI_SelectionList* _borrowItems_initialValue = (GeneralGUI_SelectionList*) [values objectForKey:@"borrowItems"];
	if (_borrowItems_initialValue == nil) {
		_borrowItems_initialValue = [self _borrowItems];
	}
	[self set_borrowItems:_borrowItems_initialValue];
	GeneralGUI_SelectionList* _collectItems_initialValue = (GeneralGUI_SelectionList*) [values objectForKey:@"collectItems"];
	if (_collectItems_initialValue == nil) {
		_collectItems_initialValue = [self _collectItems];
	}
	[self set_collectItems:_collectItems_initialValue];
	GeneralGUI_Label* _borrowedItemsLabel_initialValue = (GeneralGUI_Label*) [values objectForKey:@"borrowedItemsLabel"];
	if (_borrowedItemsLabel_initialValue == nil) {
		_borrowedItemsLabel_initialValue = [self _borrowedItemsLabel];
	}
	[self set_borrowedItemsLabel:_borrowedItemsLabel_initialValue];
	GeneralGUI_Label* _itemsToCollectLabel_initialValue = (GeneralGUI_Label*) [values objectForKey:@"itemsToCollectLabel"];
	if (_itemsToCollectLabel_initialValue == nil) {
		_itemsToCollectLabel_initialValue = [self _itemsToCollectLabel];
	}
	[self set_itemsToCollectLabel:_itemsToCollectLabel_initialValue];
	GeneralGUI_Frame* _window_initialValue = (GeneralGUI_Frame*) [values objectForKey:@"window"];
	if (_window_initialValue == nil) {
		_window_initialValue = [self _window];
	}
	[self set_window:_window_initialValue];
	Library_Copy* _selectedBorrowing_initialValue = (Library_Copy*) [values objectForKey:@"selectedBorrowing"];
	if (_selectedBorrowing_initialValue == nil) {
		_selectedBorrowing_initialValue = [self _selectedBorrowing];
	}
	[self set_selectedBorrowing:_selectedBorrowing_initialValue];
	Library_Member* _currMember_initialValue = (Library_Member*) [values objectForKey:@"currMember"];
	if (_currMember_initialValue == nil) {
		_currMember_initialValue = [self _currMember];
	}
	[self set_currMember:_currMember_initialValue];
	GeneralGUI_ConfirmationDialog* _yesNoMsg_initialValue = (GeneralGUI_ConfirmationDialog*) [values objectForKey:@"yesNoMsg"];
	if (_yesNoMsg_initialValue == nil) {
		_yesNoMsg_initialValue = [self _yesNoMsg];
	}
	[self set_yesNoMsg:_yesNoMsg_initialValue];
	DateProcessing_DateHandler* _dateHandler_initialValue = (DateProcessing_DateHandler*) [values objectForKey:@"dateHandler"];
	if (_dateHandler_initialValue == nil) {
		_dateHandler_initialValue = [self _dateHandler];
	}
	[self set_dateHandler:_dateHandler_initialValue];
	GeneralGUI_MsgDialog* _currMsg_initialValue = (GeneralGUI_MsgDialog*) [values objectForKey:@"currMsg"];
	if (_currMsg_initialValue == nil) {
		_currMsg_initialValue = [self _currMsg];
	}
	[self set_currMsg:_currMsg_initialValue];
	OCLString* _ackStatus_initialValue = (OCLString*) [values objectForKey:@"ackStatus"];
	if (_ackStatus_initialValue == nil) {
		_ackStatus_initialValue = [self _ackStatus];
	}
	[self set_ackStatus:_ackStatus_initialValue];

	
	return self;
}

 
- (void) dealloc {
	if (self->_title != nil && self->_title != (OCLString*) [NSNull null]) [self->_title release];
	if (self->_memberNameLabel != nil && self->_memberNameLabel != (GeneralGUI_Label*) [NSNull null]) [self->_memberNameLabel release];
	if (self->_memberLabel != nil && self->_memberLabel != (GeneralGUI_Label*) [NSNull null]) [self->_memberLabel release];
	if (self->_borrowItems != nil && self->_borrowItems != (GeneralGUI_SelectionList*) [NSNull null]) [self->_borrowItems release];
	if (self->_collectItems != nil && self->_collectItems != (GeneralGUI_SelectionList*) [NSNull null]) [self->_collectItems release];
	if (self->_borrowedItemsLabel != nil && self->_borrowedItemsLabel != (GeneralGUI_Label*) [NSNull null]) [self->_borrowedItemsLabel release];
	if (self->_itemsToCollectLabel != nil && self->_itemsToCollectLabel != (GeneralGUI_Label*) [NSNull null]) [self->_itemsToCollectLabel release];
	if (self->_window != nil && self->_window != (GeneralGUI_Frame*) [NSNull null]) [self->_window release];
	if (self->_selectedBorrowing != nil && self->_selectedBorrowing != (Library_Copy*) [NSNull null]) [self->_selectedBorrowing release];
	if (self->_currMember != nil && self->_currMember != (Library_Member*) [NSNull null]) [self->_currMember release];
	if (self->_yesNoMsg != nil && self->_yesNoMsg != (GeneralGUI_ConfirmationDialog*) [NSNull null]) [self->_yesNoMsg release];
	if (self->_dateHandler != nil && self->_dateHandler != (DateProcessing_DateHandler*) [NSNull null]) [self->_dateHandler release];
	if (self->_currMsg != nil && self->_currMsg != (GeneralGUI_MsgDialog*) [NSNull null]) [self->_currMsg release];
	if (self->_ackStatus != nil && self->_ackStatus != (OCLString*) [NSNull null]) [self->_ackStatus release];

	[self->Application_Main_memberControl_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"MobileLibraryGUI::MemberController\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"title\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _title]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"memberNameLabel\" type=\"GeneralGUI::Label\">\n"];
	[res appendFormat:@"%@\n", [self _memberNameLabel]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"memberLabel\" type=\"GeneralGUI::Label\">\n"];
	[res appendFormat:@"%@\n", [self _memberLabel]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"borrowItems\" type=\"GeneralGUI::SelectionList\">\n"];
	[res appendFormat:@"%@\n", [self _borrowItems]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"collectItems\" type=\"GeneralGUI::SelectionList\">\n"];
	[res appendFormat:@"%@\n", [self _collectItems]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"borrowedItemsLabel\" type=\"GeneralGUI::Label\">\n"];
	[res appendFormat:@"%@\n", [self _borrowedItemsLabel]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"itemsToCollectLabel\" type=\"GeneralGUI::Label\">\n"];
	[res appendFormat:@"%@\n", [self _itemsToCollectLabel]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"window\" type=\"GeneralGUI::Frame\">\n"];
	[res appendFormat:@"%@\n", [self _window]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"selectedBorrowing\" type=\"Library::Copy\">\n"];
	[res appendFormat:@"%@\n", [self _selectedBorrowing]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"currMember\" type=\"Library::Member\">\n"];
	[res appendFormat:@"%@\n", [self _currMember]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"yesNoMsg\" type=\"GeneralGUI::ConfirmationDialog\">\n"];
	[res appendFormat:@"%@\n", [self _yesNoMsg]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"dateHandler\" type=\"DateProcessing::DateHandler\">\n"];
	[res appendFormat:@"%@\n", [self _dateHandler]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"currMsg\" type=\"GeneralGUI::MsgDialog\">\n"];
	[res appendFormat:@"%@\n", [self _currMsg]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"ackStatus\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _ackStatus]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
-(OCLString*) initial_title {
	/* ==================================================
	 * 'Member'
	 * ================================================== */
	
	OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@"Member"];
	
	return v0;
}

-(OCLString*) _title {
	if (self->_title_initialized == YES) {
		return _title;
	} else { 
		[self set_title:[self initial_title]];
	}

	self->_title_initialized = YES;
	return _title;
}
-(GeneralGUI_Label*) initial_memberNameLabel {
	/* ==================================================
	 * GeneralGUI::Label::create()
	 * ================================================== */
	
	GeneralGUI_Label* v0 = [(GeneralGUI_Label*)[GeneralGUI_Label alloc] init];
	
	return v0;
}

-(GeneralGUI_Label*) _memberNameLabel {
	if (self->_memberNameLabel_initialized == YES) {
		return _memberNameLabel;
	} else { 
		[self set_memberNameLabel:[self initial_memberNameLabel]];
	}

	self->_memberNameLabel_initialized = YES;
	return _memberNameLabel;
}
-(GeneralGUI_Label*) initial_memberLabel {
	/* ==================================================
	 * GeneralGUI::Label::create(Tuple { text = 'Member' })
	 * ================================================== */
	
	OCLString* v4 = [(OCLString*)[OCLString alloc] initWithString:@"Member"];
	OCLString* v3 = v4;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"text" withValue:v3];
	GeneralGUI_Label* v0 = [(GeneralGUI_Label*)[GeneralGUI_Label alloc] initWithValues:v2];
	[v4 release];
	[v2 release];
	
	return v0;
}

-(GeneralGUI_Label*) _memberLabel {
	if (self->_memberLabel_initialized == YES) {
		return _memberLabel;
	} else { 
		[self set_memberLabel:[self initial_memberLabel]];
	}

	self->_memberLabel_initialized = YES;
	return _memberLabel;
}
-(GeneralGUI_SelectionList*) initial_borrowItems {
	/* ==================================================
	 * GeneralGUI::SelectionList::create(Tuple { items = Sequence { } })
	 * ================================================== */
	
	OCLSequence* v4 = [(OCLSequence*)[OCLSequence alloc] init];
	OCLSequence* v3 = v4;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"items" withValue:v3];
	GeneralGUI_SelectionList* v0 = [(GeneralGUI_SelectionList*)[GeneralGUI_SelectionList alloc] initWithValues:v2];
	[v2 release];
	[v4 release];
	
	return v0;
}

-(GeneralGUI_SelectionList*) _borrowItems {
	if (self->_borrowItems_initialized == YES) {
		return _borrowItems;
	} else { 
		[self set_borrowItems:[self initial_borrowItems]];
	}

	self->_borrowItems_initialized = YES;
	return _borrowItems;
}
-(GeneralGUI_SelectionList*) initial_collectItems {
	/* ==================================================
	 * GeneralGUI::SelectionList::create(Tuple { items = Sequence { } })
	 * ================================================== */
	
	OCLSequence* v4 = [(OCLSequence*)[OCLSequence alloc] init];
	OCLSequence* v3 = v4;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"items" withValue:v3];
	GeneralGUI_SelectionList* v0 = [(GeneralGUI_SelectionList*)[GeneralGUI_SelectionList alloc] initWithValues:v2];
	[v4 release];
	[v2 release];
	
	return v0;
}

-(GeneralGUI_SelectionList*) _collectItems {
	if (self->_collectItems_initialized == YES) {
		return _collectItems;
	} else { 
		[self set_collectItems:[self initial_collectItems]];
	}

	self->_collectItems_initialized = YES;
	return _collectItems;
}
-(GeneralGUI_Label*) initial_borrowedItemsLabel {
	/* ==================================================
	 * GeneralGUI::Label::create(Tuple { text = 'Books on loan:' })
	 * ================================================== */
	
	OCLString* v4 = [(OCLString*)[OCLString alloc] initWithString:@"Books on loan:"];
	OCLString* v3 = v4;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"text" withValue:v3];
	GeneralGUI_Label* v0 = [(GeneralGUI_Label*)[GeneralGUI_Label alloc] initWithValues:v2];
	[v4 release];
	[v2 release];
	
	return v0;
}

-(GeneralGUI_Label*) _borrowedItemsLabel {
	if (self->_borrowedItemsLabel_initialized == YES) {
		return _borrowedItemsLabel;
	} else { 
		[self set_borrowedItemsLabel:[self initial_borrowedItemsLabel]];
	}

	self->_borrowedItemsLabel_initialized = YES;
	return _borrowedItemsLabel;
}
-(GeneralGUI_Label*) initial_itemsToCollectLabel {
	/* ==================================================
	 * GeneralGUI::Label::create(Tuple { text = 'Reserved Books awaiting collection:' })
	 * ================================================== */
	
	OCLString* v4 = [(OCLString*)[OCLString alloc] initWithString:@"Reserved Books awaiting collection:"];
	OCLString* v3 = v4;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"text" withValue:v3];
	GeneralGUI_Label* v0 = [(GeneralGUI_Label*)[GeneralGUI_Label alloc] initWithValues:v2];
	[v2 release];
	[v4 release];
	
	return v0;
}

-(GeneralGUI_Label*) _itemsToCollectLabel {
	if (self->_itemsToCollectLabel_initialized == YES) {
		return _itemsToCollectLabel;
	} else { 
		[self set_itemsToCollectLabel:[self initial_itemsToCollectLabel]];
	}

	self->_itemsToCollectLabel_initialized = YES;
	return _itemsToCollectLabel;
}
-(GeneralGUI_Frame*) initial_window {
	/* ==================================================
	 * GeneralGUI::Frame::create(
	 * 	Tuple { seqGUIElements = Sequence {memberLabel, memberNameLabel, borrowedItemsLabel, borrowItems, itemsToCollectLabel, collectItems }, 
	 * 	frameTitle = title,
	 * 	iconFilename = 'icon-house.png' })
	 * ================================================== */
	
	MobileLibraryGUI_MemberController* v7 = self;
	GeneralGUI_Label* v6 = [v7 _memberLabel];
	GeneralGUI_Label* v5 = v6;
	MobileLibraryGUI_MemberController* v10 = self;
	GeneralGUI_Label* v9 = [v10 _memberNameLabel];
	GeneralGUI_Label* v8 = v9;
	MobileLibraryGUI_MemberController* v13 = self;
	GeneralGUI_Label* v12 = [v13 _borrowedItemsLabel];
	GeneralGUI_Label* v11 = v12;
	MobileLibraryGUI_MemberController* v16 = self;
	GeneralGUI_SelectionList* v15 = [v16 _borrowItems];
	GeneralGUI_SelectionList* v14 = v15;
	MobileLibraryGUI_MemberController* v19 = self;
	GeneralGUI_Label* v18 = [v19 _itemsToCollectLabel];
	GeneralGUI_Label* v17 = v18;
	MobileLibraryGUI_MemberController* v22 = self;
	GeneralGUI_SelectionList* v21 = [v22 _collectItems];
	GeneralGUI_SelectionList* v20 = v21;
	OCLSequence* v4 = [(OCLSequence*)[OCLSequence alloc] init];
	[v4 add:v5];
	[v4 add:v8];
	[v4 add:v11];
	[v4 add:v14];
	[v4 add:v17];
	[v4 add:v20];
	OCLSequence* v3 = v4;
	MobileLibraryGUI_MemberController* v25 = self;
	OCLString* v24 = [v25 _title];
	OCLString* v23 = v24;
	OCLString* v27 = [(OCLString*)[OCLString alloc] initWithString:@"icon-house.png"];
	OCLString* v26 = v27;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"seqGUIElements" withValue:v3];
	[v2 addItemNamed:@"frameTitle" withValue:v23];
	[v2 addItemNamed:@"iconFilename" withValue:v26];
	GeneralGUI_Frame* v0 = [(GeneralGUI_Frame*)[GeneralGUI_Frame alloc] initWithValues:v2];
	[v27 release];
	[v4 release];
	[v2 release];
	
	return v0;
}

-(GeneralGUI_Frame*) _window {
	if (self->_window_initialized == YES) {
		return _window;
	} else { 
		[self set_window:[self initial_window]];
	}

	self->_window_initialized = YES;
	return _window;
}
-(Library_Copy*) initial_selectedBorrowing {
	/* ==================================================
	 * null
	 * ================================================== */
	
	Library_Copy* v0 = [NSNull null];
	
	return v0;
}

-(Library_Copy*) _selectedBorrowing {
	if (self->_selectedBorrowing_initialized == YES) {
		return _selectedBorrowing;
	} else { 
		[self set_selectedBorrowing:[self initial_selectedBorrowing]];
	}

	self->_selectedBorrowing_initialized = YES;
	return _selectedBorrowing;
}
-(Library_Member*) initial_currMember {
	/* ==================================================
	 * null
	 * ================================================== */
	
	Library_Member* v0 = [NSNull null];
	
	return v0;
}

-(Library_Member*) _currMember {
	if (self->_currMember_initialized == YES) {
		return _currMember;
	} else { 
		[self set_currMember:[self initial_currMember]];
	}

	self->_currMember_initialized = YES;
	return _currMember;
}
-(GeneralGUI_ConfirmationDialog*) initial_yesNoMsg {
	/* ==================================================
	 * null
	 * ================================================== */
	
	GeneralGUI_ConfirmationDialog* v0 = [NSNull null];
	
	return v0;
}

-(GeneralGUI_ConfirmationDialog*) _yesNoMsg {
	if (self->_yesNoMsg_initialized == YES) {
		return _yesNoMsg;
	} else { 
		[self set_yesNoMsg:[self initial_yesNoMsg]];
	}

	self->_yesNoMsg_initialized = YES;
	return _yesNoMsg;
}
-(DateProcessing_DateHandler*) initial_dateHandler {
	/* ==================================================
	 * DateProcessing::DateHandler::create()
	 * ================================================== */
	
	DateProcessing_DateHandler* v0 = [(DateProcessing_DateHandler*)[DateProcessing_DateHandler alloc] init];
	
	return v0;
}

-(DateProcessing_DateHandler*) _dateHandler {
	if (self->_dateHandler_initialized == YES) {
		return _dateHandler;
	} else { 
		[self set_dateHandler:[self initial_dateHandler]];
	}

	self->_dateHandler_initialized = YES;
	return _dateHandler;
}
-(GeneralGUI_MsgDialog*) initial_currMsg {
	/* ==================================================
	 * null
	 * ================================================== */
	
	GeneralGUI_MsgDialog* v0 = [NSNull null];
	
	return v0;
}

-(GeneralGUI_MsgDialog*) _currMsg {
	if (self->_currMsg_initialized == YES) {
		return _currMsg;
	} else { 
		[self set_currMsg:[self initial_currMsg]];
	}

	self->_currMsg_initialized = YES;
	return _currMsg;
}
-(OCLString*) initial_ackStatus {
	/* ==================================================
	 * 'NotWaiting'
	 * ================================================== */
	
	OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@"NotWaiting"];
	
	return v0;
}

-(OCLString*) _ackStatus {
	if (self->_ackStatus_initialized == YES) {
		return _ackStatus;
	} else { 
		[self set_ackStatus:[self initial_ackStatus]];
	}

	self->_ackStatus_initialized = YES;
	return _ackStatus;
}


 
-(void) set_title:(OCLString*) value {
	 	if (self->_title!= nil && self->_title!= (OCLString*) [NSNull null]) {
		[self->_title release];
	}
	self->_title = value;
	if (self->_title!= nil && self->_title!= (OCLString*) [NSNull null]) {
		[self->_title retain];
	}
	self->_title_initialized = YES;

}
-(void) set_ackStatus:(OCLString*) value {
	 	if (self->_ackStatus!= nil && self->_ackStatus!= (OCLString*) [NSNull null]) {
		[self->_ackStatus release];
	}
	self->_ackStatus = value;
	if (self->_ackStatus!= nil && self->_ackStatus!= (OCLString*) [NSNull null]) {
		[self->_ackStatus retain];
	}
	self->_ackStatus_initialized = YES;

}


-(void) set_memberNameLabel:(GeneralGUI_Label*) value {
	 
	if (self->_memberNameLabel!= nil && self->_memberNameLabel!= (GeneralGUI_Label*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_memberNameLabel valueForKey:@"MobileLibraryGUI_MemberController_memberNameLabel_back"];
		[backpointers removeObject:self];
		[self->_memberNameLabel release];
	}
	self->_memberNameLabel = value;
	if (self->_memberNameLabel!= nil && self->_memberNameLabel!= (GeneralGUI_Label*) [NSNull null]) {
		[self->_memberNameLabel retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_memberNameLabel valueForKey:@"MobileLibraryGUI_MemberController_memberNameLabel_back"];
		[backpointers addObject:self];
	}
	self->_memberNameLabel_initialized = YES;

}
-(void) set_memberLabel:(GeneralGUI_Label*) value {
	 
	if (self->_memberLabel!= nil && self->_memberLabel!= (GeneralGUI_Label*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_memberLabel valueForKey:@"MobileLibraryGUI_MemberController_memberLabel_back"];
		[backpointers removeObject:self];
		[self->_memberLabel release];
	}
	self->_memberLabel = value;
	if (self->_memberLabel!= nil && self->_memberLabel!= (GeneralGUI_Label*) [NSNull null]) {
		[self->_memberLabel retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_memberLabel valueForKey:@"MobileLibraryGUI_MemberController_memberLabel_back"];
		[backpointers addObject:self];
	}
	self->_memberLabel_initialized = YES;

}
-(void) set_borrowItems:(GeneralGUI_SelectionList*) value {
	 
	if (self->_borrowItems!= nil && self->_borrowItems!= (GeneralGUI_SelectionList*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_borrowItems valueForKey:@"MobileLibraryGUI_MemberController_borrowItems_back"];
		[backpointers removeObject:self];
		[self->_borrowItems release];
	}
	self->_borrowItems = value;
	if (self->_borrowItems!= nil && self->_borrowItems!= (GeneralGUI_SelectionList*) [NSNull null]) {
		[self->_borrowItems retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_borrowItems valueForKey:@"MobileLibraryGUI_MemberController_borrowItems_back"];
		[backpointers addObject:self];
	}
	self->_borrowItems_initialized = YES;

}
-(void) set_collectItems:(GeneralGUI_SelectionList*) value {
	 
	if (self->_collectItems!= nil && self->_collectItems!= (GeneralGUI_SelectionList*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_collectItems valueForKey:@"MobileLibraryGUI_MemberController_collectItems_back"];
		[backpointers removeObject:self];
		[self->_collectItems release];
	}
	self->_collectItems = value;
	if (self->_collectItems!= nil && self->_collectItems!= (GeneralGUI_SelectionList*) [NSNull null]) {
		[self->_collectItems retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_collectItems valueForKey:@"MobileLibraryGUI_MemberController_collectItems_back"];
		[backpointers addObject:self];
	}
	self->_collectItems_initialized = YES;

}
-(void) set_borrowedItemsLabel:(GeneralGUI_Label*) value {
	 
	if (self->_borrowedItemsLabel!= nil && self->_borrowedItemsLabel!= (GeneralGUI_Label*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_borrowedItemsLabel valueForKey:@"MobileLibraryGUI_MemberController_borrowedItemsLabel_back"];
		[backpointers removeObject:self];
		[self->_borrowedItemsLabel release];
	}
	self->_borrowedItemsLabel = value;
	if (self->_borrowedItemsLabel!= nil && self->_borrowedItemsLabel!= (GeneralGUI_Label*) [NSNull null]) {
		[self->_borrowedItemsLabel retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_borrowedItemsLabel valueForKey:@"MobileLibraryGUI_MemberController_borrowedItemsLabel_back"];
		[backpointers addObject:self];
	}
	self->_borrowedItemsLabel_initialized = YES;

}
-(void) set_itemsToCollectLabel:(GeneralGUI_Label*) value {
	 
	if (self->_itemsToCollectLabel!= nil && self->_itemsToCollectLabel!= (GeneralGUI_Label*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_itemsToCollectLabel valueForKey:@"MobileLibraryGUI_MemberController_itemsToCollectLabel_back"];
		[backpointers removeObject:self];
		[self->_itemsToCollectLabel release];
	}
	self->_itemsToCollectLabel = value;
	if (self->_itemsToCollectLabel!= nil && self->_itemsToCollectLabel!= (GeneralGUI_Label*) [NSNull null]) {
		[self->_itemsToCollectLabel retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_itemsToCollectLabel valueForKey:@"MobileLibraryGUI_MemberController_itemsToCollectLabel_back"];
		[backpointers addObject:self];
	}
	self->_itemsToCollectLabel_initialized = YES;

}
-(void) set_window:(GeneralGUI_Frame*) value {
	 
	if (self->_window!= nil && self->_window!= (GeneralGUI_Frame*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_window valueForKey:@"MobileLibraryGUI_MemberController_window_back"];
		[backpointers removeObject:self];
		[self->_window release];
	}
	self->_window = value;
	if (self->_window!= nil && self->_window!= (GeneralGUI_Frame*) [NSNull null]) {
		[self->_window retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_window valueForKey:@"MobileLibraryGUI_MemberController_window_back"];
		[backpointers addObject:self];
	}
	self->_window_initialized = YES;

}
-(void) set_selectedBorrowing:(Library_Copy*) value {
	 
	if (self->_selectedBorrowing!= nil && self->_selectedBorrowing!= (Library_Copy*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_selectedBorrowing valueForKey:@"MobileLibraryGUI_MemberController_selectedBorrowing_back"];
		[backpointers removeObject:self];
		[self->_selectedBorrowing release];
	}
	self->_selectedBorrowing = value;
	if (self->_selectedBorrowing!= nil && self->_selectedBorrowing!= (Library_Copy*) [NSNull null]) {
		[self->_selectedBorrowing retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_selectedBorrowing valueForKey:@"MobileLibraryGUI_MemberController_selectedBorrowing_back"];
		[backpointers addObject:self];
	}
	self->_selectedBorrowing_initialized = YES;

}
-(void) set_currMember:(Library_Member*) value {
	 
	if (self->_currMember!= nil && self->_currMember!= (Library_Member*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_currMember valueForKey:@"MobileLibraryGUI_MemberController_currMember_back"];
		[backpointers removeObject:self];
		[self->_currMember release];
	}
	self->_currMember = value;
	if (self->_currMember!= nil && self->_currMember!= (Library_Member*) [NSNull null]) {
		[self->_currMember retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_currMember valueForKey:@"MobileLibraryGUI_MemberController_currMember_back"];
		[backpointers addObject:self];
	}
	self->_currMember_initialized = YES;

}
-(void) set_yesNoMsg:(GeneralGUI_ConfirmationDialog*) value {
	 
	if (self->_yesNoMsg!= nil && self->_yesNoMsg!= (GeneralGUI_ConfirmationDialog*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_yesNoMsg valueForKey:@"MobileLibraryGUI_MemberController_yesNoMsg_back"];
		[backpointers removeObject:self];
		[self->_yesNoMsg release];
	}
	self->_yesNoMsg = value;
	if (self->_yesNoMsg!= nil && self->_yesNoMsg!= (GeneralGUI_ConfirmationDialog*) [NSNull null]) {
		[self->_yesNoMsg retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_yesNoMsg valueForKey:@"MobileLibraryGUI_MemberController_yesNoMsg_back"];
		[backpointers addObject:self];
	}
	self->_yesNoMsg_initialized = YES;

}
-(void) set_dateHandler:(DateProcessing_DateHandler*) value {
	 
	if (self->_dateHandler!= nil && self->_dateHandler!= (DateProcessing_DateHandler*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_dateHandler valueForKey:@"MobileLibraryGUI_MemberController_dateHandler_back"];
		[backpointers removeObject:self];
		[self->_dateHandler release];
	}
	self->_dateHandler = value;
	if (self->_dateHandler!= nil && self->_dateHandler!= (DateProcessing_DateHandler*) [NSNull null]) {
		[self->_dateHandler retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_dateHandler valueForKey:@"MobileLibraryGUI_MemberController_dateHandler_back"];
		[backpointers addObject:self];
	}
	self->_dateHandler_initialized = YES;

}
-(void) set_currMsg:(GeneralGUI_MsgDialog*) value {
	 
	if (self->_currMsg!= nil && self->_currMsg!= (GeneralGUI_MsgDialog*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_currMsg valueForKey:@"MobileLibraryGUI_MemberController_currMsg_back"];
		[backpointers removeObject:self];
		[self->_currMsg release];
	}
	self->_currMsg = value;
	if (self->_currMsg!= nil && self->_currMsg!= (GeneralGUI_MsgDialog*) [NSNull null]) {
		[self->_currMsg retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_currMsg valueForKey:@"MobileLibraryGUI_MemberController_currMsg_back"];
		[backpointers addObject:self];
	}
	self->_currMsg_initialized = YES;

}




 
-(void) event_borrowItemSelected_pushed:(PropertyChangeList*) changes  p_index: (OCLInteger*) p_index{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_borrowItemSelected", @"MobileLibraryGUI_MemberController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {

			[self event_showConfirmRenewMsg_pushed:changes ];
		}
		[v0 release];


		 
		 // Process impacts relationships
		/* ==================================================
		 * currMember.borrows->asSequence()->at(index)
		 * ================================================== */
		
		MobileLibraryGUI_MemberController* v5 = self;
		Library_Member* v4 = [v5 _currMember];
		OCLSet* v3 = [v4 _borrows];
		OCLSequence* v2 = [v3 asSequence];
		OCLInteger* v6 = p_index;
		Library_Copy* v1 = ((Library_Copy*)[v2 at:v6]);
		[v2 release];
		
		Library_Copy* _selectedBorrowing_newValue = v1;
		[changes addChange:@selector(set_selectedBorrowing:) instance:self value:_selectedBorrowing_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_borrowItemSelected_pulled_edge0:(PropertyChangeList*)changes parentInstance:(GeneralGUI_SelectionList*)parentInstance p_index:(OCLInteger*)p_index  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_borrowItemSelected", @"MobileLibraryGUI_MemberController", @"_itemSelected", @"GeneralGUI_SelectionList");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {
		/* ==================================================
		 * index
		 * ================================================== */
		
		OCLInteger* v1 = p_index;
		
		OCLInteger* parameter_p_index = v1;

		[self event_borrowItemSelected_pushed:changes p_index:parameter_p_index ];

	}
	[v0 release];
}


-(void) event_refreshData_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_refreshData", @"MobileLibraryGUI_MemberController");

		 
		// Trigger Push edges

		if (self->_borrowItems != nil && self->_borrowItems != (GeneralGUI_SelectionList*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_borrowItems];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			GeneralGUI_SelectionList* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * getBorrowItemsToDisplay
				 * ================================================== */
				
				OCLSequence* v1 = [self getBorrowItemsToDisplay];
				
					OCLSequence* parameter_p_items = v1;

					[edge0_target event_refreshItems_pushed:changes p_items:parameter_p_items ];

				}
				[v0 release];
			}

		}
		if (self->_memberNameLabel != nil && self->_memberNameLabel != (GeneralGUI_Label*)[NSNull null]) {
			 
			NSMutableArray* edge1_values = [[NSMutableArray alloc] init];
			[edge1_values addObject:self->_memberNameLabel];
			NSEnumerator* edge1_enum = [edge1_values objectEnumerator];
			GeneralGUI_Label* edge1_target;
			while ((edge1_target = [edge1_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * currMember.name
				 * ================================================== */
				
				Library_Member* v2 = [self _currMember];
				OCLString* v1 = [v2 _name];
				
					OCLString* parameter_p_text = v1;

					[edge1_target event_setText_pushed:changes p_text:parameter_p_text ];

				}
				[v0 release];
			}

		}
		if (self->_collectItems != nil && self->_collectItems != (GeneralGUI_SelectionList*)[NSNull null]) {
			 
			NSMutableArray* edge2_values = [[NSMutableArray alloc] init];
			[edge2_values addObject:self->_collectItems];
			NSEnumerator* edge2_enum = [edge2_values objectEnumerator];
			GeneralGUI_SelectionList* edge2_target;
			while ((edge2_target = [edge2_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * getToCollectItemsToDisplay
				 * ================================================== */
				
				OCLSequence* v1 = [self getToCollectItemsToDisplay];
				
					OCLSequence* parameter_p_items = v1;

					[edge2_target event_refreshItems_pushed:changes p_items:parameter_p_items ];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_sessionStarted_pushed:(PropertyChangeList*) changes  p_m: (Library_Member*) p_m{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_sessionStarted", @"MobileLibraryGUI_MemberController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * m
		 * ================================================== */
		
		Library_Member* v0 = p_m;
		
		Library_Member* _currMember_newValue = v0;
		[changes addChange:@selector(set_currMember:) instance:self value:_currMember_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_showConfirmRenewMsg_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_showConfirmRenewMsg", @"MobileLibraryGUI_MemberController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * GeneralGUI::ConfirmationDialog::create(Tuple { title = 'Confirm', message = 'Would you like to renew the selected book?' })
		 * ================================================== */
		
		OCLString* v4 = [(OCLString*)[OCLString alloc] initWithString:@"Confirm"];
		OCLString* v3 = v4;
		OCLString* v6 = [(OCLString*)[OCLString alloc] initWithString:@"Would you like to renew the selected book?"];
		OCLString* v5 = v6;
		OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
		[v2 addItemNamed:@"title" withValue:v3];
		[v2 addItemNamed:@"message" withValue:v5];
		GeneralGUI_ConfirmationDialog* v0 = [(GeneralGUI_ConfirmationDialog*)[GeneralGUI_ConfirmationDialog alloc] initWithValues:v2];
		[v4 release];
		[v2 release];
		[v6 release];
		
		GeneralGUI_ConfirmationDialog* _yesNoMsg_newValue = v0;
		[changes addChange:@selector(set_yesNoMsg:) instance:self value:_yesNoMsg_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_renewConfAck_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_renewConfAck", @"MobileLibraryGUI_MemberController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {

			[self event_renewBorrowing_pushed:changes ];
		}
		[v0 release];


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_renewConfAck_pulled_edge0:(PropertyChangeList*)changes parentInstance:(GeneralGUI_ConfirmationDialog*)parentInstance  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_renewConfAck", @"MobileLibraryGUI_MemberController", @"_okClicked", @"GeneralGUI_ConfirmationDialog");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {

		[self event_renewConfAck_pushed:changes ];

	}
	[v0 release];
}


-(void) event_renewBorrowing_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_renewBorrowing", @"MobileLibraryGUI_MemberController");

		 
		// Trigger Push edges

		if (self->_selectedBorrowing != nil && self->_selectedBorrowing != (Library_Copy*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_selectedBorrowing];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			Library_Copy* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * dateHandler.calcAfterOneMonth(selectedBorrowing.dueDate)
				 * ================================================== */
				
				DateProcessing_DateHandler* v2 = [self _dateHandler];
				Library_Copy* v4 = [self _selectedBorrowing];
				OCLString* v3 = [v4 _dueDate];
				OCLString* v1 = [v2 calcAfterOneMonth:v3];
				
					OCLString* parameter_p_newDueDate = v1;

					[edge0_target event_renew_pushed:changes p_newDueDate:parameter_p_newDueDate ];
					[v1 release];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_copyRenewed_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_copyRenewed", @"MobileLibraryGUI_MemberController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {

			[self event_showRenewOkMsg_pushed:changes ];
		}
		[v0 release];


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_copyRenewed_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Library_Copy*)parentInstance p_newDueDate:(OCLString*)p_newDueDate  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_copyRenewed", @"MobileLibraryGUI_MemberController", @"_renewOk", @"Library_Copy");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {

		[self event_copyRenewed_pushed:changes ];

	}
	[v0 release];
}


-(void) event_showRenewOkMsg_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_showRenewOkMsg", @"MobileLibraryGUI_MemberController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * GeneralGUI::MsgDialog::create(
		 * 	Tuple { 
		 * 	    msg = 'Book '.concat(selectedBorrowing.book.title).concat(' renewed sucessfully.'), 
		 * 		viewTitle = 'Success!' })
		 * ================================================== */
		
		OCLString* v6 = [(OCLString*)[OCLString alloc] initWithString:@"Book "];
		MobileLibraryGUI_MemberController* v10 = self;
		Library_Copy* v9 = [v10 _selectedBorrowing];
		Library_Book* v8 = [v9 _book];
		OCLString* v7 = [v8 _title];
		OCLString* v5 = [v6 concat:v7];
		OCLString* v11 = [(OCLString*)[OCLString alloc] initWithString:@" renewed sucessfully."];
		OCLString* v4 = [v5 concat:v11];
		OCLString* v3 = v4;
		OCLString* v13 = [(OCLString*)[OCLString alloc] initWithString:@"Success!"];
		OCLString* v12 = v13;
		OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
		[v2 addItemNamed:@"msg" withValue:v3];
		[v2 addItemNamed:@"viewTitle" withValue:v12];
		GeneralGUI_MsgDialog* v0 = [(GeneralGUI_MsgDialog*)[GeneralGUI_MsgDialog alloc] initWithValues:v2];
		[v6 release];
		[v2 release];
		[v5 release];
		[v13 release];
		[v11 release];
		[v4 release];
		
		GeneralGUI_MsgDialog* _currMsg_newValue = v0;
		[changes addChange:@selector(set_currMsg:) instance:self value:_currMsg_newValue];
		/* ==================================================
		 * 'WaitingRenewAck'
		 * ================================================== */
		
		OCLString* v14 = [(OCLString*)[OCLString alloc] initWithString:@"WaitingRenewAck"];
		
		OCLString* _ackStatus_newValue = v14;
		[changes addChange:@selector(set_ackStatus:) instance:self value:_ackStatus_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_renewAck_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * ackStatus='WaitingRenewAck'
		 * ================================================== */
		
		MobileLibraryGUI_MemberController* v2 = self;
		OCLString* v1 = [v2 _ackStatus];
		OCLString* v3 = [(OCLString*)[OCLString alloc] initWithString:@"WaitingRenewAck"];
		OCLBoolean* v0 = [v1 eq:v3];
		[v3 release];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_renewAck", @"MobileLibraryGUI_MemberController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {

			[self event_refreshData_pushed:changes ];
		}
		[v0 release];
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v1 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v1->value == YES) {

			[self event_saveData_pushed:changes ];
		}
		[v1 release];
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v2 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v2->value == YES) {

			[self event_setToNotWaiting_pushed:changes ];
		}
		[v2 release];


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_renewAck_pulled_edge0:(PropertyChangeList*)changes parentInstance:(GeneralGUI_MsgDialog*)parentInstance  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_renewAck", @"MobileLibraryGUI_MemberController", @"_okClicked", @"GeneralGUI_MsgDialog");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {

		[self event_renewAck_pushed:changes ];

	}
	[v0 release];
}


-(void) event_saveData_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_saveData", @"MobileLibraryGUI_MemberController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges
		NSEnumerator* Application_Main_saveLibrary_edge0_enum = [self->Application_Main_memberControl_back objectEnumerator];
		Application_Main* Application_Main_saveLibrary_edge0_target;
		while ((Application_Main_saveLibrary_edge0_target = [Application_Main_saveLibrary_edge0_enum nextObject]) != nil) {
		    [Application_Main_saveLibrary_edge0_target event_saveLibrary_pulled_edge0:changes parentInstance:self ];
		}



		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_renewFailed_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_renewFailed", @"MobileLibraryGUI_MemberController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {

			[self event_showRenewFailedMsg_pushed:changes ];
		}
		[v0 release];


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_renewFailed_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Library_Copy*)parentInstance p_copy:(Library_Copy*)p_copy  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_renewFailed", @"MobileLibraryGUI_MemberController", @"_renewFailed", @"Library_Copy");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {

		[self event_renewFailed_pushed:changes ];

	}
	[v0 release];
}


-(void) event_showRenewFailedMsg_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_showRenewFailedMsg", @"MobileLibraryGUI_MemberController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * GeneralGUI::MsgDialog::create(
		 * 	Tuple { 
		 * 	    msg = 'Could not renew  borrowing of book '.concat(selectedBorrowing.book.title).concat('. You have reached the limit of renewals for this borrowing.'), 
		 * 		viewTitle = 'Error!' })
		 * ================================================== */
		
		OCLString* v6 = [(OCLString*)[OCLString alloc] initWithString:@"Could not renew  borrowing of book "];
		MobileLibraryGUI_MemberController* v10 = self;
		Library_Copy* v9 = [v10 _selectedBorrowing];
		Library_Book* v8 = [v9 _book];
		OCLString* v7 = [v8 _title];
		OCLString* v5 = [v6 concat:v7];
		OCLString* v11 = [(OCLString*)[OCLString alloc] initWithString:@". You have reached the limit of renewals for this borrowing."];
		OCLString* v4 = [v5 concat:v11];
		OCLString* v3 = v4;
		OCLString* v13 = [(OCLString*)[OCLString alloc] initWithString:@"Error!"];
		OCLString* v12 = v13;
		OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
		[v2 addItemNamed:@"msg" withValue:v3];
		[v2 addItemNamed:@"viewTitle" withValue:v12];
		GeneralGUI_MsgDialog* v0 = [(GeneralGUI_MsgDialog*)[GeneralGUI_MsgDialog alloc] initWithValues:v2];
		[v5 release];
		[v2 release];
		[v4 release];
		[v6 release];
		[v13 release];
		[v11 release];
		
		GeneralGUI_MsgDialog* _currMsg_newValue = v0;
		[changes addChange:@selector(set_currMsg:) instance:self value:_currMsg_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_setToNotWaiting_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_setToNotWaiting", @"MobileLibraryGUI_MemberController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * 'NotWaiting'
		 * ================================================== */
		
		OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@"NotWaiting"];
		
		OCLString* _ackStatus_newValue = v0;
		[changes addChange:@selector(set_ackStatus:) instance:self value:_ackStatus_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 




 
-(OCLSequence*) getBorrowItemsToDisplay{
	/* ==================================================
	 * if currMember <> null 
	 * 	then 
	 * 		currMember.borrows->asSequence()->collect(c:Library::Copy | c.book.title.concat(' ').concat(c.dueDate))
	 * 	else 
	 * 		Sequence {}
	 * endif
	 * ================================================== */
	
	MobileLibraryGUI_MemberController* v3 = self;
	Library_Member* v2 = [v3 _currMember];
	id v4 = [NSNull null];
	OCLBoolean* v1 = [v2 neq:v4];
	OCLSequence* v0;
	if (v1->value == YES) {
		MobileLibraryGUI_MemberController* v9 = self;
		Library_Member* v8 = [v9 _currMember];
		OCLSet* v7 = [v8 _borrows];
		OCLSequence* v6 = [v7 asSequence];
		OCLSequence* v5_nested = [(OCLSequence*)[OCLSequence alloc] init];
		NSEnumerator* v5_enum = [v6 objectEnumerator];
		Library_Copy* v10;
		while ((v10 = [v5_enum nextObject]) != nil) {
			Library_Copy* v15 = v10;
			Library_Book* v14 = [v15 _book];
			OCLString* v13 = [v14 _title];
			OCLString* v16 = [(OCLString*)[OCLString alloc] initWithString:@" "];
			OCLString* v12 = [v13 concat:v16];
			Library_Copy* v18 = v10;
			OCLString* v17 = [v18 _dueDate];
			OCLString* v11 = [v12 concat:v17];
			[v5_nested add: v11];
			[v16 release];
			[v11 release];
			[v12 release];
		}
		OCLSequence* v5 = [v5_nested flatten];
		[v5_nested release];
		v0 = v5;
		[v6 release];
	} else {
		OCLSequence* v19 = [(OCLSequence*)[OCLSequence alloc] init];
		v0 = v19;
	}
	[v1 release];
	;
	return v0;
}
-(OCLSequence*) getToCollectItemsToDisplay{
	/* ==================================================
	 * if currMember <> null 
	 * 	then 
	 * 		currMember.toCollect->asSequence()->collect(c:Library::Copy | c.book.title)
	 * 	else 
	 * 		Sequence {}
	 * endif
	 * ================================================== */
	
	MobileLibraryGUI_MemberController* v3 = self;
	Library_Member* v2 = [v3 _currMember];
	id v4 = [NSNull null];
	OCLBoolean* v1 = [v2 neq:v4];
	OCLSequence* v0;
	if (v1->value == YES) {
		MobileLibraryGUI_MemberController* v9 = self;
		Library_Member* v8 = [v9 _currMember];
		OCLSet* v7 = [v8 _toCollect];
		OCLSequence* v6 = [v7 asSequence];
		OCLSequence* v5_nested = [(OCLSequence*)[OCLSequence alloc] init];
		NSEnumerator* v5_enum = [v6 objectEnumerator];
		Library_Copy* v10;
		while ((v10 = [v5_enum nextObject]) != nil) {
			Library_Copy* v13 = v10;
			Library_Book* v12 = [v13 _book];
			OCLString* v11 = [v12 _title];
			[v5_nested add: v11];
		}
		OCLSequence* v5 = [v5_nested flatten];
		[v5_nested release];
		v0 = v5;
		[v6 release];
	} else {
		OCLSequence* v14 = [(OCLSequence*)[OCLSequence alloc] init];
		v0 = v14;
	}
	[v1 release];
	;
	return v0;
}


@end 


