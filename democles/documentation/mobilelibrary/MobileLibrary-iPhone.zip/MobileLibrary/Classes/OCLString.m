#import "OCLString.h"
#import "OCLInteger.h"
#import "OCLBoolean.h"
#import "OCLReal.h"

@implementation OCLString

-(OCLString*)initWithString:(NSString*)s {
	self = [super init];
	[s retain];
	self->string = s;
	return self;
}

-(BOOL)isEqual:(id)other {
	BOOL res;
	if ([self isCompatibleType:other]) {
		OCLString* otherString = (OCLString*)other;
		res = [self->string isEqual:otherString->string]; 
	} else {
		res = NO;
	}
	return res;
}

-(NSString*)description {
	return [NSString stringWithFormat:@"<String id=\"%p\" retainCount=\"%i\">%@</String>\n", self, [self retainCount], self->string];
}

-(OCLInteger*)size {
	return [(OCLInteger*)[OCLInteger alloc] initWithValue:[string length]];
}

-(OCLString*)concat:(OCLString*)s {
	NSString* concatenatedString = [self->string stringByAppendingString:s->string]; // Does not actually allocate a new string
	NSString* stringCopy = [[NSString alloc] initWithString:concatenatedString]; // therefore make a copy.
	OCLString* res = [(OCLString*)[OCLString alloc] initWithString:stringCopy];
	[stringCopy release];
	return res;
}

-(OCLString*)substring:(OCLInteger*)lower upper:(OCLInteger*)upper {
	NSRange range;
	range.location = lower->value - 1;
	range.length = upper->value - lower->value;

	NSString* res = [string substringWithRange:range];
	return [(OCLString*)[OCLString alloc] initWithString:res];
}

-(OCLInteger*)toInteger {
	return [(OCLInteger*)[OCLInteger alloc] initWithValue:[string intValue]];
}

-(OCLReal*)toReal {
	return [(OCLReal*)[OCLReal alloc] initWithValue:[string doubleValue]];
}

-(NSUInteger)hash {
	return [string hash];
}

-(void)dealloc {
	[self->string release];
	[super dealloc];
}

@end
