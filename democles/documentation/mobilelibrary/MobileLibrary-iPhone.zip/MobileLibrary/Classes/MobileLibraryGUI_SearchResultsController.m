 
 
 
#import "MobileLibraryGUI_SearchResultsController.h"
#import "PropertyChangeList.h"
#import "Library_Author.h"
#import "MobileLibraryGUI_BookDetailController.h"
#import "Library_Member.h"
#import "Library_Book.h"
#import "GeneralGUI_SelectionList.h"
#import "GeneralGUI_Window.h"
#import "Library_Copy.h"
#import "GeneralGUI_Label.h"
#import "MobileLibraryGUI_SearchController.h"


 
@implementation MobileLibraryGUI_SearchResultsController

 
- (MobileLibraryGUI_SearchResultsController*) init {
	self = [super init];
	 
	self->MobileLibraryGUI_SearchController_searchResults_back = [[NSMutableArray alloc] init];

	[self set_bookListTable: [self _bookListTable]];
	[self set_detailsWindow: [self _detailsWindow]];
	[self set_title: [self _title]];
	[self set_window: [self _window]];
	[self set_mode: [self _mode]];
	[self set_currMember: [self _currMember]];

	return self;
}

 
- (MobileLibraryGUI_SearchResultsController*) initWithValues: (OCLTuple*) values {
	self = [super init];
	 
	self->_bookListTable_initialized = NO;
	self->_detailsWindow_initialized = NO;
	self->_title_initialized = NO;
	self->_window_initialized = NO;
	self->_mode_initialized = NO;
	self->_currMember_initialized = NO;

	self->MobileLibraryGUI_SearchController_searchResults_back = [[NSMutableArray alloc] init];

	GeneralGUI_SelectionList* _bookListTable_initialValue = (GeneralGUI_SelectionList*) [values objectForKey:@"bookListTable"];
	if (_bookListTable_initialValue == nil) {
		_bookListTable_initialValue = [self _bookListTable];
	}
	[self set_bookListTable:_bookListTable_initialValue];
	MobileLibraryGUI_BookDetailController* _detailsWindow_initialValue = (MobileLibraryGUI_BookDetailController*) [values objectForKey:@"detailsWindow"];
	if (_detailsWindow_initialValue == nil) {
		_detailsWindow_initialValue = [self _detailsWindow];
	}
	[self set_detailsWindow:_detailsWindow_initialValue];
	OCLString* _title_initialValue = (OCLString*) [values objectForKey:@"title"];
	if (_title_initialValue == nil) {
		_title_initialValue = [self _title];
	}
	[self set_title:_title_initialValue];
	GeneralGUI_Window* _window_initialValue = (GeneralGUI_Window*) [values objectForKey:@"window"];
	if (_window_initialValue == nil) {
		_window_initialValue = [self _window];
	}
	[self set_window:_window_initialValue];
	OCLString* _mode_initialValue = (OCLString*) [values objectForKey:@"mode"];
	if (_mode_initialValue == nil) {
		_mode_initialValue = [self _mode];
	}
	[self set_mode:_mode_initialValue];
	Library_Member* _currMember_initialValue = (Library_Member*) [values objectForKey:@"currMember"];
	if (_currMember_initialValue == nil) {
		_currMember_initialValue = [self _currMember];
	}
	[self set_currMember:_currMember_initialValue];

	
	return self;
}

 
- (void) dealloc {
	if (self->_bookListTable != nil && self->_bookListTable != (GeneralGUI_SelectionList*) [NSNull null]) [self->_bookListTable release];
	if (self->_detailsWindow != nil && self->_detailsWindow != (MobileLibraryGUI_BookDetailController*) [NSNull null]) [self->_detailsWindow release];
	if (self->_title != nil && self->_title != (OCLString*) [NSNull null]) [self->_title release];
	if (self->_window != nil && self->_window != (GeneralGUI_Window*) [NSNull null]) [self->_window release];
	if (self->_mode != nil && self->_mode != (OCLString*) [NSNull null]) [self->_mode release];
	if (self->_currMember != nil && self->_currMember != (Library_Member*) [NSNull null]) [self->_currMember release];

	[self->MobileLibraryGUI_SearchController_searchResults_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"MobileLibraryGUI::SearchResultsController\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"bookListTable\" type=\"GeneralGUI::SelectionList\">\n"];
	[res appendFormat:@"%@\n", [self _bookListTable]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"detailsWindow\" type=\"MobileLibraryGUI::BookDetailController\">\n"];
	[res appendFormat:@"%@\n", [self _detailsWindow]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"title\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _title]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"window\" type=\"GeneralGUI::Window\">\n"];
	[res appendFormat:@"%@\n", [self _window]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"mode\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _mode]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"currMember\" type=\"Library::Member\">\n"];
	[res appendFormat:@"%@\n", [self _currMember]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
-(GeneralGUI_SelectionList*) initial_bookListTable {
	/* ==================================================
	 * null
	 * ================================================== */
	
	GeneralGUI_SelectionList* v0 = [NSNull null];
	
	return v0;
}

-(GeneralGUI_SelectionList*) _bookListTable {
	if (self->_bookListTable_initialized == YES) {
		return _bookListTable;
	} else { 
		[self set_bookListTable:[self initial_bookListTable]];
	}

	self->_bookListTable_initialized = YES;
	return _bookListTable;
}
-(MobileLibraryGUI_BookDetailController*) initial_detailsWindow {
	/* ==================================================
	 * null
	 * ================================================== */
	
	MobileLibraryGUI_BookDetailController* v0 = [NSNull null];
	
	return v0;
}

-(MobileLibraryGUI_BookDetailController*) _detailsWindow {
	if (self->_detailsWindow_initialized == YES) {
		return _detailsWindow;
	} else { 
		[self set_detailsWindow:[self initial_detailsWindow]];
	}

	self->_detailsWindow_initialized = YES;
	return _detailsWindow;
}
-(OCLString*) initial_title {
	/* ==================================================
	 * 'Results'
	 * ================================================== */
	
	OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@"Results"];
	
	return v0;
}

-(OCLString*) _title {
	if (self->_title_initialized == YES) {
		return _title;
	} else { 
		[self set_title:[self initial_title]];
	}

	self->_title_initialized = YES;
	return _title;
}
-(GeneralGUI_Window*) initial_window {
	/* ==================================================
	 * GeneralGUI::Window::create(
	 * 	Tuple { seqGUIElements = Sequence {bookListTable }, 
	 * 	title = title })
	 * ================================================== */
	
	MobileLibraryGUI_SearchResultsController* v7 = self;
	GeneralGUI_SelectionList* v6 = [v7 _bookListTable];
	GeneralGUI_SelectionList* v5 = v6;
	OCLSequence* v4 = [(OCLSequence*)[OCLSequence alloc] init];
	[v4 add:v5];
	OCLSequence* v3 = v4;
	MobileLibraryGUI_SearchResultsController* v10 = self;
	OCLString* v9 = [v10 _title];
	OCLString* v8 = v9;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"seqGUIElements" withValue:v3];
	[v2 addItemNamed:@"title" withValue:v8];
	GeneralGUI_Window* v0 = [(GeneralGUI_Window*)[GeneralGUI_Window alloc] initWithValues:v2];
	[v2 release];
	[v4 release];
	
	return v0;
}

-(GeneralGUI_Window*) _window {
	if (self->_window_initialized == YES) {
		return _window;
	} else { 
		[self set_window:[self initial_window]];
	}

	self->_window_initialized = YES;
	return _window;
}
-(OCLString*) initial_mode {
	/* ==================================================
	 * 'NotLoggedIn'
	 * ================================================== */
	
	OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@"NotLoggedIn"];
	
	return v0;
}

-(OCLString*) _mode {
	if (self->_mode_initialized == YES) {
		return _mode;
	} else { 
		[self set_mode:[self initial_mode]];
	}

	self->_mode_initialized = YES;
	return _mode;
}
-(Library_Member*) initial_currMember {
	/* ==================================================
	 * null
	 * ================================================== */
	
	Library_Member* v0 = [NSNull null];
	
	return v0;
}

-(Library_Member*) _currMember {
	if (self->_currMember_initialized == YES) {
		return _currMember;
	} else { 
		[self set_currMember:[self initial_currMember]];
	}

	self->_currMember_initialized = YES;
	return _currMember;
}


 
-(void) set_title:(OCLString*) value {
	 	if (self->_title!= nil && self->_title!= (OCLString*) [NSNull null]) {
		[self->_title release];
	}
	self->_title = value;
	if (self->_title!= nil && self->_title!= (OCLString*) [NSNull null]) {
		[self->_title retain];
	}
	self->_title_initialized = YES;

}
-(void) set_mode:(OCLString*) value {
	 	if (self->_mode!= nil && self->_mode!= (OCLString*) [NSNull null]) {
		[self->_mode release];
	}
	self->_mode = value;
	if (self->_mode!= nil && self->_mode!= (OCLString*) [NSNull null]) {
		[self->_mode retain];
	}
	self->_mode_initialized = YES;

}


-(void) set_bookListTable:(GeneralGUI_SelectionList*) value {
	 
	if (self->_bookListTable!= nil && self->_bookListTable!= (GeneralGUI_SelectionList*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_bookListTable valueForKey:@"MobileLibraryGUI_SearchResultsController_bookListTable_back"];
		[backpointers removeObject:self];
		[self->_bookListTable release];
	}
	self->_bookListTable = value;
	if (self->_bookListTable!= nil && self->_bookListTable!= (GeneralGUI_SelectionList*) [NSNull null]) {
		[self->_bookListTable retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_bookListTable valueForKey:@"MobileLibraryGUI_SearchResultsController_bookListTable_back"];
		[backpointers addObject:self];
	}
	self->_bookListTable_initialized = YES;

}
-(void) set_detailsWindow:(MobileLibraryGUI_BookDetailController*) value {
	 
	if (self->_detailsWindow!= nil && self->_detailsWindow!= (MobileLibraryGUI_BookDetailController*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_detailsWindow valueForKey:@"MobileLibraryGUI_SearchResultsController_detailsWindow_back"];
		[backpointers removeObject:self];
		[self->_detailsWindow release];
	}
	self->_detailsWindow = value;
	if (self->_detailsWindow!= nil && self->_detailsWindow!= (MobileLibraryGUI_BookDetailController*) [NSNull null]) {
		[self->_detailsWindow retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_detailsWindow valueForKey:@"MobileLibraryGUI_SearchResultsController_detailsWindow_back"];
		[backpointers addObject:self];
	}
	self->_detailsWindow_initialized = YES;

}
-(void) set_window:(GeneralGUI_Window*) value {
	 
	if (self->_window!= nil && self->_window!= (GeneralGUI_Window*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_window valueForKey:@"MobileLibraryGUI_SearchResultsController_window_back"];
		[backpointers removeObject:self];
		[self->_window release];
	}
	self->_window = value;
	if (self->_window!= nil && self->_window!= (GeneralGUI_Window*) [NSNull null]) {
		[self->_window retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_window valueForKey:@"MobileLibraryGUI_SearchResultsController_window_back"];
		[backpointers addObject:self];
	}
	self->_window_initialized = YES;

}
-(void) set_currMember:(Library_Member*) value {
	 
	if (self->_currMember!= nil && self->_currMember!= (Library_Member*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_currMember valueForKey:@"MobileLibraryGUI_SearchResultsController_currMember_back"];
		[backpointers removeObject:self];
		[self->_currMember release];
	}
	self->_currMember = value;
	if (self->_currMember!= nil && self->_currMember!= (Library_Member*) [NSNull null]) {
		[self->_currMember retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_currMember valueForKey:@"MobileLibraryGUI_SearchResultsController_currMember_back"];
		[backpointers addObject:self];
	}
	self->_currMember_initialized = YES;

}




 
-(void) event_bookSelected_pushed:(PropertyChangeList*) changes  p_index: (OCLInteger*) p_index{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_bookSelected", @"MobileLibraryGUI_SearchResultsController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges
		NSEnumerator* MobileLibraryGUI_SearchController_bookSelected_edge0_enum = [self->MobileLibraryGUI_SearchController_searchResults_back objectEnumerator];
		MobileLibraryGUI_SearchController* MobileLibraryGUI_SearchController_bookSelected_edge0_target;
		while ((MobileLibraryGUI_SearchController_bookSelected_edge0_target = [MobileLibraryGUI_SearchController_bookSelected_edge0_enum nextObject]) != nil) {
		    [MobileLibraryGUI_SearchController_bookSelected_edge0_target event_bookSelected_pulled_edge0:changes parentInstance:self p_index:p_index ];
		}



		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_bookSelected_pulled_edge0:(PropertyChangeList*)changes parentInstance:(GeneralGUI_SelectionList*)parentInstance p_index:(OCLInteger*)p_index  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_bookSelected", @"MobileLibraryGUI_SearchResultsController", @"_itemSelected", @"GeneralGUI_SelectionList");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {
		/* ==================================================
		 * index
		 * ================================================== */
		
		OCLInteger* v1 = p_index;
		
		OCLInteger* parameter_p_index = v1;

		[self event_bookSelected_pushed:changes p_index:parameter_p_index ];

	}
	[v0 release];
}


-(void) event_selectedBook_pushed:(PropertyChangeList*) changes  p_book: (Library_Book*) p_book{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_selectedBook", @"MobileLibraryGUI_SearchResultsController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * BookDetailController::create(
		 * Tuple { 
		 * 	bookTitleLabel = GeneralGUI::Label::create(Tuple { text = book.title }), 
		 * 	bookAuthorLabel = GeneralGUI::Label::create(Tuple { text = getAuthorsData (book) }), 
		 * 	bookIsbnLabel = GeneralGUI::Label::create(Tuple { text = book.isbn }),
		 * 	bookCopies = GeneralGUI::SelectionList::create(Tuple { items = getBookCopiesData (book) }),
		 * 	currBook = book,
		 * 	currMember = currMember,
		 * 	mode = mode
		 * })
		 * ================================================== */
		
		Library_Book* v9 = p_book;
		OCLString* v8 = [v9 _title];
		OCLString* v7 = v8;
		OCLTuple* v6 = [(OCLTuple*)[OCLTuple alloc] init];
		[v6 addItemNamed:@"text" withValue:v7];
		GeneralGUI_Label* v4 = [(GeneralGUI_Label*)[GeneralGUI_Label alloc] initWithValues:v6];
		GeneralGUI_Label* v3 = v4;
		MobileLibraryGUI_SearchResultsController* v16 = self;
		Library_Book* v17 = p_book;
		OCLString* v15 = [v16 getAuthorsData:v17];
		OCLString* v14 = v15;
		OCLTuple* v13 = [(OCLTuple*)[OCLTuple alloc] init];
		[v13 addItemNamed:@"text" withValue:v14];
		GeneralGUI_Label* v11 = [(GeneralGUI_Label*)[GeneralGUI_Label alloc] initWithValues:v13];
		GeneralGUI_Label* v10 = v11;
		Library_Book* v24 = p_book;
		OCLString* v23 = [v24 _isbn];
		OCLString* v22 = v23;
		OCLTuple* v21 = [(OCLTuple*)[OCLTuple alloc] init];
		[v21 addItemNamed:@"text" withValue:v22];
		GeneralGUI_Label* v19 = [(GeneralGUI_Label*)[GeneralGUI_Label alloc] initWithValues:v21];
		GeneralGUI_Label* v18 = v19;
		MobileLibraryGUI_SearchResultsController* v31 = self;
		Library_Book* v32 = p_book;
		OCLSequence* v30 = [v31 getBookCopiesData:v32];
		OCLSequence* v29 = v30;
		OCLTuple* v28 = [(OCLTuple*)[OCLTuple alloc] init];
		[v28 addItemNamed:@"items" withValue:v29];
		GeneralGUI_SelectionList* v26 = [(GeneralGUI_SelectionList*)[GeneralGUI_SelectionList alloc] initWithValues:v28];
		GeneralGUI_SelectionList* v25 = v26;
		Library_Book* v34 = p_book;
		Library_Book* v33 = v34;
		MobileLibraryGUI_SearchResultsController* v37 = self;
		Library_Member* v36 = [v37 _currMember];
		Library_Member* v35 = v36;
		MobileLibraryGUI_SearchResultsController* v40 = self;
		OCLString* v39 = [v40 _mode];
		OCLString* v38 = v39;
		OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
		[v2 addItemNamed:@"bookTitleLabel" withValue:v3];
		[v2 addItemNamed:@"bookAuthorLabel" withValue:v10];
		[v2 addItemNamed:@"bookIsbnLabel" withValue:v18];
		[v2 addItemNamed:@"bookCopies" withValue:v25];
		[v2 addItemNamed:@"currBook" withValue:v33];
		[v2 addItemNamed:@"currMember" withValue:v35];
		[v2 addItemNamed:@"mode" withValue:v38];
		MobileLibraryGUI_BookDetailController* v0 = [(MobileLibraryGUI_BookDetailController*)[MobileLibraryGUI_BookDetailController alloc] initWithValues:v2];
		[v28 release];
		[v4 release];
		[v19 release];
		[v11 release];
		[v13 release];
		[v6 release];
		[v26 release];
		[v2 release];
		[v21 release];
		
		MobileLibraryGUI_BookDetailController* _detailsWindow_newValue = v0;
		[changes addChange:@selector(set_detailsWindow:) instance:self value:_detailsWindow_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_refreshAndSave_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_refreshAndSave", @"MobileLibraryGUI_SearchResultsController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges
		NSEnumerator* MobileLibraryGUI_SearchController_refreshAndSave_edge0_enum = [self->MobileLibraryGUI_SearchController_searchResults_back objectEnumerator];
		MobileLibraryGUI_SearchController* MobileLibraryGUI_SearchController_refreshAndSave_edge0_target;
		while ((MobileLibraryGUI_SearchController_refreshAndSave_edge0_target = [MobileLibraryGUI_SearchController_refreshAndSave_edge0_enum nextObject]) != nil) {
		    [MobileLibraryGUI_SearchController_refreshAndSave_edge0_target event_refreshAndSave_pulled_edge0:changes parentInstance:self ];
		}



		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_refreshAndSave_pulled_edge0:(PropertyChangeList*)changes parentInstance:(MobileLibraryGUI_BookDetailController*)parentInstance  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_refreshAndSave", @"MobileLibraryGUI_SearchResultsController", @"_refreshAndSave", @"MobileLibraryGUI_BookDetailController");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {

		[self event_refreshAndSave_pushed:changes ];

	}
	[v0 release];
}


-(void) event_sessionStarted_pushed:(PropertyChangeList*) changes  p_m: (Library_Member*) p_m{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_sessionStarted", @"MobileLibraryGUI_SearchResultsController");

		 
		// Trigger Push edges

		if (self->_detailsWindow != nil && self->_detailsWindow != (MobileLibraryGUI_BookDetailController*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_detailsWindow];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			MobileLibraryGUI_BookDetailController* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * m
				 * ================================================== */
				
				Library_Member* v1 = p_m;
				
					Library_Member* parameter_p_m = v1;

					[edge0_target event_sessionStarted_pushed:changes p_m:parameter_p_m ];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * 'LoggedIn'
		 * ================================================== */
		
		OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@"LoggedIn"];
		
		OCLString* _mode_newValue = v0;
		[changes addChange:@selector(set_mode:) instance:self value:_mode_newValue];
		/* ==================================================
		 * m
		 * ================================================== */
		
		Library_Member* v1 = p_m;
		
		Library_Member* _currMember_newValue = v1;
		[changes addChange:@selector(set_currMember:) instance:self value:_currMember_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 




 
-(OCLSequence*) getBookCopiesData:p_book {
	/* ==================================================
	 * book.copies->collect(
	 * 	copyId.concat(' ').concat(state).concat(' ').concat(dueDate)
	 * )->asSequence()
	 * ================================================== */
	
	Library_Book* v3 = p_book;
	OCLSet* v2 = [v3 _copies];
	OCLBag* v1_nested = [(OCLBag*)[OCLBag alloc] init];
	NSEnumerator* v1_enum = [v2 objectEnumerator];
	Library_Copy* v4;
	while ((v4 = [v1_enum nextObject]) != nil) {
		Library_Copy* v10 = v4;
		OCLString* v9 = [v10 _copyId];
		OCLString* v11 = [(OCLString*)[OCLString alloc] initWithString:@" "];
		OCLString* v8 = [v9 concat:v11];
		Library_Copy* v13 = v4;
		OCLString* v12 = [v13 _state];
		OCLString* v7 = [v8 concat:v12];
		OCLString* v14 = [(OCLString*)[OCLString alloc] initWithString:@" "];
		OCLString* v6 = [v7 concat:v14];
		Library_Copy* v16 = v4;
		OCLString* v15 = [v16 _dueDate];
		OCLString* v5 = [v6 concat:v15];
		[v1_nested add: v5];
		[v8 release];
		[v7 release];
		[v6 release];
		[v11 release];
		[v14 release];
		[v5 release];
	}
	OCLBag* v1 = [v1_nested flatten];
	[v1_nested release];
	OCLSequence* v0 = [v1 asSequence];
	;
	return v0;
}
-(OCLString*) getAuthorsData:p_book {
	/* ==================================================
	 * book.authors->iterate(a : Library::Author; authorStr : String = '' | authorStr.concat(a.name).concat(', '))
	 * ================================================== */
	
	Library_Book* v2 = p_book;
	OCLSet* v1 = [v2 _authors];
	OCLString* v5 = [(OCLString*)[OCLString alloc] initWithString:@""];
	OCLString* v4 = v5;
	NSEnumerator* v0_enum = [v1 objectEnumerator];
	Library_Author* v3;
	while ((v3 = [v0_enum nextObject]) != nil) {
		OCLString* v8 = v4;
		Library_Author* v10 = v3;
		OCLString* v9 = [v10 _name];
		OCLString* v7 = [v8 concat:v9];
		OCLString* v11 = [(OCLString*)[OCLString alloc] initWithString:@", "];
		OCLString* v6 = [v7 concat:v11];
		v4 = v6;
		[v7 release];
		[v11 release];
	}
	OCLString* v0 = v4;
	;
	return v0;
}


@end 


