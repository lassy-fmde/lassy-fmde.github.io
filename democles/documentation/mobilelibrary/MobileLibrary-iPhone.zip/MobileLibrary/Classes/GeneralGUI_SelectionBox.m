 
 
 
#import "GeneralGUI_SelectionBox.h"
#import "PropertyChangeList.h"
#import "MobileLibraryGUI_SearchController.h"


 
@implementation GeneralGUI_SelectionBox

 
-(void)triggerRowSelectedEvent:(OCLInteger*)rowNr {
	NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
	[self event_rowSelected_pushed: NULL p_id:rowNr];
	[pool release];
}

-(void)create_binding {
	self->binding = [[UIPickerView alloc] init];
	[self->binding retain];
	self->binding.delegate = self;
	self->binding.dataSource = self;
}

- (id) init {
	self = [super init];
	 
	[self performSelectorOnMainThread:@selector(create_binding) withObject:nil waitUntilDone:YES]; 	

	 
	self->MobileLibraryGUI_SearchController_categorySelect_back = [[NSMutableArray alloc] init];

	[self set_choices: [self _choices]];
	[self set_selectedChoice: [self _selectedChoice]];


	 
	// Default row selected by picker
	OCLInteger* rowOCL = [[OCLInteger alloc] init];
	[rowOCL initWithValue:1];
	[self performSelectorInBackground:@selector(triggerRowSelectedEvent:) withObject:rowOCL];

	return self;
}

 
- (id) initWithValues: (OCLTuple*) values {
	self = [super init];
	 
	[self performSelectorOnMainThread:@selector(create_binding) withObject:nil waitUntilDone:YES]; 	

	 
	self->_choices_initialized = NO;
	self->_selectedChoice_initialized = NO;

	self->MobileLibraryGUI_SearchController_categorySelect_back = [[NSMutableArray alloc] init];

	OCLSequence* _choices_initialValue = (OCLSequence*) [values objectForKey:@"choices"];
	if (_choices_initialValue == nil) {
		_choices_initialValue = [self _choices];
	}
	[self set_choices:_choices_initialValue];
	OCLString* _selectedChoice_initialValue = (OCLString*) [values objectForKey:@"selectedChoice"];
	if (_selectedChoice_initialValue == nil) {
		_selectedChoice_initialValue = [self _selectedChoice];
	}
	[self set_selectedChoice:_selectedChoice_initialValue];


	 
	// Default row selected by picker
	OCLInteger* rowOCL = [[OCLInteger alloc] init];
	[rowOCL initWithValue:1];
	[self performSelectorInBackground:@selector(triggerRowSelectedEvent:) withObject:rowOCL];

	return self;
}

 
- (void) dealloc {
	if (self->_choices != nil && self->_choices != (OCLSequence*) [NSNull null]) [self->_choices release];
	if (self->_selectedChoice != nil && self->_selectedChoice != (OCLString*) [NSNull null]) [self->_selectedChoice release];

	[self->MobileLibraryGUI_SearchController_categorySelect_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"GeneralGUI::SelectionBox\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"choices\" type=\"Sequence\">\n"];
	[res appendFormat:@"%@\n", [self _choices]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"selectedChoice\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _selectedChoice]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
-(OCLSequence*) initial_choices {
	/* ==================================================
	 * Sequence{}
	 * ================================================== */
	
	OCLSequence* v0 = [(OCLSequence*)[OCLSequence alloc] init];
	
	return v0;
}

-(OCLSequence*) _choices {
	if (self->_choices_initialized == YES) {
		return _choices;
	} else { 
		[self set_choices:[self initial_choices]];
	}

	self->_choices_initialized = YES;
	return _choices;
}
-(OCLString*) initial_selectedChoice {
	/* ==================================================
	 * ''
	 * ================================================== */
	
	OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@""];
	
	return v0;
}

-(OCLString*) _selectedChoice {
	if (self->_selectedChoice_initialized == YES) {
		return _selectedChoice;
	} else { 
		[self set_selectedChoice:[self initial_selectedChoice]];
	}

	self->_selectedChoice_initialized = YES;
	return _selectedChoice;
}


 
-(void) set_choices:(OCLSequence*) value {
	 	if (self->_choices!= nil && self->_choices!= (OCLSequence*) [NSNull null]) {
		[self->_choices release];
	}
	self->_choices = value;
	if (self->_choices!= nil && self->_choices!= (OCLSequence*) [NSNull null]) {
		[self->_choices retain];
	}
	self->_choices_initialized = YES;
	
	[self onPropertyChange:@"choices" newValue:value];
}
-(void) set_selectedChoice:(OCLString*) value {
	 	if (self->_selectedChoice!= nil && self->_selectedChoice!= (OCLString*) [NSNull null]) {
		[self->_selectedChoice release];
	}
	self->_selectedChoice = value;
	if (self->_selectedChoice!= nil && self->_selectedChoice!= (OCLString*) [NSNull null]) {
		[self->_selectedChoice retain];
	}
	self->_selectedChoice_initialized = YES;
	
	[self onPropertyChange:@"selectedChoice" newValue:value];
}






 

 
-(void) event_rowSelected_pushed:(PropertyChangeList*) changes  p_id: (OCLInteger*) p_id{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_rowSelected", @"GeneralGUI_SelectionBox");

		OCLTuple* parameters = [[OCLTuple alloc] init];
		[parameters addItemNamed:@"id" withValue:p_id]; 

		[self onEvent:@"rowSelected" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * choices->at(id)
		 * ================================================== */
		
		GeneralGUI_SelectionBox* v2 = self;
		OCLSequence* v1 = [v2 _choices];
		OCLInteger* v3 = p_id;
		OCLString* v0 = ((OCLString*)[v1 at:v3]);
		
		OCLString* _selectedChoice_newValue = v0;
		[changes addChange:@selector(set_selectedChoice:) instance:self value:_selectedChoice_newValue];


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 




 
-(void)onPropertyChange_async:(NSDictionary*)parameters {
	NSString* propertyName = [parameters objectForKey:@"propertyName"];
	id value = [parameters objectForKey:@"value"];

	if ([propertyName isEqual:@"choices"]){ 
		[self->binding reloadAllComponents];
	}
	[parameters release];	
}

-(void)onPropertyChange:(NSString*)propertyName newValue:(id) value {
	NSMutableDictionary* parameters = [[NSMutableDictionary alloc] init];
	[parameters setValue:propertyName forKey:@"propertyName"];
	[parameters setValue:value forKey:@"value"];
	[parameters retain];
	[self performSelectorOnMainThread:@selector(onPropertyChange_async:) withObject:parameters waitUntilDone:NO];
}

 
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters{
}

 
-(id) getBinding {
	return self->binding;
}

 
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value {
}

 
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
	return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
	OCLInteger* size = [[self _choices] size];
	return size->value;
}

 
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
	OCLInteger* rowOCL = [[OCLInteger alloc] init];
	[rowOCL initWithValue:row+1];
	OCLString* text = (OCLString*) [[self _choices] at: rowOCL];
	return text->string;
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
	OCLInteger* rowOCL = [[OCLInteger alloc] init];
	[rowOCL initWithValue:row+1];
	[self performSelectorInBackground:@selector(triggerRowSelectedEvent:) withObject:rowOCL];
}


@end 


