#import <Foundation/Foundation.h>
#import <Foundation/NSObjCRuntime.h>
#import "OCLAny.h"
#import "OCLBoolean.h"

@implementation OCLAny

-(OCLBoolean*)eq:(OCLAny*)other {
	return [(OCLBoolean*)[OCLBoolean alloc] initWithValue:[self isEqual:other]];
}

-(OCLBoolean*)neq:(OCLAny*)other {
	OCLBoolean* res = [self eq:other];
	
	res->value = !res->value;
	
	return res;
}

/*-(OCLBoolean*)oclIsUndefined {
	// implemented in AST visitor (as comparison with NSNull)
	return NULL;
}*/

/*-(OCLBoolean*)oclIsInvalid {
	// implemented in AST visitor (as comparison with NSNull)
	// TODO should compare against other value because OclInvalid != null
	return NULL;
}*/

/*-(id<NSObject>)oclAsType(Class) {
	// implemented in AST visitor as cast
	return nil;
}*/

-(OCLBoolean*)oclIsTypeOf:(Class)type {
	return [(OCLBoolean*)[OCLBoolean alloc] initWithValue:[self isMemberOfClass:[type class]]];
}

-(OCLBoolean*)oclIsKindOfClass:(Class)type {
	// TODO have AST visitor generate call to this method if oclIsKindOf() is called with EP or OCL class parameter
	BOOL inherits = [self isKindOfClass:[type class]];
	return [(OCLBoolean*)[OCLBoolean alloc] initWithValue:inherits];
}

// TODO this is for GNUstep, must probably ifdef a MacOS version
-(OCLBoolean*)oclIsKindOfInterface:(NSString*)protocolName {
	// TODO have AST visitor generate call to this method if oclIsKindOf() is called with EP interface parameter

	Protocol* protocol = NSProtocolFromString(protocolName); // MacOS uses objc_getProtocol((const char*)protocolName) (?)
	BOOL implements = NO;
	
	if (protocol != NULL) {
		implements = [self conformsToProtocol:protocol];
	}
	 
	return [(OCLBoolean*)[OCLBoolean alloc] initWithValue:implements];
}


-(BOOL)isEqual:(id)other {
	// By default, delegate to super implementation. OCL standard library
	// types override this method to provide value semantics.
	return [super isEqual:other];
}


-(BOOL)isCompatibleType:(OCLAny*)other {
	BOOL res = NO;
	if (other != NULL) {
		OCLBoolean* typeComp = [other oclIsKindOfClass:[self class]];
		res = typeComp->value;
		[typeComp release];
	}
	return res;
}

-(NSString*)description {
	[self doesNotRecognizeSelector:_cmd];
	return nil;
}

@end

@implementation NSNull (NullDescription)
-(NSString*)description {
	return [NSString stringWithString:@"<Null/>"];
}
@end
