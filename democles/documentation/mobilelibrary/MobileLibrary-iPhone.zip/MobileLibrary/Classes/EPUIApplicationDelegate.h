#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@class Application_Main;

@interface EPUIApplicationDelegate : NSObject <UIApplicationDelegate> {
//    UIWindow* window;
//    UIViewController* rootController;
    Application_Main* mainInstance;
}

-(EPUIApplicationDelegate*)init;
-(BOOL)application:(UIApplication*)application didFinishLaunchingWithOptions:(NSDictionary*)launchOptions;

@end
