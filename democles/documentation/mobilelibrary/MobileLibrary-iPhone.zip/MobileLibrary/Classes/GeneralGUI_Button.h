 
 
 
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "OCLTypes.h"
#import "IBinding.h"

@class PropertyChangeList;
@class MobileLibraryGUI_SearchController;
@class MobileLibraryGUI_LoginController;


 
 
@interface GeneralGUI_Button : OCLAny <IBinding>
{
	 
	OCLString* _text;
	BOOL _text_initialized;


@public
	NSMutableArray *MobileLibraryGUI_SearchController_searchButton_back;
	NSMutableArray *MobileLibraryGUI_LoginController_loginButton_back;


	
	@protected
	UIButton* binding;
}

 
-(GeneralGUI_Button*)init;
-(GeneralGUI_Button*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(OCLString*) _text;
-(OCLString*) initial_text;
-(void) set_text:(OCLString*) value;

-(void) event_clicked_pushed:(PropertyChangeList*) changes ;

 
-(id) getBinding;
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value;
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters;
-(void) onPropertyChange: (NSString*)propertyName newValue:(id<OCLAny>)value;


@end


