 
 
 
#import <Foundation/Foundation.h>
#import "OCLTypes.h"

@class PropertyChangeList;
@class Library_Library;
@class Library_Author;
@class Library_Member;
@class Library_Book;
@class Library_Copy;
@class Application_Main;


 
 
@interface Library_Library : OCLAny  
 {
	 
	OCLSet* _catalogue;
	BOOL _catalogue_initialized;
	OCLSet* _members;
	BOOL _members_initialized;


@public
	NSMutableArray *Application_Main_library_back;


}

 
-(Library_Library*)init;
-(Library_Library*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(OCLSet*) _catalogue;
-(OCLSet*) initial_catalogue;
-(void) set_catalogue:(OCLSet*) value;
-(OCLSet*) _members;
-(OCLSet*) initial_members;
-(void) set_members:(OCLSet*) value;

-(void) event_searchBook_pushed:(PropertyChangeList*) changes p_term: (OCLString*) p_term p_category: (OCLString*) p_category;
-(void) event_booksFound_pushed:(PropertyChangeList*) changes p_foundBooks: (OCLSet*) p_foundBooks;
-(void) event_authenticate_pushed:(PropertyChangeList*) changes p_libNo: (OCLString*) p_libNo p_pw: (OCLString*) p_pw;
-(void) event_loginOk_pushed:(PropertyChangeList*) changes p_member: (Library_Member*) p_member;
-(void) event_loginFailed_pushed:(PropertyChangeList*) changes ;


@end


