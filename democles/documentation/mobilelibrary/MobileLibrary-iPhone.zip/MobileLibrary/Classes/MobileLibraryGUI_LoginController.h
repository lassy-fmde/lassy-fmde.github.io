 
 
 
#import <Foundation/Foundation.h>
#import "OCLTypes.h"

@class PropertyChangeList;
@class GeneralGUI_MsgDialog;
@class MobileLibraryGUI_LoginController;
@class GeneralGUI_Textfield;
@class GeneralGUI_Frame;
@class GeneralGUI_Button;
@class GeneralGUI_Label;
@class Application_Main;


 
 
@interface MobileLibraryGUI_LoginController : OCLAny  
 {
	 
	GeneralGUI_Label* _libraryNoLabel;
	BOOL _libraryNoLabel_initialized;
	GeneralGUI_Textfield* _libraryNoField;
	BOOL _libraryNoField_initialized;
	GeneralGUI_Label* _passwordLabel;
	BOOL _passwordLabel_initialized;
	GeneralGUI_Textfield* _passwordField;
	BOOL _passwordField_initialized;
	GeneralGUI_Button* _loginButton;
	BOOL _loginButton_initialized;
	OCLString* _title;
	BOOL _title_initialized;
	GeneralGUI_Frame* _frame;
	BOOL _frame_initialized;
	GeneralGUI_MsgDialog* _currMsg;
	BOOL _currMsg_initialized;
	OCLString* _ackStatus;
	BOOL _ackStatus_initialized;


@public
	NSMutableArray *Application_Main_loginControl_back;


}

 
-(MobileLibraryGUI_LoginController*)init;
-(MobileLibraryGUI_LoginController*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(GeneralGUI_Label*) _libraryNoLabel;
-(GeneralGUI_Label*) initial_libraryNoLabel;
-(void) set_libraryNoLabel:(GeneralGUI_Label*) value;
-(GeneralGUI_Textfield*) _libraryNoField;
-(GeneralGUI_Textfield*) initial_libraryNoField;
-(void) set_libraryNoField:(GeneralGUI_Textfield*) value;
-(GeneralGUI_Label*) _passwordLabel;
-(GeneralGUI_Label*) initial_passwordLabel;
-(void) set_passwordLabel:(GeneralGUI_Label*) value;
-(GeneralGUI_Textfield*) _passwordField;
-(GeneralGUI_Textfield*) initial_passwordField;
-(void) set_passwordField:(GeneralGUI_Textfield*) value;
-(GeneralGUI_Button*) _loginButton;
-(GeneralGUI_Button*) initial_loginButton;
-(void) set_loginButton:(GeneralGUI_Button*) value;
-(OCLString*) _title;
-(OCLString*) initial_title;
-(void) set_title:(OCLString*) value;
-(GeneralGUI_Frame*) _frame;
-(GeneralGUI_Frame*) initial_frame;
-(void) set_frame:(GeneralGUI_Frame*) value;
-(GeneralGUI_MsgDialog*) _currMsg;
-(GeneralGUI_MsgDialog*) initial_currMsg;
-(void) set_currMsg:(GeneralGUI_MsgDialog*) value;
-(OCLString*) _ackStatus;
-(OCLString*) initial_ackStatus;
-(void) set_ackStatus:(OCLString*) value;

-(void) event_authenticate_pushed:(PropertyChangeList*) changes p_libNo: (OCLString*) p_libNo p_password: (OCLString*) p_password;
-(void) event_authenticate_pulled_edge0:(PropertyChangeList*)changes parentInstance:(GeneralGUI_Button*)parentInstance ;
-(void) event_loginOk_pushed:(PropertyChangeList*) changes ;
-(void) event_showLoginSucessfulMsg_pushed:(PropertyChangeList*) changes ;
-(void) event_showInvalidLoginMsg_pushed:(PropertyChangeList*) changes ;
-(void) event_setToNotWaiting_pushed:(PropertyChangeList*) changes ;
-(void) event_loginFailed_pushed:(PropertyChangeList*) changes ;
-(void) event_loginAck_pushed:(PropertyChangeList*) changes ;
-(void) event_loginAck_pulled_edge0:(PropertyChangeList*)changes parentInstance:(GeneralGUI_MsgDialog*)parentInstance ;
-(void) event_loginConfirmed_pushed:(PropertyChangeList*) changes ;


@end


