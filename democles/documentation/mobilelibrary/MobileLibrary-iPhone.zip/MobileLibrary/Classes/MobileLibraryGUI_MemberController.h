 
 
 
#import <Foundation/Foundation.h>
#import "OCLTypes.h"

@class PropertyChangeList;
@class GeneralGUI_MsgDialog;
@class DateProcessing_DateHandler;
@class GeneralGUI_ConfirmationDialog;
@class MobileLibraryGUI_MemberController;
@class Library_Member;
@class GeneralGUI_SelectionList;
@class GeneralGUI_Frame;
@class Library_Copy;
@class GeneralGUI_Label;
@class Application_Main;


 
 
@interface MobileLibraryGUI_MemberController : OCLAny  
 {
	 
	OCLString* _title;
	BOOL _title_initialized;
	GeneralGUI_Label* _memberNameLabel;
	BOOL _memberNameLabel_initialized;
	GeneralGUI_Label* _memberLabel;
	BOOL _memberLabel_initialized;
	GeneralGUI_SelectionList* _borrowItems;
	BOOL _borrowItems_initialized;
	GeneralGUI_SelectionList* _collectItems;
	BOOL _collectItems_initialized;
	GeneralGUI_Label* _borrowedItemsLabel;
	BOOL _borrowedItemsLabel_initialized;
	GeneralGUI_Label* _itemsToCollectLabel;
	BOOL _itemsToCollectLabel_initialized;
	GeneralGUI_Frame* _window;
	BOOL _window_initialized;
	Library_Copy* _selectedBorrowing;
	BOOL _selectedBorrowing_initialized;
	Library_Member* _currMember;
	BOOL _currMember_initialized;
	GeneralGUI_ConfirmationDialog* _yesNoMsg;
	BOOL _yesNoMsg_initialized;
	DateProcessing_DateHandler* _dateHandler;
	BOOL _dateHandler_initialized;
	GeneralGUI_MsgDialog* _currMsg;
	BOOL _currMsg_initialized;
	OCLString* _ackStatus;
	BOOL _ackStatus_initialized;


@public
	NSMutableArray *Application_Main_memberControl_back;


}

 
-(MobileLibraryGUI_MemberController*)init;
-(MobileLibraryGUI_MemberController*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(OCLString*) _title;
-(OCLString*) initial_title;
-(void) set_title:(OCLString*) value;
-(GeneralGUI_Label*) _memberNameLabel;
-(GeneralGUI_Label*) initial_memberNameLabel;
-(void) set_memberNameLabel:(GeneralGUI_Label*) value;
-(GeneralGUI_Label*) _memberLabel;
-(GeneralGUI_Label*) initial_memberLabel;
-(void) set_memberLabel:(GeneralGUI_Label*) value;
-(GeneralGUI_SelectionList*) _borrowItems;
-(GeneralGUI_SelectionList*) initial_borrowItems;
-(void) set_borrowItems:(GeneralGUI_SelectionList*) value;
-(GeneralGUI_SelectionList*) _collectItems;
-(GeneralGUI_SelectionList*) initial_collectItems;
-(void) set_collectItems:(GeneralGUI_SelectionList*) value;
-(GeneralGUI_Label*) _borrowedItemsLabel;
-(GeneralGUI_Label*) initial_borrowedItemsLabel;
-(void) set_borrowedItemsLabel:(GeneralGUI_Label*) value;
-(GeneralGUI_Label*) _itemsToCollectLabel;
-(GeneralGUI_Label*) initial_itemsToCollectLabel;
-(void) set_itemsToCollectLabel:(GeneralGUI_Label*) value;
-(GeneralGUI_Frame*) _window;
-(GeneralGUI_Frame*) initial_window;
-(void) set_window:(GeneralGUI_Frame*) value;
-(Library_Copy*) _selectedBorrowing;
-(Library_Copy*) initial_selectedBorrowing;
-(void) set_selectedBorrowing:(Library_Copy*) value;
-(Library_Member*) _currMember;
-(Library_Member*) initial_currMember;
-(void) set_currMember:(Library_Member*) value;
-(GeneralGUI_ConfirmationDialog*) _yesNoMsg;
-(GeneralGUI_ConfirmationDialog*) initial_yesNoMsg;
-(void) set_yesNoMsg:(GeneralGUI_ConfirmationDialog*) value;
-(DateProcessing_DateHandler*) _dateHandler;
-(DateProcessing_DateHandler*) initial_dateHandler;
-(void) set_dateHandler:(DateProcessing_DateHandler*) value;
-(GeneralGUI_MsgDialog*) _currMsg;
-(GeneralGUI_MsgDialog*) initial_currMsg;
-(void) set_currMsg:(GeneralGUI_MsgDialog*) value;
-(OCLString*) _ackStatus;
-(OCLString*) initial_ackStatus;
-(void) set_ackStatus:(OCLString*) value;

-(void) event_borrowItemSelected_pushed:(PropertyChangeList*) changes p_index: (OCLInteger*) p_index;
-(void) event_borrowItemSelected_pulled_edge0:(PropertyChangeList*)changes parentInstance:(GeneralGUI_SelectionList*)parentInstance p_index:(OCLInteger*)p_index ;
-(void) event_refreshData_pushed:(PropertyChangeList*) changes ;
-(void) event_sessionStarted_pushed:(PropertyChangeList*) changes p_m: (Library_Member*) p_m;
-(void) event_showConfirmRenewMsg_pushed:(PropertyChangeList*) changes ;
-(void) event_renewConfAck_pushed:(PropertyChangeList*) changes ;
-(void) event_renewConfAck_pulled_edge0:(PropertyChangeList*)changes parentInstance:(GeneralGUI_ConfirmationDialog*)parentInstance ;
-(void) event_renewBorrowing_pushed:(PropertyChangeList*) changes ;
-(void) event_copyRenewed_pushed:(PropertyChangeList*) changes ;
-(void) event_copyRenewed_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Library_Copy*)parentInstance p_newDueDate:(OCLString*)p_newDueDate ;
-(void) event_showRenewOkMsg_pushed:(PropertyChangeList*) changes ;
-(void) event_renewAck_pushed:(PropertyChangeList*) changes ;
-(void) event_renewAck_pulled_edge0:(PropertyChangeList*)changes parentInstance:(GeneralGUI_MsgDialog*)parentInstance ;
-(void) event_saveData_pushed:(PropertyChangeList*) changes ;
-(void) event_renewFailed_pushed:(PropertyChangeList*) changes ;
-(void) event_renewFailed_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Library_Copy*)parentInstance p_copy:(Library_Copy*)p_copy ;
-(void) event_showRenewFailedMsg_pushed:(PropertyChangeList*) changes ;
-(void) event_setToNotWaiting_pushed:(PropertyChangeList*) changes ;


@end


