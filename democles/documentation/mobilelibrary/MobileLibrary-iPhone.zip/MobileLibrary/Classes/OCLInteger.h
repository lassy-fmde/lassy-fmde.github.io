#import <Foundation/Foundation.h>
#import "OCLAny.h"

@class OCLBoolean;
@class OCLReal;

@interface OCLInteger : OCLAny {
	@public
	int value;
}

-(int)value;

// OCLAny methods

-(OCLInteger*)initWithValue:(int)value;

// Integer methods
-(OCLInteger*)plus:(OCLInteger*)other;
-(OCLInteger*)minus:(OCLInteger*)other;
-(OCLInteger*)mult:(OCLInteger*)other;
-(OCLInteger*)neg;
-(OCLReal*)div:(OCLInteger*)other;
-(OCLInteger*)idiv:(OCLInteger*)other;
-(OCLInteger*)mod:(OCLInteger*)other;
-(OCLInteger*)abs;
-(OCLInteger*)max:(OCLInteger*)other;
-(OCLInteger*)min:(OCLInteger*)other;
-(OCLBoolean*)lt:(OCLInteger*)other;
-(OCLBoolean*)gt:(OCLInteger*)other;
-(OCLBoolean*)lte:(OCLInteger*)other;
-(OCLBoolean*)gte:(OCLInteger*)other;

// NSObject methods
-(NSString*)description;
-(NSUInteger)hash;
-(BOOL)isEqual:(id)other;

@end
