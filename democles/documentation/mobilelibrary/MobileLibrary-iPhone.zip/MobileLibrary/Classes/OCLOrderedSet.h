#import <Foundation/Foundation.h>
#import "OCLCollection.h"
#import "OCLSet.h"

@class OCLAny;
@class OCLInteger;
@class OCLBoolean;

@interface OCLOrderedSet : OCLSet {
	@public
	NSMutableArray* array;
}

-(OCLOrderedSet*)init;
-(void)dealloc;

// OCLCollection abstract methods
-(OCLOrderedSet*)newCollection;
-(void)add:(OCLAny*)object;	
-(OCLInteger*)size;
-(OCLBoolean*)includes:(OCLAny*)object;
-(NSEnumerator*)objectEnumerator;
-(NSString*)collectionName;

// Set methods
-(OCLSet*)unionWithSet:(OCLSet*)other;
//-(OCLBag*)unionWithBag:(OCLBag*)other;			// base impl. works
//-(OCLSet*)intersectionWithSet:(OCLSet*)other;	// base impl. works
//-(OCLSet*)intersectionWithBag:(OCLBag*)other;	// base impl. works
//-(OCLSet*)n:(OCLSet*)other;						// base impl. works
-(OCLSet*)including:(OCLAny*)object;
-(OCLSet*)excluding:(OCLAny*)object;
-(OCLSet*)symmetricDifference:(OCLSet*)other;
-(OCLSet*)flatten;

// OrderedSet methods
-(OCLOrderedSet*)append:(OCLAny*)object;
-(OCLOrderedSet*)prepend:(OCLAny*)object;
-(OCLOrderedSet*)insertAt:(OCLInteger*)index object:(OCLAny*)object;
-(OCLOrderedSet*)subOrderedSet:(OCLInteger*)lower upper:(OCLInteger*)upper;
-(OCLAny*)at:(OCLInteger*)index;
-(OCLInteger*)indexOf:(OCLAny*)object;
-(OCLAny*)first;
-(OCLAny*)last;

// NSObject methods
-(BOOL)isEqual:(id)other;

@end
