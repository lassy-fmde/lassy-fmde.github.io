 
 
 
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "OCLTypes.h"
#import "IBinding.h"

@class PropertyChangeList;
@class MobileLibraryGUI_MemberController;


 
 
@interface DateProcessing_DateHandler : OCLAny <IBinding>
{
	 


@public
	NSMutableArray *MobileLibraryGUI_MemberController_dateHandler_back;


}

 
-(DateProcessing_DateHandler*)init;
-(DateProcessing_DateHandler*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;



 
-(id) getBinding;
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value;
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters;
-(void) onPropertyChange: (NSString*)propertyName newValue:(id<OCLAny>)value;


@end


