 
 
 
#import "GeneralGUI_MsgDialog.h"
#import "PropertyChangeList.h"
#import "GeneralGUI_MsgDialog.h"
#import "MobileLibraryGUI_LoginController.h"
#import "MobileLibraryGUI_BookDetailController.h"
#import "MobileLibraryGUI_MemberController.h"


 
@implementation GeneralGUI_MsgDialog

 
-(void)create_binding {
	self->binding = [[UIAlertView alloc] initWithTitle:_viewTitle->string message:_msg->string delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
	[self->binding retain];
	[self->binding show]; 
}

- (id) init {
	self = [super init];
	 
	self->MobileLibraryGUI_LoginController_currMsg_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_BookDetailController_msg_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_MemberController_currMsg_back = [[NSMutableArray alloc] init];

	[self set_msg: [self _msg]];
	[self set_viewTitle: [self _viewTitle]];


	 
	[self performSelectorOnMainThread:@selector(create_binding) withObject:nil waitUntilDone:YES]; 	

	return self;
}

 
- (id) initWithValues: (OCLTuple*) values {
	self = [super init];
	 
	self->_msg_initialized = NO;
	self->_viewTitle_initialized = NO;

	self->MobileLibraryGUI_LoginController_currMsg_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_BookDetailController_msg_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_MemberController_currMsg_back = [[NSMutableArray alloc] init];

	OCLString* _msg_initialValue = (OCLString*) [values objectForKey:@"msg"];
	if (_msg_initialValue == nil) {
		_msg_initialValue = [self _msg];
	}
	[self set_msg:_msg_initialValue];
	OCLString* _viewTitle_initialValue = (OCLString*) [values objectForKey:@"viewTitle"];
	if (_viewTitle_initialValue == nil) {
		_viewTitle_initialValue = [self _viewTitle];
	}
	[self set_viewTitle:_viewTitle_initialValue];


	 
	[self performSelectorOnMainThread:@selector(create_binding) withObject:nil waitUntilDone:YES]; 	

	return self;
}

 
- (void) dealloc {
	if (self->_msg != nil && self->_msg != (OCLString*) [NSNull null]) [self->_msg release];
	if (self->_viewTitle != nil && self->_viewTitle != (OCLString*) [NSNull null]) [self->_viewTitle release];

	[self->MobileLibraryGUI_LoginController_currMsg_back release];
	[self->MobileLibraryGUI_BookDetailController_msg_back release];
	[self->MobileLibraryGUI_MemberController_currMsg_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"GeneralGUI::MsgDialog\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"msg\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _msg]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"viewTitle\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _viewTitle]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}


-(void)triggerClosedEvent {
	NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
	[self event_okClicked_pushed:nil];
	[pool release];
}
 
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
	[self performSelectorInBackground:@selector(triggerClosedEvent) withObject:nil];
}

 
-(OCLString*) initial_msg {
	/* ==================================================
	 * ''
	 * ================================================== */
	
	OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@""];
	
	return v0;
}

-(OCLString*) _msg {
	if (self->_msg_initialized == YES) {
		return _msg;
	} else { 
		[self set_msg:[self initial_msg]];
	}

	self->_msg_initialized = YES;
	return _msg;
}
-(OCLString*) initial_viewTitle {
	/* ==================================================
	 * ''
	 * ================================================== */
	
	OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@""];
	
	return v0;
}

-(OCLString*) _viewTitle {
	if (self->_viewTitle_initialized == YES) {
		return _viewTitle;
	} else { 
		[self set_viewTitle:[self initial_viewTitle]];
	}

	self->_viewTitle_initialized = YES;
	return _viewTitle;
}


 
-(void) set_msg:(OCLString*) value {
	 	if (self->_msg!= nil && self->_msg!= (OCLString*) [NSNull null]) {
		[self->_msg release];
	}
	self->_msg = value;
	if (self->_msg!= nil && self->_msg!= (OCLString*) [NSNull null]) {
		[self->_msg retain];
	}
	self->_msg_initialized = YES;
	
	[self onPropertyChange:@"msg" newValue:value];
}
-(void) set_viewTitle:(OCLString*) value {
	 	if (self->_viewTitle!= nil && self->_viewTitle!= (OCLString*) [NSNull null]) {
		[self->_viewTitle release];
	}
	self->_viewTitle = value;
	if (self->_viewTitle!= nil && self->_viewTitle!= (OCLString*) [NSNull null]) {
		[self->_viewTitle retain];
	}
	self->_viewTitle_initialized = YES;
	
	[self onPropertyChange:@"viewTitle" newValue:value];
}






 

 
-(void) event_okClicked_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_okClicked", @"GeneralGUI_MsgDialog");

		OCLTuple* parameters = [[OCLTuple alloc] init];

		[self onEvent:@"okClicked" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges
		NSEnumerator* MobileLibraryGUI_LoginController_loginAck_edge0_enum = [self->MobileLibraryGUI_LoginController_currMsg_back objectEnumerator];
		MobileLibraryGUI_LoginController* MobileLibraryGUI_LoginController_loginAck_edge0_target;
		while ((MobileLibraryGUI_LoginController_loginAck_edge0_target = [MobileLibraryGUI_LoginController_loginAck_edge0_enum nextObject]) != nil) {
		    [MobileLibraryGUI_LoginController_loginAck_edge0_target event_loginAck_pulled_edge0:changes parentInstance:self ];
		}

		NSEnumerator* MobileLibraryGUI_BookDetailController_reserveAck_edge0_enum = [self->MobileLibraryGUI_BookDetailController_msg_back objectEnumerator];
		MobileLibraryGUI_BookDetailController* MobileLibraryGUI_BookDetailController_reserveAck_edge0_target;
		while ((MobileLibraryGUI_BookDetailController_reserveAck_edge0_target = [MobileLibraryGUI_BookDetailController_reserveAck_edge0_enum nextObject]) != nil) {
		    [MobileLibraryGUI_BookDetailController_reserveAck_edge0_target event_reserveAck_pulled_edge0:changes parentInstance:self ];
		}

		NSEnumerator* MobileLibraryGUI_MemberController_renewAck_edge0_enum = [self->MobileLibraryGUI_MemberController_currMsg_back objectEnumerator];
		MobileLibraryGUI_MemberController* MobileLibraryGUI_MemberController_renewAck_edge0_target;
		while ((MobileLibraryGUI_MemberController_renewAck_edge0_target = [MobileLibraryGUI_MemberController_renewAck_edge0_enum nextObject]) != nil) {
		    [MobileLibraryGUI_MemberController_renewAck_edge0_target event_renewAck_pulled_edge0:changes parentInstance:self ];
		}



		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {

			[self event_close_pushed:changes ];
		}
		[v0 release];


		 
		 // Process impacts relationships


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_close_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_close", @"GeneralGUI_MsgDialog");

		OCLTuple* parameters = [[OCLTuple alloc] init];

		[self onEvent:@"close" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 




 
-(void)onPropertyChange:(NSString*)propertyName newValue:(id) value {
}

 
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters{
}

 
-(id) getBinding {
	return self->binding;
}

 
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value {
}


@end 


