 
 
 
#import "Library_Member.h"
#import "PropertyChangeList.h"
#import "Library_Copy.h"
#import "LibraryPersistence_LibraryLoader.h"
#import "MobileLibraryGUI_SearchController.h"
#import "MobileLibraryGUI_MemberController.h"
#import "MobileLibraryGUI_BookDetailController.h"
#import "MobileLibraryGUI_SearchResultsController.h"
#import "Library_Library.h"


 
@implementation Library_Member

 
- (Library_Member*) init {
	self = [super init];
	 
	self->LibraryPersistence_LibraryLoader_members_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_SearchController_currMember_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_MemberController_currMember_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_BookDetailController_currMember_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_SearchResultsController_currMember_back = [[NSMutableArray alloc] init];
	self->Library_Library_members_back = [[NSMutableArray alloc] init];

	[self set_libraryNo: [self _libraryNo]];
	[self set_name: [self _name]];
	[self set_borrows: [self _borrows]];
	[self set_toCollect: [self _toCollect]];
	[self set_password: [self _password]];

	return self;
}

 
- (Library_Member*) initWithValues: (OCLTuple*) values {
	self = [super init];
	 
	self->_libraryNo_initialized = NO;
	self->_name_initialized = NO;
	self->_borrows_initialized = NO;
	self->_toCollect_initialized = NO;
	self->_password_initialized = NO;

	self->LibraryPersistence_LibraryLoader_members_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_SearchController_currMember_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_MemberController_currMember_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_BookDetailController_currMember_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_SearchResultsController_currMember_back = [[NSMutableArray alloc] init];
	self->Library_Library_members_back = [[NSMutableArray alloc] init];

	OCLString* _libraryNo_initialValue = (OCLString*) [values objectForKey:@"libraryNo"];
	if (_libraryNo_initialValue == nil) {
		_libraryNo_initialValue = [self _libraryNo];
	}
	[self set_libraryNo:_libraryNo_initialValue];
	OCLString* _name_initialValue = (OCLString*) [values objectForKey:@"name"];
	if (_name_initialValue == nil) {
		_name_initialValue = [self _name];
	}
	[self set_name:_name_initialValue];
	OCLSet* _borrows_initialValue = (OCLSet*) [values objectForKey:@"borrows"];
	if (_borrows_initialValue == nil) {
		_borrows_initialValue = [self _borrows];
	}
	[self set_borrows:_borrows_initialValue];
	OCLSet* _toCollect_initialValue = (OCLSet*) [values objectForKey:@"toCollect"];
	if (_toCollect_initialValue == nil) {
		_toCollect_initialValue = [self _toCollect];
	}
	[self set_toCollect:_toCollect_initialValue];
	OCLString* _password_initialValue = (OCLString*) [values objectForKey:@"password"];
	if (_password_initialValue == nil) {
		_password_initialValue = [self _password];
	}
	[self set_password:_password_initialValue];

	
	return self;
}

 
- (void) dealloc {
	if (self->_libraryNo != nil && self->_libraryNo != (OCLString*) [NSNull null]) [self->_libraryNo release];
	if (self->_name != nil && self->_name != (OCLString*) [NSNull null]) [self->_name release];
	if (self->_borrows != nil && self->_borrows != (OCLSet*) [NSNull null]) [self->_borrows release];
	if (self->_toCollect != nil && self->_toCollect != (OCLSet*) [NSNull null]) [self->_toCollect release];
	if (self->_password != nil && self->_password != (OCLString*) [NSNull null]) [self->_password release];

	[self->LibraryPersistence_LibraryLoader_members_back release];
	[self->MobileLibraryGUI_SearchController_currMember_back release];
	[self->MobileLibraryGUI_MemberController_currMember_back release];
	[self->MobileLibraryGUI_BookDetailController_currMember_back release];
	[self->MobileLibraryGUI_SearchResultsController_currMember_back release];
	[self->Library_Library_members_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"Library::Member\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"libraryNo\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _libraryNo]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"name\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _name]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"borrows\" type=\"Set\">\n"];
	[res appendFormat:@"%@\n", [self _borrows]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"toCollect\" type=\"Set\">\n"];
	[res appendFormat:@"%@\n", [self _toCollect]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"password\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _password]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
-(OCLString*) initial_libraryNo {
	/* ==================================================
	 * null
	 * ================================================== */
	
	OCLString* v0 = [NSNull null];
	
	return v0;
}

-(OCLString*) _libraryNo {
	if (self->_libraryNo_initialized == YES) {
		return _libraryNo;
	} else { 
		[self set_libraryNo:[self initial_libraryNo]];
	}

	self->_libraryNo_initialized = YES;
	return _libraryNo;
}
-(OCLString*) initial_name {
	/* ==================================================
	 * null
	 * ================================================== */
	
	OCLString* v0 = [NSNull null];
	
	return v0;
}

-(OCLString*) _name {
	if (self->_name_initialized == YES) {
		return _name;
	} else { 
		[self set_name:[self initial_name]];
	}

	self->_name_initialized = YES;
	return _name;
}
-(OCLSet*) initial_borrows {
	/* ==================================================
	 * Set {}
	 * ================================================== */
	
	OCLSet* v0 = [(OCLSet*)[OCLSet alloc] init];
	
	return v0;
}

-(OCLSet*) _borrows {
	if (self->_borrows_initialized == YES) {
		return _borrows;
	} else { 
		[self set_borrows:[self initial_borrows]];
	}

	self->_borrows_initialized = YES;
	return _borrows;
}
-(OCLSet*) initial_toCollect {
	/* ==================================================
	 * Set {}
	 * ================================================== */
	
	OCLSet* v0 = [(OCLSet*)[OCLSet alloc] init];
	
	return v0;
}

-(OCLSet*) _toCollect {
	if (self->_toCollect_initialized == YES) {
		return _toCollect;
	} else { 
		[self set_toCollect:[self initial_toCollect]];
	}

	self->_toCollect_initialized = YES;
	return _toCollect;
}
-(OCLString*) initial_password {
	/* ==================================================
	 * null
	 * ================================================== */
	
	OCLString* v0 = [NSNull null];
	
	return v0;
}

-(OCLString*) _password {
	if (self->_password_initialized == YES) {
		return _password;
	} else { 
		[self set_password:[self initial_password]];
	}

	self->_password_initialized = YES;
	return _password;
}


 
-(void) set_libraryNo:(OCLString*) value {
	 	if (self->_libraryNo!= nil && self->_libraryNo!= (OCLString*) [NSNull null]) {
		[self->_libraryNo release];
	}
	self->_libraryNo = value;
	if (self->_libraryNo!= nil && self->_libraryNo!= (OCLString*) [NSNull null]) {
		[self->_libraryNo retain];
	}
	self->_libraryNo_initialized = YES;

}
-(void) set_name:(OCLString*) value {
	 	if (self->_name!= nil && self->_name!= (OCLString*) [NSNull null]) {
		[self->_name release];
	}
	self->_name = value;
	if (self->_name!= nil && self->_name!= (OCLString*) [NSNull null]) {
		[self->_name retain];
	}
	self->_name_initialized = YES;

}
-(void) set_password:(OCLString*) value {
	 	if (self->_password!= nil && self->_password!= (OCLString*) [NSNull null]) {
		[self->_password release];
	}
	self->_password = value;
	if (self->_password!= nil && self->_password!= (OCLString*) [NSNull null]) {
		[self->_password retain];
	}
	self->_password_initialized = YES;

}




-(void) set_borrows:(OCLSet*) value {
	 
	if (self->_borrows!= nil && self->_borrows!= (OCLSet*) [NSNull null]) {
		// Clear back pointer on old instance
		NSEnumerator* e = [self->_borrows objectEnumerator];
		Library_Copy* o;
		while ((o = [e nextObject]) != nil) {
			if (o != (Library_Copy*)[NSNull null]) {
				NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)o valueForKey:@"Library_Member_borrows_back"];
				[backpointers removeObject:self];
			}
		}
		[self->_borrows release];
	}
	self->_borrows = value;
	if (self->_borrows!= nil && self->_borrows!= (OCLSet*) [NSNull null]) {
		[self->_borrows retain];
		// Add back pointer on new instance
		NSEnumerator* e = [self->_borrows objectEnumerator];
		Library_Copy* o;
		while ((o = [e nextObject]) != nil) {
			if (o != (Library_Copy*)[NSNull null]) {
				NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)o valueForKey:@"Library_Member_borrows_back"];
				[backpointers addObject:self];
			}
		}
	}
	self->_borrows_initialized = YES;

}
-(void) set_toCollect:(OCLSet*) value {
	 
	if (self->_toCollect!= nil && self->_toCollect!= (OCLSet*) [NSNull null]) {
		// Clear back pointer on old instance
		NSEnumerator* e = [self->_toCollect objectEnumerator];
		Library_Copy* o;
		while ((o = [e nextObject]) != nil) {
			if (o != (Library_Copy*)[NSNull null]) {
				NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)o valueForKey:@"Library_Member_toCollect_back"];
				[backpointers removeObject:self];
			}
		}
		[self->_toCollect release];
	}
	self->_toCollect = value;
	if (self->_toCollect!= nil && self->_toCollect!= (OCLSet*) [NSNull null]) {
		[self->_toCollect retain];
		// Add back pointer on new instance
		NSEnumerator* e = [self->_toCollect objectEnumerator];
		Library_Copy* o;
		while ((o = [e nextObject]) != nil) {
			if (o != (Library_Copy*)[NSNull null]) {
				NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)o valueForKey:@"Library_Member_toCollect_back"];
				[backpointers addObject:self];
			}
		}
	}
	self->_toCollect_initialized = YES;

}


 
-(void) event_setBorrows_pushed:(PropertyChangeList*) changes  p_borrows: (OCLSet*) p_borrows{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_setBorrows", @"Library_Member");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * -- Generated impacts relationship code:
		 * borrows
		 * ================================================== */
		
		OCLSet* v0 = p_borrows;
		
		OCLSet* _borrows_newValue = v0;
		[changes addChange:@selector(set_borrows:) instance:self value:_borrows_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_setToCollect_pushed:(PropertyChangeList*) changes  p_toCollect: (OCLSet*) p_toCollect{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_setToCollect", @"Library_Member");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * -- Generated impacts relationship code:
		 * toCollect
		 * ================================================== */
		
		OCLSet* v0 = p_toCollect;
		
		OCLSet* _toCollect_newValue = v0;
		[changes addChange:@selector(set_toCollect:) instance:self value:_toCollect_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_addCopyToCollect_pushed:(PropertyChangeList*) changes  p_copy: (Library_Copy*) p_copy{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_addCopyToCollect", @"Library_Member");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * toCollect->union(Set{copy})
		 * ================================================== */
		
		Library_Member* v2 = self;
		OCLSet* v1 = [v2 _toCollect];
		Library_Copy* v5 = p_copy;
		Library_Copy* v4 = v5;
		OCLSet* v3 = [(OCLSet*)[OCLSet alloc] init];
		[v3 add:v4];
		OCLSet* v0 = [v1 unionWithSet:v3];
		[v3 release];
		
		OCLSet* _toCollect_newValue = v0;
		[changes addChange:@selector(set_toCollect:) instance:self value:_toCollect_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 




 


@end 


