 
 
 
#import "StringUtils_StringTokenizer.h"
#import "PropertyChangeList.h"
#import "LibraryPersistence_LibraryLoader.h"


 
@implementation StringUtils_StringTokenizer

 
- (StringUtils_StringTokenizer*) init {
	self = [super init];
	 
	self->LibraryPersistence_LibraryLoader_borrowsStringTokenizer_back = [[NSMutableArray alloc] init];
	self->LibraryPersistence_LibraryLoader_memberStringTokenizer_back = [[NSMutableArray alloc] init];
	self->LibraryPersistence_LibraryLoader_toCollectStringTokenizer_back = [[NSMutableArray alloc] init];
	self->LibraryPersistence_LibraryLoader_bookStringTokenizer_back = [[NSMutableArray alloc] init];
	self->LibraryPersistence_LibraryLoader_authorStringTokenizer_back = [[NSMutableArray alloc] init];
	self->LibraryPersistence_LibraryLoader_copyStringTokenizer_back = [[NSMutableArray alloc] init];


	return self;
}

 
- (StringUtils_StringTokenizer*) initWithValues: (OCLTuple*) values {
	self = [super init];
	 

	self->LibraryPersistence_LibraryLoader_borrowsStringTokenizer_back = [[NSMutableArray alloc] init];
	self->LibraryPersistence_LibraryLoader_memberStringTokenizer_back = [[NSMutableArray alloc] init];
	self->LibraryPersistence_LibraryLoader_toCollectStringTokenizer_back = [[NSMutableArray alloc] init];
	self->LibraryPersistence_LibraryLoader_bookStringTokenizer_back = [[NSMutableArray alloc] init];
	self->LibraryPersistence_LibraryLoader_authorStringTokenizer_back = [[NSMutableArray alloc] init];
	self->LibraryPersistence_LibraryLoader_copyStringTokenizer_back = [[NSMutableArray alloc] init];


	
	return self;
}

 
- (void) dealloc {

	[self->LibraryPersistence_LibraryLoader_borrowsStringTokenizer_back release];
	[self->LibraryPersistence_LibraryLoader_memberStringTokenizer_back release];
	[self->LibraryPersistence_LibraryLoader_toCollectStringTokenizer_back release];
	[self->LibraryPersistence_LibraryLoader_bookStringTokenizer_back release];
	[self->LibraryPersistence_LibraryLoader_authorStringTokenizer_back release];
	[self->LibraryPersistence_LibraryLoader_copyStringTokenizer_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"StringUtils::StringTokenizer\" retainCount=\"%i\">\n", self, [self retainCount]];
	
	[res appendString:@"</instance>\n"];
	return res;
}

 


 






 

 
-(void) event_tokenizeString_pushed:(PropertyChangeList*) changes  p_string: (OCLString*) p_string p_separator: (OCLString*) p_separator{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_tokenizeString", @"StringUtils_StringTokenizer");

		OCLTuple* parameters = [[OCLTuple alloc] init];
		[parameters addItemNamed:@"string" withValue:p_string]; 
		[parameters addItemNamed:@"separator" withValue:p_separator]; 

		[self onEvent:@"tokenizeString" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_stringTokenized_pushed:(PropertyChangeList*) changes  p_tokens: (OCLSequence*) p_tokens{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_stringTokenized", @"StringUtils_StringTokenizer");

		OCLTuple* parameters = [[OCLTuple alloc] init];
		[parameters addItemNamed:@"tokens" withValue:p_tokens]; 

		[self onEvent:@"stringTokenized" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges
		NSEnumerator* LibraryPersistence_LibraryLoader_authorsLineTokenized_edge0_enum = [self->LibraryPersistence_LibraryLoader_authorStringTokenizer_back objectEnumerator];
		LibraryPersistence_LibraryLoader* LibraryPersistence_LibraryLoader_authorsLineTokenized_edge0_target;
		while ((LibraryPersistence_LibraryLoader_authorsLineTokenized_edge0_target = [LibraryPersistence_LibraryLoader_authorsLineTokenized_edge0_enum nextObject]) != nil) {
		    [LibraryPersistence_LibraryLoader_authorsLineTokenized_edge0_target event_authorsLineTokenized_pulled_edge0:changes parentInstance:self p_tokens:p_tokens ];
		}

		NSEnumerator* LibraryPersistence_LibraryLoader_borrowsLineTokenized_edge0_enum = [self->LibraryPersistence_LibraryLoader_borrowsStringTokenizer_back objectEnumerator];
		LibraryPersistence_LibraryLoader* LibraryPersistence_LibraryLoader_borrowsLineTokenized_edge0_target;
		while ((LibraryPersistence_LibraryLoader_borrowsLineTokenized_edge0_target = [LibraryPersistence_LibraryLoader_borrowsLineTokenized_edge0_enum nextObject]) != nil) {
		    [LibraryPersistence_LibraryLoader_borrowsLineTokenized_edge0_target event_borrowsLineTokenized_pulled_edge0:changes parentInstance:self p_tokens:p_tokens ];
		}

		NSEnumerator* LibraryPersistence_LibraryLoader_copyLineTokenized_edge0_enum = [self->LibraryPersistence_LibraryLoader_copyStringTokenizer_back objectEnumerator];
		LibraryPersistence_LibraryLoader* LibraryPersistence_LibraryLoader_copyLineTokenized_edge0_target;
		while ((LibraryPersistence_LibraryLoader_copyLineTokenized_edge0_target = [LibraryPersistence_LibraryLoader_copyLineTokenized_edge0_enum nextObject]) != nil) {
		    [LibraryPersistence_LibraryLoader_copyLineTokenized_edge0_target event_copyLineTokenized_pulled_edge0:changes parentInstance:self p_tokens:p_tokens ];
		}

		NSEnumerator* LibraryPersistence_LibraryLoader_memberLineTokenized_edge0_enum = [self->LibraryPersistence_LibraryLoader_memberStringTokenizer_back objectEnumerator];
		LibraryPersistence_LibraryLoader* LibraryPersistence_LibraryLoader_memberLineTokenized_edge0_target;
		while ((LibraryPersistence_LibraryLoader_memberLineTokenized_edge0_target = [LibraryPersistence_LibraryLoader_memberLineTokenized_edge0_enum nextObject]) != nil) {
		    [LibraryPersistence_LibraryLoader_memberLineTokenized_edge0_target event_memberLineTokenized_pulled_edge0:changes parentInstance:self p_tokens:p_tokens ];
		}

		NSEnumerator* LibraryPersistence_LibraryLoader_bookLineTokenized_edge0_enum = [self->LibraryPersistence_LibraryLoader_bookStringTokenizer_back objectEnumerator];
		LibraryPersistence_LibraryLoader* LibraryPersistence_LibraryLoader_bookLineTokenized_edge0_target;
		while ((LibraryPersistence_LibraryLoader_bookLineTokenized_edge0_target = [LibraryPersistence_LibraryLoader_bookLineTokenized_edge0_enum nextObject]) != nil) {
		    [LibraryPersistence_LibraryLoader_bookLineTokenized_edge0_target event_bookLineTokenized_pulled_edge0:changes parentInstance:self p_tokens:p_tokens ];
		}

		NSEnumerator* LibraryPersistence_LibraryLoader_toCollectLineTokenized_edge0_enum = [self->LibraryPersistence_LibraryLoader_toCollectStringTokenizer_back objectEnumerator];
		LibraryPersistence_LibraryLoader* LibraryPersistence_LibraryLoader_toCollectLineTokenized_edge0_target;
		while ((LibraryPersistence_LibraryLoader_toCollectLineTokenized_edge0_target = [LibraryPersistence_LibraryLoader_toCollectLineTokenized_edge0_enum nextObject]) != nil) {
		    [LibraryPersistence_LibraryLoader_toCollectLineTokenized_edge0_target event_toCollectLineTokenized_pulled_edge0:changes parentInstance:self p_tokens:p_tokens ];
		}



		 	
		// Trigger local edges


		 
		 // Process impacts relationships


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 




 
-(void)onPropertyChange:(NSString*)propertyName newValue:(id) value {
}

 
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters{
	if ([eventName isEqual:@"tokenizeString"]) {
		if (parameters != nil && parameters != [NSNull null]){
			OCLString* line = (OCLString *) [parameters objectForKey:@"string"];
			OCLString* sep = (OCLString *) [parameters objectForKey:@"separator"];
			NSArray* tokens = [line->string componentsSeparatedByString:sep->string];
			
			NSEnumerator *e = [tokens objectEnumerator];
			id token;
			OCLSequence *oclTokens = [[OCLSequence alloc] init];
			while (token = [e nextObject])
				[oclTokens add: [[OCLString alloc] initWithString: (NSString *) token]];
			
			[self event_stringTokenized_pushed:nil p_tokens:oclTokens];
		}
	}
}

 
-(id) getBinding {
	return [NSNull null];
}

 
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value {
}



@end 


