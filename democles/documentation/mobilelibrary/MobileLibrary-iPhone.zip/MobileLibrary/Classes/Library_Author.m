 
 
 
#import "Library_Author.h"
#import "PropertyChangeList.h"
#import "Library_Book.h"
#import "LibraryPersistence_LibraryLoader.h"


 
@implementation Library_Author

 
- (Library_Author*) init {
	self = [super init];
	 
	self->Library_Book_authors_back = [[NSMutableArray alloc] init];
	self->LibraryPersistence_LibraryLoader_authors_back = [[NSMutableArray alloc] init];

	[self set_name: [self _name]];
	[self set_authorId: [self _authorId]];

	return self;
}

 
- (Library_Author*) initWithValues: (OCLTuple*) values {
	self = [super init];
	 
	self->_name_initialized = NO;
	self->_authorId_initialized = NO;

	self->Library_Book_authors_back = [[NSMutableArray alloc] init];
	self->LibraryPersistence_LibraryLoader_authors_back = [[NSMutableArray alloc] init];

	OCLString* _name_initialValue = (OCLString*) [values objectForKey:@"name"];
	if (_name_initialValue == nil) {
		_name_initialValue = [self _name];
	}
	[self set_name:_name_initialValue];
	OCLString* _authorId_initialValue = (OCLString*) [values objectForKey:@"authorId"];
	if (_authorId_initialValue == nil) {
		_authorId_initialValue = [self _authorId];
	}
	[self set_authorId:_authorId_initialValue];

	
	return self;
}

 
- (void) dealloc {
	if (self->_name != nil && self->_name != (OCLString*) [NSNull null]) [self->_name release];
	if (self->_authorId != nil && self->_authorId != (OCLString*) [NSNull null]) [self->_authorId release];

	[self->Library_Book_authors_back release];
	[self->LibraryPersistence_LibraryLoader_authors_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"Library::Author\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"name\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _name]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"authorId\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _authorId]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
-(OCLString*) initial_name {
	/* ==================================================
	 * null
	 * ================================================== */
	
	OCLString* v0 = [NSNull null];
	
	return v0;
}

-(OCLString*) _name {
	if (self->_name_initialized == YES) {
		return _name;
	} else { 
		[self set_name:[self initial_name]];
	}

	self->_name_initialized = YES;
	return _name;
}
-(OCLString*) initial_authorId {
	/* ==================================================
	 * null
	 * ================================================== */
	
	OCLString* v0 = [NSNull null];
	
	return v0;
}

-(OCLString*) _authorId {
	if (self->_authorId_initialized == YES) {
		return _authorId;
	} else { 
		[self set_authorId:[self initial_authorId]];
	}

	self->_authorId_initialized = YES;
	return _authorId;
}


 
-(void) set_name:(OCLString*) value {
	 	if (self->_name!= nil && self->_name!= (OCLString*) [NSNull null]) {
		[self->_name release];
	}
	self->_name = value;
	if (self->_name!= nil && self->_name!= (OCLString*) [NSNull null]) {
		[self->_name retain];
	}
	self->_name_initialized = YES;

}
-(void) set_authorId:(OCLString*) value {
	 	if (self->_authorId!= nil && self->_authorId!= (OCLString*) [NSNull null]) {
		[self->_authorId release];
	}
	self->_authorId = value;
	if (self->_authorId!= nil && self->_authorId!= (OCLString*) [NSNull null]) {
		[self->_authorId retain];
	}
	self->_authorId_initialized = YES;

}






 


 


@end 


