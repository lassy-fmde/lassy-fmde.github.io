 
 
 
#import "GeneralGUI_ConfirmationDialog.h"
#import "PropertyChangeList.h"
#import "GeneralGUI_ConfirmationDialog.h"
#import "MobileLibraryGUI_BookDetailController.h"
#import "MobileLibraryGUI_MemberController.h"


 
@implementation GeneralGUI_ConfirmationDialog

 
-(void)create_binding {
	self->binding = [[UIAlertView alloc] initWithTitle:_title->string message:_message->string delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:nil];
	[self->binding retain];
	[self->binding addButtonWithTitle:@"Ok"];
	[self->binding show]; 
}

-(id)init {
	self = [super init];
	 
	self->MobileLibraryGUI_BookDetailController_yesNoMsg_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_MemberController_yesNoMsg_back = [[NSMutableArray alloc] init];

	[self set_title: [self _title]];
	[self set_message: [self _message]];


	 
	[self performSelectorOnMainThread:@selector(create_binding) withObject:nil waitUntilDone:YES]; 	

	return self;
}

 
-(id)initWithValues: (OCLTuple*) values {
	self = [super init];
	 
	self->_title_initialized = NO;
	self->_message_initialized = NO;

	self->MobileLibraryGUI_BookDetailController_yesNoMsg_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_MemberController_yesNoMsg_back = [[NSMutableArray alloc] init];

	OCLString* _title_initialValue = (OCLString*) [values objectForKey:@"title"];
	if (_title_initialValue == nil) {
		_title_initialValue = [self _title];
	}
	[self set_title:_title_initialValue];
	OCLString* _message_initialValue = (OCLString*) [values objectForKey:@"message"];
	if (_message_initialValue == nil) {
		_message_initialValue = [self _message];
	}
	[self set_message:_message_initialValue];


	 
	[self performSelectorOnMainThread:@selector(create_binding) withObject:nil waitUntilDone:YES]; 	

	return self;
}

 
- (void) dealloc {
	if (self->_title != nil && self->_title != (OCLString*) [NSNull null]) [self->_title release];
	if (self->_message != nil && self->_message != (OCLString*) [NSNull null]) [self->_message release];

	[self->MobileLibraryGUI_BookDetailController_yesNoMsg_back release];
	[self->MobileLibraryGUI_MemberController_yesNoMsg_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"GeneralGUI::ConfirmationDialog\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"title\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _title]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"message\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _message]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
-(void)triggerConfirmedEvent {
	NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
	[self event_okClicked_pushed:nil];
	[pool release];
}

-(void)triggerCanceledEvent {
	NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
	[self event_cancelClicked_pushed:nil];
	[pool release];
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
	if (buttonIndex == 1) {
		[self performSelectorInBackground:@selector(triggerConfirmedEvent) withObject:nil];
	} else {
		[self performSelectorInBackground:@selector(triggerCanceledEvent) withObject:nil];
	}
}

 
-(OCLString*) initial_title {
	/* ==================================================
	 * ''
	 * ================================================== */
	
	OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@""];
	
	return v0;
}

-(OCLString*) _title {
	if (self->_title_initialized == YES) {
		return _title;
	} else { 
		[self set_title:[self initial_title]];
	}

	self->_title_initialized = YES;
	return _title;
}
-(OCLString*) initial_message {
	/* ==================================================
	 * ''
	 * ================================================== */
	
	OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@""];
	
	return v0;
}

-(OCLString*) _message {
	if (self->_message_initialized == YES) {
		return _message;
	} else { 
		[self set_message:[self initial_message]];
	}

	self->_message_initialized = YES;
	return _message;
}


 
-(void) set_title:(OCLString*) value {
	 	if (self->_title!= nil && self->_title!= (OCLString*) [NSNull null]) {
		[self->_title release];
	}
	self->_title = value;
	if (self->_title!= nil && self->_title!= (OCLString*) [NSNull null]) {
		[self->_title retain];
	}
	self->_title_initialized = YES;
	
	[self onPropertyChange:@"title" newValue:value];
}
-(void) set_message:(OCLString*) value {
	 	if (self->_message!= nil && self->_message!= (OCLString*) [NSNull null]) {
		[self->_message release];
	}
	self->_message = value;
	if (self->_message!= nil && self->_message!= (OCLString*) [NSNull null]) {
		[self->_message retain];
	}
	self->_message_initialized = YES;
	
	[self onPropertyChange:@"message" newValue:value];
}






 

 
-(void) event_okClicked_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_okClicked", @"GeneralGUI_ConfirmationDialog");

		OCLTuple* parameters = [[OCLTuple alloc] init];

		[self onEvent:@"okClicked" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges
		NSEnumerator* MobileLibraryGUI_MemberController_renewConfAck_edge0_enum = [self->MobileLibraryGUI_MemberController_yesNoMsg_back objectEnumerator];
		MobileLibraryGUI_MemberController* MobileLibraryGUI_MemberController_renewConfAck_edge0_target;
		while ((MobileLibraryGUI_MemberController_renewConfAck_edge0_target = [MobileLibraryGUI_MemberController_renewConfAck_edge0_enum nextObject]) != nil) {
		    [MobileLibraryGUI_MemberController_renewConfAck_edge0_target event_renewConfAck_pulled_edge0:changes parentInstance:self ];
		}

		NSEnumerator* MobileLibraryGUI_BookDetailController_reserveConfAck_edge0_enum = [self->MobileLibraryGUI_BookDetailController_yesNoMsg_back objectEnumerator];
		MobileLibraryGUI_BookDetailController* MobileLibraryGUI_BookDetailController_reserveConfAck_edge0_target;
		while ((MobileLibraryGUI_BookDetailController_reserveConfAck_edge0_target = [MobileLibraryGUI_BookDetailController_reserveConfAck_edge0_enum nextObject]) != nil) {
		    [MobileLibraryGUI_BookDetailController_reserveConfAck_edge0_target event_reserveConfAck_pulled_edge0:changes parentInstance:self ];
		}



		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {

			[self event_close_pushed:changes ];
		}
		[v0 release];


		 
		 // Process impacts relationships


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_close_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_close", @"GeneralGUI_ConfirmationDialog");

		OCLTuple* parameters = [[OCLTuple alloc] init];

		[self onEvent:@"close" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_cancelClicked_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_cancelClicked", @"GeneralGUI_ConfirmationDialog");

		OCLTuple* parameters = [[OCLTuple alloc] init];

		[self onEvent:@"cancelClicked" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {

			[self event_close_pushed:changes ];
		}
		[v0 release];


		 
		 // Process impacts relationships


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 




 
-(void)onPropertyChange:(NSString*)propertyName newValue:(id) value {
}

 
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters{
}

 
-(id) getBinding {
	return self->binding;
}

 
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value {
}


@end 


