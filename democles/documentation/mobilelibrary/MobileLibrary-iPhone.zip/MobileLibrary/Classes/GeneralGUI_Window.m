 
 
 
#import "GeneralGUI_Window.h"
#import "PropertyChangeList.h"
#import "MobileLibraryGUI_StartController.h"
#import "MobileLibraryGUI_SearchResultsController.h"
#import "MobileLibraryGUI_BookDetailController.h"


 
@implementation GeneralGUI_Window

 

-(void)create_binding {
	self->binding = [[UIViewController alloc] init];
	[self->binding retain];
	[[AppWindow instance] pushViewController:self->binding];
}

- (id) init {
	self = [super init];
	
	[self performSelectorOnMainThread:@selector(create_binding) withObject:nil waitUntilDone:YES]; 	

	 
	self->MobileLibraryGUI_StartController_window_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_SearchResultsController_window_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_BookDetailController_window_back = [[NSMutableArray alloc] init];

	[self set_seqGUIElements: [self _seqGUIElements]];
	[self set_title: [self _title]];


	return self;
}

 - (id) initWithValues: (OCLTuple*) values {
	self = [super init];
	
	[self performSelectorOnMainThread:@selector(create_binding) withObject:nil waitUntilDone:YES]; 	

	 
	self->_seqGUIElements_initialized = NO;
	self->_title_initialized = NO;

	self->MobileLibraryGUI_StartController_window_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_SearchResultsController_window_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_BookDetailController_window_back = [[NSMutableArray alloc] init];

	OCLSequence* _seqGUIElements_initialValue = (OCLSequence*) [values objectForKey:@"seqGUIElements"];
	if (_seqGUIElements_initialValue == nil) {
		_seqGUIElements_initialValue = [self _seqGUIElements];
	}
	[self set_seqGUIElements:_seqGUIElements_initialValue];
	OCLString* _title_initialValue = (OCLString*) [values objectForKey:@"title"];
	if (_title_initialValue == nil) {
		_title_initialValue = [self _title];
	}
	[self set_title:_title_initialValue];


	return self;
}

 
- (void) dealloc {
	if (self->_seqGUIElements != nil && self->_seqGUIElements != (OCLSequence*) [NSNull null]) [self->_seqGUIElements release];
	if (self->_title != nil && self->_title != (OCLString*) [NSNull null]) [self->_title release];

	[self->MobileLibraryGUI_StartController_window_back release];
	[self->MobileLibraryGUI_SearchResultsController_window_back release];
	[self->MobileLibraryGUI_BookDetailController_window_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"GeneralGUI::Window\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"seqGUIElements\" type=\"Sequence\">\n"];
	[res appendFormat:@"%@\n", [self _seqGUIElements]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"title\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _title]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
-(OCLSequence*) initial_seqGUIElements {
	/* ==================================================
	 * Sequence {}
	 * ================================================== */
	
	OCLSequence* v0 = [(OCLSequence*)[OCLSequence alloc] init];
	
	return v0;
}

-(OCLSequence*) _seqGUIElements {
	if (self->_seqGUIElements_initialized == YES) {
		return _seqGUIElements;
	} else { 
		[self set_seqGUIElements:[self initial_seqGUIElements]];
	}

	self->_seqGUIElements_initialized = YES;
	return _seqGUIElements;
}
-(OCLString*) initial_title {
	/* ==================================================
	 * ''
	 * ================================================== */
	
	OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@""];
	
	return v0;
}

-(OCLString*) _title {
	if (self->_title_initialized == YES) {
		return _title;
	} else { 
		[self set_title:[self initial_title]];
	}

	self->_title_initialized = YES;
	return _title;
}


 
-(void) set_seqGUIElements:(OCLSequence*) value {
	 	if (self->_seqGUIElements!= nil && self->_seqGUIElements!= (OCLSequence*) [NSNull null]) {
		[self->_seqGUIElements release];
	}
	self->_seqGUIElements = value;
	if (self->_seqGUIElements!= nil && self->_seqGUIElements!= (OCLSequence*) [NSNull null]) {
		[self->_seqGUIElements retain];
	}
	self->_seqGUIElements_initialized = YES;
	
	[self onPropertyChange:@"seqGUIElements" newValue:value];
}
-(void) set_title:(OCLString*) value {
	 	if (self->_title!= nil && self->_title!= (OCLString*) [NSNull null]) {
		[self->_title release];
	}
	self->_title = value;
	if (self->_title!= nil && self->_title!= (OCLString*) [NSNull null]) {
		[self->_title retain];
	}
	self->_title_initialized = YES;
	
	[self onPropertyChange:@"title" newValue:value];
}






 

 
-(void) event_closeWindow_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_closeWindow", @"GeneralGUI_Window");

		OCLTuple* parameters = [[OCLTuple alloc] init];

		[self onEvent:@"closeWindow" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 




 
-(void)onPropertyChange_async:(NSDictionary*)parameters {
	NSString* propertyName = [parameters objectForKey:@"propertyName"];
	id value = [parameters objectForKey:@"value"];
	
	if ([propertyName isEqual:@"seqGUIElements"]) {
		OCLSequence* widgets = [self _seqGUIElements];
		int y_pos = 0;
		NSEnumerator* e = [widgets objectEnumerator];
		id object;
		while ((object = [e nextObject])) {
			if ([object conformsToProtocol:@protocol(IBinding)]) {
				id<IBinding> propBinding = [object getBinding];
				UIView* view;
				if ([propBinding isKindOfClass: [UIViewController class]]) {
					view = ((UIViewController*)propBinding).view;
				} else if ([propBinding isKindOfClass: [UIView class]]) {
					view = (UIView*)propBinding;
				} else {
					NSLog(@"%@: Attempt to add incompatible object as UIView", self);
					view = NULL;
				}
			
				if ([view isKindOfClass: [UIPickerView class]]){
					view.frame  = CGRectMake(0,  y_pos, 320, 162);
					y_pos += 172;
				} else if ([view isKindOfClass: [UITableView class]]) {
					CGRect appFrame = [[UIScreen mainScreen] applicationFrame];
					
					OCLInteger* numWidgets = [widgets size];
					if (numWidgets->value == 1) {
						appFrame.origin.y = 0;
					} else {
						appFrame.origin.y = y_pos;
						appFrame.size.height = 80;
					}

					view.frame = appFrame;
					y_pos += appFrame.size.height;
					[numWidgets release];
				} else if ([view isKindOfClass: [UIImageView class]]) {
					CGRect appFrame = [[UIScreen mainScreen] applicationFrame];				
					CGSize imgSize = ((UIImageView*)view).image.size;
					int x = (appFrame.size.width - imgSize.width) / 2;
					view.frame = CGRectMake(x, y_pos, imgSize.width, imgSize.height);
					y_pos += imgSize.height + 10;
				} else {
					view.frame = CGRectMake(20, y_pos + 10, 280, 30);
					y_pos += 40;
				}
				[self->binding.view addSubview:view];
			}
		}
	}

	if ([propertyName isEqual:@"title"]) {
		[self->binding setTitle:((OCLString *)value)->string];
	}	
	[parameters release];
}

-(void)onPropertyChange:(NSString*)propertyName newValue:(id)value {
	NSMutableDictionary* parameters = [[NSMutableDictionary alloc] init];
	[parameters setValue:propertyName forKey:@"propertyName"];
	[parameters setValue:value forKey:@"value"];
	[parameters retain];
	[self performSelectorOnMainThread:@selector(onPropertyChange_async:) withObject:parameters waitUntilDone:NO];
}

 
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters{
	if ([eventName isEqual:@"closeWindow"]) {
		[[AppWindow instance] popViewController:self->binding];
	}	
}

 
-(id) getBinding {
	return self->binding;
}

 
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value {
}


@end 


