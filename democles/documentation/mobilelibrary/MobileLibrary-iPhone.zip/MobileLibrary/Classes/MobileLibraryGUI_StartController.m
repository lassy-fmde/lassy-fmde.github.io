 
 
 
#import "MobileLibraryGUI_StartController.h"
#import "PropertyChangeList.h"
#import "GeneralGUI_Image.h"
#import "GeneralGUI_Window.h"
#import "GeneralGUI_Label.h"
#import "Application_Main.h"


 
@implementation MobileLibraryGUI_StartController

 
- (MobileLibraryGUI_StartController*) init {
	self = [super init];
	 
	self->Application_Main_startControl_back = [[NSMutableArray alloc] init];

	[self set_msgLabel: [self _msgLabel]];
	[self set_windowTitle: [self _windowTitle]];
	[self set_window: [self _window]];
	[self set_logo: [self _logo]];

	return self;
}

 
- (MobileLibraryGUI_StartController*) initWithValues: (OCLTuple*) values {
	self = [super init];
	 
	self->_msgLabel_initialized = NO;
	self->_windowTitle_initialized = NO;
	self->_window_initialized = NO;
	self->_logo_initialized = NO;

	self->Application_Main_startControl_back = [[NSMutableArray alloc] init];

	GeneralGUI_Label* _msgLabel_initialValue = (GeneralGUI_Label*) [values objectForKey:@"msgLabel"];
	if (_msgLabel_initialValue == nil) {
		_msgLabel_initialValue = [self _msgLabel];
	}
	[self set_msgLabel:_msgLabel_initialValue];
	OCLString* _windowTitle_initialValue = (OCLString*) [values objectForKey:@"windowTitle"];
	if (_windowTitle_initialValue == nil) {
		_windowTitle_initialValue = [self _windowTitle];
	}
	[self set_windowTitle:_windowTitle_initialValue];
	GeneralGUI_Window* _window_initialValue = (GeneralGUI_Window*) [values objectForKey:@"window"];
	if (_window_initialValue == nil) {
		_window_initialValue = [self _window];
	}
	[self set_window:_window_initialValue];
	GeneralGUI_Image* _logo_initialValue = (GeneralGUI_Image*) [values objectForKey:@"logo"];
	if (_logo_initialValue == nil) {
		_logo_initialValue = [self _logo];
	}
	[self set_logo:_logo_initialValue];

	
	return self;
}

 
- (void) dealloc {
	if (self->_msgLabel != nil && self->_msgLabel != (GeneralGUI_Label*) [NSNull null]) [self->_msgLabel release];
	if (self->_windowTitle != nil && self->_windowTitle != (OCLString*) [NSNull null]) [self->_windowTitle release];
	if (self->_window != nil && self->_window != (GeneralGUI_Window*) [NSNull null]) [self->_window release];
	if (self->_logo != nil && self->_logo != (GeneralGUI_Image*) [NSNull null]) [self->_logo release];

	[self->Application_Main_startControl_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"MobileLibraryGUI::StartController\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"msgLabel\" type=\"GeneralGUI::Label\">\n"];
	[res appendFormat:@"%@\n", [self _msgLabel]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"windowTitle\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _windowTitle]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"window\" type=\"GeneralGUI::Window\">\n"];
	[res appendFormat:@"%@\n", [self _window]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"logo\" type=\"GeneralGUI::Image\">\n"];
	[res appendFormat:@"%@\n", [self _logo]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
-(GeneralGUI_Label*) initial_msgLabel {
	/* ==================================================
	 * GeneralGUI::Label::create(Tuple { text = '        Starting the Mobile Library' })
	 * ================================================== */
	
	OCLString* v4 = [(OCLString*)[OCLString alloc] initWithString:@"        Starting the Mobile Library"];
	OCLString* v3 = v4;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"text" withValue:v3];
	GeneralGUI_Label* v0 = [(GeneralGUI_Label*)[GeneralGUI_Label alloc] initWithValues:v2];
	[v4 release];
	[v2 release];
	
	return v0;
}

-(GeneralGUI_Label*) _msgLabel {
	if (self->_msgLabel_initialized == YES) {
		return _msgLabel;
	} else { 
		[self set_msgLabel:[self initial_msgLabel]];
	}

	self->_msgLabel_initialized = YES;
	return _msgLabel;
}
-(OCLString*) initial_windowTitle {
	/* ==================================================
	 * 'Starting...'
	 * ================================================== */
	
	OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@"Starting..."];
	
	return v0;
}

-(OCLString*) _windowTitle {
	if (self->_windowTitle_initialized == YES) {
		return _windowTitle;
	} else { 
		[self set_windowTitle:[self initial_windowTitle]];
	}

	self->_windowTitle_initialized = YES;
	return _windowTitle;
}
-(GeneralGUI_Window*) initial_window {
	/* ==================================================
	 * GeneralGUI::Window::create(
	 * 	Tuple { seqGUIElements = Sequence {msgLabel, logo}, title = windowTitle })
	 * ================================================== */
	
	MobileLibraryGUI_StartController* v7 = self;
	GeneralGUI_Label* v6 = [v7 _msgLabel];
	GeneralGUI_Label* v5 = v6;
	MobileLibraryGUI_StartController* v10 = self;
	GeneralGUI_Image* v9 = [v10 _logo];
	GeneralGUI_Image* v8 = v9;
	OCLSequence* v4 = [(OCLSequence*)[OCLSequence alloc] init];
	[v4 add:v5];
	[v4 add:v8];
	OCLSequence* v3 = v4;
	MobileLibraryGUI_StartController* v13 = self;
	OCLString* v12 = [v13 _windowTitle];
	OCLString* v11 = v12;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"seqGUIElements" withValue:v3];
	[v2 addItemNamed:@"title" withValue:v11];
	GeneralGUI_Window* v0 = [(GeneralGUI_Window*)[GeneralGUI_Window alloc] initWithValues:v2];
	[v2 release];
	[v4 release];
	
	return v0;
}

-(GeneralGUI_Window*) _window {
	if (self->_window_initialized == YES) {
		return _window;
	} else { 
		[self set_window:[self initial_window]];
	}

	self->_window_initialized = YES;
	return _window;
}
-(GeneralGUI_Image*) initial_logo {
	/* ==================================================
	 * GeneralGUI::Image::create(Tuple { imageFilename = 'icon-Uni_lu.png' })
	 * 
	 * ================================================== */
	
	OCLString* v4 = [(OCLString*)[OCLString alloc] initWithString:@"icon-Uni_lu.png"];
	OCLString* v3 = v4;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"imageFilename" withValue:v3];
	GeneralGUI_Image* v0 = [(GeneralGUI_Image*)[GeneralGUI_Image alloc] initWithValues:v2];
	[v4 release];
	[v2 release];
	
	return v0;
}

-(GeneralGUI_Image*) _logo {
	if (self->_logo_initialized == YES) {
		return _logo;
	} else { 
		[self set_logo:[self initial_logo]];
	}

	self->_logo_initialized = YES;
	return _logo;
}


 
-(void) set_windowTitle:(OCLString*) value {
	 	if (self->_windowTitle!= nil && self->_windowTitle!= (OCLString*) [NSNull null]) {
		[self->_windowTitle release];
	}
	self->_windowTitle = value;
	if (self->_windowTitle!= nil && self->_windowTitle!= (OCLString*) [NSNull null]) {
		[self->_windowTitle retain];
	}
	self->_windowTitle_initialized = YES;

}


-(void) set_msgLabel:(GeneralGUI_Label*) value {
	 
	if (self->_msgLabel!= nil && self->_msgLabel!= (GeneralGUI_Label*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_msgLabel valueForKey:@"MobileLibraryGUI_StartController_msgLabel_back"];
		[backpointers removeObject:self];
		[self->_msgLabel release];
	}
	self->_msgLabel = value;
	if (self->_msgLabel!= nil && self->_msgLabel!= (GeneralGUI_Label*) [NSNull null]) {
		[self->_msgLabel retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_msgLabel valueForKey:@"MobileLibraryGUI_StartController_msgLabel_back"];
		[backpointers addObject:self];
	}
	self->_msgLabel_initialized = YES;

}
-(void) set_window:(GeneralGUI_Window*) value {
	 
	if (self->_window!= nil && self->_window!= (GeneralGUI_Window*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_window valueForKey:@"MobileLibraryGUI_StartController_window_back"];
		[backpointers removeObject:self];
		[self->_window release];
	}
	self->_window = value;
	if (self->_window!= nil && self->_window!= (GeneralGUI_Window*) [NSNull null]) {
		[self->_window retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_window valueForKey:@"MobileLibraryGUI_StartController_window_back"];
		[backpointers addObject:self];
	}
	self->_window_initialized = YES;

}
-(void) set_logo:(GeneralGUI_Image*) value {
	 
	if (self->_logo!= nil && self->_logo!= (GeneralGUI_Image*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_logo valueForKey:@"MobileLibraryGUI_StartController_logo_back"];
		[backpointers removeObject:self];
		[self->_logo release];
	}
	self->_logo = value;
	if (self->_logo!= nil && self->_logo!= (GeneralGUI_Image*) [NSNull null]) {
		[self->_logo retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_logo valueForKey:@"MobileLibraryGUI_StartController_logo_back"];
		[backpointers addObject:self];
	}
	self->_logo_initialized = YES;

}




 
-(void) event_closeWIndow_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_closeWIndow", @"MobileLibraryGUI_StartController");

		 
		// Trigger Push edges

		if (self->_window != nil && self->_window != (GeneralGUI_Window*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_window];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			GeneralGUI_Window* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {

					[edge0_target event_closeWindow_pushed:changes ];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 




 


@end 


