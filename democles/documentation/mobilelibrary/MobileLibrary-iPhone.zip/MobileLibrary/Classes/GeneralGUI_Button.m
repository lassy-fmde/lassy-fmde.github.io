 
 
 
#import "GeneralGUI_Button.h"
#import "PropertyChangeList.h"
#import "MobileLibraryGUI_SearchController.h"
#import "MobileLibraryGUI_LoginController.h"


 
@implementation GeneralGUI_Button


-(void)create_binding {
	self->binding = [UIButton buttonWithType:UIButtonTypeRoundedRect];
	[self->binding retain];
	[self->binding addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
}
 
- (id) init {
	self = [super init];
	 
	[self performSelectorOnMainThread:@selector(create_binding) withObject:nil waitUntilDone:YES]; 	

	 
	self->MobileLibraryGUI_SearchController_searchButton_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_LoginController_loginButton_back = [[NSMutableArray alloc] init];

	[self set_text: [self _text]];


	return self;
}

 
- (id) initWithValues: (OCLTuple*) values {
	self = [super init];
	 
	[self performSelectorOnMainThread:@selector(create_binding) withObject:nil waitUntilDone:YES]; 	

	 
	self->_text_initialized = NO;

	self->MobileLibraryGUI_SearchController_searchButton_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_LoginController_loginButton_back = [[NSMutableArray alloc] init];

	OCLString* _text_initialValue = (OCLString*) [values objectForKey:@"text"];
	if (_text_initialValue == nil) {
		_text_initialValue = [self _text];
	}
	[self set_text:_text_initialValue];


	return self;
}

 
- (void) dealloc {
	if (self->_text != nil && self->_text != (OCLString*) [NSNull null]) [self->_text release];

	[self->MobileLibraryGUI_SearchController_searchButton_back release];
	[self->MobileLibraryGUI_LoginController_loginButton_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"GeneralGUI::Button\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"text\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _text]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
-(void)triggerClickedEvent {
	NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
	[self event_clicked_pushed:nil];
	[pool release];
}

- (id) buttonClicked: (id) sender {
	[self performSelectorInBackground:@selector(triggerClickedEvent) withObject:nil];
	return nil;
}

 
-(OCLString*) initial_text {
	/* ==================================================
	 * ''
	 * ================================================== */
	
	OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@""];
	
	return v0;
}

-(OCLString*) _text {
	if (self->_text_initialized == YES) {
		return _text;
	} else { 
		[self set_text:[self initial_text]];
	}

	self->_text_initialized = YES;
	return _text;
}


 
-(void) set_text:(OCLString*) value {
	 	if (self->_text!= nil && self->_text!= (OCLString*) [NSNull null]) {
		[self->_text release];
	}
	self->_text = value;
	if (self->_text!= nil && self->_text!= (OCLString*) [NSNull null]) {
		[self->_text retain];
	}
	self->_text_initialized = YES;
	
	[self onPropertyChange:@"text" newValue:value];
}






 

 
-(void) event_clicked_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_clicked", @"GeneralGUI_Button");

		OCLTuple* parameters = [[OCLTuple alloc] init];

		[self onEvent:@"clicked" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges
		NSEnumerator* MobileLibraryGUI_SearchController_searchClicked_edge0_enum = [self->MobileLibraryGUI_SearchController_searchButton_back objectEnumerator];
		MobileLibraryGUI_SearchController* MobileLibraryGUI_SearchController_searchClicked_edge0_target;
		while ((MobileLibraryGUI_SearchController_searchClicked_edge0_target = [MobileLibraryGUI_SearchController_searchClicked_edge0_enum nextObject]) != nil) {
		    [MobileLibraryGUI_SearchController_searchClicked_edge0_target event_searchClicked_pulled_edge0:changes parentInstance:self ];
		}

		NSEnumerator* MobileLibraryGUI_LoginController_authenticate_edge0_enum = [self->MobileLibraryGUI_LoginController_loginButton_back objectEnumerator];
		MobileLibraryGUI_LoginController* MobileLibraryGUI_LoginController_authenticate_edge0_target;
		while ((MobileLibraryGUI_LoginController_authenticate_edge0_target = [MobileLibraryGUI_LoginController_authenticate_edge0_enum nextObject]) != nil) {
		    [MobileLibraryGUI_LoginController_authenticate_edge0_target event_authenticate_pulled_edge0:changes parentInstance:self ];
		}



		 	
		// Trigger local edges


		 
		 // Process impacts relationships


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 




 
-(void)onPropertyChange_async:(NSDictionary*)parameters {
	NSString* propertyName = [parameters objectForKey:@"propertyName"];
	id value = [parameters objectForKey:@"value"];

	if ([propertyName isEqual:@"text"]) {
		if (value != nil && value != [NSNull null]){
			OCLString *text = (OCLString *) value;
			[self->binding setTitle:text->string forState:UIControlStateNormal];
		}
	}
	[parameters release];
}

-(void)onPropertyChange:(NSString*)propertyName newValue:(id) value {
	NSMutableDictionary* parameters = [[NSMutableDictionary alloc] init];
	[parameters setValue:propertyName forKey:@"propertyName"];
	[parameters setValue:value forKey:@"value"];
	[parameters retain];
	[self performSelectorOnMainThread:@selector(onPropertyChange_async:) withObject:parameters waitUntilDone:NO];
}

 
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters{
}

 
-(id) getBinding {
	return self->binding;
}

 
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value {
}


@end 


