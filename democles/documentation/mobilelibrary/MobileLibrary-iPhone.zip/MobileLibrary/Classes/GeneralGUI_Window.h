 
 
 
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "OCLTypes.h"
#import "IBinding.h"

@class PropertyChangeList;
@class MobileLibraryGUI_StartController;
@class MobileLibraryGUI_SearchResultsController;
@class MobileLibraryGUI_BookDetailController;


 
#import "AppWindow.h"

 
@interface GeneralGUI_Window : OCLAny <IBinding>
{
	 
	OCLSequence* _seqGUIElements;
	BOOL _seqGUIElements_initialized;
	OCLString* _title;
	BOOL _title_initialized;


@public
	NSMutableArray *MobileLibraryGUI_StartController_window_back;
	NSMutableArray *MobileLibraryGUI_SearchResultsController_window_back;
	NSMutableArray *MobileLibraryGUI_BookDetailController_window_back;


	
	@protected
	UIViewController *binding;
	BOOL rootControllerAdded;
}

 
-(GeneralGUI_Window*)init;
-(GeneralGUI_Window*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(OCLSequence*) _seqGUIElements;
-(OCLSequence*) initial_seqGUIElements;
-(void) set_seqGUIElements:(OCLSequence*) value;
-(OCLString*) _title;
-(OCLString*) initial_title;
-(void) set_title:(OCLString*) value;

-(void) event_closeWindow_pushed:(PropertyChangeList*) changes ;

 
-(id) getBinding;
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value;
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters;
-(void) onPropertyChange: (NSString*)propertyName newValue:(id<OCLAny>)value;


@end


