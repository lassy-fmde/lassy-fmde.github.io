 
 
 
#import <Foundation/Foundation.h>
#import "OCLTypes.h"

@class PropertyChangeList;
@class Library_Book;
@class LibraryPersistence_LibraryLoader;


 
 
@interface Library_Author : OCLAny  
 {
	 
	OCLString* _name;
	BOOL _name_initialized;
	OCLString* _authorId;
	BOOL _authorId_initialized;


@public
	NSMutableArray *Library_Book_authors_back;
	NSMutableArray *LibraryPersistence_LibraryLoader_authors_back;


}

 
-(Library_Author*)init;
-(Library_Author*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(OCLString*) _name;
-(OCLString*) initial_name;
-(void) set_name:(OCLString*) value;
-(OCLString*) _authorId;
-(OCLString*) initial_authorId;
-(void) set_authorId:(OCLString*) value;



@end


