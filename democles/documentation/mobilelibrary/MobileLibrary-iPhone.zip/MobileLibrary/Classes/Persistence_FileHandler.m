 
 
 
#import "Persistence_FileHandler.h"
#import "PropertyChangeList.h"
#import "LibraryPersistence_LibraryLoader.h"


 
@implementation Persistence_FileHandler

 
- (Persistence_FileHandler*) init {
	self = [super init];
	 
	self->LibraryPersistence_LibraryLoader_saveBorrowsFileHandler_back = [[NSMutableArray alloc] init];
	self->LibraryPersistence_LibraryLoader_saveToCollectFileHandler_back = [[NSMutableArray alloc] init];
	self->LibraryPersistence_LibraryLoader_toCollectFileHandler_back = [[NSMutableArray alloc] init];
	self->LibraryPersistence_LibraryLoader_authorFileHandler_back = [[NSMutableArray alloc] init];
	self->LibraryPersistence_LibraryLoader_memberFileHandler_back = [[NSMutableArray alloc] init];
	self->LibraryPersistence_LibraryLoader_bookFileHandler_back = [[NSMutableArray alloc] init];
	self->LibraryPersistence_LibraryLoader_copyFileHandler_back = [[NSMutableArray alloc] init];
	self->LibraryPersistence_LibraryLoader_saveCopiesFileHandler_back = [[NSMutableArray alloc] init];
	self->LibraryPersistence_LibraryLoader_borrowsFileHandler_back = [[NSMutableArray alloc] init];


	return self;
}

 
- (Persistence_FileHandler*) initWithValues: (OCLTuple*) values {
	self = [super init];
	 

	self->LibraryPersistence_LibraryLoader_saveBorrowsFileHandler_back = [[NSMutableArray alloc] init];
	self->LibraryPersistence_LibraryLoader_saveToCollectFileHandler_back = [[NSMutableArray alloc] init];
	self->LibraryPersistence_LibraryLoader_toCollectFileHandler_back = [[NSMutableArray alloc] init];
	self->LibraryPersistence_LibraryLoader_authorFileHandler_back = [[NSMutableArray alloc] init];
	self->LibraryPersistence_LibraryLoader_memberFileHandler_back = [[NSMutableArray alloc] init];
	self->LibraryPersistence_LibraryLoader_bookFileHandler_back = [[NSMutableArray alloc] init];
	self->LibraryPersistence_LibraryLoader_copyFileHandler_back = [[NSMutableArray alloc] init];
	self->LibraryPersistence_LibraryLoader_saveCopiesFileHandler_back = [[NSMutableArray alloc] init];
	self->LibraryPersistence_LibraryLoader_borrowsFileHandler_back = [[NSMutableArray alloc] init];


	
	return self;
}

 
- (void) dealloc {

	[self->LibraryPersistence_LibraryLoader_saveBorrowsFileHandler_back release];
	[self->LibraryPersistence_LibraryLoader_saveToCollectFileHandler_back release];
	[self->LibraryPersistence_LibraryLoader_toCollectFileHandler_back release];
	[self->LibraryPersistence_LibraryLoader_authorFileHandler_back release];
	[self->LibraryPersistence_LibraryLoader_memberFileHandler_back release];
	[self->LibraryPersistence_LibraryLoader_bookFileHandler_back release];
	[self->LibraryPersistence_LibraryLoader_copyFileHandler_back release];
	[self->LibraryPersistence_LibraryLoader_saveCopiesFileHandler_back release];
	[self->LibraryPersistence_LibraryLoader_borrowsFileHandler_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"Persistence::FileHandler\" retainCount=\"%i\">\n", self, [self retainCount]];
	
	[res appendString:@"</instance>\n"];
	return res;
}

 


 






 

 
-(void) event_openFile_pushed:(PropertyChangeList*) changes  p_filename: (OCLString*) p_filename{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_openFile", @"Persistence_FileHandler");

		OCLTuple* parameters = [[OCLTuple alloc] init];
		[parameters addItemNamed:@"filename" withValue:p_filename]; 

		[self onEvent:@"openFile" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_fileOpened_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_fileOpened", @"Persistence_FileHandler");

		OCLTuple* parameters = [[OCLTuple alloc] init];

		[self onEvent:@"fileOpened" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_lineread_pushed:(PropertyChangeList*) changes  p_line: (OCLString*) p_line{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_lineread", @"Persistence_FileHandler");

		OCLTuple* parameters = [[OCLTuple alloc] init];
		[parameters addItemNamed:@"line" withValue:p_line]; 

		[self onEvent:@"lineread" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges
		NSEnumerator* LibraryPersistence_LibraryLoader_authorsLineRead_edge0_enum = [self->LibraryPersistence_LibraryLoader_authorFileHandler_back objectEnumerator];
		LibraryPersistence_LibraryLoader* LibraryPersistence_LibraryLoader_authorsLineRead_edge0_target;
		while ((LibraryPersistence_LibraryLoader_authorsLineRead_edge0_target = [LibraryPersistence_LibraryLoader_authorsLineRead_edge0_enum nextObject]) != nil) {
		    [LibraryPersistence_LibraryLoader_authorsLineRead_edge0_target event_authorsLineRead_pulled_edge0:changes parentInstance:self p_line:p_line ];
		}

		NSEnumerator* LibraryPersistence_LibraryLoader_toCollectLineRead_edge0_enum = [self->LibraryPersistence_LibraryLoader_toCollectFileHandler_back objectEnumerator];
		LibraryPersistence_LibraryLoader* LibraryPersistence_LibraryLoader_toCollectLineRead_edge0_target;
		while ((LibraryPersistence_LibraryLoader_toCollectLineRead_edge0_target = [LibraryPersistence_LibraryLoader_toCollectLineRead_edge0_enum nextObject]) != nil) {
		    [LibraryPersistence_LibraryLoader_toCollectLineRead_edge0_target event_toCollectLineRead_pulled_edge0:changes parentInstance:self p_line:p_line ];
		}

		NSEnumerator* LibraryPersistence_LibraryLoader_copyLineRead_edge0_enum = [self->LibraryPersistence_LibraryLoader_copyFileHandler_back objectEnumerator];
		LibraryPersistence_LibraryLoader* LibraryPersistence_LibraryLoader_copyLineRead_edge0_target;
		while ((LibraryPersistence_LibraryLoader_copyLineRead_edge0_target = [LibraryPersistence_LibraryLoader_copyLineRead_edge0_enum nextObject]) != nil) {
		    [LibraryPersistence_LibraryLoader_copyLineRead_edge0_target event_copyLineRead_pulled_edge0:changes parentInstance:self p_line:p_line ];
		}

		NSEnumerator* LibraryPersistence_LibraryLoader_borrowsLineRead_edge0_enum = [self->LibraryPersistence_LibraryLoader_borrowsFileHandler_back objectEnumerator];
		LibraryPersistence_LibraryLoader* LibraryPersistence_LibraryLoader_borrowsLineRead_edge0_target;
		while ((LibraryPersistence_LibraryLoader_borrowsLineRead_edge0_target = [LibraryPersistence_LibraryLoader_borrowsLineRead_edge0_enum nextObject]) != nil) {
		    [LibraryPersistence_LibraryLoader_borrowsLineRead_edge0_target event_borrowsLineRead_pulled_edge0:changes parentInstance:self p_line:p_line ];
		}

		NSEnumerator* LibraryPersistence_LibraryLoader_memberLineRead_edge0_enum = [self->LibraryPersistence_LibraryLoader_memberFileHandler_back objectEnumerator];
		LibraryPersistence_LibraryLoader* LibraryPersistence_LibraryLoader_memberLineRead_edge0_target;
		while ((LibraryPersistence_LibraryLoader_memberLineRead_edge0_target = [LibraryPersistence_LibraryLoader_memberLineRead_edge0_enum nextObject]) != nil) {
		    [LibraryPersistence_LibraryLoader_memberLineRead_edge0_target event_memberLineRead_pulled_edge0:changes parentInstance:self p_line:p_line ];
		}

		NSEnumerator* LibraryPersistence_LibraryLoader_bookLineRead_edge0_enum = [self->LibraryPersistence_LibraryLoader_bookFileHandler_back objectEnumerator];
		LibraryPersistence_LibraryLoader* LibraryPersistence_LibraryLoader_bookLineRead_edge0_target;
		while ((LibraryPersistence_LibraryLoader_bookLineRead_edge0_target = [LibraryPersistence_LibraryLoader_bookLineRead_edge0_enum nextObject]) != nil) {
		    [LibraryPersistence_LibraryLoader_bookLineRead_edge0_target event_bookLineRead_pulled_edge0:changes parentInstance:self p_line:p_line ];
		}



		 	
		// Trigger local edges


		 
		 // Process impacts relationships


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_fileClosed_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_fileClosed", @"Persistence_FileHandler");

		OCLTuple* parameters = [[OCLTuple alloc] init];

		[self onEvent:@"fileClosed" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges
		NSEnumerator* LibraryPersistence_LibraryLoader_copyFileClosed_edge0_enum = [self->LibraryPersistence_LibraryLoader_copyFileHandler_back objectEnumerator];
		LibraryPersistence_LibraryLoader* LibraryPersistence_LibraryLoader_copyFileClosed_edge0_target;
		while ((LibraryPersistence_LibraryLoader_copyFileClosed_edge0_target = [LibraryPersistence_LibraryLoader_copyFileClosed_edge0_enum nextObject]) != nil) {
		    [LibraryPersistence_LibraryLoader_copyFileClosed_edge0_target event_copyFileClosed_pulled_edge0:changes parentInstance:self ];
		}

		NSEnumerator* LibraryPersistence_LibraryLoader_toCollectFileClosed_edge0_enum = [self->LibraryPersistence_LibraryLoader_toCollectFileHandler_back objectEnumerator];
		LibraryPersistence_LibraryLoader* LibraryPersistence_LibraryLoader_toCollectFileClosed_edge0_target;
		while ((LibraryPersistence_LibraryLoader_toCollectFileClosed_edge0_target = [LibraryPersistence_LibraryLoader_toCollectFileClosed_edge0_enum nextObject]) != nil) {
		    [LibraryPersistence_LibraryLoader_toCollectFileClosed_edge0_target event_toCollectFileClosed_pulled_edge0:changes parentInstance:self ];
		}

		NSEnumerator* LibraryPersistence_LibraryLoader_borrowsFileClosed_edge0_enum = [self->LibraryPersistence_LibraryLoader_borrowsFileHandler_back objectEnumerator];
		LibraryPersistence_LibraryLoader* LibraryPersistence_LibraryLoader_borrowsFileClosed_edge0_target;
		while ((LibraryPersistence_LibraryLoader_borrowsFileClosed_edge0_target = [LibraryPersistence_LibraryLoader_borrowsFileClosed_edge0_enum nextObject]) != nil) {
		    [LibraryPersistence_LibraryLoader_borrowsFileClosed_edge0_target event_borrowsFileClosed_pulled_edge0:changes parentInstance:self ];
		}

		NSEnumerator* LibraryPersistence_LibraryLoader_authorsFileClosed_edge0_enum = [self->LibraryPersistence_LibraryLoader_authorFileHandler_back objectEnumerator];
		LibraryPersistence_LibraryLoader* LibraryPersistence_LibraryLoader_authorsFileClosed_edge0_target;
		while ((LibraryPersistence_LibraryLoader_authorsFileClosed_edge0_target = [LibraryPersistence_LibraryLoader_authorsFileClosed_edge0_enum nextObject]) != nil) {
		    [LibraryPersistence_LibraryLoader_authorsFileClosed_edge0_target event_authorsFileClosed_pulled_edge0:changes parentInstance:self ];
		}

		NSEnumerator* LibraryPersistence_LibraryLoader_bookFileClosed_edge0_enum = [self->LibraryPersistence_LibraryLoader_bookFileHandler_back objectEnumerator];
		LibraryPersistence_LibraryLoader* LibraryPersistence_LibraryLoader_bookFileClosed_edge0_target;
		while ((LibraryPersistence_LibraryLoader_bookFileClosed_edge0_target = [LibraryPersistence_LibraryLoader_bookFileClosed_edge0_enum nextObject]) != nil) {
		    [LibraryPersistence_LibraryLoader_bookFileClosed_edge0_target event_bookFileClosed_pulled_edge0:changes parentInstance:self ];
		}

		NSEnumerator* LibraryPersistence_LibraryLoader_memberFileClosed_edge0_enum = [self->LibraryPersistence_LibraryLoader_memberFileHandler_back objectEnumerator];
		LibraryPersistence_LibraryLoader* LibraryPersistence_LibraryLoader_memberFileClosed_edge0_target;
		while ((LibraryPersistence_LibraryLoader_memberFileClosed_edge0_target = [LibraryPersistence_LibraryLoader_memberFileClosed_edge0_enum nextObject]) != nil) {
		    [LibraryPersistence_LibraryLoader_memberFileClosed_edge0_target event_memberFileClosed_pulled_edge0:changes parentInstance:self ];
		}



		 	
		// Trigger local edges


		 
		 // Process impacts relationships


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_saveString_pushed:(PropertyChangeList*) changes  p_filename: (OCLString*) p_filename p_content: (OCLString*) p_content{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_saveString", @"Persistence_FileHandler");

		OCLTuple* parameters = [[OCLTuple alloc] init];
		[parameters addItemNamed:@"filename" withValue:p_filename]; 
		[parameters addItemNamed:@"content" withValue:p_content]; 

		[self onEvent:@"saveString" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_stringSaved_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_stringSaved", @"Persistence_FileHandler");

		OCLTuple* parameters = [[OCLTuple alloc] init];

		[self onEvent:@"stringSaved" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 




 
-(void)onPropertyChange:(NSString*)propertyName newValue:(id) value {
}

 
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters{
	if ([eventName isEqual:@"openFile"]) {
		if (parameters != nil && parameters != [NSNull null]){
			OCLString* filename = (OCLString *) [parameters objectForKey:@"filename"];
			
			NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
			NSString *documentsDirectory = [paths objectAtIndex:0];
			
			NSString *filenameInDocuments = [documentsDirectory stringByAppendingPathComponent:filename->string];
			NSString *content = [NSString stringWithContentsOfFile:filenameInDocuments encoding:NSUTF8StringEncoding error: nil];
			if (content == nil) {
				NSBundle *mainBundle = [NSBundle mainBundle];
				NSString *filePath = [mainBundle pathForResource:[filename->string stringByDeletingPathExtension] ofType:[filename->string pathExtension]];
				content = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error: nil];
			}
			
			if (content != nil)
				[self event_fileOpened_pushed:nil];
			else
				return;
			
			NSString *trimmedString = [content stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
			NSArray *lines = [trimmedString componentsSeparatedByString: @"\n"];
			
			NSEnumerator *e = [lines objectEnumerator];
			id line;
			while (line = [e nextObject]){
				OCLString *oclLine = [[OCLString alloc] initWithString:(NSString *)line ];
				[self event_lineread_pushed:nil p_line: oclLine];
			}
						
			[self event_fileClosed_pushed:nil];
		}
	}
	if ([eventName isEqual:@"saveString"]) {
		if (parameters != nil && parameters != [NSNull null]){
			OCLString* filename = (OCLString *) [parameters objectForKey:@"filename"];
			OCLString* content = (OCLString *) [parameters objectForKey:@"content"];
			
			NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
			NSString *documentsDirectory = [paths objectAtIndex:0];
			
			NSString *filenameInDocuments = [documentsDirectory stringByAppendingPathComponent:filename->string];
			
			BOOL success = [content->string writeToFile:filenameInDocuments atomically:YES encoding:NSUTF8StringEncoding error: nil];
			// TODO error handling
			
			[self event_stringSaved_pushed:nil];
		}
	}
}

 
-(id) getBinding {
	return [NSNull null];
}

 
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value {
}


@end 


