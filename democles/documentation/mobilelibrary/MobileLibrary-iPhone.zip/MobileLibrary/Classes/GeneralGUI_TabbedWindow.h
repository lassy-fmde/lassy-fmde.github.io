 
 
 
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "OCLTypes.h"
#import "IBinding.h"

@class PropertyChangeList;
@class MobileLibraryGUI_ViewsController;



#import "AppWindow.h"
 
 
@interface GeneralGUI_TabbedWindow : OCLAny <IBinding, UITabBarDelegate>
{
	 
	OCLSequence* _views;
	BOOL _views_initialized;


@public
	NSMutableArray *MobileLibraryGUI_ViewsController_viewsWindow_back;


	
	@protected
	UIViewController* binding;
	UITabBar* tabBar;
}

 
-(GeneralGUI_TabbedWindow*)init;
-(GeneralGUI_TabbedWindow*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(OCLSequence*) _views;
-(OCLSequence*) initial_views;
-(void) set_views:(OCLSequence*) value;

-(void) event_closeWindow_pushed:(PropertyChangeList*) changes ;
-(void) event_addView_pushed:(PropertyChangeList*) changes p_view: (OCLAny*) p_view;
-(void) event_changeView_pushed:(PropertyChangeList*) changes p_index: (OCLInteger*) p_index p_view: (OCLAny*) p_view;

 
-(id) getBinding;
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value;
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters;
-(void) onPropertyChange: (NSString*)propertyName newValue:(id<OCLAny>)value;


@end


