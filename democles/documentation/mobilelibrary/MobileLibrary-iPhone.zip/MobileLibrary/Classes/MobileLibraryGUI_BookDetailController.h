 
 
 
#import <Foundation/Foundation.h>
#import "OCLTypes.h"

@class PropertyChangeList;
@class GeneralGUI_MsgDialog;
@class GeneralGUI_ConfirmationDialog;
@class MobileLibraryGUI_BookDetailController;
@class Library_Member;
@class Library_Book;
@class GeneralGUI_SelectionList;
@class GeneralGUI_Window;
@class Library_Copy;
@class GeneralGUI_Label;
@class MobileLibraryGUI_SearchResultsController;


 
 
@interface MobileLibraryGUI_BookDetailController : OCLAny  
 {
	 
	GeneralGUI_Label* _titleLabel;
	BOOL _titleLabel_initialized;
	GeneralGUI_Label* _bookTitleLabel;
	BOOL _bookTitleLabel_initialized;
	GeneralGUI_Label* _authorLabel;
	BOOL _authorLabel_initialized;
	GeneralGUI_Label* _bookAuthorLabel;
	BOOL _bookAuthorLabel_initialized;
	GeneralGUI_Label* _isbnLabel;
	BOOL _isbnLabel_initialized;
	GeneralGUI_Label* _bookIsbnLabel;
	BOOL _bookIsbnLabel_initialized;
	OCLString* _windowTitle;
	BOOL _windowTitle_initialized;
	GeneralGUI_SelectionList* _bookCopies;
	BOOL _bookCopies_initialized;
	GeneralGUI_Label* _bookCopiesLabel;
	BOOL _bookCopiesLabel_initialized;
	GeneralGUI_Window* _window;
	BOOL _window_initialized;
	Library_Copy* _selectedCopy;
	BOOL _selectedCopy_initialized;
	Library_Book* _currBook;
	BOOL _currBook_initialized;
	GeneralGUI_ConfirmationDialog* _yesNoMsg;
	BOOL _yesNoMsg_initialized;
	Library_Member* _currMember;
	BOOL _currMember_initialized;
	OCLString* _mode;
	BOOL _mode_initialized;
	GeneralGUI_MsgDialog* _msg;
	BOOL _msg_initialized;
	OCLString* _ackStatus;
	BOOL _ackStatus_initialized;


@public
	NSMutableArray *MobileLibraryGUI_SearchResultsController_detailsWindow_back;


}

 
-(MobileLibraryGUI_BookDetailController*)init;
-(MobileLibraryGUI_BookDetailController*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(GeneralGUI_Label*) _titleLabel;
-(GeneralGUI_Label*) initial_titleLabel;
-(void) set_titleLabel:(GeneralGUI_Label*) value;
-(GeneralGUI_Label*) _bookTitleLabel;
-(GeneralGUI_Label*) initial_bookTitleLabel;
-(void) set_bookTitleLabel:(GeneralGUI_Label*) value;
-(GeneralGUI_Label*) _authorLabel;
-(GeneralGUI_Label*) initial_authorLabel;
-(void) set_authorLabel:(GeneralGUI_Label*) value;
-(GeneralGUI_Label*) _bookAuthorLabel;
-(GeneralGUI_Label*) initial_bookAuthorLabel;
-(void) set_bookAuthorLabel:(GeneralGUI_Label*) value;
-(GeneralGUI_Label*) _isbnLabel;
-(GeneralGUI_Label*) initial_isbnLabel;
-(void) set_isbnLabel:(GeneralGUI_Label*) value;
-(GeneralGUI_Label*) _bookIsbnLabel;
-(GeneralGUI_Label*) initial_bookIsbnLabel;
-(void) set_bookIsbnLabel:(GeneralGUI_Label*) value;
-(OCLString*) _windowTitle;
-(OCLString*) initial_windowTitle;
-(void) set_windowTitle:(OCLString*) value;
-(GeneralGUI_SelectionList*) _bookCopies;
-(GeneralGUI_SelectionList*) initial_bookCopies;
-(void) set_bookCopies:(GeneralGUI_SelectionList*) value;
-(GeneralGUI_Label*) _bookCopiesLabel;
-(GeneralGUI_Label*) initial_bookCopiesLabel;
-(void) set_bookCopiesLabel:(GeneralGUI_Label*) value;
-(GeneralGUI_Window*) _window;
-(GeneralGUI_Window*) initial_window;
-(void) set_window:(GeneralGUI_Window*) value;
-(Library_Copy*) _selectedCopy;
-(Library_Copy*) initial_selectedCopy;
-(void) set_selectedCopy:(Library_Copy*) value;
-(Library_Book*) _currBook;
-(Library_Book*) initial_currBook;
-(void) set_currBook:(Library_Book*) value;
-(GeneralGUI_ConfirmationDialog*) _yesNoMsg;
-(GeneralGUI_ConfirmationDialog*) initial_yesNoMsg;
-(void) set_yesNoMsg:(GeneralGUI_ConfirmationDialog*) value;
-(Library_Member*) _currMember;
-(Library_Member*) initial_currMember;
-(void) set_currMember:(Library_Member*) value;
-(OCLString*) _mode;
-(OCLString*) initial_mode;
-(void) set_mode:(OCLString*) value;
-(GeneralGUI_MsgDialog*) _msg;
-(GeneralGUI_MsgDialog*) initial_msg;
-(void) set_msg:(GeneralGUI_MsgDialog*) value;
-(OCLString*) _ackStatus;
-(OCLString*) initial_ackStatus;
-(void) set_ackStatus:(OCLString*) value;

-(void) event_bookCopyItemSelected_pushed:(PropertyChangeList*) changes p_index: (OCLInteger*) p_index;
-(void) event_bookCopyItemSelected_pulled_edge0:(PropertyChangeList*)changes parentInstance:(GeneralGUI_SelectionList*)parentInstance p_index:(OCLInteger*)p_index ;
-(void) event_refreshBookCopiesData_pushed:(PropertyChangeList*) changes p_copiesData: (OCLSequence*) p_copiesData;
-(void) event_showConfirmReserveMsg_pushed:(PropertyChangeList*) changes ;
-(void) event_reserveConfAck_pushed:(PropertyChangeList*) changes ;
-(void) event_reserveConfAck_pulled_edge0:(PropertyChangeList*)changes parentInstance:(GeneralGUI_ConfirmationDialog*)parentInstance ;
-(void) event_sessionStarted_pushed:(PropertyChangeList*) changes p_m: (Library_Member*) p_m;
-(void) event_reserveCopyOk_pushed:(PropertyChangeList*) changes ;
-(void) event_reserveCopyNotOk_pushed:(PropertyChangeList*) changes ;
-(void) event_showCannotReserveCopyMsg_pushed:(PropertyChangeList*) changes ;
-(void) event_copyReserved_pushed:(PropertyChangeList*) changes ;
-(void) event_copyReserved_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Library_Copy*)parentInstance ;
-(void) event_showReserveOkMsg_pushed:(PropertyChangeList*) changes ;
-(void) event_reserveAck_pushed:(PropertyChangeList*) changes ;
-(void) event_reserveAck_pulled_edge0:(PropertyChangeList*)changes parentInstance:(GeneralGUI_MsgDialog*)parentInstance ;
-(void) event_addReservedToMember_pushed:(PropertyChangeList*) changes ;
-(void) event_reserveFailed_pushed:(PropertyChangeList*) changes ;
-(void) event_reserveFailed_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Library_Copy*)parentInstance ;
-(void) event_showReserveFailedMsg_pushed:(PropertyChangeList*) changes ;
-(void) event_setToNotWaiting_pushed:(PropertyChangeList*) changes ;
-(void) event_refreshAndSave_pushed:(PropertyChangeList*) changes ;


@end


