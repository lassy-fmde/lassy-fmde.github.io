 
 
 
#import "Library_Book.h"
#import "PropertyChangeList.h"
#import "Library_Author.h"
#import "Library_Copy.h"
#import "MobileLibraryGUI_SearchController.h"
#import "LibraryPersistence_LibraryLoader.h"
#import "MobileLibraryGUI_BookDetailController.h"
#import "Library_Library.h"


 
@implementation Library_Book

 
- (Library_Book*) init {
	self = [super init];
	 
	self->MobileLibraryGUI_SearchController_booksFound_back = [[NSMutableArray alloc] init];
	self->LibraryPersistence_LibraryLoader_books_back = [[NSMutableArray alloc] init];
	self->Library_Copy_book_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_BookDetailController_currBook_back = [[NSMutableArray alloc] init];
	self->Library_Library_catalogue_back = [[NSMutableArray alloc] init];

	[self set_authors: [self _authors]];
	[self set_title: [self _title]];
	[self set_isbn: [self _isbn]];
	[self set_copies: [self _copies]];
	[self set_bookId: [self _bookId]];

	return self;
}

 
- (Library_Book*) initWithValues: (OCLTuple*) values {
	self = [super init];
	 
	self->_authors_initialized = NO;
	self->_title_initialized = NO;
	self->_isbn_initialized = NO;
	self->_copies_initialized = NO;
	self->_bookId_initialized = NO;

	self->MobileLibraryGUI_SearchController_booksFound_back = [[NSMutableArray alloc] init];
	self->LibraryPersistence_LibraryLoader_books_back = [[NSMutableArray alloc] init];
	self->Library_Copy_book_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_BookDetailController_currBook_back = [[NSMutableArray alloc] init];
	self->Library_Library_catalogue_back = [[NSMutableArray alloc] init];

	OCLSet* _authors_initialValue = (OCLSet*) [values objectForKey:@"authors"];
	if (_authors_initialValue == nil) {
		_authors_initialValue = [self _authors];
	}
	[self set_authors:_authors_initialValue];
	OCLString* _title_initialValue = (OCLString*) [values objectForKey:@"title"];
	if (_title_initialValue == nil) {
		_title_initialValue = [self _title];
	}
	[self set_title:_title_initialValue];
	OCLString* _isbn_initialValue = (OCLString*) [values objectForKey:@"isbn"];
	if (_isbn_initialValue == nil) {
		_isbn_initialValue = [self _isbn];
	}
	[self set_isbn:_isbn_initialValue];
	OCLSet* _copies_initialValue = (OCLSet*) [values objectForKey:@"copies"];
	if (_copies_initialValue == nil) {
		_copies_initialValue = [self _copies];
	}
	[self set_copies:_copies_initialValue];
	OCLString* _bookId_initialValue = (OCLString*) [values objectForKey:@"bookId"];
	if (_bookId_initialValue == nil) {
		_bookId_initialValue = [self _bookId];
	}
	[self set_bookId:_bookId_initialValue];

	
	return self;
}

 
- (void) dealloc {
	if (self->_authors != nil && self->_authors != (OCLSet*) [NSNull null]) [self->_authors release];
	if (self->_title != nil && self->_title != (OCLString*) [NSNull null]) [self->_title release];
	if (self->_isbn != nil && self->_isbn != (OCLString*) [NSNull null]) [self->_isbn release];
	if (self->_copies != nil && self->_copies != (OCLSet*) [NSNull null]) [self->_copies release];
	if (self->_bookId != nil && self->_bookId != (OCLString*) [NSNull null]) [self->_bookId release];

	[self->MobileLibraryGUI_SearchController_booksFound_back release];
	[self->LibraryPersistence_LibraryLoader_books_back release];
	[self->Library_Copy_book_back release];
	[self->MobileLibraryGUI_BookDetailController_currBook_back release];
	[self->Library_Library_catalogue_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"Library::Book\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"authors\" type=\"Set\">\n"];
	[res appendFormat:@"%@\n", [self _authors]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"title\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _title]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"isbn\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _isbn]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"copies\" type=\"Set\">\n"];
	[res appendFormat:@"%@\n", [self _copies]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"bookId\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _bookId]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
-(OCLSet*) initial_authors {
	/* ==================================================
	 * Set {}
	 * ================================================== */
	
	OCLSet* v0 = [(OCLSet*)[OCLSet alloc] init];
	
	return v0;
}

-(OCLSet*) _authors {
	if (self->_authors_initialized == YES) {
		return _authors;
	} else { 
		[self set_authors:[self initial_authors]];
	}

	self->_authors_initialized = YES;
	return _authors;
}
-(OCLString*) initial_title {
	/* ==================================================
	 * null
	 * ================================================== */
	
	OCLString* v0 = [NSNull null];
	
	return v0;
}

-(OCLString*) _title {
	if (self->_title_initialized == YES) {
		return _title;
	} else { 
		[self set_title:[self initial_title]];
	}

	self->_title_initialized = YES;
	return _title;
}
-(OCLString*) initial_isbn {
	/* ==================================================
	 * null
	 * ================================================== */
	
	OCLString* v0 = [NSNull null];
	
	return v0;
}

-(OCLString*) _isbn {
	if (self->_isbn_initialized == YES) {
		return _isbn;
	} else { 
		[self set_isbn:[self initial_isbn]];
	}

	self->_isbn_initialized = YES;
	return _isbn;
}
-(OCLSet*) initial_copies {
	/* ==================================================
	 * Set {}
	 * ================================================== */
	
	OCLSet* v0 = [(OCLSet*)[OCLSet alloc] init];
	
	return v0;
}

-(OCLSet*) _copies {
	if (self->_copies_initialized == YES) {
		return _copies;
	} else { 
		[self set_copies:[self initial_copies]];
	}

	self->_copies_initialized = YES;
	return _copies;
}
-(OCLString*) initial_bookId {
	/* ==================================================
	 * null
	 * ================================================== */
	
	OCLString* v0 = [NSNull null];
	
	return v0;
}

-(OCLString*) _bookId {
	if (self->_bookId_initialized == YES) {
		return _bookId;
	} else { 
		[self set_bookId:[self initial_bookId]];
	}

	self->_bookId_initialized = YES;
	return _bookId;
}


 
-(void) set_title:(OCLString*) value {
	 	if (self->_title!= nil && self->_title!= (OCLString*) [NSNull null]) {
		[self->_title release];
	}
	self->_title = value;
	if (self->_title!= nil && self->_title!= (OCLString*) [NSNull null]) {
		[self->_title retain];
	}
	self->_title_initialized = YES;

}
-(void) set_isbn:(OCLString*) value {
	 	if (self->_isbn!= nil && self->_isbn!= (OCLString*) [NSNull null]) {
		[self->_isbn release];
	}
	self->_isbn = value;
	if (self->_isbn!= nil && self->_isbn!= (OCLString*) [NSNull null]) {
		[self->_isbn retain];
	}
	self->_isbn_initialized = YES;

}
-(void) set_bookId:(OCLString*) value {
	 	if (self->_bookId!= nil && self->_bookId!= (OCLString*) [NSNull null]) {
		[self->_bookId release];
	}
	self->_bookId = value;
	if (self->_bookId!= nil && self->_bookId!= (OCLString*) [NSNull null]) {
		[self->_bookId retain];
	}
	self->_bookId_initialized = YES;

}




-(void) set_authors:(OCLSet*) value {
	 
	if (self->_authors!= nil && self->_authors!= (OCLSet*) [NSNull null]) {
		// Clear back pointer on old instance
		NSEnumerator* e = [self->_authors objectEnumerator];
		Library_Author* o;
		while ((o = [e nextObject]) != nil) {
			if (o != (Library_Author*)[NSNull null]) {
				NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)o valueForKey:@"Library_Book_authors_back"];
				[backpointers removeObject:self];
			}
		}
		[self->_authors release];
	}
	self->_authors = value;
	if (self->_authors!= nil && self->_authors!= (OCLSet*) [NSNull null]) {
		[self->_authors retain];
		// Add back pointer on new instance
		NSEnumerator* e = [self->_authors objectEnumerator];
		Library_Author* o;
		while ((o = [e nextObject]) != nil) {
			if (o != (Library_Author*)[NSNull null]) {
				NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)o valueForKey:@"Library_Book_authors_back"];
				[backpointers addObject:self];
			}
		}
	}
	self->_authors_initialized = YES;

}
-(void) set_copies:(OCLSet*) value {
	 
	if (self->_copies!= nil && self->_copies!= (OCLSet*) [NSNull null]) {
		// Clear back pointer on old instance
		NSEnumerator* e = [self->_copies objectEnumerator];
		Library_Copy* o;
		while ((o = [e nextObject]) != nil) {
			if (o != (Library_Copy*)[NSNull null]) {
				NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)o valueForKey:@"Library_Book_copies_back"];
				[backpointers removeObject:self];
			}
		}
		[self->_copies release];
	}
	self->_copies = value;
	if (self->_copies!= nil && self->_copies!= (OCLSet*) [NSNull null]) {
		[self->_copies retain];
		// Add back pointer on new instance
		NSEnumerator* e = [self->_copies objectEnumerator];
		Library_Copy* o;
		while ((o = [e nextObject]) != nil) {
			if (o != (Library_Copy*)[NSNull null]) {
				NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)o valueForKey:@"Library_Book_copies_back"];
				[backpointers addObject:self];
			}
		}
	}
	self->_copies_initialized = YES;

}


 
-(void) event_setCopies_pushed:(PropertyChangeList*) changes  p_copies: (OCLSet*) p_copies{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_setCopies", @"Library_Book");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * -- Generated impacts relationship code:
		 * copies
		 * ================================================== */
		
		OCLSet* v0 = p_copies;
		
		OCLSet* _copies_newValue = v0;
		[changes addChange:@selector(set_copies:) instance:self value:_copies_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 




 


@end 


