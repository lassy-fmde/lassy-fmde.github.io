#import <Foundation/Foundation.h>

@class OCLAny;

/*

Idiom/Pattern
-------------

Each event_pushed method takes a PropertyChangeList* as additional parameter.
Accordingly, each event_pulled method also takes one and forwards it to the
event_pushed method it calls.

Each event_pushed method starts with:

@try:
    if (propertyChangeList == nil) propertyChangeList = [[PropertyChangeList alloc] init];
    else [propertyChangeList retain];
    [propertyChangeList enter];


After each impacts calculation, the new value is added to the PropertyChangeList:

    [propertyChangeList addChange:property instance:self value:newValue];

The property can be passed as a name or as a (setter) selector. Possibly an IMP (implementation pointer)
can be used that encompasses instance and property setter.
The method ends with:

@finally:
    [propertyChangeList leave];
    [propertyChangeList release];  


PropertyChangeList methods
--------------------------

- init sets depth to 0
- enter increments depth
- leave decrements depth, checks if depth is zero, and applies all changes if it is.
- addChange adds a new value for a given property of a given instance to a list (as an object of an internal class).

Together with the afore-described idiom, this results in the following desirable behaviour:
- An event can be triggered by calling its _pushed method with a nil PropertyChangeList.
  In this case all property changes will be applied just before this event's method returns.
- A central entity that queues events can pass a PropertyChangeList that has already been entered.
  The event propagation will append its property changes to the given list. The caller can then
  apply property changes at its leisure by simple calling leave on the PropertyChangeList.
- The PropertyChangeList can simply check in addChange() if a given property is already in the
  list. If so, we have a MultipleModification runtime error.

*/

@interface PropertyChangeList : NSObject {

    int depth;
    NSMutableArray* changes;
}

-(PropertyChangeList*)init;
-(void)dealloc;

-(void)enter;
-(void)leave;
-(void)addChange:(SEL)propertySelector instance:(OCLAny*)instance value:(OCLAny*)newValue;

-(NSString*)description;
@end
