 
 
 
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "OCLTypes.h"
#import "IBinding.h"

@class PropertyChangeList;
@class MobileLibraryGUI_LoginController;
@class MobileLibraryGUI_SearchController;


 
 
@interface GeneralGUI_Textfield : OCLAny <IBinding, UITextFieldDelegate>
{
	 
	OCLString* _text;
	BOOL _text_initialized;


@public
	NSMutableArray *MobileLibraryGUI_LoginController_passwordField_back;
	NSMutableArray *MobileLibraryGUI_SearchController_searchField_back;
	NSMutableArray *MobileLibraryGUI_LoginController_libraryNoField_back;


	
	@protected
	UITextField* binding;
}

 
-(GeneralGUI_Textfield*)init;
-(GeneralGUI_Textfield*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(OCLString*) _text;
-(OCLString*) initial_text;
-(void) set_text:(OCLString*) value;

-(void) event_setText_pushed:(PropertyChangeList*) changes p_text: (OCLString*) p_text;

 
-(id) getBinding;
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value;
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters;
-(void) onPropertyChange: (NSString*)propertyName newValue:(id<OCLAny>)value;


@end


