#import <Foundation/Foundation.h>
#import "OCLOrderedSet.h"
#import "OCLAny.h"
#import "OCLBoolean.h"
#import "OCLInteger.h"

@implementation OCLOrderedSet

-(OCLOrderedSet*)init {
	self = (OCLOrderedSet*)[super init];
	array = [[NSMutableArray alloc] init];
	return self;
}

-(void)dealloc {
	[array release];
	[super dealloc];
}

-(BOOL)isEqual:(id)other {
	BOOL res;
	if ([self isCompatibleType:other]) {
		OCLOrderedSet* otherSet = (OCLOrderedSet*)other;
		res = [self->array isEqual:otherSet->array];
	} else {
		res = NO;
	}
	return res;
}

-(OCLOrderedSet*)newCollection {
	return [(OCLOrderedSet*)[OCLOrderedSet alloc] init];
}

-(void)add:(OCLAny*)object {
	if ([array containsObject:object]) {
		return;
	}
	[array addObject:object];
}

-(OCLInteger*)size {
	return [(OCLInteger*)[OCLInteger alloc] initWithValue:[array count]];
}

-(OCLBoolean*)includes:(OCLAny*)object {
	BOOL res = [array containsObject:object];
	return [(OCLBoolean*)[OCLBoolean alloc] initWithValue:res];
}

-(NSEnumerator*)objectEnumerator {
	return [array objectEnumerator];
}

-(NSString*)collectionName {
	return [NSString stringWithString:@"OrderedSet"];
}

-(OCLOrderedSet*)append:(OCLAny*)object {
	OCLOrderedSet* res = [[OCLOrderedSet alloc] init];
	[res->array setArray:self->array];

	[res add:object];	
	
	return res;
}

-(OCLOrderedSet*)prepend:(OCLAny*)object {
	OCLOrderedSet* res = [[OCLOrderedSet alloc] init];
	[res->array setArray:self->array];

	if (![res->array containsObject:object]) {
		[res->array insertObject:object atIndex:0];
	}	

	return res;
}

-(OCLOrderedSet*)insertAt:(OCLInteger*)index object:(OCLAny*)object {
	OCLOrderedSet* res = [[OCLOrderedSet alloc] init];
	[res->array setArray:self->array];
	
	if (![res->array containsObject:object]) {
		[res->array insertObject:object atIndex:(index->value - 1)];
	}	

	return res;	
}

-(OCLOrderedSet*)subOrderedSet:(OCLInteger*)lower upper:(OCLInteger*)upper {
	OCLOrderedSet* res = [[OCLOrderedSet alloc] init];
	
	NSRange range;
	range.location = lower->value - 1;
	range.length = upper->value - lower->value;
	
	NSIndexSet* indexSet = [NSIndexSet indexSetWithIndexesInRange:range];
	
	[res->array insertObjects:self->array atIndexes:indexSet];

	[indexSet release];
	return res;	
}

-(OCLAny*)at:(OCLInteger*)index {
	return [self->array objectAtIndex:(index->value - 1)];
}

-(OCLInteger*)indexOf:(OCLAny*)object {
	NSUInteger index = [self->array indexOfObject:object] + 1;
	return [(OCLInteger*)[OCLInteger alloc] initWithValue:index]; 
}

-(OCLAny*)first {
	return [self->array objectAtIndex:1];
}

-(OCLAny*)last {
	return [self->array lastObject];
}

// Set methods
-(OCLSet*)unionWithSet:(OCLSet*)other {
	OCLSet* res = [[OCLSet alloc] init];
	[res->set addObjectsFromArray:self->array]; // Adds elements of this set
	[res->set unionSet:other->set]; // Adds elements of other set
	return res;
}

// Base impl works for this.
/*-(OCLBag*)unionWithBag:(OCLBag*)other {
}*/


// Base impl works for this.
/*-(OCLSet*)intersectionWithSet:(OCLSet*)other {
}*/

// Base impl works for this.
/*-(OCLSet*)intersectionWithBag:(OCLBag*)other {
}*/

// Base imple works for this
//-(OCLSet*)n:(OCLSet*)other;

-(OCLSet*)including:(OCLAny*)object {
	OCLSet* res = [[OCLSet alloc] init];	
	[res->set addObjectsFromArray:self->array]; // Make copy of set
	[res add:object];
	
	return res;
}

-(OCLSet*)excluding:(OCLAny*)object {
	OCLSet* res = [[OCLSet alloc] init];	
	[res->set addObjectsFromArray:self->array]; // Make copy of set
	[res->set removeObject:object];
	
	return res;
}

-(OCLSet*)symmetricDifference:(OCLSet*)other {
	OCLSet* is = [[OCLSet alloc] init];
	[is->set addObjectsFromArray:self->array];
	[is->set intersectSet:other->set];
	
	OCLSet* res = [self unionWithSet:other];
	
	[res->set minusSet:is->set];
	[is release];

	return res;
}

-(OCLSet*)flatten {
	return [super flatten];
}

@end
