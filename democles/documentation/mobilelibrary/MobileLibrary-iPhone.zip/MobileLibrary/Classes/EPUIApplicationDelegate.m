#import "EPUIApplicationDelegate.h"
#import "Application_Main.h"

@implementation EPUIApplicationDelegate

-(EPUIApplicationDelegate*)init {
    self = [super init];
    return self;
}

-(void)initThread {
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];	
    self->mainInstance = [[Application_Main alloc] init];
    if ([self->mainInstance respondsToSelector:@selector(event_init_pushed:)] == YES ) {
        [self->mainInstance event_init_pushed:nil];
    }
	[pool release];
}

-(BOOL)application:(UIApplication*)application didFinishLaunchingWithOptions:(NSDictionary*)launchOptions {
	[self performSelectorInBackground:@selector(initThread) withObject:nil];
	return YES;
}

@end
