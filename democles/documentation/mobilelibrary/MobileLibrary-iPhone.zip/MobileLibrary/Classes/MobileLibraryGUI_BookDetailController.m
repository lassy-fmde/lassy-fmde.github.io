 
 
 
#import "MobileLibraryGUI_BookDetailController.h"
#import "PropertyChangeList.h"
#import "GeneralGUI_MsgDialog.h"
#import "GeneralGUI_ConfirmationDialog.h"
#import "MobileLibraryGUI_BookDetailController.h"
#import "Library_Member.h"
#import "Library_Book.h"
#import "GeneralGUI_SelectionList.h"
#import "GeneralGUI_Window.h"
#import "Library_Copy.h"
#import "GeneralGUI_Label.h"
#import "MobileLibraryGUI_SearchResultsController.h"


 
@implementation MobileLibraryGUI_BookDetailController

 
- (MobileLibraryGUI_BookDetailController*) init {
	self = [super init];
	 
	self->MobileLibraryGUI_SearchResultsController_detailsWindow_back = [[NSMutableArray alloc] init];

	[self set_titleLabel: [self _titleLabel]];
	[self set_bookTitleLabel: [self _bookTitleLabel]];
	[self set_authorLabel: [self _authorLabel]];
	[self set_bookAuthorLabel: [self _bookAuthorLabel]];
	[self set_isbnLabel: [self _isbnLabel]];
	[self set_bookIsbnLabel: [self _bookIsbnLabel]];
	[self set_windowTitle: [self _windowTitle]];
	[self set_bookCopies: [self _bookCopies]];
	[self set_bookCopiesLabel: [self _bookCopiesLabel]];
	[self set_window: [self _window]];
	[self set_selectedCopy: [self _selectedCopy]];
	[self set_currBook: [self _currBook]];
	[self set_yesNoMsg: [self _yesNoMsg]];
	[self set_currMember: [self _currMember]];
	[self set_mode: [self _mode]];
	[self set_msg: [self _msg]];
	[self set_ackStatus: [self _ackStatus]];

	return self;
}

 
- (MobileLibraryGUI_BookDetailController*) initWithValues: (OCLTuple*) values {
	self = [super init];
	 
	self->_titleLabel_initialized = NO;
	self->_bookTitleLabel_initialized = NO;
	self->_authorLabel_initialized = NO;
	self->_bookAuthorLabel_initialized = NO;
	self->_isbnLabel_initialized = NO;
	self->_bookIsbnLabel_initialized = NO;
	self->_windowTitle_initialized = NO;
	self->_bookCopies_initialized = NO;
	self->_bookCopiesLabel_initialized = NO;
	self->_window_initialized = NO;
	self->_selectedCopy_initialized = NO;
	self->_currBook_initialized = NO;
	self->_yesNoMsg_initialized = NO;
	self->_currMember_initialized = NO;
	self->_mode_initialized = NO;
	self->_msg_initialized = NO;
	self->_ackStatus_initialized = NO;

	self->MobileLibraryGUI_SearchResultsController_detailsWindow_back = [[NSMutableArray alloc] init];

	GeneralGUI_Label* _titleLabel_initialValue = (GeneralGUI_Label*) [values objectForKey:@"titleLabel"];
	if (_titleLabel_initialValue == nil) {
		_titleLabel_initialValue = [self _titleLabel];
	}
	[self set_titleLabel:_titleLabel_initialValue];
	GeneralGUI_Label* _bookTitleLabel_initialValue = (GeneralGUI_Label*) [values objectForKey:@"bookTitleLabel"];
	if (_bookTitleLabel_initialValue == nil) {
		_bookTitleLabel_initialValue = [self _bookTitleLabel];
	}
	[self set_bookTitleLabel:_bookTitleLabel_initialValue];
	GeneralGUI_Label* _authorLabel_initialValue = (GeneralGUI_Label*) [values objectForKey:@"authorLabel"];
	if (_authorLabel_initialValue == nil) {
		_authorLabel_initialValue = [self _authorLabel];
	}
	[self set_authorLabel:_authorLabel_initialValue];
	GeneralGUI_Label* _bookAuthorLabel_initialValue = (GeneralGUI_Label*) [values objectForKey:@"bookAuthorLabel"];
	if (_bookAuthorLabel_initialValue == nil) {
		_bookAuthorLabel_initialValue = [self _bookAuthorLabel];
	}
	[self set_bookAuthorLabel:_bookAuthorLabel_initialValue];
	GeneralGUI_Label* _isbnLabel_initialValue = (GeneralGUI_Label*) [values objectForKey:@"isbnLabel"];
	if (_isbnLabel_initialValue == nil) {
		_isbnLabel_initialValue = [self _isbnLabel];
	}
	[self set_isbnLabel:_isbnLabel_initialValue];
	GeneralGUI_Label* _bookIsbnLabel_initialValue = (GeneralGUI_Label*) [values objectForKey:@"bookIsbnLabel"];
	if (_bookIsbnLabel_initialValue == nil) {
		_bookIsbnLabel_initialValue = [self _bookIsbnLabel];
	}
	[self set_bookIsbnLabel:_bookIsbnLabel_initialValue];
	OCLString* _windowTitle_initialValue = (OCLString*) [values objectForKey:@"windowTitle"];
	if (_windowTitle_initialValue == nil) {
		_windowTitle_initialValue = [self _windowTitle];
	}
	[self set_windowTitle:_windowTitle_initialValue];
	GeneralGUI_SelectionList* _bookCopies_initialValue = (GeneralGUI_SelectionList*) [values objectForKey:@"bookCopies"];
	if (_bookCopies_initialValue == nil) {
		_bookCopies_initialValue = [self _bookCopies];
	}
	[self set_bookCopies:_bookCopies_initialValue];
	GeneralGUI_Label* _bookCopiesLabel_initialValue = (GeneralGUI_Label*) [values objectForKey:@"bookCopiesLabel"];
	if (_bookCopiesLabel_initialValue == nil) {
		_bookCopiesLabel_initialValue = [self _bookCopiesLabel];
	}
	[self set_bookCopiesLabel:_bookCopiesLabel_initialValue];
	GeneralGUI_Window* _window_initialValue = (GeneralGUI_Window*) [values objectForKey:@"window"];
	if (_window_initialValue == nil) {
		_window_initialValue = [self _window];
	}
	[self set_window:_window_initialValue];
	Library_Copy* _selectedCopy_initialValue = (Library_Copy*) [values objectForKey:@"selectedCopy"];
	if (_selectedCopy_initialValue == nil) {
		_selectedCopy_initialValue = [self _selectedCopy];
	}
	[self set_selectedCopy:_selectedCopy_initialValue];
	Library_Book* _currBook_initialValue = (Library_Book*) [values objectForKey:@"currBook"];
	if (_currBook_initialValue == nil) {
		_currBook_initialValue = [self _currBook];
	}
	[self set_currBook:_currBook_initialValue];
	GeneralGUI_ConfirmationDialog* _yesNoMsg_initialValue = (GeneralGUI_ConfirmationDialog*) [values objectForKey:@"yesNoMsg"];
	if (_yesNoMsg_initialValue == nil) {
		_yesNoMsg_initialValue = [self _yesNoMsg];
	}
	[self set_yesNoMsg:_yesNoMsg_initialValue];
	Library_Member* _currMember_initialValue = (Library_Member*) [values objectForKey:@"currMember"];
	if (_currMember_initialValue == nil) {
		_currMember_initialValue = [self _currMember];
	}
	[self set_currMember:_currMember_initialValue];
	OCLString* _mode_initialValue = (OCLString*) [values objectForKey:@"mode"];
	if (_mode_initialValue == nil) {
		_mode_initialValue = [self _mode];
	}
	[self set_mode:_mode_initialValue];
	GeneralGUI_MsgDialog* _msg_initialValue = (GeneralGUI_MsgDialog*) [values objectForKey:@"msg"];
	if (_msg_initialValue == nil) {
		_msg_initialValue = [self _msg];
	}
	[self set_msg:_msg_initialValue];
	OCLString* _ackStatus_initialValue = (OCLString*) [values objectForKey:@"ackStatus"];
	if (_ackStatus_initialValue == nil) {
		_ackStatus_initialValue = [self _ackStatus];
	}
	[self set_ackStatus:_ackStatus_initialValue];

	
	return self;
}

 
- (void) dealloc {
	if (self->_titleLabel != nil && self->_titleLabel != (GeneralGUI_Label*) [NSNull null]) [self->_titleLabel release];
	if (self->_bookTitleLabel != nil && self->_bookTitleLabel != (GeneralGUI_Label*) [NSNull null]) [self->_bookTitleLabel release];
	if (self->_authorLabel != nil && self->_authorLabel != (GeneralGUI_Label*) [NSNull null]) [self->_authorLabel release];
	if (self->_bookAuthorLabel != nil && self->_bookAuthorLabel != (GeneralGUI_Label*) [NSNull null]) [self->_bookAuthorLabel release];
	if (self->_isbnLabel != nil && self->_isbnLabel != (GeneralGUI_Label*) [NSNull null]) [self->_isbnLabel release];
	if (self->_bookIsbnLabel != nil && self->_bookIsbnLabel != (GeneralGUI_Label*) [NSNull null]) [self->_bookIsbnLabel release];
	if (self->_windowTitle != nil && self->_windowTitle != (OCLString*) [NSNull null]) [self->_windowTitle release];
	if (self->_bookCopies != nil && self->_bookCopies != (GeneralGUI_SelectionList*) [NSNull null]) [self->_bookCopies release];
	if (self->_bookCopiesLabel != nil && self->_bookCopiesLabel != (GeneralGUI_Label*) [NSNull null]) [self->_bookCopiesLabel release];
	if (self->_window != nil && self->_window != (GeneralGUI_Window*) [NSNull null]) [self->_window release];
	if (self->_selectedCopy != nil && self->_selectedCopy != (Library_Copy*) [NSNull null]) [self->_selectedCopy release];
	if (self->_currBook != nil && self->_currBook != (Library_Book*) [NSNull null]) [self->_currBook release];
	if (self->_yesNoMsg != nil && self->_yesNoMsg != (GeneralGUI_ConfirmationDialog*) [NSNull null]) [self->_yesNoMsg release];
	if (self->_currMember != nil && self->_currMember != (Library_Member*) [NSNull null]) [self->_currMember release];
	if (self->_mode != nil && self->_mode != (OCLString*) [NSNull null]) [self->_mode release];
	if (self->_msg != nil && self->_msg != (GeneralGUI_MsgDialog*) [NSNull null]) [self->_msg release];
	if (self->_ackStatus != nil && self->_ackStatus != (OCLString*) [NSNull null]) [self->_ackStatus release];

	[self->MobileLibraryGUI_SearchResultsController_detailsWindow_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"MobileLibraryGUI::BookDetailController\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"titleLabel\" type=\"GeneralGUI::Label\">\n"];
	[res appendFormat:@"%@\n", [self _titleLabel]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"bookTitleLabel\" type=\"GeneralGUI::Label\">\n"];
	[res appendFormat:@"%@\n", [self _bookTitleLabel]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"authorLabel\" type=\"GeneralGUI::Label\">\n"];
	[res appendFormat:@"%@\n", [self _authorLabel]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"bookAuthorLabel\" type=\"GeneralGUI::Label\">\n"];
	[res appendFormat:@"%@\n", [self _bookAuthorLabel]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"isbnLabel\" type=\"GeneralGUI::Label\">\n"];
	[res appendFormat:@"%@\n", [self _isbnLabel]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"bookIsbnLabel\" type=\"GeneralGUI::Label\">\n"];
	[res appendFormat:@"%@\n", [self _bookIsbnLabel]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"windowTitle\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _windowTitle]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"bookCopies\" type=\"GeneralGUI::SelectionList\">\n"];
	[res appendFormat:@"%@\n", [self _bookCopies]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"bookCopiesLabel\" type=\"GeneralGUI::Label\">\n"];
	[res appendFormat:@"%@\n", [self _bookCopiesLabel]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"window\" type=\"GeneralGUI::Window\">\n"];
	[res appendFormat:@"%@\n", [self _window]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"selectedCopy\" type=\"Library::Copy\">\n"];
	[res appendFormat:@"%@\n", [self _selectedCopy]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"currBook\" type=\"Library::Book\">\n"];
	[res appendFormat:@"%@\n", [self _currBook]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"yesNoMsg\" type=\"GeneralGUI::ConfirmationDialog\">\n"];
	[res appendFormat:@"%@\n", [self _yesNoMsg]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"currMember\" type=\"Library::Member\">\n"];
	[res appendFormat:@"%@\n", [self _currMember]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"mode\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _mode]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"msg\" type=\"GeneralGUI::MsgDialog\">\n"];
	[res appendFormat:@"%@\n", [self _msg]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"ackStatus\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _ackStatus]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
-(GeneralGUI_Label*) initial_titleLabel {
	/* ==================================================
	 * GeneralGUI::Label::create(Tuple { text = 'Title: ' })
	 * ================================================== */
	
	OCLString* v4 = [(OCLString*)[OCLString alloc] initWithString:@"Title: "];
	OCLString* v3 = v4;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"text" withValue:v3];
	GeneralGUI_Label* v0 = [(GeneralGUI_Label*)[GeneralGUI_Label alloc] initWithValues:v2];
	[v2 release];
	[v4 release];
	
	return v0;
}

-(GeneralGUI_Label*) _titleLabel {
	if (self->_titleLabel_initialized == YES) {
		return _titleLabel;
	} else { 
		[self set_titleLabel:[self initial_titleLabel]];
	}

	self->_titleLabel_initialized = YES;
	return _titleLabel;
}
-(GeneralGUI_Label*) initial_bookTitleLabel {
	/* ==================================================
	 * null
	 * ================================================== */
	
	GeneralGUI_Label* v0 = [NSNull null];
	
	return v0;
}

-(GeneralGUI_Label*) _bookTitleLabel {
	if (self->_bookTitleLabel_initialized == YES) {
		return _bookTitleLabel;
	} else { 
		[self set_bookTitleLabel:[self initial_bookTitleLabel]];
	}

	self->_bookTitleLabel_initialized = YES;
	return _bookTitleLabel;
}
-(GeneralGUI_Label*) initial_authorLabel {
	/* ==================================================
	 * GeneralGUI::Label::create(Tuple { text = 'Authors: ' })
	 * ================================================== */
	
	OCLString* v4 = [(OCLString*)[OCLString alloc] initWithString:@"Authors: "];
	OCLString* v3 = v4;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"text" withValue:v3];
	GeneralGUI_Label* v0 = [(GeneralGUI_Label*)[GeneralGUI_Label alloc] initWithValues:v2];
	[v2 release];
	[v4 release];
	
	return v0;
}

-(GeneralGUI_Label*) _authorLabel {
	if (self->_authorLabel_initialized == YES) {
		return _authorLabel;
	} else { 
		[self set_authorLabel:[self initial_authorLabel]];
	}

	self->_authorLabel_initialized = YES;
	return _authorLabel;
}
-(GeneralGUI_Label*) initial_bookAuthorLabel {
	/* ==================================================
	 * null
	 * ================================================== */
	
	GeneralGUI_Label* v0 = [NSNull null];
	
	return v0;
}

-(GeneralGUI_Label*) _bookAuthorLabel {
	if (self->_bookAuthorLabel_initialized == YES) {
		return _bookAuthorLabel;
	} else { 
		[self set_bookAuthorLabel:[self initial_bookAuthorLabel]];
	}

	self->_bookAuthorLabel_initialized = YES;
	return _bookAuthorLabel;
}
-(GeneralGUI_Label*) initial_isbnLabel {
	/* ==================================================
	 * GeneralGUI::Label::create(Tuple { text = 'ISBN: ' })
	 * ================================================== */
	
	OCLString* v4 = [(OCLString*)[OCLString alloc] initWithString:@"ISBN: "];
	OCLString* v3 = v4;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"text" withValue:v3];
	GeneralGUI_Label* v0 = [(GeneralGUI_Label*)[GeneralGUI_Label alloc] initWithValues:v2];
	[v2 release];
	[v4 release];
	
	return v0;
}

-(GeneralGUI_Label*) _isbnLabel {
	if (self->_isbnLabel_initialized == YES) {
		return _isbnLabel;
	} else { 
		[self set_isbnLabel:[self initial_isbnLabel]];
	}

	self->_isbnLabel_initialized = YES;
	return _isbnLabel;
}
-(GeneralGUI_Label*) initial_bookIsbnLabel {
	/* ==================================================
	 * null
	 * ================================================== */
	
	GeneralGUI_Label* v0 = [NSNull null];
	
	return v0;
}

-(GeneralGUI_Label*) _bookIsbnLabel {
	if (self->_bookIsbnLabel_initialized == YES) {
		return _bookIsbnLabel;
	} else { 
		[self set_bookIsbnLabel:[self initial_bookIsbnLabel]];
	}

	self->_bookIsbnLabel_initialized = YES;
	return _bookIsbnLabel;
}
-(OCLString*) initial_windowTitle {
	/* ==================================================
	 * 'Book Detail'
	 * ================================================== */
	
	OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@"Book Detail"];
	
	return v0;
}

-(OCLString*) _windowTitle {
	if (self->_windowTitle_initialized == YES) {
		return _windowTitle;
	} else { 
		[self set_windowTitle:[self initial_windowTitle]];
	}

	self->_windowTitle_initialized = YES;
	return _windowTitle;
}
-(GeneralGUI_SelectionList*) initial_bookCopies {
	/* ==================================================
	 * GeneralGUI::SelectionList::create(Tuple { items = Sequence { } })
	 * ================================================== */
	
	OCLSequence* v4 = [(OCLSequence*)[OCLSequence alloc] init];
	OCLSequence* v3 = v4;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"items" withValue:v3];
	GeneralGUI_SelectionList* v0 = [(GeneralGUI_SelectionList*)[GeneralGUI_SelectionList alloc] initWithValues:v2];
	[v4 release];
	[v2 release];
	
	return v0;
}

-(GeneralGUI_SelectionList*) _bookCopies {
	if (self->_bookCopies_initialized == YES) {
		return _bookCopies;
	} else { 
		[self set_bookCopies:[self initial_bookCopies]];
	}

	self->_bookCopies_initialized = YES;
	return _bookCopies;
}
-(GeneralGUI_Label*) initial_bookCopiesLabel {
	/* ==================================================
	 * GeneralGUI::Label::create(Tuple { text = 'Copies of books available in the library:' })
	 * ================================================== */
	
	OCLString* v4 = [(OCLString*)[OCLString alloc] initWithString:@"Copies of books available in the library:"];
	OCLString* v3 = v4;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"text" withValue:v3];
	GeneralGUI_Label* v0 = [(GeneralGUI_Label*)[GeneralGUI_Label alloc] initWithValues:v2];
	[v4 release];
	[v2 release];
	
	return v0;
}

-(GeneralGUI_Label*) _bookCopiesLabel {
	if (self->_bookCopiesLabel_initialized == YES) {
		return _bookCopiesLabel;
	} else { 
		[self set_bookCopiesLabel:[self initial_bookCopiesLabel]];
	}

	self->_bookCopiesLabel_initialized = YES;
	return _bookCopiesLabel;
}
-(GeneralGUI_Window*) initial_window {
	/* ==================================================
	 * GeneralGUI::Window::create(
	 * 	Tuple { 
	 * 	seqGUIElements = Sequence { titleLabel, 
	 * 		bookTitleLabel, 
	 * 		authorLabel, 
	 * 		bookAuthorLabel, 
	 * 		isbnLabel, 
	 * 		bookIsbnLabel,
	 * 		bookCopiesLabel,
	 * 		bookCopies}, 
	 * 		title = windowTitle })
	 * ================================================== */
	
	MobileLibraryGUI_BookDetailController* v7 = self;
	GeneralGUI_Label* v6 = [v7 _titleLabel];
	GeneralGUI_Label* v5 = v6;
	MobileLibraryGUI_BookDetailController* v10 = self;
	GeneralGUI_Label* v9 = [v10 _bookTitleLabel];
	GeneralGUI_Label* v8 = v9;
	MobileLibraryGUI_BookDetailController* v13 = self;
	GeneralGUI_Label* v12 = [v13 _authorLabel];
	GeneralGUI_Label* v11 = v12;
	MobileLibraryGUI_BookDetailController* v16 = self;
	GeneralGUI_Label* v15 = [v16 _bookAuthorLabel];
	GeneralGUI_Label* v14 = v15;
	MobileLibraryGUI_BookDetailController* v19 = self;
	GeneralGUI_Label* v18 = [v19 _isbnLabel];
	GeneralGUI_Label* v17 = v18;
	MobileLibraryGUI_BookDetailController* v22 = self;
	GeneralGUI_Label* v21 = [v22 _bookIsbnLabel];
	GeneralGUI_Label* v20 = v21;
	MobileLibraryGUI_BookDetailController* v25 = self;
	GeneralGUI_Label* v24 = [v25 _bookCopiesLabel];
	GeneralGUI_Label* v23 = v24;
	MobileLibraryGUI_BookDetailController* v28 = self;
	GeneralGUI_SelectionList* v27 = [v28 _bookCopies];
	GeneralGUI_SelectionList* v26 = v27;
	OCLSequence* v4 = [(OCLSequence*)[OCLSequence alloc] init];
	[v4 add:v5];
	[v4 add:v8];
	[v4 add:v11];
	[v4 add:v14];
	[v4 add:v17];
	[v4 add:v20];
	[v4 add:v23];
	[v4 add:v26];
	OCLSequence* v3 = v4;
	MobileLibraryGUI_BookDetailController* v31 = self;
	OCLString* v30 = [v31 _windowTitle];
	OCLString* v29 = v30;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"seqGUIElements" withValue:v3];
	[v2 addItemNamed:@"title" withValue:v29];
	GeneralGUI_Window* v0 = [(GeneralGUI_Window*)[GeneralGUI_Window alloc] initWithValues:v2];
	[v2 release];
	[v4 release];
	
	return v0;
}

-(GeneralGUI_Window*) _window {
	if (self->_window_initialized == YES) {
		return _window;
	} else { 
		[self set_window:[self initial_window]];
	}

	self->_window_initialized = YES;
	return _window;
}
-(Library_Copy*) initial_selectedCopy {
	/* ==================================================
	 * null
	 * ================================================== */
	
	Library_Copy* v0 = [NSNull null];
	
	return v0;
}

-(Library_Copy*) _selectedCopy {
	if (self->_selectedCopy_initialized == YES) {
		return _selectedCopy;
	} else { 
		[self set_selectedCopy:[self initial_selectedCopy]];
	}

	self->_selectedCopy_initialized = YES;
	return _selectedCopy;
}
-(Library_Book*) initial_currBook {
	/* ==================================================
	 * null
	 * ================================================== */
	
	Library_Book* v0 = [NSNull null];
	
	return v0;
}

-(Library_Book*) _currBook {
	if (self->_currBook_initialized == YES) {
		return _currBook;
	} else { 
		[self set_currBook:[self initial_currBook]];
	}

	self->_currBook_initialized = YES;
	return _currBook;
}
-(GeneralGUI_ConfirmationDialog*) initial_yesNoMsg {
	/* ==================================================
	 * null
	 * ================================================== */
	
	GeneralGUI_ConfirmationDialog* v0 = [NSNull null];
	
	return v0;
}

-(GeneralGUI_ConfirmationDialog*) _yesNoMsg {
	if (self->_yesNoMsg_initialized == YES) {
		return _yesNoMsg;
	} else { 
		[self set_yesNoMsg:[self initial_yesNoMsg]];
	}

	self->_yesNoMsg_initialized = YES;
	return _yesNoMsg;
}
-(Library_Member*) initial_currMember {
	/* ==================================================
	 * null
	 * ================================================== */
	
	Library_Member* v0 = [NSNull null];
	
	return v0;
}

-(Library_Member*) _currMember {
	if (self->_currMember_initialized == YES) {
		return _currMember;
	} else { 
		[self set_currMember:[self initial_currMember]];
	}

	self->_currMember_initialized = YES;
	return _currMember;
}
-(OCLString*) initial_mode {
	/* ==================================================
	 * 'NotLoggedIn'
	 * ================================================== */
	
	OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@"NotLoggedIn"];
	
	return v0;
}

-(OCLString*) _mode {
	if (self->_mode_initialized == YES) {
		return _mode;
	} else { 
		[self set_mode:[self initial_mode]];
	}

	self->_mode_initialized = YES;
	return _mode;
}
-(GeneralGUI_MsgDialog*) initial_msg {
	/* ==================================================
	 * null
	 * ================================================== */
	
	GeneralGUI_MsgDialog* v0 = [NSNull null];
	
	return v0;
}

-(GeneralGUI_MsgDialog*) _msg {
	if (self->_msg_initialized == YES) {
		return _msg;
	} else { 
		[self set_msg:[self initial_msg]];
	}

	self->_msg_initialized = YES;
	return _msg;
}
-(OCLString*) initial_ackStatus {
	/* ==================================================
	 * 'NotWaiting'
	 * ================================================== */
	
	OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@"NotWaiting"];
	
	return v0;
}

-(OCLString*) _ackStatus {
	if (self->_ackStatus_initialized == YES) {
		return _ackStatus;
	} else { 
		[self set_ackStatus:[self initial_ackStatus]];
	}

	self->_ackStatus_initialized = YES;
	return _ackStatus;
}


 
-(void) set_windowTitle:(OCLString*) value {
	 	if (self->_windowTitle!= nil && self->_windowTitle!= (OCLString*) [NSNull null]) {
		[self->_windowTitle release];
	}
	self->_windowTitle = value;
	if (self->_windowTitle!= nil && self->_windowTitle!= (OCLString*) [NSNull null]) {
		[self->_windowTitle retain];
	}
	self->_windowTitle_initialized = YES;

}
-(void) set_mode:(OCLString*) value {
	 	if (self->_mode!= nil && self->_mode!= (OCLString*) [NSNull null]) {
		[self->_mode release];
	}
	self->_mode = value;
	if (self->_mode!= nil && self->_mode!= (OCLString*) [NSNull null]) {
		[self->_mode retain];
	}
	self->_mode_initialized = YES;

}
-(void) set_ackStatus:(OCLString*) value {
	 	if (self->_ackStatus!= nil && self->_ackStatus!= (OCLString*) [NSNull null]) {
		[self->_ackStatus release];
	}
	self->_ackStatus = value;
	if (self->_ackStatus!= nil && self->_ackStatus!= (OCLString*) [NSNull null]) {
		[self->_ackStatus retain];
	}
	self->_ackStatus_initialized = YES;

}


-(void) set_titleLabel:(GeneralGUI_Label*) value {
	 
	if (self->_titleLabel!= nil && self->_titleLabel!= (GeneralGUI_Label*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_titleLabel valueForKey:@"MobileLibraryGUI_BookDetailController_titleLabel_back"];
		[backpointers removeObject:self];
		[self->_titleLabel release];
	}
	self->_titleLabel = value;
	if (self->_titleLabel!= nil && self->_titleLabel!= (GeneralGUI_Label*) [NSNull null]) {
		[self->_titleLabel retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_titleLabel valueForKey:@"MobileLibraryGUI_BookDetailController_titleLabel_back"];
		[backpointers addObject:self];
	}
	self->_titleLabel_initialized = YES;

}
-(void) set_bookTitleLabel:(GeneralGUI_Label*) value {
	 
	if (self->_bookTitleLabel!= nil && self->_bookTitleLabel!= (GeneralGUI_Label*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_bookTitleLabel valueForKey:@"MobileLibraryGUI_BookDetailController_bookTitleLabel_back"];
		[backpointers removeObject:self];
		[self->_bookTitleLabel release];
	}
	self->_bookTitleLabel = value;
	if (self->_bookTitleLabel!= nil && self->_bookTitleLabel!= (GeneralGUI_Label*) [NSNull null]) {
		[self->_bookTitleLabel retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_bookTitleLabel valueForKey:@"MobileLibraryGUI_BookDetailController_bookTitleLabel_back"];
		[backpointers addObject:self];
	}
	self->_bookTitleLabel_initialized = YES;

}
-(void) set_authorLabel:(GeneralGUI_Label*) value {
	 
	if (self->_authorLabel!= nil && self->_authorLabel!= (GeneralGUI_Label*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_authorLabel valueForKey:@"MobileLibraryGUI_BookDetailController_authorLabel_back"];
		[backpointers removeObject:self];
		[self->_authorLabel release];
	}
	self->_authorLabel = value;
	if (self->_authorLabel!= nil && self->_authorLabel!= (GeneralGUI_Label*) [NSNull null]) {
		[self->_authorLabel retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_authorLabel valueForKey:@"MobileLibraryGUI_BookDetailController_authorLabel_back"];
		[backpointers addObject:self];
	}
	self->_authorLabel_initialized = YES;

}
-(void) set_bookAuthorLabel:(GeneralGUI_Label*) value {
	 
	if (self->_bookAuthorLabel!= nil && self->_bookAuthorLabel!= (GeneralGUI_Label*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_bookAuthorLabel valueForKey:@"MobileLibraryGUI_BookDetailController_bookAuthorLabel_back"];
		[backpointers removeObject:self];
		[self->_bookAuthorLabel release];
	}
	self->_bookAuthorLabel = value;
	if (self->_bookAuthorLabel!= nil && self->_bookAuthorLabel!= (GeneralGUI_Label*) [NSNull null]) {
		[self->_bookAuthorLabel retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_bookAuthorLabel valueForKey:@"MobileLibraryGUI_BookDetailController_bookAuthorLabel_back"];
		[backpointers addObject:self];
	}
	self->_bookAuthorLabel_initialized = YES;

}
-(void) set_isbnLabel:(GeneralGUI_Label*) value {
	 
	if (self->_isbnLabel!= nil && self->_isbnLabel!= (GeneralGUI_Label*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_isbnLabel valueForKey:@"MobileLibraryGUI_BookDetailController_isbnLabel_back"];
		[backpointers removeObject:self];
		[self->_isbnLabel release];
	}
	self->_isbnLabel = value;
	if (self->_isbnLabel!= nil && self->_isbnLabel!= (GeneralGUI_Label*) [NSNull null]) {
		[self->_isbnLabel retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_isbnLabel valueForKey:@"MobileLibraryGUI_BookDetailController_isbnLabel_back"];
		[backpointers addObject:self];
	}
	self->_isbnLabel_initialized = YES;

}
-(void) set_bookIsbnLabel:(GeneralGUI_Label*) value {
	 
	if (self->_bookIsbnLabel!= nil && self->_bookIsbnLabel!= (GeneralGUI_Label*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_bookIsbnLabel valueForKey:@"MobileLibraryGUI_BookDetailController_bookIsbnLabel_back"];
		[backpointers removeObject:self];
		[self->_bookIsbnLabel release];
	}
	self->_bookIsbnLabel = value;
	if (self->_bookIsbnLabel!= nil && self->_bookIsbnLabel!= (GeneralGUI_Label*) [NSNull null]) {
		[self->_bookIsbnLabel retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_bookIsbnLabel valueForKey:@"MobileLibraryGUI_BookDetailController_bookIsbnLabel_back"];
		[backpointers addObject:self];
	}
	self->_bookIsbnLabel_initialized = YES;

}
-(void) set_bookCopies:(GeneralGUI_SelectionList*) value {
	 
	if (self->_bookCopies!= nil && self->_bookCopies!= (GeneralGUI_SelectionList*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_bookCopies valueForKey:@"MobileLibraryGUI_BookDetailController_bookCopies_back"];
		[backpointers removeObject:self];
		[self->_bookCopies release];
	}
	self->_bookCopies = value;
	if (self->_bookCopies!= nil && self->_bookCopies!= (GeneralGUI_SelectionList*) [NSNull null]) {
		[self->_bookCopies retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_bookCopies valueForKey:@"MobileLibraryGUI_BookDetailController_bookCopies_back"];
		[backpointers addObject:self];
	}
	self->_bookCopies_initialized = YES;

}
-(void) set_bookCopiesLabel:(GeneralGUI_Label*) value {
	 
	if (self->_bookCopiesLabel!= nil && self->_bookCopiesLabel!= (GeneralGUI_Label*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_bookCopiesLabel valueForKey:@"MobileLibraryGUI_BookDetailController_bookCopiesLabel_back"];
		[backpointers removeObject:self];
		[self->_bookCopiesLabel release];
	}
	self->_bookCopiesLabel = value;
	if (self->_bookCopiesLabel!= nil && self->_bookCopiesLabel!= (GeneralGUI_Label*) [NSNull null]) {
		[self->_bookCopiesLabel retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_bookCopiesLabel valueForKey:@"MobileLibraryGUI_BookDetailController_bookCopiesLabel_back"];
		[backpointers addObject:self];
	}
	self->_bookCopiesLabel_initialized = YES;

}
-(void) set_window:(GeneralGUI_Window*) value {
	 
	if (self->_window!= nil && self->_window!= (GeneralGUI_Window*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_window valueForKey:@"MobileLibraryGUI_BookDetailController_window_back"];
		[backpointers removeObject:self];
		[self->_window release];
	}
	self->_window = value;
	if (self->_window!= nil && self->_window!= (GeneralGUI_Window*) [NSNull null]) {
		[self->_window retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_window valueForKey:@"MobileLibraryGUI_BookDetailController_window_back"];
		[backpointers addObject:self];
	}
	self->_window_initialized = YES;

}
-(void) set_selectedCopy:(Library_Copy*) value {
	 
	if (self->_selectedCopy!= nil && self->_selectedCopy!= (Library_Copy*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_selectedCopy valueForKey:@"MobileLibraryGUI_BookDetailController_selectedCopy_back"];
		[backpointers removeObject:self];
		[self->_selectedCopy release];
	}
	self->_selectedCopy = value;
	if (self->_selectedCopy!= nil && self->_selectedCopy!= (Library_Copy*) [NSNull null]) {
		[self->_selectedCopy retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_selectedCopy valueForKey:@"MobileLibraryGUI_BookDetailController_selectedCopy_back"];
		[backpointers addObject:self];
	}
	self->_selectedCopy_initialized = YES;

}
-(void) set_currBook:(Library_Book*) value {
	 
	if (self->_currBook!= nil && self->_currBook!= (Library_Book*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_currBook valueForKey:@"MobileLibraryGUI_BookDetailController_currBook_back"];
		[backpointers removeObject:self];
		[self->_currBook release];
	}
	self->_currBook = value;
	if (self->_currBook!= nil && self->_currBook!= (Library_Book*) [NSNull null]) {
		[self->_currBook retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_currBook valueForKey:@"MobileLibraryGUI_BookDetailController_currBook_back"];
		[backpointers addObject:self];
	}
	self->_currBook_initialized = YES;

}
-(void) set_yesNoMsg:(GeneralGUI_ConfirmationDialog*) value {
	 
	if (self->_yesNoMsg!= nil && self->_yesNoMsg!= (GeneralGUI_ConfirmationDialog*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_yesNoMsg valueForKey:@"MobileLibraryGUI_BookDetailController_yesNoMsg_back"];
		[backpointers removeObject:self];
		[self->_yesNoMsg release];
	}
	self->_yesNoMsg = value;
	if (self->_yesNoMsg!= nil && self->_yesNoMsg!= (GeneralGUI_ConfirmationDialog*) [NSNull null]) {
		[self->_yesNoMsg retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_yesNoMsg valueForKey:@"MobileLibraryGUI_BookDetailController_yesNoMsg_back"];
		[backpointers addObject:self];
	}
	self->_yesNoMsg_initialized = YES;

}
-(void) set_currMember:(Library_Member*) value {
	 
	if (self->_currMember!= nil && self->_currMember!= (Library_Member*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_currMember valueForKey:@"MobileLibraryGUI_BookDetailController_currMember_back"];
		[backpointers removeObject:self];
		[self->_currMember release];
	}
	self->_currMember = value;
	if (self->_currMember!= nil && self->_currMember!= (Library_Member*) [NSNull null]) {
		[self->_currMember retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_currMember valueForKey:@"MobileLibraryGUI_BookDetailController_currMember_back"];
		[backpointers addObject:self];
	}
	self->_currMember_initialized = YES;

}
-(void) set_msg:(GeneralGUI_MsgDialog*) value {
	 
	if (self->_msg!= nil && self->_msg!= (GeneralGUI_MsgDialog*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_msg valueForKey:@"MobileLibraryGUI_BookDetailController_msg_back"];
		[backpointers removeObject:self];
		[self->_msg release];
	}
	self->_msg = value;
	if (self->_msg!= nil && self->_msg!= (GeneralGUI_MsgDialog*) [NSNull null]) {
		[self->_msg retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_msg valueForKey:@"MobileLibraryGUI_BookDetailController_msg_back"];
		[backpointers addObject:self];
	}
	self->_msg_initialized = YES;

}




 
-(void) event_bookCopyItemSelected_pushed:(PropertyChangeList*) changes  p_index: (OCLInteger*) p_index{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_bookCopyItemSelected", @"MobileLibraryGUI_BookDetailController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {

			[self event_showConfirmReserveMsg_pushed:changes ];
		}
		[v0 release];


		 
		 // Process impacts relationships
		/* ==================================================
		 * currBook.copies->asSequence()->at(index)
		 * ================================================== */
		
		MobileLibraryGUI_BookDetailController* v5 = self;
		Library_Book* v4 = [v5 _currBook];
		OCLSet* v3 = [v4 _copies];
		OCLSequence* v2 = [v3 asSequence];
		OCLInteger* v6 = p_index;
		Library_Copy* v1 = ((Library_Copy*)[v2 at:v6]);
		[v2 release];
		
		Library_Copy* _selectedCopy_newValue = v1;
		[changes addChange:@selector(set_selectedCopy:) instance:self value:_selectedCopy_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_bookCopyItemSelected_pulled_edge0:(PropertyChangeList*)changes parentInstance:(GeneralGUI_SelectionList*)parentInstance p_index:(OCLInteger*)p_index  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_bookCopyItemSelected", @"MobileLibraryGUI_BookDetailController", @"_itemSelected", @"GeneralGUI_SelectionList");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {
		/* ==================================================
		 * index
		 * ================================================== */
		
		OCLInteger* v1 = p_index;
		
		OCLInteger* parameter_p_index = v1;

		[self event_bookCopyItemSelected_pushed:changes p_index:parameter_p_index ];

	}
	[v0 release];
}


-(void) event_refreshBookCopiesData_pushed:(PropertyChangeList*) changes  p_copiesData: (OCLSequence*) p_copiesData{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_refreshBookCopiesData", @"MobileLibraryGUI_BookDetailController");

		 
		// Trigger Push edges

		if (self->_bookCopies != nil && self->_bookCopies != (GeneralGUI_SelectionList*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_bookCopies];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			GeneralGUI_SelectionList* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * copiesData
				 * ================================================== */
				
				OCLSequence* v1 = p_copiesData;
				
					OCLSequence* parameter_p_items = v1;

					[edge0_target event_refreshItems_pushed:changes p_items:parameter_p_items ];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_showConfirmReserveMsg_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_showConfirmReserveMsg", @"MobileLibraryGUI_BookDetailController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * GeneralGUI::ConfirmationDialog::create(
		 * 	Tuple { title = 'Confirm', 
		 * 		message = 'Would you like to reserve the selected book copy?' })
		 * ================================================== */
		
		OCLString* v4 = [(OCLString*)[OCLString alloc] initWithString:@"Confirm"];
		OCLString* v3 = v4;
		OCLString* v6 = [(OCLString*)[OCLString alloc] initWithString:@"Would you like to reserve the selected book copy?"];
		OCLString* v5 = v6;
		OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
		[v2 addItemNamed:@"title" withValue:v3];
		[v2 addItemNamed:@"message" withValue:v5];
		GeneralGUI_ConfirmationDialog* v0 = [(GeneralGUI_ConfirmationDialog*)[GeneralGUI_ConfirmationDialog alloc] initWithValues:v2];
		[v4 release];
		[v6 release];
		[v2 release];
		
		GeneralGUI_ConfirmationDialog* _yesNoMsg_newValue = v0;
		[changes addChange:@selector(set_yesNoMsg:) instance:self value:_yesNoMsg_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_reserveConfAck_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_reserveConfAck", @"MobileLibraryGUI_BookDetailController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {

			[self event_reserveCopyOk_pushed:changes ];
		}
		[v0 release];
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v1 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v1->value == YES) {

			[self event_reserveCopyNotOk_pushed:changes ];
		}
		[v1 release];


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_reserveConfAck_pulled_edge0:(PropertyChangeList*)changes parentInstance:(GeneralGUI_ConfirmationDialog*)parentInstance  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_reserveConfAck", @"MobileLibraryGUI_BookDetailController", @"_okClicked", @"GeneralGUI_ConfirmationDialog");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {

		[self event_reserveConfAck_pushed:changes ];

	}
	[v0 release];
}


-(void) event_sessionStarted_pushed:(PropertyChangeList*) changes  p_m: (Library_Member*) p_m{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_sessionStarted", @"MobileLibraryGUI_BookDetailController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * m
		 * ================================================== */
		
		Library_Member* v0 = p_m;
		
		Library_Member* _currMember_newValue = v0;
		[changes addChange:@selector(set_currMember:) instance:self value:_currMember_newValue];
		/* ==================================================
		 * 'LoggedIn'
		 * ================================================== */
		
		OCLString* v1 = [(OCLString*)[OCLString alloc] initWithString:@"LoggedIn"];
		
		OCLString* _mode_newValue = v1;
		[changes addChange:@selector(set_mode:) instance:self value:_mode_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_reserveCopyOk_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * mode = 'LoggedIn'
		 * ================================================== */
		
		MobileLibraryGUI_BookDetailController* v2 = self;
		OCLString* v1 = [v2 _mode];
		OCLString* v3 = [(OCLString*)[OCLString alloc] initWithString:@"LoggedIn"];
		OCLBoolean* v0 = [v1 eq:v3];
		[v3 release];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_reserveCopyOk", @"MobileLibraryGUI_BookDetailController");

		 
		// Trigger Push edges

		if (self->_selectedCopy != nil && self->_selectedCopy != (Library_Copy*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_selectedCopy];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			Library_Copy* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {

					[edge0_target event_reserve_pushed:changes ];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_reserveCopyNotOk_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * mode = 'NotLoggedIn'
		 * ================================================== */
		
		MobileLibraryGUI_BookDetailController* v2 = self;
		OCLString* v1 = [v2 _mode];
		OCLString* v3 = [(OCLString*)[OCLString alloc] initWithString:@"NotLoggedIn"];
		OCLBoolean* v0 = [v1 eq:v3];
		[v3 release];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_reserveCopyNotOk", @"MobileLibraryGUI_BookDetailController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {

			[self event_showCannotReserveCopyMsg_pushed:changes ];
		}
		[v0 release];


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_showCannotReserveCopyMsg_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_showCannotReserveCopyMsg", @"MobileLibraryGUI_BookDetailController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {

			[self event_setToNotWaiting_pushed:changes ];
		}
		[v0 release];


		 
		 // Process impacts relationships
		/* ==================================================
		 * GeneralGUI::MsgDialog::create(
		 * 	Tuple { 
		 * 	    msg = 'Not possible to reserve the selected copy. No user is logged-in!', 
		 * 		viewTitle = 'Error!' })
		 * ================================================== */
		
		OCLString* v5 = [(OCLString*)[OCLString alloc] initWithString:@"Not possible to reserve the selected copy. No user is logged-in!"];
		OCLString* v4 = v5;
		OCLString* v7 = [(OCLString*)[OCLString alloc] initWithString:@"Error!"];
		OCLString* v6 = v7;
		OCLTuple* v3 = [(OCLTuple*)[OCLTuple alloc] init];
		[v3 addItemNamed:@"msg" withValue:v4];
		[v3 addItemNamed:@"viewTitle" withValue:v6];
		GeneralGUI_MsgDialog* v1 = [(GeneralGUI_MsgDialog*)[GeneralGUI_MsgDialog alloc] initWithValues:v3];
		[v7 release];
		[v3 release];
		[v5 release];
		
		GeneralGUI_MsgDialog* _msg_newValue = v1;
		[changes addChange:@selector(set_msg:) instance:self value:_msg_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_copyReserved_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_copyReserved", @"MobileLibraryGUI_BookDetailController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {

			[self event_showReserveOkMsg_pushed:changes ];
		}
		[v0 release];
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v1 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v1->value == YES) {

			[self event_addReservedToMember_pushed:changes ];
		}
		[v1 release];


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_copyReserved_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Library_Copy*)parentInstance  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_copyReserved", @"MobileLibraryGUI_BookDetailController", @"_reserveOk", @"Library_Copy");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {

		[self event_copyReserved_pushed:changes ];

	}
	[v0 release];
}


-(void) event_showReserveOkMsg_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_showReserveOkMsg", @"MobileLibraryGUI_BookDetailController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * GeneralGUI::MsgDialog::create(
		 * 	Tuple { 
		 * 	    msg = 'A copy of book \''.concat(currBook.title).concat('\' has been reserved and is now awaiting collection at your library.'), 
		 * 		viewTitle = 'Success!' })
		 * ================================================== */
		
		OCLString* v6 = [(OCLString*)[OCLString alloc] initWithString:@"A copy of book '"];
		MobileLibraryGUI_BookDetailController* v9 = self;
		Library_Book* v8 = [v9 _currBook];
		OCLString* v7 = [v8 _title];
		OCLString* v5 = [v6 concat:v7];
		OCLString* v10 = [(OCLString*)[OCLString alloc] initWithString:@"' has been reserved and is now awaiting collection at your library."];
		OCLString* v4 = [v5 concat:v10];
		OCLString* v3 = v4;
		OCLString* v12 = [(OCLString*)[OCLString alloc] initWithString:@"Success!"];
		OCLString* v11 = v12;
		OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
		[v2 addItemNamed:@"msg" withValue:v3];
		[v2 addItemNamed:@"viewTitle" withValue:v11];
		GeneralGUI_MsgDialog* v0 = [(GeneralGUI_MsgDialog*)[GeneralGUI_MsgDialog alloc] initWithValues:v2];
		[v6 release];
		[v10 release];
		[v5 release];
		[v4 release];
		[v2 release];
		[v12 release];
		
		GeneralGUI_MsgDialog* _msg_newValue = v0;
		[changes addChange:@selector(set_msg:) instance:self value:_msg_newValue];
		/* ==================================================
		 * 'WaitingReserveAck'
		 * ================================================== */
		
		OCLString* v13 = [(OCLString*)[OCLString alloc] initWithString:@"WaitingReserveAck"];
		
		OCLString* _ackStatus_newValue = v13;
		[changes addChange:@selector(set_ackStatus:) instance:self value:_ackStatus_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_reserveAck_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * ackStatus='WaitingReserveAck'
		 * ================================================== */
		
		MobileLibraryGUI_BookDetailController* v2 = self;
		OCLString* v1 = [v2 _ackStatus];
		OCLString* v3 = [(OCLString*)[OCLString alloc] initWithString:@"WaitingReserveAck"];
		OCLBoolean* v0 = [v1 eq:v3];
		[v3 release];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_reserveAck", @"MobileLibraryGUI_BookDetailController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {

			[self event_refreshAndSave_pushed:changes ];
		}
		[v0 release];
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v1 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v1->value == YES) {

			[self event_setToNotWaiting_pushed:changes ];
		}
		[v1 release];


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_reserveAck_pulled_edge0:(PropertyChangeList*)changes parentInstance:(GeneralGUI_MsgDialog*)parentInstance  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_reserveAck", @"MobileLibraryGUI_BookDetailController", @"_okClicked", @"GeneralGUI_MsgDialog");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {

		[self event_reserveAck_pushed:changes ];

	}
	[v0 release];
}


-(void) event_addReservedToMember_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_addReservedToMember", @"MobileLibraryGUI_BookDetailController");

		 
		// Trigger Push edges

		if (self->_currMember != nil && self->_currMember != (Library_Member*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_currMember];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			Library_Member* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * selectedCopy
				 * ================================================== */
				
				Library_Copy* v1 = [self _selectedCopy];
				
					Library_Copy* parameter_p_copy = v1;

					[edge0_target event_addCopyToCollect_pushed:changes p_copy:parameter_p_copy ];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_reserveFailed_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_reserveFailed", @"MobileLibraryGUI_BookDetailController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {

			[self event_showReserveFailedMsg_pushed:changes ];
		}
		[v0 release];


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_reserveFailed_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Library_Copy*)parentInstance  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_reserveFailed", @"MobileLibraryGUI_BookDetailController", @"_reserveFailed", @"Library_Copy");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {

		[self event_reserveFailed_pushed:changes ];

	}
	[v0 release];
}


-(void) event_showReserveFailedMsg_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_showReserveFailedMsg", @"MobileLibraryGUI_BookDetailController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {

			[self event_setToNotWaiting_pushed:changes ];
		}
		[v0 release];


		 
		 // Process impacts relationships
		/* ==================================================
		 * GeneralGUI::MsgDialog::create(
		 * 	Tuple { 
		 * 	    msg = 'The selected copy of book \''.concat(currBook.title).concat('\' could not be reserved because it is not available for borrowing.'), 
		 * 		viewTitle = 'Copy Reservation Failed!' })
		 * ================================================== */
		
		OCLString* v7 = [(OCLString*)[OCLString alloc] initWithString:@"The selected copy of book '"];
		MobileLibraryGUI_BookDetailController* v10 = self;
		Library_Book* v9 = [v10 _currBook];
		OCLString* v8 = [v9 _title];
		OCLString* v6 = [v7 concat:v8];
		OCLString* v11 = [(OCLString*)[OCLString alloc] initWithString:@"' could not be reserved because it is not available for borrowing."];
		OCLString* v5 = [v6 concat:v11];
		OCLString* v4 = v5;
		OCLString* v13 = [(OCLString*)[OCLString alloc] initWithString:@"Copy Reservation Failed!"];
		OCLString* v12 = v13;
		OCLTuple* v3 = [(OCLTuple*)[OCLTuple alloc] init];
		[v3 addItemNamed:@"msg" withValue:v4];
		[v3 addItemNamed:@"viewTitle" withValue:v12];
		GeneralGUI_MsgDialog* v1 = [(GeneralGUI_MsgDialog*)[GeneralGUI_MsgDialog alloc] initWithValues:v3];
		[v11 release];
		[v6 release];
		[v5 release];
		[v3 release];
		[v13 release];
		[v7 release];
		
		GeneralGUI_MsgDialog* _msg_newValue = v1;
		[changes addChange:@selector(set_msg:) instance:self value:_msg_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_setToNotWaiting_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_setToNotWaiting", @"MobileLibraryGUI_BookDetailController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * 'NotWaiting'
		 * ================================================== */
		
		OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@"NotWaiting"];
		
		OCLString* _ackStatus_newValue = v0;
		[changes addChange:@selector(set_ackStatus:) instance:self value:_ackStatus_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_refreshAndSave_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_refreshAndSave", @"MobileLibraryGUI_BookDetailController");

		 
		// Trigger Push edges

		if (self->_bookCopies != nil && self->_bookCopies != (GeneralGUI_SelectionList*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_bookCopies];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			GeneralGUI_SelectionList* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * getBookCopiesData
				 * ================================================== */
				
				OCLSequence* v1 = [self getBookCopiesData];
				
					OCLSequence* parameter_p_items = v1;

					[edge0_target event_refreshItems_pushed:changes p_items:parameter_p_items ];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges
		NSEnumerator* MobileLibraryGUI_SearchResultsController_refreshAndSave_edge0_enum = [self->MobileLibraryGUI_SearchResultsController_detailsWindow_back objectEnumerator];
		MobileLibraryGUI_SearchResultsController* MobileLibraryGUI_SearchResultsController_refreshAndSave_edge0_target;
		while ((MobileLibraryGUI_SearchResultsController_refreshAndSave_edge0_target = [MobileLibraryGUI_SearchResultsController_refreshAndSave_edge0_enum nextObject]) != nil) {
		    [MobileLibraryGUI_SearchResultsController_refreshAndSave_edge0_target event_refreshAndSave_pulled_edge0:changes parentInstance:self ];
		}



		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 




 
-(OCLSequence*) getBookCopiesData{
	/* ==================================================
	 * currBook.copies->collect(
	 * 	copyId.concat(' ').concat(state).concat(' ').concat(dueDate)
	 * )->asSequence()
	 * ================================================== */
	
	MobileLibraryGUI_BookDetailController* v4 = self;
	Library_Book* v3 = [v4 _currBook];
	OCLSet* v2 = [v3 _copies];
	OCLBag* v1_nested = [(OCLBag*)[OCLBag alloc] init];
	NSEnumerator* v1_enum = [v2 objectEnumerator];
	Library_Copy* v5;
	while ((v5 = [v1_enum nextObject]) != nil) {
		Library_Copy* v11 = v5;
		OCLString* v10 = [v11 _copyId];
		OCLString* v12 = [(OCLString*)[OCLString alloc] initWithString:@" "];
		OCLString* v9 = [v10 concat:v12];
		Library_Copy* v14 = v5;
		OCLString* v13 = [v14 _state];
		OCLString* v8 = [v9 concat:v13];
		OCLString* v15 = [(OCLString*)[OCLString alloc] initWithString:@" "];
		OCLString* v7 = [v8 concat:v15];
		Library_Copy* v17 = v5;
		OCLString* v16 = [v17 _dueDate];
		OCLString* v6 = [v7 concat:v16];
		[v1_nested add: v6];
		[v15 release];
		[v8 release];
		[v9 release];
		[v12 release];
		[v7 release];
		[v6 release];
	}
	OCLBag* v1 = [v1_nested flatten];
	[v1_nested release];
	OCLSequence* v0 = [v1 asSequence];
	;
	return v0;
}


@end 


