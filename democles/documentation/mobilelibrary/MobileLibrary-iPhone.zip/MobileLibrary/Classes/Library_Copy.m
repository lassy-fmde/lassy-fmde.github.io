 
 
 
#import "Library_Copy.h"
#import "PropertyChangeList.h"
#import "Library_Book.h"
#import "Library_Copy.h"
#import "LibraryPersistence_LibraryLoader.h"
#import "MobileLibraryGUI_MemberController.h"
#import "Library_Member.h"
#import "MobileLibraryGUI_BookDetailController.h"


 
@implementation Library_Copy

 
- (Library_Copy*) init {
	self = [super init];
	 
	self->Library_Book_copies_back = [[NSMutableArray alloc] init];
	self->LibraryPersistence_LibraryLoader_copies_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_MemberController_selectedBorrowing_back = [[NSMutableArray alloc] init];
	self->Library_Member_borrows_back = [[NSMutableArray alloc] init];
	self->Library_Member_toCollect_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_BookDetailController_selectedCopy_back = [[NSMutableArray alloc] init];

	[self set_book: [self _book]];
	[self set_dueDate: [self _dueDate]];
	[self set_renewals: [self _renewals]];
	[self set_state: [self _state]];
	[self set_copyId: [self _copyId]];

	return self;
}

 
- (Library_Copy*) initWithValues: (OCLTuple*) values {
	self = [super init];
	 
	self->_book_initialized = NO;
	self->_dueDate_initialized = NO;
	self->_renewals_initialized = NO;
	self->_state_initialized = NO;
	self->_copyId_initialized = NO;

	self->Library_Book_copies_back = [[NSMutableArray alloc] init];
	self->LibraryPersistence_LibraryLoader_copies_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_MemberController_selectedBorrowing_back = [[NSMutableArray alloc] init];
	self->Library_Member_borrows_back = [[NSMutableArray alloc] init];
	self->Library_Member_toCollect_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_BookDetailController_selectedCopy_back = [[NSMutableArray alloc] init];

	Library_Book* _book_initialValue = (Library_Book*) [values objectForKey:@"book"];
	if (_book_initialValue == nil) {
		_book_initialValue = [self _book];
	}
	[self set_book:_book_initialValue];
	OCLString* _dueDate_initialValue = (OCLString*) [values objectForKey:@"dueDate"];
	if (_dueDate_initialValue == nil) {
		_dueDate_initialValue = [self _dueDate];
	}
	[self set_dueDate:_dueDate_initialValue];
	OCLInteger* _renewals_initialValue = (OCLInteger*) [values objectForKey:@"renewals"];
	if (_renewals_initialValue == nil) {
		_renewals_initialValue = [self _renewals];
	}
	[self set_renewals:_renewals_initialValue];
	OCLString* _state_initialValue = (OCLString*) [values objectForKey:@"state"];
	if (_state_initialValue == nil) {
		_state_initialValue = [self _state];
	}
	[self set_state:_state_initialValue];
	OCLString* _copyId_initialValue = (OCLString*) [values objectForKey:@"copyId"];
	if (_copyId_initialValue == nil) {
		_copyId_initialValue = [self _copyId];
	}
	[self set_copyId:_copyId_initialValue];

	
	return self;
}

 
- (void) dealloc {
	if (self->_book != nil && self->_book != (Library_Book*) [NSNull null]) [self->_book release];
	if (self->_dueDate != nil && self->_dueDate != (OCLString*) [NSNull null]) [self->_dueDate release];
	if (self->_renewals != nil && self->_renewals != (OCLInteger*) [NSNull null]) [self->_renewals release];
	if (self->_state != nil && self->_state != (OCLString*) [NSNull null]) [self->_state release];
	if (self->_copyId != nil && self->_copyId != (OCLString*) [NSNull null]) [self->_copyId release];

	[self->Library_Book_copies_back release];
	[self->LibraryPersistence_LibraryLoader_copies_back release];
	[self->MobileLibraryGUI_MemberController_selectedBorrowing_back release];
	[self->Library_Member_borrows_back release];
	[self->Library_Member_toCollect_back release];
	[self->MobileLibraryGUI_BookDetailController_selectedCopy_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"Library::Copy\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"book\" type=\"Library::Book\">\n"];
	[res appendFormat:@"%@\n", [self _book]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"dueDate\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _dueDate]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"renewals\" type=\"Integer\">\n"];
	[res appendFormat:@"%@\n", [self _renewals]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"state\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _state]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"copyId\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _copyId]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
-(Library_Book*) initial_book {
	/* ==================================================
	 * null
	 * ================================================== */
	
	Library_Book* v0 = [NSNull null];
	
	return v0;
}

-(Library_Book*) _book {
	if (self->_book_initialized == YES) {
		return _book;
	} else { 
		[self set_book:[self initial_book]];
	}

	self->_book_initialized = YES;
	return _book;
}
-(OCLString*) initial_dueDate {
	/* ==================================================
	 * null
	 * ================================================== */
	
	OCLString* v0 = [NSNull null];
	
	return v0;
}

-(OCLString*) _dueDate {
	if (self->_dueDate_initialized == YES) {
		return _dueDate;
	} else { 
		[self set_dueDate:[self initial_dueDate]];
	}

	self->_dueDate_initialized = YES;
	return _dueDate;
}
-(OCLInteger*) initial_renewals {
	/* ==================================================
	 * 0
	 * ================================================== */
	
	OCLInteger* v0 = [(OCLInteger*)[OCLInteger alloc] initWithValue:0];
	
	return v0;
}

-(OCLInteger*) _renewals {
	if (self->_renewals_initialized == YES) {
		return _renewals;
	} else { 
		[self set_renewals:[self initial_renewals]];
	}

	self->_renewals_initialized = YES;
	return _renewals;
}
-(OCLString*) initial_state {
	/* ==================================================
	 * 'Borrowable'
	 * ================================================== */
	
	OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@"Borrowable"];
	
	return v0;
}

-(OCLString*) _state {
	if (self->_state_initialized == YES) {
		return _state;
	} else { 
		[self set_state:[self initial_state]];
	}

	self->_state_initialized = YES;
	return _state;
}
-(OCLString*) initial_copyId {
	/* ==================================================
	 * null
	 * ================================================== */
	
	OCLString* v0 = [NSNull null];
	
	return v0;
}

-(OCLString*) _copyId {
	if (self->_copyId_initialized == YES) {
		return _copyId;
	} else { 
		[self set_copyId:[self initial_copyId]];
	}

	self->_copyId_initialized = YES;
	return _copyId;
}


 
-(void) set_dueDate:(OCLString*) value {
	 	if (self->_dueDate!= nil && self->_dueDate!= (OCLString*) [NSNull null]) {
		[self->_dueDate release];
	}
	self->_dueDate = value;
	if (self->_dueDate!= nil && self->_dueDate!= (OCLString*) [NSNull null]) {
		[self->_dueDate retain];
	}
	self->_dueDate_initialized = YES;

}
-(void) set_renewals:(OCLInteger*) value {
	 	if (self->_renewals!= nil && self->_renewals!= (OCLInteger*) [NSNull null]) {
		[self->_renewals release];
	}
	self->_renewals = value;
	if (self->_renewals!= nil && self->_renewals!= (OCLInteger*) [NSNull null]) {
		[self->_renewals retain];
	}
	self->_renewals_initialized = YES;

}
-(void) set_state:(OCLString*) value {
	 	if (self->_state!= nil && self->_state!= (OCLString*) [NSNull null]) {
		[self->_state release];
	}
	self->_state = value;
	if (self->_state!= nil && self->_state!= (OCLString*) [NSNull null]) {
		[self->_state retain];
	}
	self->_state_initialized = YES;

}
-(void) set_copyId:(OCLString*) value {
	 	if (self->_copyId!= nil && self->_copyId!= (OCLString*) [NSNull null]) {
		[self->_copyId release];
	}
	self->_copyId = value;
	if (self->_copyId!= nil && self->_copyId!= (OCLString*) [NSNull null]) {
		[self->_copyId retain];
	}
	self->_copyId_initialized = YES;

}


-(void) set_book:(Library_Book*) value {
	 
	if (self->_book!= nil && self->_book!= (Library_Book*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_book valueForKey:@"Library_Copy_book_back"];
		[backpointers removeObject:self];
		[self->_book release];
	}
	self->_book = value;
	if (self->_book!= nil && self->_book!= (Library_Book*) [NSNull null]) {
		[self->_book retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_book valueForKey:@"Library_Copy_book_back"];
		[backpointers addObject:self];
	}
	self->_book_initialized = YES;

}




 
-(void) event_renewOk_pushed:(PropertyChangeList*) changes  p_newDueDate: (OCLString*) p_newDueDate{
	{ // New scope for following guard code:
		/* ==================================================
		 * renewals < maxRenewals
		 * ================================================== */
		
		Library_Copy* v2 = self;
		OCLInteger* v1 = [v2 _renewals];
		Library_Copy* v4 = self;
		OCLInteger* v3 = [v4 maxRenewals];
		OCLBoolean* v0 = [v1 lt:v3];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_renewOk", @"Library_Copy");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges
		NSEnumerator* MobileLibraryGUI_MemberController_copyRenewed_edge0_enum = [self->MobileLibraryGUI_MemberController_selectedBorrowing_back objectEnumerator];
		MobileLibraryGUI_MemberController* MobileLibraryGUI_MemberController_copyRenewed_edge0_target;
		while ((MobileLibraryGUI_MemberController_copyRenewed_edge0_target = [MobileLibraryGUI_MemberController_copyRenewed_edge0_enum nextObject]) != nil) {
		    [MobileLibraryGUI_MemberController_copyRenewed_edge0_target event_copyRenewed_pulled_edge0:changes parentInstance:self p_newDueDate:p_newDueDate ];
		}



		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * renewals+1
		 * ================================================== */
		
		Library_Copy* v2 = self;
		OCLInteger* v1 = [v2 _renewals];
		OCLInteger* v3 = [(OCLInteger*)[OCLInteger alloc] initWithValue:1];
		OCLInteger* v0 = [v1 plus:v3];
		[v3 release];
		
		OCLInteger* _renewals_newValue = v0;
		[changes addChange:@selector(set_renewals:) instance:self value:_renewals_newValue];
		/* ==================================================
		 * newDueDate
		 * ================================================== */
		
		OCLString* v4 = p_newDueDate;
		
		OCLString* _dueDate_newValue = v4;
		[changes addChange:@selector(set_dueDate:) instance:self value:_dueDate_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_renewFailed_pushed:(PropertyChangeList*) changes  p_copy: (Library_Copy*) p_copy{
	{ // New scope for following guard code:
		/* ==================================================
		 * renewals >= maxRenewals
		 * ================================================== */
		
		Library_Copy* v2 = self;
		OCLInteger* v1 = [v2 _renewals];
		Library_Copy* v4 = self;
		OCLInteger* v3 = [v4 maxRenewals];
		OCLBoolean* v0 = [v1 gte:v3];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_renewFailed", @"Library_Copy");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges
		NSEnumerator* MobileLibraryGUI_MemberController_renewFailed_edge0_enum = [self->MobileLibraryGUI_MemberController_selectedBorrowing_back objectEnumerator];
		MobileLibraryGUI_MemberController* MobileLibraryGUI_MemberController_renewFailed_edge0_target;
		while ((MobileLibraryGUI_MemberController_renewFailed_edge0_target = [MobileLibraryGUI_MemberController_renewFailed_edge0_enum nextObject]) != nil) {
		    [MobileLibraryGUI_MemberController_renewFailed_edge0_target event_renewFailed_pulled_edge0:changes parentInstance:self p_copy:p_copy ];
		}



		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_renew_pushed:(PropertyChangeList*) changes  p_newDueDate: (OCLString*) p_newDueDate{
	{ // New scope for following guard code:
		/* ==================================================
		 * state = 'Onloan'
		 * ================================================== */
		
		Library_Copy* v2 = self;
		OCLString* v1 = [v2 _state];
		OCLString* v3 = [(OCLString*)[OCLString alloc] initWithString:@"Onloan"];
		OCLBoolean* v0 = [v1 eq:v3];
		[v3 release];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_renew", @"Library_Copy");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {
			/* ==================================================
			 * newDueDate
			 * ================================================== */
			
			OCLString* v1 = p_newDueDate;
			
			OCLString* parameter_p_newDueDate = v1;

			[self event_renewOk_pushed:changes p_newDueDate:parameter_p_newDueDate ];
		}
		[v0 release];
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v2 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v2->value == YES) {
			/* ==================================================
			 * self
			 * ================================================== */
			
			Library_Copy* v3 = self;
			
			Library_Copy* parameter_p_copy = v3;

			[self event_renewFailed_pushed:changes p_copy:parameter_p_copy ];
		}
		[v2 release];


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_reserve_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_reserve", @"Library_Copy");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {

			[self event_reserveOk_pushed:changes ];
		}
		[v0 release];
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v1 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v1->value == YES) {

			[self event_reserveFailed_pushed:changes ];
		}
		[v1 release];


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_reserveOk_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * state = 'Borrowable'
		 * ================================================== */
		
		Library_Copy* v2 = self;
		OCLString* v1 = [v2 _state];
		OCLString* v3 = [(OCLString*)[OCLString alloc] initWithString:@"Borrowable"];
		OCLBoolean* v0 = [v1 eq:v3];
		[v3 release];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_reserveOk", @"Library_Copy");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges
		NSEnumerator* MobileLibraryGUI_BookDetailController_copyReserved_edge0_enum = [self->MobileLibraryGUI_BookDetailController_selectedCopy_back objectEnumerator];
		MobileLibraryGUI_BookDetailController* MobileLibraryGUI_BookDetailController_copyReserved_edge0_target;
		while ((MobileLibraryGUI_BookDetailController_copyReserved_edge0_target = [MobileLibraryGUI_BookDetailController_copyReserved_edge0_enum nextObject]) != nil) {
		    [MobileLibraryGUI_BookDetailController_copyReserved_edge0_target event_copyReserved_pulled_edge0:changes parentInstance:self ];
		}



		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * 'ToCollect'
		 * ================================================== */
		
		OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@"ToCollect"];
		
		OCLString* _state_newValue = v0;
		[changes addChange:@selector(set_state:) instance:self value:_state_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_reserveFailed_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * state <> 'Borrowable'
		 * ================================================== */
		
		Library_Copy* v2 = self;
		OCLString* v1 = [v2 _state];
		OCLString* v3 = [(OCLString*)[OCLString alloc] initWithString:@"Borrowable"];
		OCLBoolean* v0 = [v1 neq:v3];
		[v3 release];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_reserveFailed", @"Library_Copy");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges
		NSEnumerator* MobileLibraryGUI_BookDetailController_reserveFailed_edge0_enum = [self->MobileLibraryGUI_BookDetailController_selectedCopy_back objectEnumerator];
		MobileLibraryGUI_BookDetailController* MobileLibraryGUI_BookDetailController_reserveFailed_edge0_target;
		while ((MobileLibraryGUI_BookDetailController_reserveFailed_edge0_target = [MobileLibraryGUI_BookDetailController_reserveFailed_edge0_enum nextObject]) != nil) {
		    [MobileLibraryGUI_BookDetailController_reserveFailed_edge0_target event_reserveFailed_pulled_edge0:changes parentInstance:self ];
		}



		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 




 
-(OCLInteger*) maxRenewals{
	/* ==================================================
	 * 3
	 * ================================================== */
	
	OCLInteger* v0 = [(OCLInteger*)[OCLInteger alloc] initWithValue:3];
	;
	return v0;
}


@end 


