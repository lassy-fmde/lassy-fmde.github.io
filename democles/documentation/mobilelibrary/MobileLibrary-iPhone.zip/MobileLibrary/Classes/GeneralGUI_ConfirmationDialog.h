 
 
 
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "OCLTypes.h"
#import "IBinding.h"

@class PropertyChangeList;
@class GeneralGUI_ConfirmationDialog;
@class MobileLibraryGUI_BookDetailController;
@class MobileLibraryGUI_MemberController;


 
 
@interface GeneralGUI_ConfirmationDialog : OCLAny <IBinding, UIAlertViewDelegate>
{
	 
	OCLString* _title;
	BOOL _title_initialized;
	OCLString* _message;
	BOOL _message_initialized;


@public
	NSMutableArray *MobileLibraryGUI_BookDetailController_yesNoMsg_back;
	NSMutableArray *MobileLibraryGUI_MemberController_yesNoMsg_back;


	
	@protected
	UIAlertView* binding;
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex;

 
-(GeneralGUI_ConfirmationDialog*)init;
-(GeneralGUI_ConfirmationDialog*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(OCLString*) _title;
-(OCLString*) initial_title;
-(void) set_title:(OCLString*) value;
-(OCLString*) _message;
-(OCLString*) initial_message;
-(void) set_message:(OCLString*) value;

-(void) event_okClicked_pushed:(PropertyChangeList*) changes ;
-(void) event_close_pushed:(PropertyChangeList*) changes ;
-(void) event_cancelClicked_pushed:(PropertyChangeList*) changes ;

 
-(id) getBinding;
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value;
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters;
-(void) onPropertyChange: (NSString*)propertyName newValue:(id<OCLAny>)value;


@end


