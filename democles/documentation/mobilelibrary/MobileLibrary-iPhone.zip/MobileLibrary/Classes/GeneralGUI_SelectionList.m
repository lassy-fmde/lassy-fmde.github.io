 
 
 
#import "GeneralGUI_SelectionList.h"
#import "PropertyChangeList.h"
#import "MobileLibraryGUI_MemberController.h"
#import "MobileLibraryGUI_SearchResultsController.h"
#import "MobileLibraryGUI_BookDetailController.h"


 
@implementation GeneralGUI_SelectionList


-(void)create_binding {
	self->binding = [[UITableView alloc] init];
	[self->binding retain];
	self->binding.delegate = self;
	self->binding.dataSource = self;
}
 
- (id) init {
	self = [super init];
	 
	[self performSelectorOnMainThread:@selector(create_binding) withObject:nil waitUntilDone:YES]; 	

	 
	self->MobileLibraryGUI_MemberController_borrowItems_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_MemberController_collectItems_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_SearchResultsController_bookListTable_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_BookDetailController_bookCopies_back = [[NSMutableArray alloc] init];

	[self set_items: [self _items]];


	return self;
}

 
- (id) initWithValues: (OCLTuple*) values {
	self = [super init];
	 
	[self performSelectorOnMainThread:@selector(create_binding) withObject:nil waitUntilDone:YES]; 	

	 
	self->_items_initialized = NO;

	self->MobileLibraryGUI_MemberController_borrowItems_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_MemberController_collectItems_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_SearchResultsController_bookListTable_back = [[NSMutableArray alloc] init];
	self->MobileLibraryGUI_BookDetailController_bookCopies_back = [[NSMutableArray alloc] init];

	OCLSequence* _items_initialValue = (OCLSequence*) [values objectForKey:@"items"];
	if (_items_initialValue == nil) {
		_items_initialValue = [self _items];
	}
	[self set_items:_items_initialValue];


	return self;
}

 
- (void) dealloc {
	if (self->_items != nil && self->_items != (OCLSequence*) [NSNull null]) [self->_items release];

	[self->MobileLibraryGUI_MemberController_borrowItems_back release];
	[self->MobileLibraryGUI_MemberController_collectItems_back release];
	[self->MobileLibraryGUI_SearchResultsController_bookListTable_back release];
	[self->MobileLibraryGUI_BookDetailController_bookCopies_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"GeneralGUI::SelectionList\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"items\" type=\"Sequence\">\n"];
	[res appendFormat:@"%@\n", [self _items]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
-(OCLSequence*) initial_items {
	/* ==================================================
	 * Sequence {}
	 * ================================================== */
	
	OCLSequence* v0 = [(OCLSequence*)[OCLSequence alloc] init];
	
	return v0;
}

-(OCLSequence*) _items {
	if (self->_items_initialized == YES) {
		return _items;
	} else { 
		[self set_items:[self initial_items]];
	}

	self->_items_initialized = YES;
	return _items;
}


 
-(void) set_items:(OCLSequence*) value {
	 	if (self->_items!= nil && self->_items!= (OCLSequence*) [NSNull null]) {
		[self->_items release];
	}
	self->_items = value;
	if (self->_items!= nil && self->_items!= (OCLSequence*) [NSNull null]) {
		[self->_items retain];
	}
	self->_items_initialized = YES;
	
	[self onPropertyChange:@"items" newValue:value];
}






 

 
-(void) event_itemSelected_pushed:(PropertyChangeList*) changes  p_index: (OCLInteger*) p_index{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_itemSelected", @"GeneralGUI_SelectionList");

		OCLTuple* parameters = [[OCLTuple alloc] init];
		[parameters addItemNamed:@"index" withValue:p_index]; 

		[self onEvent:@"itemSelected" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges
		NSEnumerator* MobileLibraryGUI_SearchResultsController_bookSelected_edge0_enum = [self->MobileLibraryGUI_SearchResultsController_bookListTable_back objectEnumerator];
		MobileLibraryGUI_SearchResultsController* MobileLibraryGUI_SearchResultsController_bookSelected_edge0_target;
		while ((MobileLibraryGUI_SearchResultsController_bookSelected_edge0_target = [MobileLibraryGUI_SearchResultsController_bookSelected_edge0_enum nextObject]) != nil) {
		    [MobileLibraryGUI_SearchResultsController_bookSelected_edge0_target event_bookSelected_pulled_edge0:changes parentInstance:self p_index:p_index ];
		}

		NSEnumerator* MobileLibraryGUI_MemberController_borrowItemSelected_edge0_enum = [self->MobileLibraryGUI_MemberController_borrowItems_back objectEnumerator];
		MobileLibraryGUI_MemberController* MobileLibraryGUI_MemberController_borrowItemSelected_edge0_target;
		while ((MobileLibraryGUI_MemberController_borrowItemSelected_edge0_target = [MobileLibraryGUI_MemberController_borrowItemSelected_edge0_enum nextObject]) != nil) {
		    [MobileLibraryGUI_MemberController_borrowItemSelected_edge0_target event_borrowItemSelected_pulled_edge0:changes parentInstance:self p_index:p_index ];
		}

		NSEnumerator* MobileLibraryGUI_BookDetailController_bookCopyItemSelected_edge0_enum = [self->MobileLibraryGUI_BookDetailController_bookCopies_back objectEnumerator];
		MobileLibraryGUI_BookDetailController* MobileLibraryGUI_BookDetailController_bookCopyItemSelected_edge0_target;
		while ((MobileLibraryGUI_BookDetailController_bookCopyItemSelected_edge0_target = [MobileLibraryGUI_BookDetailController_bookCopyItemSelected_edge0_enum nextObject]) != nil) {
		    [MobileLibraryGUI_BookDetailController_bookCopyItemSelected_edge0_target event_bookCopyItemSelected_pulled_edge0:changes parentInstance:self p_index:p_index ];
		}



		 	
		// Trigger local edges


		 
		 // Process impacts relationships


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_refreshItems_pushed:(PropertyChangeList*) changes  p_items: (OCLSequence*) p_items{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_refreshItems", @"GeneralGUI_SelectionList");

		OCLTuple* parameters = [[OCLTuple alloc] init];
		[parameters addItemNamed:@"items" withValue:p_items]; 

		[self onEvent:@"refreshItems" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * items
		 * ================================================== */
		
		OCLSequence* v0 = p_items;
		
		OCLSequence* _items_newValue = v0;
		[changes addChange:@selector(set_items:) instance:self value:_items_newValue];


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 




 
- (NSInteger) tableView:(UITableView *) tableView numberOfRowsInSection:(NSInteger)section { 
	OCLInteger* size = [[ self _items] size];
	return size->value;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	static NSString *CellIdentifier = @"GeneralGUI_SelectionListCellIdentifier";
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	if (cell == nil) { 
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
		cell.accessoryType = UITableViewCellAccessoryDetailDisclosureButton;
	}
	NSUInteger row = [indexPath row];
	OCLInteger* rowOCL = [(OCLInteger*)[OCLInteger alloc] initWithValue:row + 1];
	OCLString* text = (OCLString*) [[ self _items] at: rowOCL];
	[cell.textLabel setText:text->string]; 
	return cell;
}

 
-(void)triggerRowSelectedEvent:(OCLInteger*)rowNr {
	NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
	[self event_itemSelected_pushed:NULL p_index:rowNr];
	[pool release];
}

- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath {
	NSUInteger row = [indexPath row];
	OCLInteger* rowOCL = [(OCLInteger*)[OCLInteger alloc] initWithValue:row+1];
	[self performSelectorInBackground:@selector(triggerRowSelectedEvent:) withObject:rowOCL];
}

 
-(void)onPropertyChange_async:(NSDictionary*)parameters {
	NSString* propertyName = [parameters objectForKey:@"propertyName"];
	id value = [parameters objectForKey:@"value"];

	if ([propertyName isEqual:@"items"]){ 
		[self->binding reloadData];
	}	
	[parameters release];
}

-(void)onPropertyChange:(NSString*)propertyName newValue:(id) value {
	NSMutableDictionary* parameters = [[NSMutableDictionary alloc] init];
	[parameters setValue:propertyName forKey:@"propertyName"];
	[parameters setValue:value forKey:@"value"];
	[parameters retain];
	[self performSelectorOnMainThread:@selector(onPropertyChange_async:) withObject:parameters waitUntilDone:NO];
}

 
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters{
}

 
-(id) getBinding {
	return self->binding;
}

 
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value {
}


@end 


