 
 
 
#import "MobileLibraryGUI_LoginController.h"
#import "PropertyChangeList.h"
#import "GeneralGUI_MsgDialog.h"
#import "MobileLibraryGUI_LoginController.h"
#import "GeneralGUI_Textfield.h"
#import "GeneralGUI_Frame.h"
#import "GeneralGUI_Button.h"
#import "GeneralGUI_Label.h"
#import "Application_Main.h"


 
@implementation MobileLibraryGUI_LoginController

 
- (MobileLibraryGUI_LoginController*) init {
	self = [super init];
	 
	self->Application_Main_loginControl_back = [[NSMutableArray alloc] init];

	[self set_libraryNoLabel: [self _libraryNoLabel]];
	[self set_libraryNoField: [self _libraryNoField]];
	[self set_passwordLabel: [self _passwordLabel]];
	[self set_passwordField: [self _passwordField]];
	[self set_loginButton: [self _loginButton]];
	[self set_title: [self _title]];
	[self set_frame: [self _frame]];
	[self set_currMsg: [self _currMsg]];
	[self set_ackStatus: [self _ackStatus]];

	return self;
}

 
- (MobileLibraryGUI_LoginController*) initWithValues: (OCLTuple*) values {
	self = [super init];
	 
	self->_libraryNoLabel_initialized = NO;
	self->_libraryNoField_initialized = NO;
	self->_passwordLabel_initialized = NO;
	self->_passwordField_initialized = NO;
	self->_loginButton_initialized = NO;
	self->_title_initialized = NO;
	self->_frame_initialized = NO;
	self->_currMsg_initialized = NO;
	self->_ackStatus_initialized = NO;

	self->Application_Main_loginControl_back = [[NSMutableArray alloc] init];

	GeneralGUI_Label* _libraryNoLabel_initialValue = (GeneralGUI_Label*) [values objectForKey:@"libraryNoLabel"];
	if (_libraryNoLabel_initialValue == nil) {
		_libraryNoLabel_initialValue = [self _libraryNoLabel];
	}
	[self set_libraryNoLabel:_libraryNoLabel_initialValue];
	GeneralGUI_Textfield* _libraryNoField_initialValue = (GeneralGUI_Textfield*) [values objectForKey:@"libraryNoField"];
	if (_libraryNoField_initialValue == nil) {
		_libraryNoField_initialValue = [self _libraryNoField];
	}
	[self set_libraryNoField:_libraryNoField_initialValue];
	GeneralGUI_Label* _passwordLabel_initialValue = (GeneralGUI_Label*) [values objectForKey:@"passwordLabel"];
	if (_passwordLabel_initialValue == nil) {
		_passwordLabel_initialValue = [self _passwordLabel];
	}
	[self set_passwordLabel:_passwordLabel_initialValue];
	GeneralGUI_Textfield* _passwordField_initialValue = (GeneralGUI_Textfield*) [values objectForKey:@"passwordField"];
	if (_passwordField_initialValue == nil) {
		_passwordField_initialValue = [self _passwordField];
	}
	[self set_passwordField:_passwordField_initialValue];
	GeneralGUI_Button* _loginButton_initialValue = (GeneralGUI_Button*) [values objectForKey:@"loginButton"];
	if (_loginButton_initialValue == nil) {
		_loginButton_initialValue = [self _loginButton];
	}
	[self set_loginButton:_loginButton_initialValue];
	OCLString* _title_initialValue = (OCLString*) [values objectForKey:@"title"];
	if (_title_initialValue == nil) {
		_title_initialValue = [self _title];
	}
	[self set_title:_title_initialValue];
	GeneralGUI_Frame* _frame_initialValue = (GeneralGUI_Frame*) [values objectForKey:@"frame"];
	if (_frame_initialValue == nil) {
		_frame_initialValue = [self _frame];
	}
	[self set_frame:_frame_initialValue];
	GeneralGUI_MsgDialog* _currMsg_initialValue = (GeneralGUI_MsgDialog*) [values objectForKey:@"currMsg"];
	if (_currMsg_initialValue == nil) {
		_currMsg_initialValue = [self _currMsg];
	}
	[self set_currMsg:_currMsg_initialValue];
	OCLString* _ackStatus_initialValue = (OCLString*) [values objectForKey:@"ackStatus"];
	if (_ackStatus_initialValue == nil) {
		_ackStatus_initialValue = [self _ackStatus];
	}
	[self set_ackStatus:_ackStatus_initialValue];

	
	return self;
}

 
- (void) dealloc {
	if (self->_libraryNoLabel != nil && self->_libraryNoLabel != (GeneralGUI_Label*) [NSNull null]) [self->_libraryNoLabel release];
	if (self->_libraryNoField != nil && self->_libraryNoField != (GeneralGUI_Textfield*) [NSNull null]) [self->_libraryNoField release];
	if (self->_passwordLabel != nil && self->_passwordLabel != (GeneralGUI_Label*) [NSNull null]) [self->_passwordLabel release];
	if (self->_passwordField != nil && self->_passwordField != (GeneralGUI_Textfield*) [NSNull null]) [self->_passwordField release];
	if (self->_loginButton != nil && self->_loginButton != (GeneralGUI_Button*) [NSNull null]) [self->_loginButton release];
	if (self->_title != nil && self->_title != (OCLString*) [NSNull null]) [self->_title release];
	if (self->_frame != nil && self->_frame != (GeneralGUI_Frame*) [NSNull null]) [self->_frame release];
	if (self->_currMsg != nil && self->_currMsg != (GeneralGUI_MsgDialog*) [NSNull null]) [self->_currMsg release];
	if (self->_ackStatus != nil && self->_ackStatus != (OCLString*) [NSNull null]) [self->_ackStatus release];

	[self->Application_Main_loginControl_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"MobileLibraryGUI::LoginController\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"libraryNoLabel\" type=\"GeneralGUI::Label\">\n"];
	[res appendFormat:@"%@\n", [self _libraryNoLabel]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"libraryNoField\" type=\"GeneralGUI::Textfield\">\n"];
	[res appendFormat:@"%@\n", [self _libraryNoField]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"passwordLabel\" type=\"GeneralGUI::Label\">\n"];
	[res appendFormat:@"%@\n", [self _passwordLabel]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"passwordField\" type=\"GeneralGUI::Textfield\">\n"];
	[res appendFormat:@"%@\n", [self _passwordField]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"loginButton\" type=\"GeneralGUI::Button\">\n"];
	[res appendFormat:@"%@\n", [self _loginButton]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"title\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _title]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"frame\" type=\"GeneralGUI::Frame\">\n"];
	[res appendFormat:@"%@\n", [self _frame]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"currMsg\" type=\"GeneralGUI::MsgDialog\">\n"];
	[res appendFormat:@"%@\n", [self _currMsg]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"ackStatus\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _ackStatus]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
-(GeneralGUI_Label*) initial_libraryNoLabel {
	/* ==================================================
	 * GeneralGUI::Label::create(Tuple { text = 'Library No:' })
	 * ================================================== */
	
	OCLString* v4 = [(OCLString*)[OCLString alloc] initWithString:@"Library No:"];
	OCLString* v3 = v4;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"text" withValue:v3];
	GeneralGUI_Label* v0 = [(GeneralGUI_Label*)[GeneralGUI_Label alloc] initWithValues:v2];
	[v2 release];
	[v4 release];
	
	return v0;
}

-(GeneralGUI_Label*) _libraryNoLabel {
	if (self->_libraryNoLabel_initialized == YES) {
		return _libraryNoLabel;
	} else { 
		[self set_libraryNoLabel:[self initial_libraryNoLabel]];
	}

	self->_libraryNoLabel_initialized = YES;
	return _libraryNoLabel;
}
-(GeneralGUI_Textfield*) initial_libraryNoField {
	/* ==================================================
	 * GeneralGUI::Textfield::create(Tuple { text = '' })
	 * ================================================== */
	
	OCLString* v4 = [(OCLString*)[OCLString alloc] initWithString:@""];
	OCLString* v3 = v4;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"text" withValue:v3];
	GeneralGUI_Textfield* v0 = [(GeneralGUI_Textfield*)[GeneralGUI_Textfield alloc] initWithValues:v2];
	[v4 release];
	[v2 release];
	
	return v0;
}

-(GeneralGUI_Textfield*) _libraryNoField {
	if (self->_libraryNoField_initialized == YES) {
		return _libraryNoField;
	} else { 
		[self set_libraryNoField:[self initial_libraryNoField]];
	}

	self->_libraryNoField_initialized = YES;
	return _libraryNoField;
}
-(GeneralGUI_Label*) initial_passwordLabel {
	/* ==================================================
	 * GeneralGUI::Label::create(Tuple { text = 'Password:' })
	 * ================================================== */
	
	OCLString* v4 = [(OCLString*)[OCLString alloc] initWithString:@"Password:"];
	OCLString* v3 = v4;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"text" withValue:v3];
	GeneralGUI_Label* v0 = [(GeneralGUI_Label*)[GeneralGUI_Label alloc] initWithValues:v2];
	[v2 release];
	[v4 release];
	
	return v0;
}

-(GeneralGUI_Label*) _passwordLabel {
	if (self->_passwordLabel_initialized == YES) {
		return _passwordLabel;
	} else { 
		[self set_passwordLabel:[self initial_passwordLabel]];
	}

	self->_passwordLabel_initialized = YES;
	return _passwordLabel;
}
-(GeneralGUI_Textfield*) initial_passwordField {
	/* ==================================================
	 * GeneralGUI::Textfield::create(Tuple { text = '' })
	 * ================================================== */
	
	OCLString* v4 = [(OCLString*)[OCLString alloc] initWithString:@""];
	OCLString* v3 = v4;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"text" withValue:v3];
	GeneralGUI_Textfield* v0 = [(GeneralGUI_Textfield*)[GeneralGUI_Textfield alloc] initWithValues:v2];
	[v2 release];
	[v4 release];
	
	return v0;
}

-(GeneralGUI_Textfield*) _passwordField {
	if (self->_passwordField_initialized == YES) {
		return _passwordField;
	} else { 
		[self set_passwordField:[self initial_passwordField]];
	}

	self->_passwordField_initialized = YES;
	return _passwordField;
}
-(GeneralGUI_Button*) initial_loginButton {
	/* ==================================================
	 * GeneralGUI::Button::create(Tuple { text = 'Login' })
	 * ================================================== */
	
	OCLString* v4 = [(OCLString*)[OCLString alloc] initWithString:@"Login"];
	OCLString* v3 = v4;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"text" withValue:v3];
	GeneralGUI_Button* v0 = [(GeneralGUI_Button*)[GeneralGUI_Button alloc] initWithValues:v2];
	[v2 release];
	[v4 release];
	
	return v0;
}

-(GeneralGUI_Button*) _loginButton {
	if (self->_loginButton_initialized == YES) {
		return _loginButton;
	} else { 
		[self set_loginButton:[self initial_loginButton]];
	}

	self->_loginButton_initialized = YES;
	return _loginButton;
}
-(OCLString*) initial_title {
	/* ==================================================
	 * 'Login'
	 * ================================================== */
	
	OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@"Login"];
	
	return v0;
}

-(OCLString*) _title {
	if (self->_title_initialized == YES) {
		return _title;
	} else { 
		[self set_title:[self initial_title]];
	}

	self->_title_initialized = YES;
	return _title;
}
-(GeneralGUI_Frame*) initial_frame {
	/* ==================================================
	 * GeneralGUI::Frame::create(
	 * 	Tuple { seqGUIElements = Sequence {libraryNoLabel, libraryNoField, passwordLabel, passwordField, loginButton }, 
	 * 	frameTitle = title,
	 * 	iconFilename = 'icon-house.png' })
	 * ================================================== */
	
	MobileLibraryGUI_LoginController* v7 = self;
	GeneralGUI_Label* v6 = [v7 _libraryNoLabel];
	GeneralGUI_Label* v5 = v6;
	MobileLibraryGUI_LoginController* v10 = self;
	GeneralGUI_Textfield* v9 = [v10 _libraryNoField];
	GeneralGUI_Textfield* v8 = v9;
	MobileLibraryGUI_LoginController* v13 = self;
	GeneralGUI_Label* v12 = [v13 _passwordLabel];
	GeneralGUI_Label* v11 = v12;
	MobileLibraryGUI_LoginController* v16 = self;
	GeneralGUI_Textfield* v15 = [v16 _passwordField];
	GeneralGUI_Textfield* v14 = v15;
	MobileLibraryGUI_LoginController* v19 = self;
	GeneralGUI_Button* v18 = [v19 _loginButton];
	GeneralGUI_Button* v17 = v18;
	OCLSequence* v4 = [(OCLSequence*)[OCLSequence alloc] init];
	[v4 add:v5];
	[v4 add:v8];
	[v4 add:v11];
	[v4 add:v14];
	[v4 add:v17];
	OCLSequence* v3 = v4;
	MobileLibraryGUI_LoginController* v22 = self;
	OCLString* v21 = [v22 _title];
	OCLString* v20 = v21;
	OCLString* v24 = [(OCLString*)[OCLString alloc] initWithString:@"icon-house.png"];
	OCLString* v23 = v24;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"seqGUIElements" withValue:v3];
	[v2 addItemNamed:@"frameTitle" withValue:v20];
	[v2 addItemNamed:@"iconFilename" withValue:v23];
	GeneralGUI_Frame* v0 = [(GeneralGUI_Frame*)[GeneralGUI_Frame alloc] initWithValues:v2];
	[v4 release];
	[v2 release];
	[v24 release];
	
	return v0;
}

-(GeneralGUI_Frame*) _frame {
	if (self->_frame_initialized == YES) {
		return _frame;
	} else { 
		[self set_frame:[self initial_frame]];
	}

	self->_frame_initialized = YES;
	return _frame;
}
-(GeneralGUI_MsgDialog*) initial_currMsg {
	/* ==================================================
	 * null
	 * ================================================== */
	
	GeneralGUI_MsgDialog* v0 = [NSNull null];
	
	return v0;
}

-(GeneralGUI_MsgDialog*) _currMsg {
	if (self->_currMsg_initialized == YES) {
		return _currMsg;
	} else { 
		[self set_currMsg:[self initial_currMsg]];
	}

	self->_currMsg_initialized = YES;
	return _currMsg;
}
-(OCLString*) initial_ackStatus {
	/* ==================================================
	 * 'NotWaiting'
	 * ================================================== */
	
	OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@"NotWaiting"];
	
	return v0;
}

-(OCLString*) _ackStatus {
	if (self->_ackStatus_initialized == YES) {
		return _ackStatus;
	} else { 
		[self set_ackStatus:[self initial_ackStatus]];
	}

	self->_ackStatus_initialized = YES;
	return _ackStatus;
}


 
-(void) set_title:(OCLString*) value {
	 	if (self->_title!= nil && self->_title!= (OCLString*) [NSNull null]) {
		[self->_title release];
	}
	self->_title = value;
	if (self->_title!= nil && self->_title!= (OCLString*) [NSNull null]) {
		[self->_title retain];
	}
	self->_title_initialized = YES;

}
-(void) set_ackStatus:(OCLString*) value {
	 	if (self->_ackStatus!= nil && self->_ackStatus!= (OCLString*) [NSNull null]) {
		[self->_ackStatus release];
	}
	self->_ackStatus = value;
	if (self->_ackStatus!= nil && self->_ackStatus!= (OCLString*) [NSNull null]) {
		[self->_ackStatus retain];
	}
	self->_ackStatus_initialized = YES;

}


-(void) set_libraryNoLabel:(GeneralGUI_Label*) value {
	 
	if (self->_libraryNoLabel!= nil && self->_libraryNoLabel!= (GeneralGUI_Label*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_libraryNoLabel valueForKey:@"MobileLibraryGUI_LoginController_libraryNoLabel_back"];
		[backpointers removeObject:self];
		[self->_libraryNoLabel release];
	}
	self->_libraryNoLabel = value;
	if (self->_libraryNoLabel!= nil && self->_libraryNoLabel!= (GeneralGUI_Label*) [NSNull null]) {
		[self->_libraryNoLabel retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_libraryNoLabel valueForKey:@"MobileLibraryGUI_LoginController_libraryNoLabel_back"];
		[backpointers addObject:self];
	}
	self->_libraryNoLabel_initialized = YES;

}
-(void) set_libraryNoField:(GeneralGUI_Textfield*) value {
	 
	if (self->_libraryNoField!= nil && self->_libraryNoField!= (GeneralGUI_Textfield*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_libraryNoField valueForKey:@"MobileLibraryGUI_LoginController_libraryNoField_back"];
		[backpointers removeObject:self];
		[self->_libraryNoField release];
	}
	self->_libraryNoField = value;
	if (self->_libraryNoField!= nil && self->_libraryNoField!= (GeneralGUI_Textfield*) [NSNull null]) {
		[self->_libraryNoField retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_libraryNoField valueForKey:@"MobileLibraryGUI_LoginController_libraryNoField_back"];
		[backpointers addObject:self];
	}
	self->_libraryNoField_initialized = YES;

}
-(void) set_passwordLabel:(GeneralGUI_Label*) value {
	 
	if (self->_passwordLabel!= nil && self->_passwordLabel!= (GeneralGUI_Label*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_passwordLabel valueForKey:@"MobileLibraryGUI_LoginController_passwordLabel_back"];
		[backpointers removeObject:self];
		[self->_passwordLabel release];
	}
	self->_passwordLabel = value;
	if (self->_passwordLabel!= nil && self->_passwordLabel!= (GeneralGUI_Label*) [NSNull null]) {
		[self->_passwordLabel retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_passwordLabel valueForKey:@"MobileLibraryGUI_LoginController_passwordLabel_back"];
		[backpointers addObject:self];
	}
	self->_passwordLabel_initialized = YES;

}
-(void) set_passwordField:(GeneralGUI_Textfield*) value {
	 
	if (self->_passwordField!= nil && self->_passwordField!= (GeneralGUI_Textfield*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_passwordField valueForKey:@"MobileLibraryGUI_LoginController_passwordField_back"];
		[backpointers removeObject:self];
		[self->_passwordField release];
	}
	self->_passwordField = value;
	if (self->_passwordField!= nil && self->_passwordField!= (GeneralGUI_Textfield*) [NSNull null]) {
		[self->_passwordField retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_passwordField valueForKey:@"MobileLibraryGUI_LoginController_passwordField_back"];
		[backpointers addObject:self];
	}
	self->_passwordField_initialized = YES;

}
-(void) set_loginButton:(GeneralGUI_Button*) value {
	 
	if (self->_loginButton!= nil && self->_loginButton!= (GeneralGUI_Button*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_loginButton valueForKey:@"MobileLibraryGUI_LoginController_loginButton_back"];
		[backpointers removeObject:self];
		[self->_loginButton release];
	}
	self->_loginButton = value;
	if (self->_loginButton!= nil && self->_loginButton!= (GeneralGUI_Button*) [NSNull null]) {
		[self->_loginButton retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_loginButton valueForKey:@"MobileLibraryGUI_LoginController_loginButton_back"];
		[backpointers addObject:self];
	}
	self->_loginButton_initialized = YES;

}
-(void) set_frame:(GeneralGUI_Frame*) value {
	 
	if (self->_frame!= nil && self->_frame!= (GeneralGUI_Frame*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_frame valueForKey:@"MobileLibraryGUI_LoginController_frame_back"];
		[backpointers removeObject:self];
		[self->_frame release];
	}
	self->_frame = value;
	if (self->_frame!= nil && self->_frame!= (GeneralGUI_Frame*) [NSNull null]) {
		[self->_frame retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_frame valueForKey:@"MobileLibraryGUI_LoginController_frame_back"];
		[backpointers addObject:self];
	}
	self->_frame_initialized = YES;

}
-(void) set_currMsg:(GeneralGUI_MsgDialog*) value {
	 
	if (self->_currMsg!= nil && self->_currMsg!= (GeneralGUI_MsgDialog*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_currMsg valueForKey:@"MobileLibraryGUI_LoginController_currMsg_back"];
		[backpointers removeObject:self];
		[self->_currMsg release];
	}
	self->_currMsg = value;
	if (self->_currMsg!= nil && self->_currMsg!= (GeneralGUI_MsgDialog*) [NSNull null]) {
		[self->_currMsg retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_currMsg valueForKey:@"MobileLibraryGUI_LoginController_currMsg_back"];
		[backpointers addObject:self];
	}
	self->_currMsg_initialized = YES;

}




 
-(void) event_authenticate_pushed:(PropertyChangeList*) changes  p_libNo: (OCLString*) p_libNo p_password: (OCLString*) p_password{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_authenticate", @"MobileLibraryGUI_LoginController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges
		NSEnumerator* Application_Main_authenticate_edge0_enum = [self->Application_Main_loginControl_back objectEnumerator];
		Application_Main* Application_Main_authenticate_edge0_target;
		while ((Application_Main_authenticate_edge0_target = [Application_Main_authenticate_edge0_enum nextObject]) != nil) {
		    [Application_Main_authenticate_edge0_target event_authenticate_pulled_edge0:changes parentInstance:self p_libNo:p_libNo p_password:p_password ];
		}



		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_authenticate_pulled_edge0:(PropertyChangeList*)changes parentInstance:(GeneralGUI_Button*)parentInstance  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_authenticate", @"MobileLibraryGUI_LoginController", @"_clicked", @"GeneralGUI_Button");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {
		/* ==================================================
		 * libraryNoField.text
		 * ================================================== */
		
		MobileLibraryGUI_LoginController* v3 = self;
		GeneralGUI_Textfield* v2 = [v3 _libraryNoField];
		OCLString* v1 = [v2 _text];
		
		OCLString* parameter_p_libNo = v1;
		/* ==================================================
		 * passwordField.text
		 * ================================================== */
		
		MobileLibraryGUI_LoginController* v6 = self;
		GeneralGUI_Textfield* v5 = [v6 _passwordField];
		OCLString* v4 = [v5 _text];
		
		OCLString* parameter_p_password = v4;

		[self event_authenticate_pushed:changes p_libNo:parameter_p_libNo p_password:parameter_p_password ];

	}
	[v0 release];
}


-(void) event_loginOk_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_loginOk", @"MobileLibraryGUI_LoginController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {

			[self event_showLoginSucessfulMsg_pushed:changes ];
		}
		[v0 release];


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_showLoginSucessfulMsg_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_showLoginSucessfulMsg", @"MobileLibraryGUI_LoginController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * GeneralGUI::MsgDialog::create(
		 * 	Tuple { 
		 * 	    msg = 'You are now logged into the library!', 
		 * 		viewTitle = 'Success!' })
		 * ================================================== */
		
		OCLString* v4 = [(OCLString*)[OCLString alloc] initWithString:@"You are now logged into the library!"];
		OCLString* v3 = v4;
		OCLString* v6 = [(OCLString*)[OCLString alloc] initWithString:@"Success!"];
		OCLString* v5 = v6;
		OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
		[v2 addItemNamed:@"msg" withValue:v3];
		[v2 addItemNamed:@"viewTitle" withValue:v5];
		GeneralGUI_MsgDialog* v0 = [(GeneralGUI_MsgDialog*)[GeneralGUI_MsgDialog alloc] initWithValues:v2];
		[v2 release];
		[v4 release];
		[v6 release];
		
		GeneralGUI_MsgDialog* _currMsg_newValue = v0;
		[changes addChange:@selector(set_currMsg:) instance:self value:_currMsg_newValue];
		/* ==================================================
		 * 'WaitingLoginAck'
		 * ================================================== */
		
		OCLString* v7 = [(OCLString*)[OCLString alloc] initWithString:@"WaitingLoginAck"];
		
		OCLString* _ackStatus_newValue = v7;
		[changes addChange:@selector(set_ackStatus:) instance:self value:_ackStatus_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_showInvalidLoginMsg_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_showInvalidLoginMsg", @"MobileLibraryGUI_LoginController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * GeneralGUI::MsgDialog::create(
		 * 	Tuple { 
		 * 	    msg = 'Invalid Library Number  or wrong password!', 
		 * 		viewTitle = 'Error!' })
		 * ================================================== */
		
		OCLString* v4 = [(OCLString*)[OCLString alloc] initWithString:@"Invalid Library Number  or wrong password!"];
		OCLString* v3 = v4;
		OCLString* v6 = [(OCLString*)[OCLString alloc] initWithString:@"Error!"];
		OCLString* v5 = v6;
		OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
		[v2 addItemNamed:@"msg" withValue:v3];
		[v2 addItemNamed:@"viewTitle" withValue:v5];
		GeneralGUI_MsgDialog* v0 = [(GeneralGUI_MsgDialog*)[GeneralGUI_MsgDialog alloc] initWithValues:v2];
		[v6 release];
		[v2 release];
		[v4 release];
		
		GeneralGUI_MsgDialog* _currMsg_newValue = v0;
		[changes addChange:@selector(set_currMsg:) instance:self value:_currMsg_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_setToNotWaiting_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_setToNotWaiting", @"MobileLibraryGUI_LoginController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * 'NotWaiting'
		 * ================================================== */
		
		OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@"NotWaiting"];
		
		OCLString* _ackStatus_newValue = v0;
		[changes addChange:@selector(set_ackStatus:) instance:self value:_ackStatus_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_loginFailed_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_loginFailed", @"MobileLibraryGUI_LoginController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {

			[self event_showInvalidLoginMsg_pushed:changes ];
		}
		[v0 release];


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_loginAck_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * ackStatus='WaitingLoginAck'
		 * ================================================== */
		
		MobileLibraryGUI_LoginController* v2 = self;
		OCLString* v1 = [v2 _ackStatus];
		OCLString* v3 = [(OCLString*)[OCLString alloc] initWithString:@"WaitingLoginAck"];
		OCLBoolean* v0 = [v1 eq:v3];
		[v3 release];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_loginAck", @"MobileLibraryGUI_LoginController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {

			[self event_setToNotWaiting_pushed:changes ];
		}
		[v0 release];
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v1 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v1->value == YES) {

			[self event_loginConfirmed_pushed:changes ];
		}
		[v1 release];


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_loginAck_pulled_edge0:(PropertyChangeList*)changes parentInstance:(GeneralGUI_MsgDialog*)parentInstance  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_loginAck", @"MobileLibraryGUI_LoginController", @"_okClicked", @"GeneralGUI_MsgDialog");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {

		[self event_loginAck_pushed:changes ];

	}
	[v0 release];
}


-(void) event_loginConfirmed_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_loginConfirmed", @"MobileLibraryGUI_LoginController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges
		NSEnumerator* Application_Main_loginConfirmed_edge0_enum = [self->Application_Main_loginControl_back objectEnumerator];
		Application_Main* Application_Main_loginConfirmed_edge0_target;
		while ((Application_Main_loginConfirmed_edge0_target = [Application_Main_loginConfirmed_edge0_enum nextObject]) != nil) {
		    [Application_Main_loginConfirmed_edge0_target event_loginConfirmed_pulled_edge0:changes parentInstance:self ];
		}



		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 




 
-(OCLString*) getLibraryNo{
	/* ==================================================
	 * libraryNoField.text
	 * ================================================== */
	
	MobileLibraryGUI_LoginController* v2 = self;
	GeneralGUI_Textfield* v1 = [v2 _libraryNoField];
	OCLString* v0 = [v1 _text];
	;
	return v0;
}
-(OCLString*) getPassword{
	/* ==================================================
	 * passwordField.text
	 * ================================================== */
	
	MobileLibraryGUI_LoginController* v2 = self;
	GeneralGUI_Textfield* v1 = [v2 _passwordField];
	OCLString* v0 = [v1 _text];
	;
	return v0;
}


@end 


