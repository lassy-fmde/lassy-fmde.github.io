#import "OCLCollection.h"
#import "OCLSequence.h"
#import "OCLSet.h"
#import "OCLOrderedSet.h"
#import "OCLBag.h"
#import "OCLInteger.h"
#import "OCLReal.h"
#import "OCLBoolean.h"
#import "OCLString.h"
#import "OCLTuple.h"


@implementation OCLCollection

// abstract
-(OCLCollection*)newCollection {
	[self doesNotRecognizeSelector:_cmd];
	return nil;
}

// abstract
-(void)add:(OCLAny*)object {
	[self doesNotRecognizeSelector:_cmd];
}

// abstract
-(OCLInteger*)size {
	[self doesNotRecognizeSelector:_cmd];
	return nil;
}

// abstract
-(OCLBoolean*)includes:(OCLAny*)object {
	[self doesNotRecognizeSelector:_cmd];
	return nil;
}

// abstract
-(NSEnumerator*)objectEnumerator {
	[self doesNotRecognizeSelector:_cmd];
	return nil;
}

// abstract
-(NSString*)collectionName {
	[self doesNotRecognizeSelector:_cmd];
	return nil;
}


-(OCLCollection*)flatten {
	OCLCollection* res = [self newCollection];
	
	NSEnumerator* e = [self objectEnumerator];
	OCLAny* o;
	while ((o = [e nextObject]) != nil) {
		if ([o isKindOfClass:[OCLCollection class]]) {
			OCLCollection* flattenedContainedCollection = [((OCLCollection*)o) flatten];

			NSEnumerator* e2 = [flattenedContainedCollection objectEnumerator];
			OCLAny* o2;
			while ((o2 = [e2 nextObject]) != nil) {
				[res add:o2];
			}
				
			[flattenedContainedCollection release];
		} else {
			[res add:o];
		}
	}
	
	return res;
}

-(OCLInteger*)count:(OCLAny*)object {
	NSUInteger res = 0;
	
	NSEnumerator* e = [self objectEnumerator];
	OCLAny* o;
	while ((o = [e nextObject]) != nil) {
		if ([o isEqual:object]) {
			res++;
		}
	}
	
	return [(OCLInteger*)[OCLInteger alloc] initWithValue:res];
}

-(OCLBoolean*)excludes:(OCLAny*)object {
	OCLBoolean* includes = [self includes:object];
	OCLBoolean* res = [includes not];
	[includes release];
	return res;
}

-(OCLBoolean*)includesAll:(OCLCollection*)collection {
	BOOL res = YES;
	
	OCLInteger* cCount = [collection size];
	OCLInteger* selfCount = [self size];
	
	if ([selfCount value] >= [cCount value]) {
		NSEnumerator* e = [collection objectEnumerator];
		OCLAny* o;
		while ((o = [e nextObject]) != nil) {
			OCLBoolean* included = [self includes:o];
			if (!included->value) {
				res = NO;
				[included release];
				break;
			}
			[included release];
		}
	} else {
		res = NO;
	}
	
	[cCount release];
	[selfCount release];
	return [(OCLBoolean*)[OCLBoolean alloc] initWithValue:res];
}

-(OCLBoolean*)excludesAll:(OCLCollection*)collection {
	BOOL res = YES;
	
	NSEnumerator* e = [collection objectEnumerator];
	OCLAny* o;
	while ((o = [e nextObject]) != nil) {
		OCLBoolean* included = [self includes:o];
		if (included->value) {
			res = NO;
			[included release];
			break;
		}
		[included release];
	}

	return [(OCLBoolean*)[OCLBoolean alloc] initWithValue:res];
}


-(OCLBoolean*)isEmpty {
	OCLInteger* sz = [self size];
	OCLBoolean* res = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:sz->value == 0];
	[sz release];
	return res;
}

-(OCLBoolean*)notEmpty {
	OCLInteger* sz = [self size];
	OCLBoolean* res = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:sz->value > 0];
	[sz release];
	return res;
}

-(OCLAny*)sum { // Returns all elements added with "+"
	OCLInteger* sz = [self size];
	if (sz->value == 0) {
		// Default to returning OCLInteger if the collection is empty
		// since we can't know the real type of the collection.
		[sz release];
		return [[OCLInteger alloc] init];
	}
	[sz release];
	
	
	OCLAny* o1 = [[self objectEnumerator] nextObject];
	
	if ([o1 isKindOfClass:[OCLInteger class]]) {
		int s = 0;
		
		NSEnumerator* e = [self objectEnumerator];
		OCLAny* o;
		while ((o = [e nextObject]) != nil) {
			s += ((OCLInteger*)o)->value;
		}
		return [(OCLInteger*)[OCLInteger alloc] initWithValue:s];
	} else { // must be OCLReal
		double s = 0.0;
		
		NSEnumerator* e = [self objectEnumerator];
		OCLAny* o;
		while ((o = [e nextObject]) != nil) {
			s += ((OCLReal*)o)->value;
		}
		return [(OCLReal*)[OCLReal alloc] initWithValue:s];
	}
}

-(OCLSet*)product:(OCLCollection*)collection { // Returns cartesian product as Set(Tuple(first, second))

	OCLSet* res = [(OCLSet*)[OCLSet alloc] init];

	NSEnumerator* e1 = [self objectEnumerator];
	OCLAny* o1;
	while ((o1 = [e1 nextObject]) != nil) {

		NSEnumerator* e2 = [collection objectEnumerator];
		OCLAny* o2;
		while ((o2 = [e2 nextObject]) != nil) {
			OCLTuple* tuple = [(OCLTuple*)[OCLTuple alloc] init];
			[tuple addItemNamed:@"first" withValue:o1]; 
			[tuple addItemNamed:@"second" withValue:o2]; 
			
			[res add:tuple];
			
			[tuple release];
		}
	}

	return res;
}

-(OCLSet*)asSet {
	OCLSet * res = [[OCLSet alloc] init];
	NSEnumerator* e = [self objectEnumerator];
	OCLAny* o;
	while ((o = [e nextObject]) != nil) {
		[res add:o];
	}
	return res;
}

-(OCLOrderedSet*)asOrderedSet {
	OCLOrderedSet* res = [[OCLOrderedSet alloc] init];

	NSEnumerator* e = [self objectEnumerator];
	OCLAny* o;
	while ((o = [e nextObject]) != nil) {
		[res add:o];
	}

	return res;
}

-(OCLSequence*)asSequence {
	OCLSequence* res = [[OCLSequence alloc] init];

	NSEnumerator* e = [self objectEnumerator];
	OCLAny* o;
	while ((o = [e nextObject]) != nil) {
		[res add:o];
	}

	return res;
}

-(OCLBag*)asBag {
	OCLBag* res = [[OCLBag alloc] init];

	NSEnumerator* e = [self objectEnumerator];
	OCLAny* o;
	while ((o = [e nextObject]) != nil) {
		[res add:o];
	}

	return res;
}

-(NSString*)description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<%@ id=\"%p\" retainCount=\"%i\">\n", [self collectionName], self, [self retainCount]];
	
	NSEnumerator* e = [self objectEnumerator];
	OCLAny* o;
	while ((o = [e nextObject]) != nil) {
		[res appendFormat:@"%@\n", o];
	}
	
	[res appendFormat:@"</%@>\n", [self collectionName]];
	return res;
}

@end
