 
 
 
#import "DateProcessing_DateHandler.h"
#import "PropertyChangeList.h"
#import "MobileLibraryGUI_MemberController.h"


 
@implementation DateProcessing_DateHandler

 
- (DateProcessing_DateHandler*) init {
	self = [super init];
	 
	self->MobileLibraryGUI_MemberController_dateHandler_back = [[NSMutableArray alloc] init];


	return self;
}

 
- (DateProcessing_DateHandler*) initWithValues: (OCLTuple*) values {
	self = [super init];
	 

	self->MobileLibraryGUI_MemberController_dateHandler_back = [[NSMutableArray alloc] init];


	
	return self;
}

 
- (void) dealloc {

	[self->MobileLibraryGUI_MemberController_dateHandler_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"DateProcessing::DateHandler\" retainCount=\"%i\">\n", self, [self retainCount]];
	
	[res appendString:@"</instance>\n"];
	return res;
}

 


 






 
-(OCLString*)calcAfterOneMonth:(OCLString*)p_currDate {
	NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
	[dateFormatter setDateFormat:@"dd-MM-yyyy"];
	NSDate* date = [dateFormatter dateFromString:p_currDate->string];
	NSTimeInterval secondsPer30Days = 60 * 60 * 24 * 30;
	NSDate* newDate = [[NSDate alloc] initWithTimeInterval:secondsPer30Days sinceDate:date];
	NSString* newDateString = [dateFormatter stringFromDate:newDate];
	return [[OCLString alloc] initWithString:newDateString];
}

 


 
-(void)onPropertyChange:(NSString*)propertyName newValue:(id) value {
}

 
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters{
}

 
-(id) getBinding {
	return [NSNull null];
}

 
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value {
}


@end 


