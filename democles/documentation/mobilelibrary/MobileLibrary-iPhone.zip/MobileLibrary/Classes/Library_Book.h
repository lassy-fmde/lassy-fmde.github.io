 
 
 
#import <Foundation/Foundation.h>
#import "OCLTypes.h"

@class PropertyChangeList;
@class Library_Author;
@class Library_Copy;
@class MobileLibraryGUI_SearchController;
@class LibraryPersistence_LibraryLoader;
@class MobileLibraryGUI_BookDetailController;
@class Library_Library;


 
 
@interface Library_Book : OCLAny  
 {
	 
	OCLSet* _authors;
	BOOL _authors_initialized;
	OCLString* _title;
	BOOL _title_initialized;
	OCLString* _isbn;
	BOOL _isbn_initialized;
	OCLSet* _copies;
	BOOL _copies_initialized;
	OCLString* _bookId;
	BOOL _bookId_initialized;


@public
	NSMutableArray *MobileLibraryGUI_SearchController_booksFound_back;
	NSMutableArray *LibraryPersistence_LibraryLoader_books_back;
	NSMutableArray *Library_Copy_book_back;
	NSMutableArray *MobileLibraryGUI_BookDetailController_currBook_back;
	NSMutableArray *Library_Library_catalogue_back;


}

 
-(Library_Book*)init;
-(Library_Book*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(OCLSet*) _authors;
-(OCLSet*) initial_authors;
-(void) set_authors:(OCLSet*) value;
-(OCLString*) _title;
-(OCLString*) initial_title;
-(void) set_title:(OCLString*) value;
-(OCLString*) _isbn;
-(OCLString*) initial_isbn;
-(void) set_isbn:(OCLString*) value;
-(OCLSet*) _copies;
-(OCLSet*) initial_copies;
-(void) set_copies:(OCLSet*) value;
-(OCLString*) _bookId;
-(OCLString*) initial_bookId;
-(void) set_bookId:(OCLString*) value;

-(void) event_setCopies_pushed:(PropertyChangeList*) changes p_copies: (OCLSet*) p_copies;


@end


