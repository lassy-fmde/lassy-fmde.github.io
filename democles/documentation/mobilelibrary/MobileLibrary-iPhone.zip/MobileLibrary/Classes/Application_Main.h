 
 
 
#import <Foundation/Foundation.h>
#import "OCLTypes.h"

@class PropertyChangeList;
@class MobileLibraryGUI_StartController;
@class MobileLibraryGUI_LoginController;
@class MobileLibraryGUI_MemberController;
@class Library_Library;
@class LibraryPersistence_LibraryLoader;
@class Library_Author;
@class Library_Member;
@class Library_Book;
@class Application_Main;
@class MobileLibraryGUI_SearchController;
@class MobileLibraryGUI_ViewsController;


 
 
@interface Application_Main : OCLAny  
 {
	 
	Library_Library* _library;
	BOOL _library_initialized;
	LibraryPersistence_LibraryLoader* _libraryFileHandler;
	BOOL _libraryFileHandler_initialized;
	MobileLibraryGUI_ViewsController* _viewsControl;
	BOOL _viewsControl_initialized;
	MobileLibraryGUI_StartController* _startControl;
	BOOL _startControl_initialized;
	MobileLibraryGUI_SearchController* _searchControl;
	BOOL _searchControl_initialized;
	OCLString* _memberViewMode;
	BOOL _memberViewMode_initialized;
	MobileLibraryGUI_MemberController* _memberControl;
	BOOL _memberControl_initialized;
	MobileLibraryGUI_LoginController* _loginControl;
	BOOL _loginControl_initialized;


@public


}

 
-(Application_Main*)init;
-(Application_Main*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(Library_Library*) _library;
-(Library_Library*) initial_library;
-(void) set_library:(Library_Library*) value;
-(LibraryPersistence_LibraryLoader*) _libraryFileHandler;
-(LibraryPersistence_LibraryLoader*) initial_libraryFileHandler;
-(void) set_libraryFileHandler:(LibraryPersistence_LibraryLoader*) value;
-(MobileLibraryGUI_ViewsController*) _viewsControl;
-(MobileLibraryGUI_ViewsController*) initial_viewsControl;
-(void) set_viewsControl:(MobileLibraryGUI_ViewsController*) value;
-(MobileLibraryGUI_StartController*) _startControl;
-(MobileLibraryGUI_StartController*) initial_startControl;
-(void) set_startControl:(MobileLibraryGUI_StartController*) value;
-(MobileLibraryGUI_SearchController*) _searchControl;
-(MobileLibraryGUI_SearchController*) initial_searchControl;
-(void) set_searchControl:(MobileLibraryGUI_SearchController*) value;
-(OCLString*) _memberViewMode;
-(OCLString*) initial_memberViewMode;
-(void) set_memberViewMode:(OCLString*) value;
-(MobileLibraryGUI_MemberController*) _memberControl;
-(MobileLibraryGUI_MemberController*) initial_memberControl;
-(void) set_memberControl:(MobileLibraryGUI_MemberController*) value;
-(MobileLibraryGUI_LoginController*) _loginControl;
-(MobileLibraryGUI_LoginController*) initial_loginControl;
-(void) set_loginControl:(MobileLibraryGUI_LoginController*) value;

-(void) event_searchFinished_pushed:(PropertyChangeList*) changes p_booksFound: (OCLSet*) p_booksFound;
-(void) event_searchFinished_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Library_Library*)parentInstance p_foundBooks:(OCLSet*)p_foundBooks ;
-(void) event_searchBook_pushed:(PropertyChangeList*) changes p_term: (OCLString*) p_term p_category: (OCLString*) p_category;
-(void) event_searchBook_pulled_edge0:(PropertyChangeList*)changes parentInstance:(MobileLibraryGUI_SearchController*)parentInstance p_term:(OCLString*)p_term p_category:(OCLString*)p_category ;
-(void) event_libraryBooksLoaded_pushed:(PropertyChangeList*) changes p_bookCollection: (Library_Library*) p_bookCollection;
-(void) event_libraryBooksLoaded_pulled_edge0:(PropertyChangeList*)changes parentInstance:(LibraryPersistence_LibraryLoader*)parentInstance p_library:(Library_Library*)p_library ;
-(void) event_setCatalogue_pushed:(PropertyChangeList*) changes p_completeBookCollection: (Library_Library*) p_completeBookCollection;
-(void) event_init_pushed:(PropertyChangeList*) changes ;
-(void) event_loadLibrary_pushed:(PropertyChangeList*) changes ;
-(void) event_authenticate_pushed:(PropertyChangeList*) changes p_libNo: (OCLString*) p_libNo p_pw: (OCLString*) p_pw;
-(void) event_authenticate_pulled_edge0:(PropertyChangeList*)changes parentInstance:(MobileLibraryGUI_LoginController*)parentInstance p_libNo:(OCLString*)p_libNo p_password:(OCLString*)p_password ;
-(void) event_loginOk_pushed:(PropertyChangeList*) changes p_m: (Library_Member*) p_m;
-(void) event_loginOk_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Library_Library*)parentInstance p_member:(Library_Member*)p_member ;
-(void) event_saveLibrary_pushed:(PropertyChangeList*) changes ;
-(void) event_saveLibrary_pulled_edge0:(PropertyChangeList*)changes parentInstance:(MobileLibraryGUI_MemberController*)parentInstance ;
-(void) event_saveLibrary_pulled_edge1:(PropertyChangeList*)changes parentInstance:(MobileLibraryGUI_SearchController*)parentInstance ;
-(void) event_loginFailed_pushed:(PropertyChangeList*) changes ;
-(void) event_loginFailed_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Library_Library*)parentInstance ;
-(void) event_endStartWindow_pushed:(PropertyChangeList*) changes ;
-(void) event_refreshMemberWindow_pushed:(PropertyChangeList*) changes ;
-(void) event_refreshMemberWindow_pulled_edge0:(PropertyChangeList*)changes parentInstance:(MobileLibraryGUI_SearchController*)parentInstance ;
-(void) event_loginConfirmed_pushed:(PropertyChangeList*) changes ;
-(void) event_loginConfirmed_pulled_edge0:(PropertyChangeList*)changes parentInstance:(MobileLibraryGUI_LoginController*)parentInstance ;
-(void) event_setToMemberMode_pushed:(PropertyChangeList*) changes ;


@end


