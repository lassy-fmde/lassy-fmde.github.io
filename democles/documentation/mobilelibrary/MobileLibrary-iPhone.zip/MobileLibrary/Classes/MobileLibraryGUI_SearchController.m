 
 
 
#import "MobileLibraryGUI_SearchController.h"
#import "PropertyChangeList.h"
#import "Library_Member.h"
#import "Library_Book.h"
#import "GeneralGUI_Textfield.h"
#import "GeneralGUI_SelectionBox.h"
#import "GeneralGUI_SelectionList.h"
#import "GeneralGUI_Frame.h"
#import "MobileLibraryGUI_SearchController.h"
#import "GeneralGUI_Button.h"
#import "GeneralGUI_Label.h"
#import "MobileLibraryGUI_SearchResultsController.h"
#import "Application_Main.h"


 
@implementation MobileLibraryGUI_SearchController

 
- (MobileLibraryGUI_SearchController*) init {
	self = [super init];
	 
	self->Application_Main_searchControl_back = [[NSMutableArray alloc] init];

	[self set_searchLabel: [self _searchLabel]];
	[self set_searchField: [self _searchField]];
	[self set_categorySelect: [self _categorySelect]];
	[self set_searchButton: [self _searchButton]];
	[self set_searchResults: [self _searchResults]];
	[self set_title: [self _title]];
	[self set_frame: [self _frame]];
	[self set_mode: [self _mode]];
	[self set_currMember: [self _currMember]];
	[self set_booksFound: [self _booksFound]];

	return self;
}

 
- (MobileLibraryGUI_SearchController*) initWithValues: (OCLTuple*) values {
	self = [super init];
	 
	self->_searchLabel_initialized = NO;
	self->_searchField_initialized = NO;
	self->_categorySelect_initialized = NO;
	self->_searchButton_initialized = NO;
	self->_searchResults_initialized = NO;
	self->_title_initialized = NO;
	self->_frame_initialized = NO;
	self->_mode_initialized = NO;
	self->_currMember_initialized = NO;
	self->_booksFound_initialized = NO;

	self->Application_Main_searchControl_back = [[NSMutableArray alloc] init];

	GeneralGUI_Label* _searchLabel_initialValue = (GeneralGUI_Label*) [values objectForKey:@"searchLabel"];
	if (_searchLabel_initialValue == nil) {
		_searchLabel_initialValue = [self _searchLabel];
	}
	[self set_searchLabel:_searchLabel_initialValue];
	GeneralGUI_Textfield* _searchField_initialValue = (GeneralGUI_Textfield*) [values objectForKey:@"searchField"];
	if (_searchField_initialValue == nil) {
		_searchField_initialValue = [self _searchField];
	}
	[self set_searchField:_searchField_initialValue];
	GeneralGUI_SelectionBox* _categorySelect_initialValue = (GeneralGUI_SelectionBox*) [values objectForKey:@"categorySelect"];
	if (_categorySelect_initialValue == nil) {
		_categorySelect_initialValue = [self _categorySelect];
	}
	[self set_categorySelect:_categorySelect_initialValue];
	GeneralGUI_Button* _searchButton_initialValue = (GeneralGUI_Button*) [values objectForKey:@"searchButton"];
	if (_searchButton_initialValue == nil) {
		_searchButton_initialValue = [self _searchButton];
	}
	[self set_searchButton:_searchButton_initialValue];
	MobileLibraryGUI_SearchResultsController* _searchResults_initialValue = (MobileLibraryGUI_SearchResultsController*) [values objectForKey:@"searchResults"];
	if (_searchResults_initialValue == nil) {
		_searchResults_initialValue = [self _searchResults];
	}
	[self set_searchResults:_searchResults_initialValue];
	OCLString* _title_initialValue = (OCLString*) [values objectForKey:@"title"];
	if (_title_initialValue == nil) {
		_title_initialValue = [self _title];
	}
	[self set_title:_title_initialValue];
	GeneralGUI_Frame* _frame_initialValue = (GeneralGUI_Frame*) [values objectForKey:@"frame"];
	if (_frame_initialValue == nil) {
		_frame_initialValue = [self _frame];
	}
	[self set_frame:_frame_initialValue];
	OCLString* _mode_initialValue = (OCLString*) [values objectForKey:@"mode"];
	if (_mode_initialValue == nil) {
		_mode_initialValue = [self _mode];
	}
	[self set_mode:_mode_initialValue];
	Library_Member* _currMember_initialValue = (Library_Member*) [values objectForKey:@"currMember"];
	if (_currMember_initialValue == nil) {
		_currMember_initialValue = [self _currMember];
	}
	[self set_currMember:_currMember_initialValue];
	OCLSequence* _booksFound_initialValue = (OCLSequence*) [values objectForKey:@"booksFound"];
	if (_booksFound_initialValue == nil) {
		_booksFound_initialValue = [self _booksFound];
	}
	[self set_booksFound:_booksFound_initialValue];

	
	return self;
}

 
- (void) dealloc {
	if (self->_searchLabel != nil && self->_searchLabel != (GeneralGUI_Label*) [NSNull null]) [self->_searchLabel release];
	if (self->_searchField != nil && self->_searchField != (GeneralGUI_Textfield*) [NSNull null]) [self->_searchField release];
	if (self->_categorySelect != nil && self->_categorySelect != (GeneralGUI_SelectionBox*) [NSNull null]) [self->_categorySelect release];
	if (self->_searchButton != nil && self->_searchButton != (GeneralGUI_Button*) [NSNull null]) [self->_searchButton release];
	if (self->_searchResults != nil && self->_searchResults != (MobileLibraryGUI_SearchResultsController*) [NSNull null]) [self->_searchResults release];
	if (self->_title != nil && self->_title != (OCLString*) [NSNull null]) [self->_title release];
	if (self->_frame != nil && self->_frame != (GeneralGUI_Frame*) [NSNull null]) [self->_frame release];
	if (self->_mode != nil && self->_mode != (OCLString*) [NSNull null]) [self->_mode release];
	if (self->_currMember != nil && self->_currMember != (Library_Member*) [NSNull null]) [self->_currMember release];
	if (self->_booksFound != nil && self->_booksFound != (OCLSequence*) [NSNull null]) [self->_booksFound release];

	[self->Application_Main_searchControl_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"MobileLibraryGUI::SearchController\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"searchLabel\" type=\"GeneralGUI::Label\">\n"];
	[res appendFormat:@"%@\n", [self _searchLabel]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"searchField\" type=\"GeneralGUI::Textfield\">\n"];
	[res appendFormat:@"%@\n", [self _searchField]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"categorySelect\" type=\"GeneralGUI::SelectionBox\">\n"];
	[res appendFormat:@"%@\n", [self _categorySelect]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"searchButton\" type=\"GeneralGUI::Button\">\n"];
	[res appendFormat:@"%@\n", [self _searchButton]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"searchResults\" type=\"MobileLibraryGUI::SearchResultsController\">\n"];
	[res appendFormat:@"%@\n", [self _searchResults]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"title\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _title]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"frame\" type=\"GeneralGUI::Frame\">\n"];
	[res appendFormat:@"%@\n", [self _frame]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"mode\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _mode]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"currMember\" type=\"Library::Member\">\n"];
	[res appendFormat:@"%@\n", [self _currMember]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"booksFound\" type=\"Sequence\">\n"];
	[res appendFormat:@"%@\n", [self _booksFound]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
-(GeneralGUI_Label*) initial_searchLabel {
	/* ==================================================
	 * GeneralGUI::Label::create(Tuple { text = 'Search by:' })
	 * ================================================== */
	
	OCLString* v4 = [(OCLString*)[OCLString alloc] initWithString:@"Search by:"];
	OCLString* v3 = v4;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"text" withValue:v3];
	GeneralGUI_Label* v0 = [(GeneralGUI_Label*)[GeneralGUI_Label alloc] initWithValues:v2];
	[v4 release];
	[v2 release];
	
	return v0;
}

-(GeneralGUI_Label*) _searchLabel {
	if (self->_searchLabel_initialized == YES) {
		return _searchLabel;
	} else { 
		[self set_searchLabel:[self initial_searchLabel]];
	}

	self->_searchLabel_initialized = YES;
	return _searchLabel;
}
-(GeneralGUI_Textfield*) initial_searchField {
	/* ==================================================
	 * GeneralGUI::Textfield::create()
	 * ================================================== */
	
	GeneralGUI_Textfield* v0 = [(GeneralGUI_Textfield*)[GeneralGUI_Textfield alloc] init];
	
	return v0;
}

-(GeneralGUI_Textfield*) _searchField {
	if (self->_searchField_initialized == YES) {
		return _searchField;
	} else { 
		[self set_searchField:[self initial_searchField]];
	}

	self->_searchField_initialized = YES;
	return _searchField;
}
-(GeneralGUI_SelectionBox*) initial_categorySelect {
	/* ==================================================
	 * GeneralGUI::SelectionBox::create(Tuple { choices = Sequence { 'Author', 'Title', 'ISBN' }})
	 * ================================================== */
	
	OCLString* v6 = [(OCLString*)[OCLString alloc] initWithString:@"Author"];
	OCLString* v5 = v6;
	OCLString* v8 = [(OCLString*)[OCLString alloc] initWithString:@"Title"];
	OCLString* v7 = v8;
	OCLString* v10 = [(OCLString*)[OCLString alloc] initWithString:@"ISBN"];
	OCLString* v9 = v10;
	OCLSequence* v4 = [(OCLSequence*)[OCLSequence alloc] init];
	[v4 add:v5];
	[v4 add:v7];
	[v4 add:v9];
	OCLSequence* v3 = v4;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"choices" withValue:v3];
	GeneralGUI_SelectionBox* v0 = [(GeneralGUI_SelectionBox*)[GeneralGUI_SelectionBox alloc] initWithValues:v2];
	[v2 release];
	[v4 release];
	[v6 release];
	[v8 release];
	[v10 release];
	
	return v0;
}

-(GeneralGUI_SelectionBox*) _categorySelect {
	if (self->_categorySelect_initialized == YES) {
		return _categorySelect;
	} else { 
		[self set_categorySelect:[self initial_categorySelect]];
	}

	self->_categorySelect_initialized = YES;
	return _categorySelect;
}
-(GeneralGUI_Button*) initial_searchButton {
	/* ==================================================
	 * GeneralGUI::Button::create(Tuple { text = 'Search' })
	 * ================================================== */
	
	OCLString* v4 = [(OCLString*)[OCLString alloc] initWithString:@"Search"];
	OCLString* v3 = v4;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"text" withValue:v3];
	GeneralGUI_Button* v0 = [(GeneralGUI_Button*)[GeneralGUI_Button alloc] initWithValues:v2];
	[v4 release];
	[v2 release];
	
	return v0;
}

-(GeneralGUI_Button*) _searchButton {
	if (self->_searchButton_initialized == YES) {
		return _searchButton;
	} else { 
		[self set_searchButton:[self initial_searchButton]];
	}

	self->_searchButton_initialized = YES;
	return _searchButton;
}
-(MobileLibraryGUI_SearchResultsController*) initial_searchResults {
	/* ==================================================
	 * null
	 * ================================================== */
	
	MobileLibraryGUI_SearchResultsController* v0 = [NSNull null];
	
	return v0;
}

-(MobileLibraryGUI_SearchResultsController*) _searchResults {
	if (self->_searchResults_initialized == YES) {
		return _searchResults;
	} else { 
		[self set_searchResults:[self initial_searchResults]];
	}

	self->_searchResults_initialized = YES;
	return _searchResults;
}
-(OCLString*) initial_title {
	/* ==================================================
	 * 'Search'
	 * ================================================== */
	
	OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@"Search"];
	
	return v0;
}

-(OCLString*) _title {
	if (self->_title_initialized == YES) {
		return _title;
	} else { 
		[self set_title:[self initial_title]];
	}

	self->_title_initialized = YES;
	return _title;
}
-(GeneralGUI_Frame*) initial_frame {
	/* ==================================================
	 * GeneralGUI::Frame::create(
	 * 	Tuple { seqGUIElements = Sequence {searchLabel, categorySelect, searchField, searchButton }, 
	 * 	frameTitle = title,
	 * 	iconFilename = 'icon-search.png' })
	 * ================================================== */
	
	MobileLibraryGUI_SearchController* v7 = self;
	GeneralGUI_Label* v6 = [v7 _searchLabel];
	GeneralGUI_Label* v5 = v6;
	MobileLibraryGUI_SearchController* v10 = self;
	GeneralGUI_SelectionBox* v9 = [v10 _categorySelect];
	GeneralGUI_SelectionBox* v8 = v9;
	MobileLibraryGUI_SearchController* v13 = self;
	GeneralGUI_Textfield* v12 = [v13 _searchField];
	GeneralGUI_Textfield* v11 = v12;
	MobileLibraryGUI_SearchController* v16 = self;
	GeneralGUI_Button* v15 = [v16 _searchButton];
	GeneralGUI_Button* v14 = v15;
	OCLSequence* v4 = [(OCLSequence*)[OCLSequence alloc] init];
	[v4 add:v5];
	[v4 add:v8];
	[v4 add:v11];
	[v4 add:v14];
	OCLSequence* v3 = v4;
	MobileLibraryGUI_SearchController* v19 = self;
	OCLString* v18 = [v19 _title];
	OCLString* v17 = v18;
	OCLString* v21 = [(OCLString*)[OCLString alloc] initWithString:@"icon-search.png"];
	OCLString* v20 = v21;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"seqGUIElements" withValue:v3];
	[v2 addItemNamed:@"frameTitle" withValue:v17];
	[v2 addItemNamed:@"iconFilename" withValue:v20];
	GeneralGUI_Frame* v0 = [(GeneralGUI_Frame*)[GeneralGUI_Frame alloc] initWithValues:v2];
	[v2 release];
	[v4 release];
	[v21 release];
	
	return v0;
}

-(GeneralGUI_Frame*) _frame {
	if (self->_frame_initialized == YES) {
		return _frame;
	} else { 
		[self set_frame:[self initial_frame]];
	}

	self->_frame_initialized = YES;
	return _frame;
}
-(OCLString*) initial_mode {
	/* ==================================================
	 * 'NotLoggedIn'
	 * ================================================== */
	
	OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@"NotLoggedIn"];
	
	return v0;
}

-(OCLString*) _mode {
	if (self->_mode_initialized == YES) {
		return _mode;
	} else { 
		[self set_mode:[self initial_mode]];
	}

	self->_mode_initialized = YES;
	return _mode;
}
-(Library_Member*) initial_currMember {
	/* ==================================================
	 * null
	 * ================================================== */
	
	Library_Member* v0 = [NSNull null];
	
	return v0;
}

-(Library_Member*) _currMember {
	if (self->_currMember_initialized == YES) {
		return _currMember;
	} else { 
		[self set_currMember:[self initial_currMember]];
	}

	self->_currMember_initialized = YES;
	return _currMember;
}
-(OCLSequence*) initial_booksFound {
	/* ==================================================
	 * Sequence {}
	 * ================================================== */
	
	OCLSequence* v0 = [(OCLSequence*)[OCLSequence alloc] init];
	
	return v0;
}

-(OCLSequence*) _booksFound {
	if (self->_booksFound_initialized == YES) {
		return _booksFound;
	} else { 
		[self set_booksFound:[self initial_booksFound]];
	}

	self->_booksFound_initialized = YES;
	return _booksFound;
}


 
-(void) set_title:(OCLString*) value {
	 	if (self->_title!= nil && self->_title!= (OCLString*) [NSNull null]) {
		[self->_title release];
	}
	self->_title = value;
	if (self->_title!= nil && self->_title!= (OCLString*) [NSNull null]) {
		[self->_title retain];
	}
	self->_title_initialized = YES;

}
-(void) set_mode:(OCLString*) value {
	 	if (self->_mode!= nil && self->_mode!= (OCLString*) [NSNull null]) {
		[self->_mode release];
	}
	self->_mode = value;
	if (self->_mode!= nil && self->_mode!= (OCLString*) [NSNull null]) {
		[self->_mode retain];
	}
	self->_mode_initialized = YES;

}


-(void) set_searchLabel:(GeneralGUI_Label*) value {
	 
	if (self->_searchLabel!= nil && self->_searchLabel!= (GeneralGUI_Label*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_searchLabel valueForKey:@"MobileLibraryGUI_SearchController_searchLabel_back"];
		[backpointers removeObject:self];
		[self->_searchLabel release];
	}
	self->_searchLabel = value;
	if (self->_searchLabel!= nil && self->_searchLabel!= (GeneralGUI_Label*) [NSNull null]) {
		[self->_searchLabel retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_searchLabel valueForKey:@"MobileLibraryGUI_SearchController_searchLabel_back"];
		[backpointers addObject:self];
	}
	self->_searchLabel_initialized = YES;

}
-(void) set_searchField:(GeneralGUI_Textfield*) value {
	 
	if (self->_searchField!= nil && self->_searchField!= (GeneralGUI_Textfield*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_searchField valueForKey:@"MobileLibraryGUI_SearchController_searchField_back"];
		[backpointers removeObject:self];
		[self->_searchField release];
	}
	self->_searchField = value;
	if (self->_searchField!= nil && self->_searchField!= (GeneralGUI_Textfield*) [NSNull null]) {
		[self->_searchField retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_searchField valueForKey:@"MobileLibraryGUI_SearchController_searchField_back"];
		[backpointers addObject:self];
	}
	self->_searchField_initialized = YES;

}
-(void) set_categorySelect:(GeneralGUI_SelectionBox*) value {
	 
	if (self->_categorySelect!= nil && self->_categorySelect!= (GeneralGUI_SelectionBox*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_categorySelect valueForKey:@"MobileLibraryGUI_SearchController_categorySelect_back"];
		[backpointers removeObject:self];
		[self->_categorySelect release];
	}
	self->_categorySelect = value;
	if (self->_categorySelect!= nil && self->_categorySelect!= (GeneralGUI_SelectionBox*) [NSNull null]) {
		[self->_categorySelect retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_categorySelect valueForKey:@"MobileLibraryGUI_SearchController_categorySelect_back"];
		[backpointers addObject:self];
	}
	self->_categorySelect_initialized = YES;

}
-(void) set_searchButton:(GeneralGUI_Button*) value {
	 
	if (self->_searchButton!= nil && self->_searchButton!= (GeneralGUI_Button*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_searchButton valueForKey:@"MobileLibraryGUI_SearchController_searchButton_back"];
		[backpointers removeObject:self];
		[self->_searchButton release];
	}
	self->_searchButton = value;
	if (self->_searchButton!= nil && self->_searchButton!= (GeneralGUI_Button*) [NSNull null]) {
		[self->_searchButton retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_searchButton valueForKey:@"MobileLibraryGUI_SearchController_searchButton_back"];
		[backpointers addObject:self];
	}
	self->_searchButton_initialized = YES;

}
-(void) set_searchResults:(MobileLibraryGUI_SearchResultsController*) value {
	 
	if (self->_searchResults!= nil && self->_searchResults!= (MobileLibraryGUI_SearchResultsController*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_searchResults valueForKey:@"MobileLibraryGUI_SearchController_searchResults_back"];
		[backpointers removeObject:self];
		[self->_searchResults release];
	}
	self->_searchResults = value;
	if (self->_searchResults!= nil && self->_searchResults!= (MobileLibraryGUI_SearchResultsController*) [NSNull null]) {
		[self->_searchResults retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_searchResults valueForKey:@"MobileLibraryGUI_SearchController_searchResults_back"];
		[backpointers addObject:self];
	}
	self->_searchResults_initialized = YES;

}
-(void) set_frame:(GeneralGUI_Frame*) value {
	 
	if (self->_frame!= nil && self->_frame!= (GeneralGUI_Frame*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_frame valueForKey:@"MobileLibraryGUI_SearchController_frame_back"];
		[backpointers removeObject:self];
		[self->_frame release];
	}
	self->_frame = value;
	if (self->_frame!= nil && self->_frame!= (GeneralGUI_Frame*) [NSNull null]) {
		[self->_frame retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_frame valueForKey:@"MobileLibraryGUI_SearchController_frame_back"];
		[backpointers addObject:self];
	}
	self->_frame_initialized = YES;

}
-(void) set_currMember:(Library_Member*) value {
	 
	if (self->_currMember!= nil && self->_currMember!= (Library_Member*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_currMember valueForKey:@"MobileLibraryGUI_SearchController_currMember_back"];
		[backpointers removeObject:self];
		[self->_currMember release];
	}
	self->_currMember = value;
	if (self->_currMember!= nil && self->_currMember!= (Library_Member*) [NSNull null]) {
		[self->_currMember retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_currMember valueForKey:@"MobileLibraryGUI_SearchController_currMember_back"];
		[backpointers addObject:self];
	}
	self->_currMember_initialized = YES;

}


-(void) set_booksFound:(OCLSequence*) value {
	 
	if (self->_booksFound!= nil && self->_booksFound!= (OCLSequence*) [NSNull null]) {
		// Clear back pointer on old instance
		NSEnumerator* e = [self->_booksFound objectEnumerator];
		Library_Book* o;
		while ((o = [e nextObject]) != nil) {
			if (o != (Library_Book*)[NSNull null]) {
				NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)o valueForKey:@"MobileLibraryGUI_SearchController_booksFound_back"];
				[backpointers removeObject:self];
			}
		}
		[self->_booksFound release];
	}
	self->_booksFound = value;
	if (self->_booksFound!= nil && self->_booksFound!= (OCLSequence*) [NSNull null]) {
		[self->_booksFound retain];
		// Add back pointer on new instance
		NSEnumerator* e = [self->_booksFound objectEnumerator];
		Library_Book* o;
		while ((o = [e nextObject]) != nil) {
			if (o != (Library_Book*)[NSNull null]) {
				NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)o valueForKey:@"MobileLibraryGUI_SearchController_booksFound_back"];
				[backpointers addObject:self];
			}
		}
	}
	self->_booksFound_initialized = YES;

}


 
-(void) event_searchClicked_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_searchClicked", @"MobileLibraryGUI_SearchController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {
			/* ==================================================
			 * searchField.text
			 * ================================================== */
			
			GeneralGUI_Textfield* v2 = [self _searchField];
			OCLString* v1 = [v2 _text];
			
			OCLString* parameter_p_term = v1;
			/* ==================================================
			 * categorySelect.selectedChoice
			 * ================================================== */
			
			GeneralGUI_SelectionBox* v4 = [self _categorySelect];
			OCLString* v3 = [v4 _selectedChoice];
			
			OCLString* parameter_p_category = v3;

			[self event_searchBook_pushed:changes p_term:parameter_p_term p_category:parameter_p_category ];
		}
		[v0 release];


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_searchClicked_pulled_edge0:(PropertyChangeList*)changes parentInstance:(GeneralGUI_Button*)parentInstance  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_searchClicked", @"MobileLibraryGUI_SearchController", @"_clicked", @"GeneralGUI_Button");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {

		[self event_searchClicked_pushed:changes ];

	}
	[v0 release];
}


-(void) event_searchFinished_pushed:(PropertyChangeList*) changes  p_booksFound: (OCLSet*) p_booksFound{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_searchFinished", @"MobileLibraryGUI_SearchController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * SearchResultsController::create(
		 * 	Tuple { 
		 * 		bookListTable = GeneralGUI::SelectionList::create(Tuple { items = getBooksFoundData(booksFound) }),
		 * 		mode = mode,
		 * 		currMember = currMember
		 * 	})
		 * ================================================== */
		
		MobileLibraryGUI_SearchController* v9 = self;
		OCLSet* v10 = p_booksFound;
		OCLSequence* v8 = [v9 getBooksFoundData:v10];
		OCLSequence* v7 = v8;
		OCLTuple* v6 = [(OCLTuple*)[OCLTuple alloc] init];
		[v6 addItemNamed:@"items" withValue:v7];
		GeneralGUI_SelectionList* v4 = [(GeneralGUI_SelectionList*)[GeneralGUI_SelectionList alloc] initWithValues:v6];
		GeneralGUI_SelectionList* v3 = v4;
		MobileLibraryGUI_SearchController* v13 = self;
		OCLString* v12 = [v13 _mode];
		OCLString* v11 = v12;
		MobileLibraryGUI_SearchController* v16 = self;
		Library_Member* v15 = [v16 _currMember];
		Library_Member* v14 = v15;
		OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
		[v2 addItemNamed:@"bookListTable" withValue:v3];
		[v2 addItemNamed:@"mode" withValue:v11];
		[v2 addItemNamed:@"currMember" withValue:v14];
		MobileLibraryGUI_SearchResultsController* v0 = [(MobileLibraryGUI_SearchResultsController*)[MobileLibraryGUI_SearchResultsController alloc] initWithValues:v2];
		[v4 release];
		[v6 release];
		[v2 release];
		
		MobileLibraryGUI_SearchResultsController* _searchResults_newValue = v0;
		[changes addChange:@selector(set_searchResults:) instance:self value:_searchResults_newValue];
		/* ==================================================
		 * booksFound->asSequence()
		 * ================================================== */
		
		OCLSet* v18 = p_booksFound;
		OCLSequence* v17 = [v18 asSequence];
		
		OCLSequence* _booksFound_newValue = v17;
		[changes addChange:@selector(set_booksFound:) instance:self value:_booksFound_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_bookSelected_pushed:(PropertyChangeList*) changes  p_index: (OCLInteger*) p_index{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_bookSelected", @"MobileLibraryGUI_SearchController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {
			/* ==================================================
			 * booksFound->at(index)
			 * ================================================== */
			
			OCLSequence* v2 = [self _booksFound];
			OCLInteger* v3 = p_index;
			Library_Book* v1 = ((Library_Book*)[v2 at:v3]);
			
			Library_Book* parameter_p_book = v1;

			[self event_selectedBook_pushed:changes p_book:parameter_p_book ];
		}
		[v0 release];


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_bookSelected_pulled_edge0:(PropertyChangeList*)changes parentInstance:(MobileLibraryGUI_SearchResultsController*)parentInstance p_index:(OCLInteger*)p_index  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_bookSelected", @"MobileLibraryGUI_SearchController", @"_bookSelected", @"MobileLibraryGUI_SearchResultsController");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {
		/* ==================================================
		 * index
		 * ================================================== */
		
		OCLInteger* v1 = p_index;
		
		OCLInteger* parameter_p_index = v1;

		[self event_bookSelected_pushed:changes p_index:parameter_p_index ];

	}
	[v0 release];
}


-(void) event_searchBook_pushed:(PropertyChangeList*) changes  p_term: (OCLString*) p_term p_category: (OCLString*) p_category{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_searchBook", @"MobileLibraryGUI_SearchController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges
		NSEnumerator* Application_Main_searchBook_edge0_enum = [self->Application_Main_searchControl_back objectEnumerator];
		Application_Main* Application_Main_searchBook_edge0_target;
		while ((Application_Main_searchBook_edge0_target = [Application_Main_searchBook_edge0_enum nextObject]) != nil) {
		    [Application_Main_searchBook_edge0_target event_searchBook_pulled_edge0:changes parentInstance:self p_term:p_term p_category:p_category ];
		}



		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_refreshAndSave_pushed:(PropertyChangeList*) changes  {
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_refreshAndSave", @"MobileLibraryGUI_SearchController");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges
		NSEnumerator* Application_Main_refreshMemberWindow_edge0_enum = [self->Application_Main_searchControl_back objectEnumerator];
		Application_Main* Application_Main_refreshMemberWindow_edge0_target;
		while ((Application_Main_refreshMemberWindow_edge0_target = [Application_Main_refreshMemberWindow_edge0_enum nextObject]) != nil) {
		    [Application_Main_refreshMemberWindow_edge0_target event_refreshMemberWindow_pulled_edge0:changes parentInstance:self ];
		}

		NSEnumerator* Application_Main_saveLibrary_edge1_enum = [self->Application_Main_searchControl_back objectEnumerator];
		Application_Main* Application_Main_saveLibrary_edge1_target;
		while ((Application_Main_saveLibrary_edge1_target = [Application_Main_saveLibrary_edge1_enum nextObject]) != nil) {
		    [Application_Main_saveLibrary_edge1_target event_saveLibrary_pulled_edge1:changes parentInstance:self ];
		}



		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_refreshAndSave_pulled_edge0:(PropertyChangeList*)changes parentInstance:(MobileLibraryGUI_SearchResultsController*)parentInstance  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_refreshAndSave", @"MobileLibraryGUI_SearchController", @"_refreshAndSave", @"MobileLibraryGUI_SearchResultsController");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {

		[self event_refreshAndSave_pushed:changes ];

	}
	[v0 release];
}


-(void) event_sessionStarted_pushed:(PropertyChangeList*) changes  p_m: (Library_Member*) p_m{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_sessionStarted", @"MobileLibraryGUI_SearchController");

		 
		// Trigger Push edges

		if (self->_searchResults != nil && self->_searchResults != (MobileLibraryGUI_SearchResultsController*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_searchResults];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			MobileLibraryGUI_SearchResultsController* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * m
				 * ================================================== */
				
				Library_Member* v1 = p_m;
				
					Library_Member* parameter_p_m = v1;

					[edge0_target event_sessionStarted_pushed:changes p_m:parameter_p_m ];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * 'LoggedIn'
		 * ================================================== */
		
		OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@"LoggedIn"];
		
		OCLString* _mode_newValue = v0;
		[changes addChange:@selector(set_mode:) instance:self value:_mode_newValue];
		/* ==================================================
		 * m
		 * ================================================== */
		
		Library_Member* v1 = p_m;
		
		Library_Member* _currMember_newValue = v1;
		[changes addChange:@selector(set_currMember:) instance:self value:_currMember_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_selectedBook_pushed:(PropertyChangeList*) changes  p_book: (Library_Book*) p_book{
	{ // New scope for following guard code:
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
					
		if (!v0->value == YES) {
			[v0 release];
			return;
		} else {
			[v0 release];
		}
	}

	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_selectedBook", @"MobileLibraryGUI_SearchController");

		 
		// Trigger Push edges

		if (self->_searchResults != nil && self->_searchResults != (MobileLibraryGUI_SearchResultsController*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_searchResults];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			MobileLibraryGUI_SearchResultsController* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * book
				 * ================================================== */
				
				Library_Book* v1 = p_book;
				
					Library_Book* parameter_p_book = v1;

					[edge0_target event_selectedBook_pushed:changes p_book:parameter_p_book ];

				}
				[v0 release];
			}

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 




 
-(OCLSequence*) getBooksFoundData:p_books {
	/* ==================================================
	 * books->asSequence()->collect(b:Library::Book | b.title)->asSequence()
	 * ================================================== */
	
	OCLSet* v3 = p_books;
	OCLSequence* v2 = [v3 asSequence];
	OCLSequence* v1_nested = [(OCLSequence*)[OCLSequence alloc] init];
	NSEnumerator* v1_enum = [v2 objectEnumerator];
	Library_Book* v4;
	while ((v4 = [v1_enum nextObject]) != nil) {
		Library_Book* v6 = v4;
		OCLString* v5 = [v6 _title];
		[v1_nested add: v5];
	}
	OCLSequence* v1 = [v1_nested flatten];
	[v1_nested release];
	OCLSequence* v0 = [v1 asSequence];
	[v2 release];
	;
	return v0;
}


@end 


