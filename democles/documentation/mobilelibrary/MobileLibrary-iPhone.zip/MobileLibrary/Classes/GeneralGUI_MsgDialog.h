 
 
 
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "OCLTypes.h"
#import "IBinding.h"

@class PropertyChangeList;
@class GeneralGUI_MsgDialog;
@class MobileLibraryGUI_LoginController;
@class MobileLibraryGUI_BookDetailController;
@class MobileLibraryGUI_MemberController;


 
 
@interface GeneralGUI_MsgDialog : OCLAny <IBinding, UIAlertViewDelegate>
{
	 
	OCLString* _msg;
	BOOL _msg_initialized;
	OCLString* _viewTitle;
	BOOL _viewTitle_initialized;


@public
	NSMutableArray *MobileLibraryGUI_LoginController_currMsg_back;
	NSMutableArray *MobileLibraryGUI_BookDetailController_msg_back;
	NSMutableArray *MobileLibraryGUI_MemberController_currMsg_back;


	
	@protected
	UIAlertView* binding;
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex;

 
-(GeneralGUI_MsgDialog*)init;
-(GeneralGUI_MsgDialog*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(OCLString*) _msg;
-(OCLString*) initial_msg;
-(void) set_msg:(OCLString*) value;
-(OCLString*) _viewTitle;
-(OCLString*) initial_viewTitle;
-(void) set_viewTitle:(OCLString*) value;

-(void) event_okClicked_pushed:(PropertyChangeList*) changes ;
-(void) event_close_pushed:(PropertyChangeList*) changes ;

 
-(id) getBinding;
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value;
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters;
-(void) onPropertyChange: (NSString*)propertyName newValue:(id<OCLAny>)value;


@end


