 
	  
package democles.generated;

import android.content.Context;
import java.util.Vector;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import java.io.InputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import democles.generated.ocl.*;

	 
public class Persistence_FileHandler implements OCLAny {
	 

	public Vector<OCLAny> LibraryPersistenceHandler_LibraryLoader_fileHandler_back = new Vector<OCLAny>();

	private Object context;

	 
	private Persistence_FileHandler(Object context) {
		super();
		this.context = context;
		 


	}
	
	static public Persistence_FileHandler newInstance(Object context) {
		if (context == null) throw new NullPointerException();
		return new Persistence_FileHandler(context);
	}
 
	 
	private Persistence_FileHandler(Object context, OCLTuple values) {
		super();
		this.context = context;
		 

		if (values == null) values = new OCLTuple(); // Empty


	}

	static public Persistence_FileHandler newInstance(Object context, OCLTuple values) {
		if (context == null) throw new NullPointerException();
		return new Persistence_FileHandler(context, values);
	}

	 


	 






	 
 	public void event_openFile_pushed (PropertyChangeList changes  , OCLString p_filename ){
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			parameterTuple.addItem("filename", p_filename);
			this.onEvent("openFile", parameterTuple);
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_fileOpened_pushed (PropertyChangeList changes   ){
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			
			this.onEvent("fileOpened", parameterTuple);
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges
			Enumeration LibraryPersistenceHandler_LibraryLoader_libraryFileRead_edge0_enum = this.LibraryPersistenceHandler_LibraryLoader_fileHandler_back.elements();
			while (LibraryPersistenceHandler_LibraryLoader_libraryFileRead_edge0_enum.hasMoreElements()) {
				LibraryPersistenceHandler_LibraryLoader LibraryPersistenceHandler_LibraryLoader_libraryFileRead_edge0_target = (LibraryPersistenceHandler_LibraryLoader)LibraryPersistenceHandler_LibraryLoader_libraryFileRead_edge0_enum.nextElement();
						LibraryPersistenceHandler_LibraryLoader_libraryFileRead_edge0_target.event_libraryFileRead_pulled_edge0(changes, this  );
			}


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_lineread_pushed (PropertyChangeList changes  , OCLString p_line ){
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			parameterTuple.addItem("line", p_line);
			this.onEvent("lineread", parameterTuple);
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges
			Enumeration LibraryPersistenceHandler_LibraryLoader_bookLineRead_edge0_enum = this.LibraryPersistenceHandler_LibraryLoader_fileHandler_back.elements();
			while (LibraryPersistenceHandler_LibraryLoader_bookLineRead_edge0_enum.hasMoreElements()) {
				LibraryPersistenceHandler_LibraryLoader LibraryPersistenceHandler_LibraryLoader_bookLineRead_edge0_target = (LibraryPersistenceHandler_LibraryLoader)LibraryPersistenceHandler_LibraryLoader_bookLineRead_edge0_enum.nextElement();
						LibraryPersistenceHandler_LibraryLoader_bookLineRead_edge0_target.event_bookLineRead_pulled_edge0(changes, this , p_line  );
			}


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_fileClosed_pushed (PropertyChangeList changes   ){
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			
			this.onEvent("fileClosed", parameterTuple);
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges
			Enumeration LibraryPersistenceHandler_LibraryLoader_libraryFileClosed_edge0_enum = this.LibraryPersistenceHandler_LibraryLoader_fileHandler_back.elements();
			while (LibraryPersistenceHandler_LibraryLoader_libraryFileClosed_edge0_enum.hasMoreElements()) {
				LibraryPersistenceHandler_LibraryLoader LibraryPersistenceHandler_LibraryLoader_libraryFileClosed_edge0_target = (LibraryPersistenceHandler_LibraryLoader)LibraryPersistenceHandler_LibraryLoader_libraryFileClosed_edge0_enum.nextElement();
						LibraryPersistenceHandler_LibraryLoader_libraryFileClosed_edge0_target.event_libraryFileClosed_pulled_edge0(changes, this  );
			}


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 




	 


	 
	public void onEvent(String eventName, OCLTuple parameters) {
		if (eventName.equals("openFile")) {
			String filename = ((OCLString)parameters.objectForKey("filename")).string;
			
	        try {
	            InputStream inputStream = ((Context)this.context).getAssets().open(filename);
	            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
	            
	            this.event_fileOpened_pushed(null);
	            
	            String line = reader.readLine();
	            while (line != null) {	                
		            this.event_lineread_pushed(null, new OCLString(line));
	                line = reader.readLine();
	            };
	            
	            this.event_fileClosed_pushed(null);
	        } catch (Exception e) {
	            this.event_fileOpened_pushed(null);
	            this.event_fileClosed_pushed(null);
	        }			
		}
	}

	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

