package democles.generated.ocl;

public class OCLReal implements OCLAny {

    public float value;
    
    public OCLReal(float value) {
        this.value = value;
    }
    
    public OCLReal plus(OCLReal other) {
        return new OCLReal(this.value + other.value);
    }

    public OCLReal minus(OCLReal other) {
        return new OCLReal(this.value - other.value);
    }

    public OCLReal mult(OCLReal other) {
        return new OCLReal(this.value * other.value);
    }

    public OCLReal neg() {
        return new OCLReal(-this.value);
    }
    
    public OCLReal div(OCLReal other) {
        return new OCLReal(this.value / other.value);
    }

    public OCLReal abs() {
        return new OCLReal(Math.abs(this.value));
    }
    
    public OCLInteger floor() {
        return new OCLInteger((int)Math.floor(this.value));
    }

    public OCLInteger round() {
        return new OCLInteger((int)Math.round(this.value));
    }
    
    public OCLReal max(OCLReal other) {
        return new OCLReal(Math.max(this.value, other.value));
    }

    public OCLReal min(OCLReal other) {
        return new OCLReal(Math.min(this.value, other.value));
    }

    public OCLBoolean lt(OCLReal other) {
        return new OCLBoolean(this.value < other.value);
    }

    public OCLBoolean gt(OCLReal other) {
        return new OCLBoolean(this.value > other.value);
    }

    public OCLBoolean lte(OCLReal other) {
        return new OCLBoolean(this.value <= other.value);
    }

    public OCLBoolean gte(OCLReal other) {
        return new OCLBoolean(this.value >= other.value);
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + Float.floatToIntBits(value);
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        OCLReal other = (OCLReal)obj;
        if (Float.floatToIntBits(value) != Float.floatToIntBits(other.value))
            return false;
        return true;
    }

    // OCLAny implementation, using delegation so that inheritance remains available. -----------------
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }
}
