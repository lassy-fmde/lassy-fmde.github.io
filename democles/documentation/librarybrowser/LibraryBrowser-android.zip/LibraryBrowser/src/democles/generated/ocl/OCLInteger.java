package democles.generated.ocl;

public class OCLInteger implements OCLAny {

    public int value;
    
    public OCLInteger(int value) {
        this.value = value;
    }
    
    public OCLInteger plus(OCLInteger other) {
        return new OCLInteger(this.value + other.value);
    }

    public OCLInteger minus(OCLInteger other) {
        return new OCLInteger(this.value - other.value);
    }

    public OCLInteger mult(OCLInteger other) {
        return new OCLInteger(this.value * other.value);
    }

    public OCLInteger neg() {
        return new OCLInteger(-this.value);
    }

    public OCLReal div(OCLInteger other) {
        return new OCLReal(this.value / other.value);
    }

    public OCLInteger idiv(OCLInteger other) {
        return new OCLInteger(this.value / other.value);
    }

    public OCLInteger mod(OCLInteger other) {
        return new OCLInteger(this.value % other.value);
    }

    public OCLInteger abs() {
        return new OCLInteger(Math.abs(this.value));
    }

    public OCLInteger max(OCLInteger other) {
        return new OCLInteger(Math.max(this.value, other.value));
    }

    public OCLInteger min(OCLInteger other) {
        return new OCLInteger(Math.min(this.value, other.value));
    }
    
    public OCLBoolean lt(OCLInteger other) {
        return new OCLBoolean(this.value < other.value);
    }

    public OCLBoolean gt(OCLInteger other) {
        return new OCLBoolean(this.value > other.value);
    }

    public OCLBoolean lte(OCLInteger other) {
        return new OCLBoolean(this.value <= other.value);
    }

    public OCLBoolean gte(OCLInteger other) {
        return new OCLBoolean(this.value >= other.value);
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + value;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        OCLInteger other = (OCLInteger)obj;
        if (value != other.value)
            return false;
        return true;
    }

    // OCLAny implementation, using delegation so that inheritance remains available. -----------------
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }
}
