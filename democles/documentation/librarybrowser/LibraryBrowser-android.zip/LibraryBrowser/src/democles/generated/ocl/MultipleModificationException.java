package democles.generated.ocl;

public class MultipleModificationException extends RuntimeException {

}
