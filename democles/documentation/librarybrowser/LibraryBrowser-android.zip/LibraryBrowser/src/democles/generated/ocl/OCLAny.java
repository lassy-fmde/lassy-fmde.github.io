package democles.generated.ocl;

public interface OCLAny {

    public OCLBoolean eq(OCLAny other);
    public OCLBoolean neq(OCLAny other);
    public OCLBoolean oclIsTypeOf(Class<?> type);
    public OCLBoolean oclIsKindOfClass(Class<?> type);
    public OCLBoolean oclIsKindOfInterface(String interfaceName);
    
    public boolean isCompatibleType(OCLAny other);

    // public boolean equals(Object other);
    // public String toString();
    
    static public class DefaultOCLAnyImpl implements OCLAny {

        private final OCLAny object;

        public DefaultOCLAnyImpl(OCLAny object) {
            this.object = object;
        }
        
        @Override
        public OCLBoolean eq(OCLAny other) {
            return new OCLBoolean(this.object.equals(other));
        }

        @Override
        public OCLBoolean neq(OCLAny other) {
            return this.eq(other).not();
        }

        @Override
        public OCLBoolean oclIsTypeOf(Class<?> type) {
            return new OCLBoolean(this.object.getClass().equals(type));
        }

        @Override
        public OCLBoolean oclIsKindOfClass(Class<?> type) {
            return new OCLBoolean(type.isInstance(this.object));
        }

        @Override
        public OCLBoolean oclIsKindOfInterface(String interfaceName) {
            try {
                Class<?> interfaceType = Class.forName(interfaceName);
                return this.object.oclIsKindOfClass(interfaceType);
            } catch (ClassNotFoundException e) {
                return new OCLBoolean(false);
            }
        }

        @Override
        public boolean isCompatibleType(OCLAny other) {
            boolean res = false;
            if (other != null) {
                OCLBoolean typeCompat = other.oclIsKindOfClass(this.getClass());
                res = typeCompat.value;
            }
            return res;
        }
        
        @Override
        public boolean equals(Object o) {
            return this.object.equals(o);
        }
    }
}
