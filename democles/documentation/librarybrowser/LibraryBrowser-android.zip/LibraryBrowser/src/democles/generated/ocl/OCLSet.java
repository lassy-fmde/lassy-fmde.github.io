package democles.generated.ocl;

import java.util.HashSet;
import java.util.Set;

public class OCLSet extends OCLCollection {

    public Set<OCLAny> values = new HashSet<OCLAny>();
    
    @Override
    public OCLCollection newCollection() {
        return new OCLSet();
    }

    @Override
    public void add(OCLAny object) {
        this.values.add(object);
    }

    @Override
    public OCLInteger size() {
        return new OCLInteger(this.values.size());
    }

    @Override
    public OCLBoolean includes(OCLAny object) {
        return new OCLBoolean(this.values.contains(object));
    }

    @Override
    public Iterable<OCLAny> objectIterable() {
        return this.values;
    }

    @Override
    public String collectionName() {
        return "Set";
    }

    public OCLSet union(OCLSet other) {
        OCLSet res = new OCLSet();
        res.values.addAll(this.values);
        res.values.addAll(other.values);
        return res;
    }

    public OCLBag union(OCLBag other) {
        OCLBag res = new OCLBag();
        res.addAll(this.values);
        res.addAll(other.values);
        return res;
    }
    
    public OCLSet intersection(OCLSet set) {
        OCLSet res = new OCLSet();
        
        for (OCLAny o : this.values) {
            if (set.values.contains(o)) {
                res.values.add(o);
            }
        }
        
        return res;
    }

    public OCLSet intersection(OCLBag bag) {
        OCLSet res = new OCLSet();
        
        for (OCLAny o : this.values) {
            if (bag.values.contains(o)) {
                res.values.add(o);
            }
        }
        
        return res;
    }
    
    public OCLSet n(OCLSet other) {
        OCLSet res = new OCLSet();
        
        for (OCLAny o : this.values) {
            if (!other.values.contains(o)) {
                res.values.add(o);
            }
        }
        
        return res;
    }
    
    public OCLSet including(OCLAny object) {
        OCLSet res = new OCLSet();
        res.values.addAll(this.values);
        res.values.add(object);
        return res;
    }

    public OCLSet excluding(OCLAny object) {
        OCLSet res = new OCLSet();
        res.values.addAll(this.values);
        res.values.remove(object);
        return res;
    }

    public OCLSet symmetricDifference(OCLSet other) {
        OCLSet intersection = this.intersection(other);
        OCLSet union = this.union(other);
        OCLSet res = new OCLSet();
        res.values.addAll(union.values);
        res.values.removeAll(intersection.values);
        return res;
    }

    public OCLSet flatten() {
        return (OCLSet)super.flatten();
    }
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((values == null) ? 0 : values.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        OCLSet other = (OCLSet)obj;
        if (values == null) {
            if (other.values != null)
                return false;
        } else if (!values.equals(other.values))
            return false;
        return true;
    }
}
