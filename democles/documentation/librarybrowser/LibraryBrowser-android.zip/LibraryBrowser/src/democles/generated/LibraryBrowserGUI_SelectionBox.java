 
	  
package democles.generated;

import java.util.Vector;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
import android.content.Context;
import android.view.View;

	 
import android.widget.AdapterView;
import android.widget.Spinner;
import java.util.List;
import java.util.ArrayList;

	 
public class LibraryBrowserGUI_SelectionBox implements IWidgetWrapper, OCLAny {
	 
	private OCLSequence _choices;
	private boolean _choices_isInitialized;
	private OCLString _selectedChoice;
	private boolean _selectedChoice_isInitialized;

	public Vector<OCLAny> LibraryBrowserGUI_SearchView_categorySelect_back = new Vector<OCLAny>();

	private Object context;

	  
	private Spinner spinner;

	 
	private LibraryBrowserGUI_SelectionBox(Object context) {
		super();
		this.context = context;
		 
		this.set_choices(this.initial_choices()); 
		this.set_selectedChoice(this.initial_selectedChoice()); 


	}
	
	static public LibraryBrowserGUI_SelectionBox newInstance(Object context) {
		if (context == null) throw new NullPointerException();
		return new LibraryBrowserGUI_SelectionBox(context);
	}
 
	 
	private LibraryBrowserGUI_SelectionBox(Object context, OCLTuple values) {
		super();
		this.context = context;
		 
		this._choices_isInitialized = false; 
		this._selectedChoice_isInitialized = false; 

		if (values == null) values = new OCLTuple(); // Empty
		if (values.containsKey("choices")) {
			this.set_choices((OCLSequence)values.objectForKey("choices"));
		} else {
			this.set_choices(this.initial_choices());
		}
		if (values.containsKey("selectedChoice")) {
			this.set_selectedChoice((OCLString)values.objectForKey("selectedChoice"));
		} else {
			this.set_selectedChoice(this.initial_selectedChoice());
		}


	}

	static public LibraryBrowserGUI_SelectionBox newInstance(Object context, OCLTuple values) {
		if (context == null) throw new NullPointerException();
		return new LibraryBrowserGUI_SelectionBox(context, values);
	}

	 
	public OCLSequence initial_choices() {
		/* ==================================================
	 * Sequence{}
	 * ================================================== */
	
	OCLSequence v0 = new OCLSequence();
	
		return v0;
	}

	public OCLSequence get_choices(){
		if (this._choices_isInitialized) {
			return _choices;
		} else { 
			this.set_choices(this.initial_choices());
		}
		this._choices_isInitialized = true;
		return this._choices;
	}
	public OCLString initial_selectedChoice() {
		/* ==================================================
	 * ''
	 * ================================================== */
	
	OCLString v0 = new OCLString("");
	
		return v0;
	}

	public OCLString get_selectedChoice(){
		if (this._selectedChoice_isInitialized) {
			return _selectedChoice;
		} else { 
			this.set_selectedChoice(this.initial_selectedChoice());
		}
		this._selectedChoice_isInitialized = true;
		return this._selectedChoice;
	}


	 
	public void set_choices(OCLSequence value) {
		 	
		this._choices = value;
		this._choices_isInitialized = true;

		this.onPropertyChange("choices",value);
	}
	public void set_selectedChoice(OCLString value) {
		 	
		this._selectedChoice = value;
		this._selectedChoice_isInitialized = true;

		this.onPropertyChange("selectedChoice",value);
	}






	 
 	public void event_rowSelected_pushed (PropertyChangeList changes  , OCLInteger p_id ){
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			parameterTuple.addItem("id", p_id);
			this.onEvent("rowSelected", parameterTuple);
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * choices->at(id)
		 * ================================================== */
		
		LibraryBrowserGUI_SelectionBox v2 = this;
		OCLSequence v1 = v2.get_choices();
		OCLInteger v3 = p_id;
		OCLString v0 = ((OCLString)v1.at(v3));
		
			OCLString _selectedChoice_newValue = v0;
			changes.addChange("_selectedChoice", this, _selectedChoice_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 




	 


	 
	public void onPropertyChange(String propertyName, Object value) {
		if (propertyName.equals("choices")) {
			if (value != null) {
				updateSpinner();
			}
		}
	}

	 
	public void onEvent(String eventName, OCLTuple parameters) {
	}

	  
	@Override
    public View createWidget(Context context) {
        this.context = context;
        this.spinner = new Spinner(context);
        this.updateSpinner();
        
        this.spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                new Thread() { @Override public void run() {
	                int selectedItemPosition = spinner.getSelectedItemPosition() + 1;
					OCLInteger posOCL = new OCLInteger(selectedItemPosition);
					event_rowSelected_pushed(null, posOCL);
                }}.start();
            }
            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO trigger rowSelected event (with -1 as position?)
            }
        });
        
        return this.spinner;
    }
    
    private List<String> getChoices() {
		ArrayList<String> choices = new ArrayList<String>();
		for (OCLAny s : this.get_choices().objectIterable()) {
			choices.add(((OCLString)s).string);
		}
        return choices;
    }

    private void updateSpinner() {
    	if (this.spinner == null) return;
        this.spinner.setAdapter(new ListSpinnerAdapter<String>((Context)this.context, this.getChoices()));
    }

	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

