 
	  
package democles.generated;

import java.util.Vector;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
public class LibraryPersistenceHandler_LibraryLoader implements OCLAny {
	 
	private Library_BookCollection _libraryBooks;
	private boolean _libraryBooks_isInitialized;
	private Persistence_FileHandler _fileHandler;
	private boolean _fileHandler_isInitialized;
	private StringUtils_StringTokenizer _bookLineTokenizer;
	private boolean _bookLineTokenizer_isInitialized;

	public Vector<OCLAny> Application_Main_libraryLoader_back = new Vector<OCLAny>();

	private Object context;

	 
	private LibraryPersistenceHandler_LibraryLoader(Object context) {
		super();
		this.context = context;
		 
		this.set_libraryBooks(this.initial_libraryBooks()); 
		this.set_fileHandler(this.initial_fileHandler()); 
		this.set_bookLineTokenizer(this.initial_bookLineTokenizer()); 


	}
	
	static public LibraryPersistenceHandler_LibraryLoader newInstance(Object context) {
		if (context == null) throw new NullPointerException();
		return new LibraryPersistenceHandler_LibraryLoader(context);
	}
 
	 
	private LibraryPersistenceHandler_LibraryLoader(Object context, OCLTuple values) {
		super();
		this.context = context;
		 
		this._libraryBooks_isInitialized = false; 
		this._fileHandler_isInitialized = false; 
		this._bookLineTokenizer_isInitialized = false; 

		if (values == null) values = new OCLTuple(); // Empty
		if (values.containsKey("libraryBooks")) {
			this.set_libraryBooks((Library_BookCollection)values.objectForKey("libraryBooks"));
		} else {
			this.set_libraryBooks(this.initial_libraryBooks());
		}
		if (values.containsKey("fileHandler")) {
			this.set_fileHandler((Persistence_FileHandler)values.objectForKey("fileHandler"));
		} else {
			this.set_fileHandler(this.initial_fileHandler());
		}
		if (values.containsKey("bookLineTokenizer")) {
			this.set_bookLineTokenizer((StringUtils_StringTokenizer)values.objectForKey("bookLineTokenizer"));
		} else {
			this.set_bookLineTokenizer(this.initial_bookLineTokenizer());
		}


	}

	static public LibraryPersistenceHandler_LibraryLoader newInstance(Object context, OCLTuple values) {
		if (context == null) throw new NullPointerException();
		return new LibraryPersistenceHandler_LibraryLoader(context, values);
	}

	 
	public Library_BookCollection initial_libraryBooks() {
		/* ==================================================
	 * null
	 * ================================================== */
	
	Library_BookCollection v0 = null;
	
		return v0;
	}

	public Library_BookCollection get_libraryBooks(){
		if (this._libraryBooks_isInitialized) {
			return _libraryBooks;
		} else { 
			this.set_libraryBooks(this.initial_libraryBooks());
		}
		this._libraryBooks_isInitialized = true;
		return this._libraryBooks;
	}
	public Persistence_FileHandler initial_fileHandler() {
		/* ==================================================
	 * Persistence::FileHandler::create()
	 * ================================================== */
	
	Persistence_FileHandler v0 = Persistence_FileHandler.newInstance(this.context);
	
		return v0;
	}

	public Persistence_FileHandler get_fileHandler(){
		if (this._fileHandler_isInitialized) {
			return _fileHandler;
		} else { 
			this.set_fileHandler(this.initial_fileHandler());
		}
		this._fileHandler_isInitialized = true;
		return this._fileHandler;
	}
	public StringUtils_StringTokenizer initial_bookLineTokenizer() {
		/* ==================================================
	 * StringUtils::StringTokenizer::create()
	 * ================================================== */
	
	StringUtils_StringTokenizer v0 = StringUtils_StringTokenizer.newInstance(this.context);
	
		return v0;
	}

	public StringUtils_StringTokenizer get_bookLineTokenizer(){
		if (this._bookLineTokenizer_isInitialized) {
			return _bookLineTokenizer;
		} else { 
			this.set_bookLineTokenizer(this.initial_bookLineTokenizer());
		}
		this._bookLineTokenizer_isInitialized = true;
		return this._bookLineTokenizer;
	}


	 


	public void set_libraryBooks(Library_BookCollection value) {
	 	
		if (this._libraryBooks!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._libraryBooks.LibraryPersistenceHandler_LibraryLoader_libraryBooks_back;
			backpointers.removeElement(this);
		}
		this._libraryBooks = value;
		if (this._libraryBooks!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._libraryBooks.LibraryPersistenceHandler_LibraryLoader_libraryBooks_back;
			backpointers.addElement(this);
		}
		this._libraryBooks_isInitialized = true;

	}
	public void set_fileHandler(Persistence_FileHandler value) {
	 	
		if (this._fileHandler!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._fileHandler.LibraryPersistenceHandler_LibraryLoader_fileHandler_back;
			backpointers.removeElement(this);
		}
		this._fileHandler = value;
		if (this._fileHandler!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._fileHandler.LibraryPersistenceHandler_LibraryLoader_fileHandler_back;
			backpointers.addElement(this);
		}
		this._fileHandler_isInitialized = true;

	}
	public void set_bookLineTokenizer(StringUtils_StringTokenizer value) {
	 	
		if (this._bookLineTokenizer!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._bookLineTokenizer.LibraryPersistenceHandler_LibraryLoader_bookLineTokenizer_back;
			backpointers.removeElement(this);
		}
		this._bookLineTokenizer = value;
		if (this._bookLineTokenizer!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._bookLineTokenizer.LibraryPersistenceHandler_LibraryLoader_bookLineTokenizer_back;
			backpointers.addElement(this);
		}
		this._bookLineTokenizer_isInitialized = true;

	}




	 
 	public void event_loadLibrary_pushed (PropertyChangeList changes   ){
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_loadLibrary_pushed in model LibraryPersistenceHandler_LibraryLoader");
			 		
			// Trigger Push edges


			if (this._fileHandler != null) {
			 	
				Vector edge0_values = new Vector();
				edge0_values.addElement(this._fileHandler);
			 	Enumeration edge0_enum = edge0_values.elements();
				while (edge0_enum.hasMoreElements()) {
					Persistence_FileHandler edge0_target = (Persistence_FileHandler)edge0_enum.nextElement();
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * 'libraryDataFile.dat'
				 * ================================================== */
				
				OCLString v1 = new OCLString("libraryDataFile.dat");
				
						OCLString parameter_p_filename = v1;

						edge0_target.event_openFile_pushed(changes ,parameter_p_filename );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_bookLineRead_pushed (PropertyChangeList changes  , OCLString p_line ){
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_bookLineRead_pushed in model LibraryPersistenceHandler_LibraryLoader");
			 		
			// Trigger Push edges


			if (this._bookLineTokenizer != null) {
			 	
				Vector edge0_values = new Vector();
				edge0_values.addElement(this._bookLineTokenizer);
			 	Enumeration edge0_enum = edge0_values.elements();
				while (edge0_enum.hasMoreElements()) {
					StringUtils_StringTokenizer edge0_target = (StringUtils_StringTokenizer)edge0_enum.nextElement();
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * line
				 * ================================================== */
				
				OCLString v1 = p_line;
				
						OCLString parameter_p_string = v1;
						/* ==================================================
				 * ';'
				 * ================================================== */
				
				OCLString v2 = new OCLString(";");
				
						OCLString parameter_p_separator = v2;

						edge0_target.event_tokenizeString_pushed(changes ,parameter_p_string ,parameter_p_separator );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_bookLineRead_pulled_edge0(PropertyChangeList changes, Persistence_FileHandler parentInstance ,OCLString p_line  ) {
		System.out.println("event_bookLineRead_pulled in model LibraryPersistenceHandler_LibraryLoader from event _lineread in model Persistence_FileHandler");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {
			/* ==================================================
		 * line
		 * ================================================== */
		
		OCLString v1 = p_line;
		
			OCLString parameter_p_line = v1;

			this.event_bookLineRead_pushed(changes ,parameter_p_line  );
		}
	}


 	public void event_libraryFileRead_pushed (PropertyChangeList changes   ){
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_libraryFileRead_pushed in model LibraryPersistenceHandler_LibraryLoader");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * Library::BookCollection::create(Tuple { Books = Sequence { } })
		 * ================================================== */
		
		OCLSequence v4 = new OCLSequence();
		OCLSequence v3 = v4;
		OCLTuple v2 = new OCLTuple();
		v2.addItem("Books", v3);
		Library_BookCollection v0 = Library_BookCollection.newInstance(this.context, v2);
		
			Library_BookCollection _libraryBooks_newValue = v0;
			changes.addChange("_libraryBooks", this, _libraryBooks_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_libraryFileRead_pulled_edge0(PropertyChangeList changes, Persistence_FileHandler parentInstance  ) {
		System.out.println("event_libraryFileRead_pulled in model LibraryPersistenceHandler_LibraryLoader from event _fileOpened in model Persistence_FileHandler");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {

			this.event_libraryFileRead_pushed(changes  );
		}
	}


 	public void event_libraryFileClosed_pushed (PropertyChangeList changes   ){
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_libraryFileClosed_pushed in model LibraryPersistenceHandler_LibraryLoader");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges
			Enumeration Application_Main_libraryBooksLoaded_edge0_enum = this.Application_Main_libraryLoader_back.elements();
			while (Application_Main_libraryBooksLoaded_edge0_enum.hasMoreElements()) {
				Application_Main Application_Main_libraryBooksLoaded_edge0_target = (Application_Main)Application_Main_libraryBooksLoaded_edge0_enum.nextElement();
						Application_Main_libraryBooksLoaded_edge0_target.event_libraryBooksLoaded_pulled_edge0(changes, this  );
			}


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_libraryFileClosed_pulled_edge0(PropertyChangeList changes, Persistence_FileHandler parentInstance  ) {
		System.out.println("event_libraryFileClosed_pulled in model LibraryPersistenceHandler_LibraryLoader from event _fileClosed in model Persistence_FileHandler");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {

			this.event_libraryFileClosed_pushed(changes  );
		}
	}


 	public void event_bookLineTokenized_pushed (PropertyChangeList changes  , OCLSequence p_bookTokens ){
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_bookLineTokenized_pushed in model LibraryPersistenceHandler_LibraryLoader");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * if bookTokens->size() = 3 then 
		 * 	Library::BookCollection::create(Tuple { 
		 * 		Books = libraryBooks.Books->including(
		 * 					Library::Book::create(
		 * 					Tuple { author = bookTokens->at(1), 
		 * 							title =  bookTokens->at(2), 
		 * 							isbn =   bookTokens->at(3) 
		 * 					}
		 * 		))})
		 * else
		 * 	Library::BookCollection::create(Tuple { Books = libraryBooks.Books })
		 * endif
		 * 
		 * ================================================== */
		
		OCLSequence v3 = p_bookTokens;
		OCLInteger v2 = v3.size();
		OCLInteger v4 = new OCLInteger(3);
		OCLBoolean v1 = v2.eq(v4);
		Library_BookCollection v0;
		if (v1.value == true) {
				LibraryPersistenceHandler_LibraryLoader v12 = this;
				Library_BookCollection v11 = v12.get_libraryBooks();
				OCLSequence v10 = v11.get_Books();
				OCLSequence v18 = p_bookTokens;
				OCLInteger v19 = new OCLInteger(1);
				OCLString v17 = ((OCLString)v18.at(v19));
				OCLString v16 = v17;
				OCLSequence v22 = p_bookTokens;
				OCLInteger v23 = new OCLInteger(2);
				OCLString v21 = ((OCLString)v22.at(v23));
				OCLString v20 = v21;
				OCLSequence v26 = p_bookTokens;
				OCLInteger v27 = new OCLInteger(3);
				OCLString v25 = ((OCLString)v26.at(v27));
				OCLString v24 = v25;
				OCLTuple v15 = new OCLTuple();
				v15.addItem("author", v16);
				v15.addItem("title", v20);
				v15.addItem("isbn", v24);
				Library_Book v13 = Library_Book.newInstance(this.context, v15);
				OCLSequence v9 = v10.including(v13);
				OCLSequence v8 = v9;
				OCLTuple v7 = new OCLTuple();
				v7.addItem("Books", v8);
				Library_BookCollection v5 = Library_BookCollection.newInstance(this.context, v7);
				v0 = v5;
		} else {
				LibraryPersistenceHandler_LibraryLoader v34 = this;
				Library_BookCollection v33 = v34.get_libraryBooks();
				OCLSequence v32 = v33.get_Books();
				OCLSequence v31 = v32;
				OCLTuple v30 = new OCLTuple();
				v30.addItem("Books", v31);
				Library_BookCollection v28 = Library_BookCollection.newInstance(this.context, v30);
				v0 = v28;
		}
		
			Library_BookCollection _libraryBooks_newValue = v0;
			changes.addChange("_libraryBooks", this, _libraryBooks_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_bookLineTokenized_pulled_edge0(PropertyChangeList changes, StringUtils_StringTokenizer parentInstance ,OCLSequence p_tokens  ) {
		System.out.println("event_bookLineTokenized_pulled in model LibraryPersistenceHandler_LibraryLoader from event _stringTokenized in model StringUtils_StringTokenizer");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {
			/* ==================================================
		 * tokens
		 * ================================================== */
		
		OCLSequence v1 = p_tokens;
		
			OCLSequence parameter_p_bookTokens = v1;

			this.event_bookLineTokenized_pushed(changes ,parameter_p_bookTokens  );
		}
	}




	 


	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

