 
	  
package democles.generated;

import java.util.Vector;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
import android.content.Context;
import android.view.View;

	 
import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;

	 
public class LibraryBrowserGUI_BookListView extends ListActivity implements OCLAny {
	 
	private OCLSequence _bookListTable;
	private boolean _bookListTable_isInitialized;
	private LibraryBrowserGUI_BookDetailView _bookDetailView;
	private boolean _bookDetailView_isInitialized;
	private OCLString _viewTitle;
	private boolean _viewTitle_isInitialized;

	public Vector<OCLAny> LibraryBrowserGUI_SearchView_resultView_back = new Vector<OCLAny>();

	private Object context;

	  

	final static private String INIT_PROP_VALUES_KEY = "initialPropertyValues";
	final static private String HOLDER_KEY = "instanceHolder";
    
    static class Holder {
        public LibraryBrowserGUI_BookListView instance = null;
    }

	 
    public LibraryBrowserGUI_BookListView() {
        super();
        this.context = this;
    }

	 
    public static LibraryBrowserGUI_BookListView newInstance(Object contextObject) {
		if (contextObject == null) throw new NullPointerException();
    	return newInstance(contextObject, null);
    }
    
    public static LibraryBrowserGUI_BookListView newInstance(Object contextObject, OCLTuple initialPropertyValues) {
		if (contextObject == null) throw new NullPointerException();
    	Context context = (Context)contextObject;
        Thread currentThread = Thread.currentThread();
        Thread mainThread = context.getMainLooper().getThread();
        
        if (currentThread == mainThread) {
            throw new RuntimeException("LibraryBrowserGUI_BookListView can not be instantiated from the UI thread.");
        }
        
        final Intent intent = new Intent(context, LibraryBrowserGUI_BookListView.class);
        if (initialPropertyValues != null) {
            Long initDataKey = InitializationDataHolder.putData(initialPropertyValues);
            intent.putExtra(INIT_PROP_VALUES_KEY, initDataKey);
        }
        
        Holder holder = new Holder();
        Long holderKey = InitializationDataHolder.putData(holder);
        intent.putExtra(HOLDER_KEY, holderKey);

        final Context contextClosure = context;
        new Thread() {
            public void run() {
                contextClosure.startActivity(intent);
            };
        }.start();
        
        synchronized(holder) {
            try {
                holder.wait();
            } catch (InterruptedException e) {
            }
        }
        return holder.instance;
    }
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        OCLTuple values = null;
        
        Bundle extras = this.getIntent().getExtras();
        if (extras != null) {
            Long initDataKey = extras.getLong(INIT_PROP_VALUES_KEY);
            if (initDataKey != null) {
                values = (OCLTuple)InitializationDataHolder.retrieveData(initDataKey);
            }
            
            Long holderKey = extras.getLong(HOLDER_KEY);
            Holder holder = (Holder)InitializationDataHolder.retrieveData(holderKey);
            holder.instance = this;
            
            synchronized(holder) {
                holder.notify();
            }
        }

        this.getListView().setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(android.widget.AdapterView<?> arg0, View arg1, final int position, long arg3) {
                new Thread() { @Override public void run() {
                    int selectedItemPosition = position + 1;
                    OCLInteger posOCL = new OCLInteger(selectedItemPosition);
                    event_bookSelected_pushed(null, posOCL);
                }}.start();                
            }
        });
        
		 
		this._bookListTable_isInitialized = false; 
		this._bookDetailView_isInitialized = false; 
		this._viewTitle_isInitialized = false; 

		if (values == null) values = new OCLTuple(); // Empty
		if (values.containsKey("bookListTable")) {
			this.set_bookListTable((OCLSequence)values.objectForKey("bookListTable"));
		} else {
			this.set_bookListTable(this.initial_bookListTable());
		}
		if (values.containsKey("bookDetailView")) {
			this.set_bookDetailView((LibraryBrowserGUI_BookDetailView)values.objectForKey("bookDetailView"));
		} else {
			this.set_bookDetailView(this.initial_bookDetailView());
		}
		if (values.containsKey("viewTitle")) {
			this.set_viewTitle((OCLString)values.objectForKey("viewTitle"));
		} else {
			this.set_viewTitle(this.initial_viewTitle());
		}


        
        this.updateList();
    }

	 
	public OCLSequence initial_bookListTable() {
		/* ==================================================
	 * Sequence {}
	 * ================================================== */
	
	OCLSequence v0 = new OCLSequence();
	
		return v0;
	}

	public OCLSequence get_bookListTable(){
		if (this._bookListTable_isInitialized) {
			return _bookListTable;
		} else { 
			this.set_bookListTable(this.initial_bookListTable());
		}
		this._bookListTable_isInitialized = true;
		return this._bookListTable;
	}
	public LibraryBrowserGUI_BookDetailView initial_bookDetailView() {
		/* ==================================================
	 * null
	 * ================================================== */
	
	LibraryBrowserGUI_BookDetailView v0 = null;
	
		return v0;
	}

	public LibraryBrowserGUI_BookDetailView get_bookDetailView(){
		if (this._bookDetailView_isInitialized) {
			return _bookDetailView;
		} else { 
			this.set_bookDetailView(this.initial_bookDetailView());
		}
		this._bookDetailView_isInitialized = true;
		return this._bookDetailView;
	}
	public OCLString initial_viewTitle() {
		/* ==================================================
	 * 'Results'
	 * ================================================== */
	
	OCLString v0 = new OCLString("Results");
	
		return v0;
	}

	public OCLString get_viewTitle(){
		if (this._viewTitle_isInitialized) {
			return _viewTitle;
		} else { 
			this.set_viewTitle(this.initial_viewTitle());
		}
		this._viewTitle_isInitialized = true;
		return this._viewTitle;
	}


	 
	public void set_bookListTable(OCLSequence value) {
		 	
		this._bookListTable = value;
		this._bookListTable_isInitialized = true;

		this.onPropertyChange("bookListTable",value);
	}
	public void set_viewTitle(OCLString value) {
		 	
		this._viewTitle = value;
		this._viewTitle_isInitialized = true;

		this.onPropertyChange("viewTitle",value);
	}


	public void set_bookDetailView(LibraryBrowserGUI_BookDetailView value) {
		 	
		if (this._bookDetailView!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._bookDetailView.LibraryBrowserGUI_BookListView_bookDetailView_back;
			backpointers.removeElement(this);
		}
		this._bookDetailView = value;
		if (this._bookDetailView!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._bookDetailView.LibraryBrowserGUI_BookListView_bookDetailView_back;
			backpointers.addElement(this);
		}
		this._bookDetailView_isInitialized = true;

		this.onPropertyChange("bookDetailView",value);
	}




	 
 	public void event_bookSelected_pushed (PropertyChangeList changes  , OCLInteger p_id ){
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			parameterTuple.addItem("id", p_id);
			this.onEvent("bookSelected", parameterTuple);
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges
			Enumeration LibraryBrowserGUI_SearchView_bookSelected_edge0_enum = this.LibraryBrowserGUI_SearchView_resultView_back.elements();
			while (LibraryBrowserGUI_SearchView_bookSelected_edge0_enum.hasMoreElements()) {
				LibraryBrowserGUI_SearchView LibraryBrowserGUI_SearchView_bookSelected_edge0_target = (LibraryBrowserGUI_SearchView)LibraryBrowserGUI_SearchView_bookSelected_edge0_enum.nextElement();
						LibraryBrowserGUI_SearchView_bookSelected_edge0_target.event_bookSelected_pulled_edge0(changes, this , p_id  );
			}


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_selectedBookData_pushed (PropertyChangeList changes  , OCLString p_author , OCLString p_title , OCLString p_isbn ){
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			parameterTuple.addItem("author", p_author);parameterTuple.addItem("title", p_title);parameterTuple.addItem("isbn", p_isbn);
			this.onEvent("selectedBookData", parameterTuple);
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * LibraryBrowserGUI::BookDetailView::create(
		 * Tuple { 
		 * 	bookTitleLabel = Label::create(Tuple { text = title }), 
		 * 	bookAuthorLabel = Label::create(Tuple { text = author }), 
		 * 	bookIsbnLabel = Label::create(Tuple { text = isbn })
		 * })
		 * ================================================== */
		
		OCLString v8 = p_title;
		OCLString v7 = v8;
		OCLTuple v6 = new OCLTuple();
		v6.addItem("text", v7);
		LibraryBrowserGUI_Label v4 = LibraryBrowserGUI_Label.newInstance(this.context, v6);
		LibraryBrowserGUI_Label v3 = v4;
		OCLString v14 = p_author;
		OCLString v13 = v14;
		OCLTuple v12 = new OCLTuple();
		v12.addItem("text", v13);
		LibraryBrowserGUI_Label v10 = LibraryBrowserGUI_Label.newInstance(this.context, v12);
		LibraryBrowserGUI_Label v9 = v10;
		OCLString v20 = p_isbn;
		OCLString v19 = v20;
		OCLTuple v18 = new OCLTuple();
		v18.addItem("text", v19);
		LibraryBrowserGUI_Label v16 = LibraryBrowserGUI_Label.newInstance(this.context, v18);
		LibraryBrowserGUI_Label v15 = v16;
		OCLTuple v2 = new OCLTuple();
		v2.addItem("bookTitleLabel", v3);
		v2.addItem("bookAuthorLabel", v9);
		v2.addItem("bookIsbnLabel", v15);
		LibraryBrowserGUI_BookDetailView v0 = LibraryBrowserGUI_BookDetailView.newInstance(this.context, v2);
		
			LibraryBrowserGUI_BookDetailView _bookDetailView_newValue = v0;
			changes.addChange("_bookDetailView", this, _bookDetailView_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 




	 


	 
	public void onPropertyChange(String propertyName, Object value) {
		if (propertyName.equals("bookListTable")) {
			if (value != null) {
				updateList();
			}
		}
	}

	 
	public void onEvent(String eventName, OCLTuple parameters) {
	}

	  
    private void updateList() {
    	List<String> items = new ArrayList<String>();
        for (OCLAny s : this.get_bookListTable().objectIterable()) {
            items.add(((OCLString)s).string);
        }
    
        this.setListAdapter(new ListAdapter<String>(this, items));    
    }

	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

