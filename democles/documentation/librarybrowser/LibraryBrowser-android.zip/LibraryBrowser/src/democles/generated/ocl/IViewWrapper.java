package democles.generated.ocl;

import android.content.Context;
import android.view.View;

public interface IViewWrapper {

    public String getTitle();
    
    public View createView(Context context);
}
