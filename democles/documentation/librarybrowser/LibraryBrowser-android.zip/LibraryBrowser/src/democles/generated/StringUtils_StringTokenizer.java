 
	  
package democles.generated;

import java.util.Vector;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.regex.Pattern;
import democles.generated.ocl.*;

	 
public class StringUtils_StringTokenizer implements OCLAny {
	 

	public Vector<OCLAny> LibraryPersistenceHandler_LibraryLoader_bookLineTokenizer_back = new Vector<OCLAny>();

	private Object context;

	 
	private StringUtils_StringTokenizer(Object context) {
		super();
		this.context = context;
		 


	}
	
	static public StringUtils_StringTokenizer newInstance(Object context) {
		if (context == null) throw new NullPointerException();
		return new StringUtils_StringTokenizer(context);
	}
 
	 
	private StringUtils_StringTokenizer(Object context, OCLTuple values) {
		super();
		this.context = context;
		 

		if (values == null) values = new OCLTuple(); // Empty


	}

	static public StringUtils_StringTokenizer newInstance(Object context, OCLTuple values) {
		if (context == null) throw new NullPointerException();
		return new StringUtils_StringTokenizer(context, values);
	}

	 


	 






	 
 	public void event_tokenizeString_pushed (PropertyChangeList changes  , OCLString p_string , OCLString p_separator ){
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			parameterTuple.addItem("string", p_string);parameterTuple.addItem("separator", p_separator);
			this.onEvent("tokenizeString", parameterTuple);
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_stringTokenized_pushed (PropertyChangeList changes  , OCLSequence p_tokens ){
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			parameterTuple.addItem("tokens", p_tokens);
			this.onEvent("stringTokenized", parameterTuple);
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges
			Enumeration LibraryPersistenceHandler_LibraryLoader_bookLineTokenized_edge0_enum = this.LibraryPersistenceHandler_LibraryLoader_bookLineTokenizer_back.elements();
			while (LibraryPersistenceHandler_LibraryLoader_bookLineTokenized_edge0_enum.hasMoreElements()) {
				LibraryPersistenceHandler_LibraryLoader LibraryPersistenceHandler_LibraryLoader_bookLineTokenized_edge0_target = (LibraryPersistenceHandler_LibraryLoader)LibraryPersistenceHandler_LibraryLoader_bookLineTokenized_edge0_enum.nextElement();
						LibraryPersistenceHandler_LibraryLoader_bookLineTokenized_edge0_target.event_bookLineTokenized_pulled_edge0(changes, this , p_tokens  );
			}


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 




	 


	 
	public void onEvent(String eventName, OCLTuple parameters) {
		if (eventName.equals("tokenizeString")) {
		
			OCLString separator = (OCLString)parameters.objectForKey("separator");
			OCLString string = (OCLString)parameters.objectForKey("string");
			
	        String sepAsRE = Pattern.quote(separator.string);
	        
	        String[] substrings = string.string.split(sepAsRE);
	        OCLSequence res = new OCLSequence();
	        for (String s : substrings) {
	            res.add(new OCLString(s));
	        }

	        this.event_stringTokenized_pushed(null, res);		
		}
	}

	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

