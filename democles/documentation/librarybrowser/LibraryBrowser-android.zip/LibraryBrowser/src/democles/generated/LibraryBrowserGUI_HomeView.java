 
	  
package democles.generated;

import java.util.Vector;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
import android.content.Context;
import android.view.View;

	 
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;
import java.util.Collection;

	 
public class LibraryBrowserGUI_HomeView implements IViewWrapper, OCLAny {
	 
	private LibraryBrowserGUI_Label _titleLabel;
	private boolean _titleLabel_isInitialized;
	private OCLString _viewTitle;
	private boolean _viewTitle_isInitialized;
	private OCLSequence _seqGUIElements;
	private boolean _seqGUIElements_isInitialized;

	public Vector<OCLAny> LibraryBrowserGUI_MainWindow_homeView_back = new Vector<OCLAny>();

	private Object context;

	  
	private LinearLayout layout;

	 
	private LibraryBrowserGUI_HomeView(Object context) {
		super();
		this.context = context;
		 
		this.set_titleLabel(this.initial_titleLabel()); 
		this.set_viewTitle(this.initial_viewTitle()); 
		this.set_seqGUIElements(this.initial_seqGUIElements()); 


	}
	
	static public LibraryBrowserGUI_HomeView newInstance(Object context) {
		if (context == null) throw new NullPointerException();
		return new LibraryBrowserGUI_HomeView(context);
	}
 
	 
	private LibraryBrowserGUI_HomeView(Object context, OCLTuple values) {
		super();
		this.context = context;
		 
		this._titleLabel_isInitialized = false; 
		this._viewTitle_isInitialized = false; 
		this._seqGUIElements_isInitialized = false; 

		if (values == null) values = new OCLTuple(); // Empty
		if (values.containsKey("titleLabel")) {
			this.set_titleLabel((LibraryBrowserGUI_Label)values.objectForKey("titleLabel"));
		} else {
			this.set_titleLabel(this.initial_titleLabel());
		}
		if (values.containsKey("viewTitle")) {
			this.set_viewTitle((OCLString)values.objectForKey("viewTitle"));
		} else {
			this.set_viewTitle(this.initial_viewTitle());
		}
		if (values.containsKey("seqGUIElements")) {
			this.set_seqGUIElements((OCLSequence)values.objectForKey("seqGUIElements"));
		} else {
			this.set_seqGUIElements(this.initial_seqGUIElements());
		}


	}

	static public LibraryBrowserGUI_HomeView newInstance(Object context, OCLTuple values) {
		if (context == null) throw new NullPointerException();
		return new LibraryBrowserGUI_HomeView(context, values);
	}

	 
	public LibraryBrowserGUI_Label initial_titleLabel() {
		/* ==================================================
	 * Label::create(Tuple { text = 'Welcome to the Library Browser' })
	 * ================================================== */
	
	OCLString v4 = new OCLString("Welcome to the Library Browser");
	OCLString v3 = v4;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("text", v3);
	LibraryBrowserGUI_Label v0 = LibraryBrowserGUI_Label.newInstance(this.context, v2);
	
		return v0;
	}

	public LibraryBrowserGUI_Label get_titleLabel(){
		if (this._titleLabel_isInitialized) {
			return _titleLabel;
		} else { 
			this.set_titleLabel(this.initial_titleLabel());
		}
		this._titleLabel_isInitialized = true;
		return this._titleLabel;
	}
	public OCLString initial_viewTitle() {
		/* ==================================================
	 * 'Home'
	 * ================================================== */
	
	OCLString v0 = new OCLString("Home");
	
		return v0;
	}

	public OCLString get_viewTitle(){
		if (this._viewTitle_isInitialized) {
			return _viewTitle;
		} else { 
			this.set_viewTitle(this.initial_viewTitle());
		}
		this._viewTitle_isInitialized = true;
		return this._viewTitle;
	}
	public OCLSequence initial_seqGUIElements() {
		/* ==================================================
	 * Sequence {titleLabel}
	 * ================================================== */
	
	LibraryBrowserGUI_HomeView v3 = this;
	LibraryBrowserGUI_Label v2 = v3.get_titleLabel();
	LibraryBrowserGUI_Label v1 = v2;
	OCLSequence v0 = new OCLSequence();
	v0.add(v1);
	
		return v0;
	}

	public OCLSequence get_seqGUIElements(){
		if (this._seqGUIElements_isInitialized) {
			return _seqGUIElements;
		} else { 
			this.set_seqGUIElements(this.initial_seqGUIElements());
		}
		this._seqGUIElements_isInitialized = true;
		return this._seqGUIElements;
	}


	 
	public void set_viewTitle(OCLString value) {
		 	
		this._viewTitle = value;
		this._viewTitle_isInitialized = true;

		this.onPropertyChange("viewTitle",value);
	}
	public void set_seqGUIElements(OCLSequence value) {
		 	
		this._seqGUIElements = value;
		this._seqGUIElements_isInitialized = true;

		this.onPropertyChange("seqGUIElements",value);
	}


	public void set_titleLabel(LibraryBrowserGUI_Label value) {
		 	
		if (this._titleLabel!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._titleLabel.LibraryBrowserGUI_HomeView_titleLabel_back;
			backpointers.removeElement(this);
		}
		this._titleLabel = value;
		if (this._titleLabel!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._titleLabel.LibraryBrowserGUI_HomeView_titleLabel_back;
			backpointers.addElement(this);
		}
		this._titleLabel_isInitialized = true;

		this.onPropertyChange("titleLabel",value);
	}




	 


	 


	 
	public void onPropertyChange(String propertyName, Object value) {
		if (propertyName.equals("seqGUIElements")) {
			if (value != null) {
				updateLayout();
			}
		}
	}

	 
	public void onEvent(String eventName, OCLTuple parameters){
	}

	  
	@Override
    public String getTitle() {
        return this.get_viewTitle().string;
    }

    @Override
    public View createView(Context context) {
        this.context = context;
        this.layout = new LinearLayout(context);
        this.layout.setOrientation(LinearLayout.VERTICAL);
        
        this.updateLayout();
        return this.layout;
    }
    
    private Collection<IWidgetWrapper> getWidgets() {
    	return (Collection)this.get_seqGUIElements().values;
    }
    
    private void updateLayout() {
    	if (this.layout == null) return;
        this.layout.removeAllViews();

        for (IWidgetWrapper wrapper : this.getWidgets()) {
            View widget = wrapper.createWidget((Context)this.context);
            this.layout.addView(widget, new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
        }
    }

	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

