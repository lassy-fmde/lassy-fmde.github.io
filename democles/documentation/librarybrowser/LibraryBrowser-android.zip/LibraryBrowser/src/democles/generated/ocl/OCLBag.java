package democles.generated.ocl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class OCLBag extends OCLCollection {

    public List<OCLAny> values = new ArrayList<OCLAny>();
    
    public void addAll(Collection<OCLAny> collection) {
        this.values.addAll(collection);
    }

    @Override
    public OCLCollection newCollection() {
        return new OCLBag();
    }

    @Override
    public void add(OCLAny object) {
        this.values.add(object);
    }

    @Override
    public OCLInteger size() {
        return new OCLInteger(this.values.size());
    }

    @Override
    public OCLBoolean includes(OCLAny object) {
        return new OCLBoolean(this.values.contains(object));
    }

    @Override
    public Iterable<OCLAny> objectIterable() {
        return this.values;
    }

    @Override
    public String collectionName() {
        return "Bag";
    }
    
    public OCLBag union(OCLSet other) {
        OCLBag res = new OCLBag();
        res.values.addAll(this.values);
        res.values.addAll(other.values);
        return res;
    }

    public OCLBag union(OCLBag other) {
        OCLBag res = new OCLBag();
        res.addAll(this.values);
        res.addAll(other.values);
        return res;
    }
    
    public OCLSet intersection(OCLSet set) {
        OCLSet res = new OCLSet();
        
        for (OCLAny o : this.values) {
            if (set.values.contains(o)) {
                res.values.add(o);
            }
        }
        
        return res;
    }

    public OCLBag intersection(OCLBag bag) {
        OCLBag res = new OCLBag();
        
        for (OCLAny o : this.values) {
            if (bag.values.contains(o)) {
                res.values.add(o);
            }
        }
        
        return res;
    }
    
    public OCLBag including(OCLAny object) {
        OCLBag res = new OCLBag();
        res.values.addAll(this.values);
        res.values.add(object);
        return res;
    }

    public OCLBag excluding(OCLAny object) {
        OCLBag res = new OCLBag();
        res.values.addAll(this.values);
        res.values.remove(object);
        return res;
    }
    
    public OCLBag flatten() {
        return (OCLBag)super.flatten();
    }
    

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((values == null) ? 0 : values.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        OCLBag other = (OCLBag)obj;
        if (values == null) {
            if (other.values != null)
                return false;
        } else if (!values.equals(other.values))
            return false;
        return true;
    }

    // OCLAny implementation, using delegation so that inheritance remains available. -----------------
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }
}
