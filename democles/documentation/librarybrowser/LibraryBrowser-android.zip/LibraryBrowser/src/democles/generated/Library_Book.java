 
	  
package democles.generated;

import java.util.Vector;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
public class Library_Book implements OCLAny {
	 
	private OCLString _author;
	private boolean _author_isInitialized;
	private OCLString _title;
	private boolean _title_isInitialized;
	private OCLString _isbn;
	private boolean _isbn_isInitialized;

	public Vector<OCLAny> Library_BookCollection_Books_back = new Vector<OCLAny>();

	private Object context;

	 
	private Library_Book(Object context) {
		super();
		this.context = context;
		 
		this.set_author(this.initial_author()); 
		this.set_title(this.initial_title()); 
		this.set_isbn(this.initial_isbn()); 


	}
	
	static public Library_Book newInstance(Object context) {
		if (context == null) throw new NullPointerException();
		return new Library_Book(context);
	}
 
	 
	private Library_Book(Object context, OCLTuple values) {
		super();
		this.context = context;
		 
		this._author_isInitialized = false; 
		this._title_isInitialized = false; 
		this._isbn_isInitialized = false; 

		if (values == null) values = new OCLTuple(); // Empty
		if (values.containsKey("author")) {
			this.set_author((OCLString)values.objectForKey("author"));
		} else {
			this.set_author(this.initial_author());
		}
		if (values.containsKey("title")) {
			this.set_title((OCLString)values.objectForKey("title"));
		} else {
			this.set_title(this.initial_title());
		}
		if (values.containsKey("isbn")) {
			this.set_isbn((OCLString)values.objectForKey("isbn"));
		} else {
			this.set_isbn(this.initial_isbn());
		}


	}

	static public Library_Book newInstance(Object context, OCLTuple values) {
		if (context == null) throw new NullPointerException();
		return new Library_Book(context, values);
	}

	 
	public OCLString initial_author() {
		/* ==================================================
	 * null
	 * ================================================== */
	
	OCLString v0 = null;
	
		return v0;
	}

	public OCLString get_author(){
		if (this._author_isInitialized) {
			return _author;
		} else { 
			this.set_author(this.initial_author());
		}
		this._author_isInitialized = true;
		return this._author;
	}
	public OCLString initial_title() {
		/* ==================================================
	 * null
	 * ================================================== */
	
	OCLString v0 = null;
	
		return v0;
	}

	public OCLString get_title(){
		if (this._title_isInitialized) {
			return _title;
		} else { 
			this.set_title(this.initial_title());
		}
		this._title_isInitialized = true;
		return this._title;
	}
	public OCLString initial_isbn() {
		/* ==================================================
	 * null
	 * ================================================== */
	
	OCLString v0 = null;
	
		return v0;
	}

	public OCLString get_isbn(){
		if (this._isbn_isInitialized) {
			return _isbn;
		} else { 
			this.set_isbn(this.initial_isbn());
		}
		this._isbn_isInitialized = true;
		return this._isbn;
	}


	 
	public void set_author(OCLString value) {
	 	
		this._author = value;
		this._author_isInitialized = true;

	}
	public void set_title(OCLString value) {
	 	
		this._title = value;
		this._title_isInitialized = true;

	}
	public void set_isbn(OCLString value) {
	 	
		this._isbn = value;
		this._isbn_isInitialized = true;

	}






	 


	 


	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

