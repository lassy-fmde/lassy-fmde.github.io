 
	  
package democles.generated;

import java.util.Vector;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
import android.content.Context;
import android.view.View;

	 
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;
import java.util.Collection;

	 
public class LibraryBrowserGUI_BookDetailView extends Activity implements OCLAny {
	 
	private LibraryBrowserGUI_Label _titleLabel;
	private boolean _titleLabel_isInitialized;
	private LibraryBrowserGUI_Label _bookTitleLabel;
	private boolean _bookTitleLabel_isInitialized;
	private LibraryBrowserGUI_Label _authorLabel;
	private boolean _authorLabel_isInitialized;
	private LibraryBrowserGUI_Label _bookAuthorLabel;
	private boolean _bookAuthorLabel_isInitialized;
	private LibraryBrowserGUI_Label _isbnLabel;
	private boolean _isbnLabel_isInitialized;
	private LibraryBrowserGUI_Label _bookIsbnLabel;
	private boolean _bookIsbnLabel_isInitialized;
	private OCLString _viewTitle;
	private boolean _viewTitle_isInitialized;
	private OCLSequence _seqGUIElements;
	private boolean _seqGUIElements_isInitialized;

	public Vector<OCLAny> LibraryBrowserGUI_BookListView_bookDetailView_back = new Vector<OCLAny>();

	private Object context;

	  
	private LinearLayout layout;
	 
	final static private String INIT_PROP_VALUES_KEY = "initialPropertyValues";
	final static private String HOLDER_KEY = "instanceHolder";
    
    static class Holder {
        public LibraryBrowserGUI_BookDetailView instance = null;
    }

	 
    public LibraryBrowserGUI_BookDetailView() {
        super();
        this.context = this;
    }

	 
    public static LibraryBrowserGUI_BookDetailView newInstance(Object contextObject) {
		if (contextObject == null) throw new NullPointerException();
    	return newInstance(contextObject, null);
    }
    
    public static LibraryBrowserGUI_BookDetailView newInstance(Object contextObject, OCLTuple initialPropertyValues) {
		if (contextObject == null) throw new NullPointerException();

    	Context context = (Context)contextObject;
        Thread currentThread = Thread.currentThread();
        Thread mainThread = context.getMainLooper().getThread();
        
        if (currentThread == mainThread) {
            throw new RuntimeException("LibraryBrowserGUI_BookDetailView can not be instantiated from the UI thread.");
        }
        
        final Intent intent = new Intent(context, LibraryBrowserGUI_BookDetailView.class);
        if (initialPropertyValues != null) {
            Long initDataKey = InitializationDataHolder.putData(initialPropertyValues);
            intent.putExtra(INIT_PROP_VALUES_KEY, initDataKey);
        }
        
        Holder holder = new Holder();
        Long holderKey = InitializationDataHolder.putData(holder);
        intent.putExtra(HOLDER_KEY, holderKey);

        final Context contextClosure = context;
        new Thread() {
            public void run() {
                contextClosure.startActivity(intent);
            };
        }.start();
        
        synchronized(holder) {
            try {
                holder.wait();
            } catch (InterruptedException e) {
            }
        }
        return holder.instance;
    }
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        OCLTuple values = null;
        
        Bundle extras = this.getIntent().getExtras();
        if (extras != null) {
            Long initDataKey = extras.getLong(INIT_PROP_VALUES_KEY);
            if (initDataKey != null) {
                values = (OCLTuple)InitializationDataHolder.retrieveData(initDataKey);
            }
            
            Long holderKey = extras.getLong(HOLDER_KEY);
            Holder holder = (Holder)InitializationDataHolder.retrieveData(holderKey);
            holder.instance = this;
            
            synchronized(holder) {
                holder.notify();
            }
        }
        
		 
		this._titleLabel_isInitialized = false; 
		this._bookTitleLabel_isInitialized = false; 
		this._authorLabel_isInitialized = false; 
		this._bookAuthorLabel_isInitialized = false; 
		this._isbnLabel_isInitialized = false; 
		this._bookIsbnLabel_isInitialized = false; 
		this._viewTitle_isInitialized = false; 
		this._seqGUIElements_isInitialized = false; 

		if (values == null) values = new OCLTuple(); // Empty
		if (values.containsKey("titleLabel")) {
			this.set_titleLabel((LibraryBrowserGUI_Label)values.objectForKey("titleLabel"));
		} else {
			this.set_titleLabel(this.initial_titleLabel());
		}
		if (values.containsKey("bookTitleLabel")) {
			this.set_bookTitleLabel((LibraryBrowserGUI_Label)values.objectForKey("bookTitleLabel"));
		} else {
			this.set_bookTitleLabel(this.initial_bookTitleLabel());
		}
		if (values.containsKey("authorLabel")) {
			this.set_authorLabel((LibraryBrowserGUI_Label)values.objectForKey("authorLabel"));
		} else {
			this.set_authorLabel(this.initial_authorLabel());
		}
		if (values.containsKey("bookAuthorLabel")) {
			this.set_bookAuthorLabel((LibraryBrowserGUI_Label)values.objectForKey("bookAuthorLabel"));
		} else {
			this.set_bookAuthorLabel(this.initial_bookAuthorLabel());
		}
		if (values.containsKey("isbnLabel")) {
			this.set_isbnLabel((LibraryBrowserGUI_Label)values.objectForKey("isbnLabel"));
		} else {
			this.set_isbnLabel(this.initial_isbnLabel());
		}
		if (values.containsKey("bookIsbnLabel")) {
			this.set_bookIsbnLabel((LibraryBrowserGUI_Label)values.objectForKey("bookIsbnLabel"));
		} else {
			this.set_bookIsbnLabel(this.initial_bookIsbnLabel());
		}
		if (values.containsKey("viewTitle")) {
			this.set_viewTitle((OCLString)values.objectForKey("viewTitle"));
		} else {
			this.set_viewTitle(this.initial_viewTitle());
		}
		if (values.containsKey("seqGUIElements")) {
			this.set_seqGUIElements((OCLSequence)values.objectForKey("seqGUIElements"));
		} else {
			this.set_seqGUIElements(this.initial_seqGUIElements());
		}


        
        this.updateLayout();
    }

	 
	public LibraryBrowserGUI_Label initial_titleLabel() {
		/* ==================================================
	 * Label::create(Tuple { text = 'Title: ' })
	 * ================================================== */
	
	OCLString v4 = new OCLString("Title: ");
	OCLString v3 = v4;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("text", v3);
	LibraryBrowserGUI_Label v0 = LibraryBrowserGUI_Label.newInstance(this.context, v2);
	
		return v0;
	}

	public LibraryBrowserGUI_Label get_titleLabel(){
		if (this._titleLabel_isInitialized) {
			return _titleLabel;
		} else { 
			this.set_titleLabel(this.initial_titleLabel());
		}
		this._titleLabel_isInitialized = true;
		return this._titleLabel;
	}
	public LibraryBrowserGUI_Label initial_bookTitleLabel() {
		/* ==================================================
	 * null
	 * ================================================== */
	
	LibraryBrowserGUI_Label v0 = null;
	
		return v0;
	}

	public LibraryBrowserGUI_Label get_bookTitleLabel(){
		if (this._bookTitleLabel_isInitialized) {
			return _bookTitleLabel;
		} else { 
			this.set_bookTitleLabel(this.initial_bookTitleLabel());
		}
		this._bookTitleLabel_isInitialized = true;
		return this._bookTitleLabel;
	}
	public LibraryBrowserGUI_Label initial_authorLabel() {
		/* ==================================================
	 * Label::create(Tuple { text = 'Author: ' })
	 * ================================================== */
	
	OCLString v4 = new OCLString("Author: ");
	OCLString v3 = v4;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("text", v3);
	LibraryBrowserGUI_Label v0 = LibraryBrowserGUI_Label.newInstance(this.context, v2);
	
		return v0;
	}

	public LibraryBrowserGUI_Label get_authorLabel(){
		if (this._authorLabel_isInitialized) {
			return _authorLabel;
		} else { 
			this.set_authorLabel(this.initial_authorLabel());
		}
		this._authorLabel_isInitialized = true;
		return this._authorLabel;
	}
	public LibraryBrowserGUI_Label initial_bookAuthorLabel() {
		/* ==================================================
	 * null
	 * ================================================== */
	
	LibraryBrowserGUI_Label v0 = null;
	
		return v0;
	}

	public LibraryBrowserGUI_Label get_bookAuthorLabel(){
		if (this._bookAuthorLabel_isInitialized) {
			return _bookAuthorLabel;
		} else { 
			this.set_bookAuthorLabel(this.initial_bookAuthorLabel());
		}
		this._bookAuthorLabel_isInitialized = true;
		return this._bookAuthorLabel;
	}
	public LibraryBrowserGUI_Label initial_isbnLabel() {
		/* ==================================================
	 * Label::create(Tuple { text = 'ISBN: ' })
	 * ================================================== */
	
	OCLString v4 = new OCLString("ISBN: ");
	OCLString v3 = v4;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("text", v3);
	LibraryBrowserGUI_Label v0 = LibraryBrowserGUI_Label.newInstance(this.context, v2);
	
		return v0;
	}

	public LibraryBrowserGUI_Label get_isbnLabel(){
		if (this._isbnLabel_isInitialized) {
			return _isbnLabel;
		} else { 
			this.set_isbnLabel(this.initial_isbnLabel());
		}
		this._isbnLabel_isInitialized = true;
		return this._isbnLabel;
	}
	public LibraryBrowserGUI_Label initial_bookIsbnLabel() {
		/* ==================================================
	 * null
	 * ================================================== */
	
	LibraryBrowserGUI_Label v0 = null;
	
		return v0;
	}

	public LibraryBrowserGUI_Label get_bookIsbnLabel(){
		if (this._bookIsbnLabel_isInitialized) {
			return _bookIsbnLabel;
		} else { 
			this.set_bookIsbnLabel(this.initial_bookIsbnLabel());
		}
		this._bookIsbnLabel_isInitialized = true;
		return this._bookIsbnLabel;
	}
	public OCLString initial_viewTitle() {
		/* ==================================================
	 * 'Book Detail'
	 * ================================================== */
	
	OCLString v0 = new OCLString("Book Detail");
	
		return v0;
	}

	public OCLString get_viewTitle(){
		if (this._viewTitle_isInitialized) {
			return _viewTitle;
		} else { 
			this.set_viewTitle(this.initial_viewTitle());
		}
		this._viewTitle_isInitialized = true;
		return this._viewTitle;
	}
	public OCLSequence initial_seqGUIElements() {
		/* ==================================================
	 * Sequence { titleLabel, bookTitleLabel, authorLabel, bookAuthorLabel, isbnLabel, bookIsbnLabel }
	 * ================================================== */
	
	LibraryBrowserGUI_BookDetailView v3 = this;
	LibraryBrowserGUI_Label v2 = v3.get_titleLabel();
	LibraryBrowserGUI_Label v1 = v2;
	LibraryBrowserGUI_BookDetailView v6 = this;
	LibraryBrowserGUI_Label v5 = v6.get_bookTitleLabel();
	LibraryBrowserGUI_Label v4 = v5;
	LibraryBrowserGUI_BookDetailView v9 = this;
	LibraryBrowserGUI_Label v8 = v9.get_authorLabel();
	LibraryBrowserGUI_Label v7 = v8;
	LibraryBrowserGUI_BookDetailView v12 = this;
	LibraryBrowserGUI_Label v11 = v12.get_bookAuthorLabel();
	LibraryBrowserGUI_Label v10 = v11;
	LibraryBrowserGUI_BookDetailView v15 = this;
	LibraryBrowserGUI_Label v14 = v15.get_isbnLabel();
	LibraryBrowserGUI_Label v13 = v14;
	LibraryBrowserGUI_BookDetailView v18 = this;
	LibraryBrowserGUI_Label v17 = v18.get_bookIsbnLabel();
	LibraryBrowserGUI_Label v16 = v17;
	OCLSequence v0 = new OCLSequence();
	v0.add(v1);
	v0.add(v4);
	v0.add(v7);
	v0.add(v10);
	v0.add(v13);
	v0.add(v16);
	
		return v0;
	}

	public OCLSequence get_seqGUIElements(){
		if (this._seqGUIElements_isInitialized) {
			return _seqGUIElements;
		} else { 
			this.set_seqGUIElements(this.initial_seqGUIElements());
		}
		this._seqGUIElements_isInitialized = true;
		return this._seqGUIElements;
	}


	 
	public void set_viewTitle(OCLString value) {
		 	
		this._viewTitle = value;
		this._viewTitle_isInitialized = true;

		this.onPropertyChange("viewTitle",value);
	}
	public void set_seqGUIElements(OCLSequence value) {
		 	
		this._seqGUIElements = value;
		this._seqGUIElements_isInitialized = true;

		this.onPropertyChange("seqGUIElements",value);
	}


	public void set_titleLabel(LibraryBrowserGUI_Label value) {
		 	
		if (this._titleLabel!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._titleLabel.LibraryBrowserGUI_BookDetailView_titleLabel_back;
			backpointers.removeElement(this);
		}
		this._titleLabel = value;
		if (this._titleLabel!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._titleLabel.LibraryBrowserGUI_BookDetailView_titleLabel_back;
			backpointers.addElement(this);
		}
		this._titleLabel_isInitialized = true;

		this.onPropertyChange("titleLabel",value);
	}
	public void set_bookTitleLabel(LibraryBrowserGUI_Label value) {
		 	
		if (this._bookTitleLabel!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._bookTitleLabel.LibraryBrowserGUI_BookDetailView_bookTitleLabel_back;
			backpointers.removeElement(this);
		}
		this._bookTitleLabel = value;
		if (this._bookTitleLabel!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._bookTitleLabel.LibraryBrowserGUI_BookDetailView_bookTitleLabel_back;
			backpointers.addElement(this);
		}
		this._bookTitleLabel_isInitialized = true;

		this.onPropertyChange("bookTitleLabel",value);
	}
	public void set_authorLabel(LibraryBrowserGUI_Label value) {
		 	
		if (this._authorLabel!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._authorLabel.LibraryBrowserGUI_BookDetailView_authorLabel_back;
			backpointers.removeElement(this);
		}
		this._authorLabel = value;
		if (this._authorLabel!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._authorLabel.LibraryBrowserGUI_BookDetailView_authorLabel_back;
			backpointers.addElement(this);
		}
		this._authorLabel_isInitialized = true;

		this.onPropertyChange("authorLabel",value);
	}
	public void set_bookAuthorLabel(LibraryBrowserGUI_Label value) {
		 	
		if (this._bookAuthorLabel!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._bookAuthorLabel.LibraryBrowserGUI_BookDetailView_bookAuthorLabel_back;
			backpointers.removeElement(this);
		}
		this._bookAuthorLabel = value;
		if (this._bookAuthorLabel!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._bookAuthorLabel.LibraryBrowserGUI_BookDetailView_bookAuthorLabel_back;
			backpointers.addElement(this);
		}
		this._bookAuthorLabel_isInitialized = true;

		this.onPropertyChange("bookAuthorLabel",value);
	}
	public void set_isbnLabel(LibraryBrowserGUI_Label value) {
		 	
		if (this._isbnLabel!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._isbnLabel.LibraryBrowserGUI_BookDetailView_isbnLabel_back;
			backpointers.removeElement(this);
		}
		this._isbnLabel = value;
		if (this._isbnLabel!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._isbnLabel.LibraryBrowserGUI_BookDetailView_isbnLabel_back;
			backpointers.addElement(this);
		}
		this._isbnLabel_isInitialized = true;

		this.onPropertyChange("isbnLabel",value);
	}
	public void set_bookIsbnLabel(LibraryBrowserGUI_Label value) {
		 	
		if (this._bookIsbnLabel!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._bookIsbnLabel.LibraryBrowserGUI_BookDetailView_bookIsbnLabel_back;
			backpointers.removeElement(this);
		}
		this._bookIsbnLabel = value;
		if (this._bookIsbnLabel!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._bookIsbnLabel.LibraryBrowserGUI_BookDetailView_bookIsbnLabel_back;
			backpointers.addElement(this);
		}
		this._bookIsbnLabel_isInitialized = true;

		this.onPropertyChange("bookIsbnLabel",value);
	}




	 


	 


	 
	public void onPropertyChange(String propertyName, Object value) {
		if (propertyName.equals("seqGUIElements")) {
			if (value != null) {
				updateLayout();
			}
		}
	}

	 
	public void onEvent(String eventName, OCLTuple parameters) {
	}

	  
    private Collection<IWidgetWrapper> getWidgets() {
        return (Collection)this.get_seqGUIElements().values;
    }
    
    private void updateLayout() {
        this.layout = new LinearLayout(this);
        this.layout.setOrientation(LinearLayout.VERTICAL);
        
        this.setContentView(this.layout);
        
        for (IWidgetWrapper wrapper : this.getWidgets()) {
            View widget = wrapper.createWidget(this);

            this.layout.addView(widget, new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
        }
    }

	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

