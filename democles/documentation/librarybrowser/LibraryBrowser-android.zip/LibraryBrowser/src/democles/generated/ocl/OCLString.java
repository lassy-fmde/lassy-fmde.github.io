package democles.generated.ocl;

public class OCLString implements OCLAny {
    
    public String string;
    
    public OCLString(String string) {
        this.string = string;
    }
        
    public OCLInteger size() {
        return new OCLInteger(this.string.length());
    }
    
    public OCLString concat(OCLString other) {
        return new OCLString(this.string + other.string);
    }
    
    public OCLString substring(OCLInteger lower, OCLInteger upper) {
        return new OCLString(this.string.substring(lower.value - 1, upper.value - 1));
    }
    
    public OCLInteger toInteger() {
        return new OCLInteger(Integer.parseInt(this.string));
    }
    
    public OCLReal toReal() {
        return new OCLReal(Float.parseFloat(this.string));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((string == null) ? 0 : string.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        OCLString other = (OCLString)obj;
        if (string == null) {
            if (other.string != null)
                return false;
        } else if (!string.equals(other.string))
            return false;
        return true;
    }

    // OCLAny implementation, using delegation so that inheritance remains available. -----------------
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }
}
