 
	  
package democles.generated;

import java.util.Vector;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
import android.content.Context;
import android.view.View;

	 
public class LibraryBrowserGUI_Button implements IWidgetWrapper, OCLAny {
	 
	private OCLString _text;
	private boolean _text_isInitialized;

	public Vector<OCLAny> LibraryBrowserGUI_SearchView_searchButton_back = new Vector<OCLAny>();

	private Object context;

	  
	private android.widget.Button button;

	 
	private LibraryBrowserGUI_Button(Object context) {
		super();
		this.context = context;
		 
		this.set_text(this.initial_text()); 


	}
	
	static public LibraryBrowserGUI_Button newInstance(Object context) {
		if (context == null) throw new NullPointerException();
		return new LibraryBrowserGUI_Button(context);
	}
 
	 
	private LibraryBrowserGUI_Button(Object context, OCLTuple values) {
		super();
		this.context = context;
		 
		this._text_isInitialized = false; 

		if (values == null) values = new OCLTuple(); // Empty
		if (values.containsKey("text")) {
			this.set_text((OCLString)values.objectForKey("text"));
		} else {
			this.set_text(this.initial_text());
		}


	}

	static public LibraryBrowserGUI_Button newInstance(Object context, OCLTuple values) {
		if (context == null) throw new NullPointerException();
		return new LibraryBrowserGUI_Button(context, values);
	}

	 
	public OCLString initial_text() {
		/* ==================================================
	 * ''
	 * ================================================== */
	
	OCLString v0 = new OCLString("");
	
		return v0;
	}

	public OCLString get_text(){
		if (this._text_isInitialized) {
			return _text;
		} else { 
			this.set_text(this.initial_text());
		}
		this._text_isInitialized = true;
		return this._text;
	}


	 
	public void set_text(OCLString value) {
		 	
		this._text = value;
		this._text_isInitialized = true;

		this.onPropertyChange("text",value);
	}






	 
 	public void event_clicked_pushed (PropertyChangeList changes   ){
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			
			this.onEvent("clicked", parameterTuple);
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges
			Enumeration LibraryBrowserGUI_SearchView_searchButtonClicked_edge0_enum = this.LibraryBrowserGUI_SearchView_searchButton_back.elements();
			while (LibraryBrowserGUI_SearchView_searchButtonClicked_edge0_enum.hasMoreElements()) {
				LibraryBrowserGUI_SearchView LibraryBrowserGUI_SearchView_searchButtonClicked_edge0_target = (LibraryBrowserGUI_SearchView)LibraryBrowserGUI_SearchView_searchButtonClicked_edge0_enum.nextElement();
						LibraryBrowserGUI_SearchView_searchButtonClicked_edge0_target.event_searchButtonClicked_pulled_edge0(changes, this  );
			}


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 




	 


	 
	public void onPropertyChange(String propertyName, Object value) {
		if (propertyName.equals("text")) {
			if (value != null) {
				updateButton();
			}
		}
	}

	 
	public void onEvent(String eventName, OCLTuple parameters) {
	}

	  
	@Override
    public View createWidget(final Context context) {
        this.button = new android.widget.Button(context);
        this.updateButton();
        
        this.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread() { @Override public void run() {
	                event_clicked_pushed(null);
                }}.start();
            }
        });
        return this.button;
    }
    
    private void updateButton() {
    	if (this.button == null) return;
        this.button.setText(this.get_text().string);
    }

	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

