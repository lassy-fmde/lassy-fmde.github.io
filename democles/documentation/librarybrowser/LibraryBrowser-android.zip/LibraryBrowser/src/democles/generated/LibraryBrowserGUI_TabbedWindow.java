 
	  
package democles.generated;

import java.util.Vector;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
import android.content.Context;
import android.view.View;

	 
import android.app.ActivityGroup;
import android.content.Intent;
import android.os.Bundle;
import android.view.ViewGroup.LayoutParams;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;
import android.widget.TabWidget;
import android.widget.LinearLayout;
import android.widget.FrameLayout;
import java.util.Collection;

	 
public class LibraryBrowserGUI_TabbedWindow extends ActivityGroup implements OCLAny {
	 
	private OCLSequence _views;
	private boolean _views_isInitialized;

	public Vector<OCLAny> LibraryBrowserGUI_MainWindow_viewSelector_back = new Vector<OCLAny>();

	private Object context;

	  
    private TabHost tabHost;
	 
	final static private String INIT_PROP_VALUES_KEY = "initialPropertyValues";
	final static private String HOLDER_KEY = "instanceHolder";
    
    static class Holder {
        public LibraryBrowserGUI_TabbedWindow instance = null;
    }

	 
    public LibraryBrowserGUI_TabbedWindow() {
        super();
        this.context = this;
    }

	 
    public static LibraryBrowserGUI_TabbedWindow newInstance(Object contextObject) {
		if (contextObject == null) throw new NullPointerException();
    	return newInstance(contextObject, null);
    }
    
    public static LibraryBrowserGUI_TabbedWindow newInstance(Object contextObject, OCLTuple initialPropertyValues) {
		if (contextObject == null) throw new NullPointerException();
    	Context context = (Context)contextObject;
        Thread currentThread = Thread.currentThread();
        Thread mainThread = context.getMainLooper().getThread();
        
        if (currentThread == mainThread) {
            throw new RuntimeException("LibraryBrowserGUI_TabbedWindow can not be instantiated from the UI thread.");
        }
        
        final Intent intent = new Intent(context, LibraryBrowserGUI_TabbedWindow.class);
        if (initialPropertyValues != null) {
            Long initDataKey = InitializationDataHolder.putData(initialPropertyValues);
            intent.putExtra(INIT_PROP_VALUES_KEY, initDataKey);
        }
        
        Holder holder = new Holder();
        Long holderKey = InitializationDataHolder.putData(holder);
        intent.putExtra(HOLDER_KEY, holderKey);

        final Context contextClosure = context;
        new Thread() {
            public void run() {
                contextClosure.startActivity(intent);
            };
        }.start();
        
        synchronized(holder) {
            try {
                holder.wait();
            } catch (InterruptedException e) {
            }
        }
        return holder.instance;
    }
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        OCLTuple values = null;
        
        Bundle extras = this.getIntent().getExtras();
        if (extras != null) {
            Long initDataKey = extras.getLong(INIT_PROP_VALUES_KEY);
            if (initDataKey != null) {
                values = (OCLTuple)InitializationDataHolder.retrieveData(initDataKey);
            }
            
            Long holderKey = extras.getLong(HOLDER_KEY);
            Holder holder = (Holder)InitializationDataHolder.retrieveData(holderKey);
            holder.instance = this;
            
            synchronized(holder) {
                holder.notify();
            }
        }
        
		 
		this._views_isInitialized = false; 

		if (values == null) values = new OCLTuple(); // Empty
		if (values.containsKey("views")) {
			this.set_views((OCLSequence)values.objectForKey("views"));
		} else {
			this.set_views(this.initial_views());
		}


        
        this.updateTabs();
    }

	 
	public OCLSequence initial_views() {
		/* ==================================================
	 * Sequence {}
	 * ================================================== */
	
	OCLSequence v0 = new OCLSequence();
	
		return v0;
	}

	public OCLSequence get_views(){
		if (this._views_isInitialized) {
			return _views;
		} else { 
			this.set_views(this.initial_views());
		}
		this._views_isInitialized = true;
		return this._views;
	}


	 
	public void set_views(OCLSequence value) {
		 	
		this._views = value;
		this._views_isInitialized = true;

		this.onPropertyChange("views",value);
	}






	 


	 


	 
	public void onPropertyChange(String propertyName, Object value) {
		if (propertyName.equals("views")) {
			if (value != null) {
				updateTabs();
			}
		}
	}

	 
	public void onEvent(String eventName, OCLTuple parameters) {
	}

	  
    private TabHost createTabHost() {
        // construct the TAB Host
        TabHost tabHost = new TabHost(this);
        tabHost.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT));
 
        // the tabhost needs a tabwidget, that is a container for the visible tabs
        TabWidget tabWidget = new TabWidget(this);
        tabWidget.setId(android.R.id.tabs);
        tabHost.addView(tabWidget, new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT)); 
 
        // the tabhost needs a frame layout for the views associated with each visible tab
        FrameLayout frameLayout = new FrameLayout(this);
        frameLayout.setId(android.R.id.tabcontent);
        frameLayout.setPadding(0, 65, 0, 0);
        tabHost.addView(frameLayout, new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT)); 
 
        // setup must be called if you are not initialising the tabhost from XML
        tabHost.setup(this.getLocalActivityManager());
 
        return tabHost;
    }

    private Collection<IViewWrapper> getViews() {
        return (Collection)this.get_views().values;
    }

    // This must happen on change of "views" property, and in onCreate
    private void updateTabs() {
        
        this.tabHost = this.createTabHost();
        
        this.setContentView(this.tabHost);
        
        int i = 0;
        for (final IViewWrapper view : this.getViews()) {
            TabSpec ts = this.tabHost.newTabSpec("TAB_TAG_" + i++);

            String tabLabel = view.getTitle();
            ts.setIndicator(tabLabel);

            ts.setContent(new TabHost.TabContentFactory() {
                @Override
                public View createTabContent(String tag) {
                    return view.createView(LibraryBrowserGUI_TabbedWindow.this);
                }
            });

            this.tabHost.addTab(ts);
        }
    }

	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

