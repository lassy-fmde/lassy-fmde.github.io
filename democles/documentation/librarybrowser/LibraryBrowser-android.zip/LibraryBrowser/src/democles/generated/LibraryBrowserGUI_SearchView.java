 
	  
package democles.generated;

import java.util.Vector;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
import android.content.Context;
import android.view.View;

	 
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;
import java.util.Collection;

	 
public class LibraryBrowserGUI_SearchView implements IViewWrapper, OCLAny {
	 
	private LibraryBrowserGUI_Label _searchLabel;
	private boolean _searchLabel_isInitialized;
	private LibraryBrowserGUI_Textfield _searchField;
	private boolean _searchField_isInitialized;
	private LibraryBrowserGUI_SelectionBox _categorySelect;
	private boolean _categorySelect_isInitialized;
	private LibraryBrowserGUI_Button _searchButton;
	private boolean _searchButton_isInitialized;
	private LibraryBrowserGUI_BookListView _resultView;
	private boolean _resultView_isInitialized;
	private OCLString _viewTitle;
	private boolean _viewTitle_isInitialized;
	private OCLSequence _seqGUIElements;
	private boolean _seqGUIElements_isInitialized;

	public Vector<OCLAny> LibraryBrowserGUI_MainWindow_searchView_back = new Vector<OCLAny>();

	private Object context;

	  
	private LinearLayout layout;

	 
	private LibraryBrowserGUI_SearchView(Object context) {
		super();
		this.context = context;
		 
		this.set_searchLabel(this.initial_searchLabel()); 
		this.set_searchField(this.initial_searchField()); 
		this.set_categorySelect(this.initial_categorySelect()); 
		this.set_searchButton(this.initial_searchButton()); 
		this.set_resultView(this.initial_resultView()); 
		this.set_viewTitle(this.initial_viewTitle()); 
		this.set_seqGUIElements(this.initial_seqGUIElements()); 


	}
	
	static public LibraryBrowserGUI_SearchView newInstance(Object context) {
		if (context == null) throw new NullPointerException();
		return new LibraryBrowserGUI_SearchView(context);
	}
 
	 
	private LibraryBrowserGUI_SearchView(Object context, OCLTuple values) {
		super();
		this.context = context;
		 
		this._searchLabel_isInitialized = false; 
		this._searchField_isInitialized = false; 
		this._categorySelect_isInitialized = false; 
		this._searchButton_isInitialized = false; 
		this._resultView_isInitialized = false; 
		this._viewTitle_isInitialized = false; 
		this._seqGUIElements_isInitialized = false; 

		if (values == null) values = new OCLTuple(); // Empty
		if (values.containsKey("searchLabel")) {
			this.set_searchLabel((LibraryBrowserGUI_Label)values.objectForKey("searchLabel"));
		} else {
			this.set_searchLabel(this.initial_searchLabel());
		}
		if (values.containsKey("searchField")) {
			this.set_searchField((LibraryBrowserGUI_Textfield)values.objectForKey("searchField"));
		} else {
			this.set_searchField(this.initial_searchField());
		}
		if (values.containsKey("categorySelect")) {
			this.set_categorySelect((LibraryBrowserGUI_SelectionBox)values.objectForKey("categorySelect"));
		} else {
			this.set_categorySelect(this.initial_categorySelect());
		}
		if (values.containsKey("searchButton")) {
			this.set_searchButton((LibraryBrowserGUI_Button)values.objectForKey("searchButton"));
		} else {
			this.set_searchButton(this.initial_searchButton());
		}
		if (values.containsKey("resultView")) {
			this.set_resultView((LibraryBrowserGUI_BookListView)values.objectForKey("resultView"));
		} else {
			this.set_resultView(this.initial_resultView());
		}
		if (values.containsKey("viewTitle")) {
			this.set_viewTitle((OCLString)values.objectForKey("viewTitle"));
		} else {
			this.set_viewTitle(this.initial_viewTitle());
		}
		if (values.containsKey("seqGUIElements")) {
			this.set_seqGUIElements((OCLSequence)values.objectForKey("seqGUIElements"));
		} else {
			this.set_seqGUIElements(this.initial_seqGUIElements());
		}


	}

	static public LibraryBrowserGUI_SearchView newInstance(Object context, OCLTuple values) {
		if (context == null) throw new NullPointerException();
		return new LibraryBrowserGUI_SearchView(context, values);
	}

	 
	public LibraryBrowserGUI_Label initial_searchLabel() {
		/* ==================================================
	 * Label::create()
	 * ================================================== */
	
	LibraryBrowserGUI_Label v0 = LibraryBrowserGUI_Label.newInstance(this.context);
	
		return v0;
	}

	public LibraryBrowserGUI_Label get_searchLabel(){
		if (this._searchLabel_isInitialized) {
			return _searchLabel;
		} else { 
			this.set_searchLabel(this.initial_searchLabel());
		}
		this._searchLabel_isInitialized = true;
		return this._searchLabel;
	}
	public LibraryBrowserGUI_Textfield initial_searchField() {
		/* ==================================================
	 * Textfield::create()
	 * ================================================== */
	
	LibraryBrowserGUI_Textfield v0 = LibraryBrowserGUI_Textfield.newInstance(this.context);
	
		return v0;
	}

	public LibraryBrowserGUI_Textfield get_searchField(){
		if (this._searchField_isInitialized) {
			return _searchField;
		} else { 
			this.set_searchField(this.initial_searchField());
		}
		this._searchField_isInitialized = true;
		return this._searchField;
	}
	public LibraryBrowserGUI_SelectionBox initial_categorySelect() {
		/* ==================================================
	 * SelectionBox::create(Tuple { choices = Sequence { 'Author', 'Title', 'ISBN' }})
	 * ================================================== */
	
	OCLString v6 = new OCLString("Author");
	OCLString v5 = v6;
	OCLString v8 = new OCLString("Title");
	OCLString v7 = v8;
	OCLString v10 = new OCLString("ISBN");
	OCLString v9 = v10;
	OCLSequence v4 = new OCLSequence();
	v4.add(v5);
	v4.add(v7);
	v4.add(v9);
	OCLSequence v3 = v4;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("choices", v3);
	LibraryBrowserGUI_SelectionBox v0 = LibraryBrowserGUI_SelectionBox.newInstance(this.context, v2);
	
		return v0;
	}

	public LibraryBrowserGUI_SelectionBox get_categorySelect(){
		if (this._categorySelect_isInitialized) {
			return _categorySelect;
		} else { 
			this.set_categorySelect(this.initial_categorySelect());
		}
		this._categorySelect_isInitialized = true;
		return this._categorySelect;
	}
	public LibraryBrowserGUI_Button initial_searchButton() {
		/* ==================================================
	 * Button::create(Tuple { text = 'Search' })
	 * ================================================== */
	
	OCLString v4 = new OCLString("Search");
	OCLString v3 = v4;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("text", v3);
	LibraryBrowserGUI_Button v0 = LibraryBrowserGUI_Button.newInstance(this.context, v2);
	
		return v0;
	}

	public LibraryBrowserGUI_Button get_searchButton(){
		if (this._searchButton_isInitialized) {
			return _searchButton;
		} else { 
			this.set_searchButton(this.initial_searchButton());
		}
		this._searchButton_isInitialized = true;
		return this._searchButton;
	}
	public LibraryBrowserGUI_BookListView initial_resultView() {
		/* ==================================================
	 * null
	 * ================================================== */
	
	LibraryBrowserGUI_BookListView v0 = null;
	
		return v0;
	}

	public LibraryBrowserGUI_BookListView get_resultView(){
		if (this._resultView_isInitialized) {
			return _resultView;
		} else { 
			this.set_resultView(this.initial_resultView());
		}
		this._resultView_isInitialized = true;
		return this._resultView;
	}
	public OCLString initial_viewTitle() {
		/* ==================================================
	 * 'Search'
	 * ================================================== */
	
	OCLString v0 = new OCLString("Search");
	
		return v0;
	}

	public OCLString get_viewTitle(){
		if (this._viewTitle_isInitialized) {
			return _viewTitle;
		} else { 
			this.set_viewTitle(this.initial_viewTitle());
		}
		this._viewTitle_isInitialized = true;
		return this._viewTitle;
	}
	public OCLSequence initial_seqGUIElements() {
		/* ==================================================
	 * Sequence {searchLabel, searchField, searchButton, categorySelect }
	 * ================================================== */
	
	LibraryBrowserGUI_SearchView v3 = this;
	LibraryBrowserGUI_Label v2 = v3.get_searchLabel();
	LibraryBrowserGUI_Label v1 = v2;
	LibraryBrowserGUI_SearchView v6 = this;
	LibraryBrowserGUI_Textfield v5 = v6.get_searchField();
	LibraryBrowserGUI_Textfield v4 = v5;
	LibraryBrowserGUI_SearchView v9 = this;
	LibraryBrowserGUI_Button v8 = v9.get_searchButton();
	LibraryBrowserGUI_Button v7 = v8;
	LibraryBrowserGUI_SearchView v12 = this;
	LibraryBrowserGUI_SelectionBox v11 = v12.get_categorySelect();
	LibraryBrowserGUI_SelectionBox v10 = v11;
	OCLSequence v0 = new OCLSequence();
	v0.add(v1);
	v0.add(v4);
	v0.add(v7);
	v0.add(v10);
	
		return v0;
	}

	public OCLSequence get_seqGUIElements(){
		if (this._seqGUIElements_isInitialized) {
			return _seqGUIElements;
		} else { 
			this.set_seqGUIElements(this.initial_seqGUIElements());
		}
		this._seqGUIElements_isInitialized = true;
		return this._seqGUIElements;
	}


	 
	public void set_viewTitle(OCLString value) {
		 	
		this._viewTitle = value;
		this._viewTitle_isInitialized = true;

		this.onPropertyChange("viewTitle",value);
	}
	public void set_seqGUIElements(OCLSequence value) {
		 	
		this._seqGUIElements = value;
		this._seqGUIElements_isInitialized = true;

		this.onPropertyChange("seqGUIElements",value);
	}


	public void set_searchLabel(LibraryBrowserGUI_Label value) {
		 	
		if (this._searchLabel!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._searchLabel.LibraryBrowserGUI_SearchView_searchLabel_back;
			backpointers.removeElement(this);
		}
		this._searchLabel = value;
		if (this._searchLabel!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._searchLabel.LibraryBrowserGUI_SearchView_searchLabel_back;
			backpointers.addElement(this);
		}
		this._searchLabel_isInitialized = true;

		this.onPropertyChange("searchLabel",value);
	}
	public void set_searchField(LibraryBrowserGUI_Textfield value) {
		 	
		if (this._searchField!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._searchField.LibraryBrowserGUI_SearchView_searchField_back;
			backpointers.removeElement(this);
		}
		this._searchField = value;
		if (this._searchField!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._searchField.LibraryBrowserGUI_SearchView_searchField_back;
			backpointers.addElement(this);
		}
		this._searchField_isInitialized = true;

		this.onPropertyChange("searchField",value);
	}
	public void set_categorySelect(LibraryBrowserGUI_SelectionBox value) {
		 	
		if (this._categorySelect!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._categorySelect.LibraryBrowserGUI_SearchView_categorySelect_back;
			backpointers.removeElement(this);
		}
		this._categorySelect = value;
		if (this._categorySelect!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._categorySelect.LibraryBrowserGUI_SearchView_categorySelect_back;
			backpointers.addElement(this);
		}
		this._categorySelect_isInitialized = true;

		this.onPropertyChange("categorySelect",value);
	}
	public void set_searchButton(LibraryBrowserGUI_Button value) {
		 	
		if (this._searchButton!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._searchButton.LibraryBrowserGUI_SearchView_searchButton_back;
			backpointers.removeElement(this);
		}
		this._searchButton = value;
		if (this._searchButton!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._searchButton.LibraryBrowserGUI_SearchView_searchButton_back;
			backpointers.addElement(this);
		}
		this._searchButton_isInitialized = true;

		this.onPropertyChange("searchButton",value);
	}
	public void set_resultView(LibraryBrowserGUI_BookListView value) {
		 	
		if (this._resultView!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._resultView.LibraryBrowserGUI_SearchView_resultView_back;
			backpointers.removeElement(this);
		}
		this._resultView = value;
		if (this._resultView!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._resultView.LibraryBrowserGUI_SearchView_resultView_back;
			backpointers.addElement(this);
		}
		this._resultView_isInitialized = true;

		this.onPropertyChange("resultView",value);
	}




	 
 	public void event_searchButtonClicked_pushed (PropertyChangeList changes   ){
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			
			this.onEvent("searchButtonClicked", parameterTuple);
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {

				this.event_searchBook_pushed(changes );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_searchButtonClicked_pulled_edge0(PropertyChangeList changes, LibraryBrowserGUI_Button parentInstance  ) {
		System.out.println("event_searchButtonClicked_pulled in model LibraryBrowserGUI_SearchView from event _clicked in model LibraryBrowserGUI_Button");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {

			this.event_searchButtonClicked_pushed(changes  );
		}
	}


 	public void event_searchFinished_pushed (PropertyChangeList changes  , OCLSequence p_booksFound ){
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			parameterTuple.addItem("booksFound", p_booksFound);
			this.onEvent("searchFinished", parameterTuple);
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * BookListView::create(
		 * 	Tuple { 
		 * 		bookListTable = booksFound, 
		 * 		bookDetailView = null 
		 * 	})
		 * ================================================== */
		
		OCLSequence v4 = p_booksFound;
		OCLSequence v3 = v4;
		OCLAny v6 = null;
		OCLAny v5 = v6;
		OCLTuple v2 = new OCLTuple();
		v2.addItem("bookListTable", v3);
		v2.addItem("bookDetailView", v5);
		LibraryBrowserGUI_BookListView v0 = LibraryBrowserGUI_BookListView.newInstance(this.context, v2);
		
			LibraryBrowserGUI_BookListView _resultView_newValue = v0;
			changes.addChange("_resultView", this, _resultView_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_selectedBookData_pushed (PropertyChangeList changes  , OCLString p_author , OCLString p_title , OCLString p_isbn ){
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			parameterTuple.addItem("author", p_author);parameterTuple.addItem("title", p_title);parameterTuple.addItem("isbn", p_isbn);
			this.onEvent("selectedBookData", parameterTuple);
			 		
			// Trigger Push edges


			if (this._resultView != null) {
			 	
				Vector edge0_values = new Vector();
				edge0_values.addElement(this._resultView);
			 	Enumeration edge0_enum = edge0_values.elements();
				while (edge0_enum.hasMoreElements()) {
					LibraryBrowserGUI_BookListView edge0_target = (LibraryBrowserGUI_BookListView)edge0_enum.nextElement();
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * author
				 * ================================================== */
				
				OCLString v1 = p_author;
				
						OCLString parameter_p_author = v1;
						/* ==================================================
				 * title
				 * ================================================== */
				
				OCLString v2 = p_title;
				
						OCLString parameter_p_title = v2;
						/* ==================================================
				 * isbn
				 * ================================================== */
				
				OCLString v3 = p_isbn;
				
						OCLString parameter_p_isbn = v3;

						edge0_target.event_selectedBookData_pushed(changes ,parameter_p_author ,parameter_p_title ,parameter_p_isbn );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_bookSelected_pushed (PropertyChangeList changes  , OCLInteger p_id ){
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			parameterTuple.addItem("id", p_id);
			this.onEvent("bookSelected", parameterTuple);
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges
			Enumeration LibraryBrowserGUI_MainWindow_bookSelected_edge0_enum = this.LibraryBrowserGUI_MainWindow_searchView_back.elements();
			while (LibraryBrowserGUI_MainWindow_bookSelected_edge0_enum.hasMoreElements()) {
				LibraryBrowserGUI_MainWindow LibraryBrowserGUI_MainWindow_bookSelected_edge0_target = (LibraryBrowserGUI_MainWindow)LibraryBrowserGUI_MainWindow_bookSelected_edge0_enum.nextElement();
						LibraryBrowserGUI_MainWindow_bookSelected_edge0_target.event_bookSelected_pulled_edge0(changes, this , p_id  );
			}


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_bookSelected_pulled_edge0(PropertyChangeList changes, LibraryBrowserGUI_BookListView parentInstance ,OCLInteger p_id  ) {
		System.out.println("event_bookSelected_pulled in model LibraryBrowserGUI_SearchView from event _bookSelected in model LibraryBrowserGUI_BookListView");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {
			/* ==================================================
		 * id
		 * ================================================== */
		
		OCLInteger v1 = p_id;
		
			OCLInteger parameter_p_id = v1;

			this.event_bookSelected_pushed(changes ,parameter_p_id  );
		}
	}


 	public void event_searchBook_pushed (PropertyChangeList changes   ){
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			
			this.onEvent("searchBook", parameterTuple);
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges
			Enumeration LibraryBrowserGUI_MainWindow_searchBook_edge0_enum = this.LibraryBrowserGUI_MainWindow_searchView_back.elements();
			while (LibraryBrowserGUI_MainWindow_searchBook_edge0_enum.hasMoreElements()) {
				LibraryBrowserGUI_MainWindow LibraryBrowserGUI_MainWindow_searchBook_edge0_target = (LibraryBrowserGUI_MainWindow)LibraryBrowserGUI_MainWindow_searchBook_edge0_enum.nextElement();
						LibraryBrowserGUI_MainWindow_searchBook_edge0_target.event_searchBook_pulled_edge0(changes, this  );
			}


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 




	 


	 
	public void onPropertyChange(String propertyName, Object value) {
		if (propertyName.equals("seqGUIElements")) {
			if (value != null) {
				updateLayout();
			}
		}
	}

	 
	public void onEvent(String eventName, OCLTuple parameters){
	}

	  
	@Override
    public String getTitle() {
        return this.get_viewTitle().string;
    }

    @Override
    public View createView(Context context) {
        this.context = context;
        this.layout = new LinearLayout(context);
        this.layout.setOrientation(LinearLayout.VERTICAL);
        
        this.updateLayout();
        return this.layout;
    }
    
    private Collection<IWidgetWrapper> getWidgets() {
    	return (Collection)this.get_seqGUIElements().values;
    }
    
    private void updateLayout() {
    	if (this.layout == null) return;
        this.layout.removeAllViews();

        for (IWidgetWrapper wrapper : this.getWidgets()) {
            View widget = wrapper.createWidget((Context)this.context);
            this.layout.addView(widget, new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));
        }
    }

	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

