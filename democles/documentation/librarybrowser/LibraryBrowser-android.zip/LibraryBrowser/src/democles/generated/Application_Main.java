 
	  
package democles.generated;

import java.util.Vector;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
import android.content.Context;
import android.view.View;

	 
import android.app.Activity;
import android.os.Bundle;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import java.util.Collection;

	 
public class Application_Main extends Activity implements OCLAny {
	 
	private Library_BookCollection _completeBookCollection;
	private boolean _completeBookCollection_isInitialized;
	private Library_BookCollection _booksFound;
	private boolean _booksFound_isInitialized;
	private LibraryBrowserGUI_MainWindow _mainGUI;
	private boolean _mainGUI_isInitialized;
	private LibraryPersistenceHandler_LibraryLoader _libraryLoader;
	private boolean _libraryLoader_isInitialized;


	private Object context;

	 
	public Application_Main() {
		this(null);
	}

	private Application_Main(Object context) {
		super();
		this.context = this;
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);

	    new Thread() {
	        @Override
	        public void run() {
	        	initializePropertiesAndTriggerInitEvent();
	        }
	    }.start();
	}
	
	private void initializePropertiesAndTriggerInitEvent() {
		 
		this.set_completeBookCollection(this.initial_completeBookCollection()); 
		this.set_booksFound(this.initial_booksFound()); 
		this.set_mainGUI(this.initial_mainGUI()); 
		this.set_libraryLoader(this.initial_libraryLoader()); 


		
        try {
        	Method init = Application_Main.this.getClass().getMethod("event_init_pushed", PropertyChangeList.class);
        	init.invoke(Application_Main.this, (Object)null);
        } catch (IllegalAccessException e) {
        } catch (InvocationTargetException e) {
        } catch (NoSuchMethodException e) {
        }
	}

	 
	public Library_BookCollection initial_completeBookCollection() {
		/* ==================================================
	 * Library::BookCollection::create(
	 * 	Tuple { 
	 * 		Books = Sequence {
	 * 			Library::Book::create(Tuple { author = 'Author', title = 'Test', isbn = '1234' })
	 * 		} 
	 * 	})
	 * ================================================== */
	
	OCLString v10 = new OCLString("Author");
	OCLString v9 = v10;
	OCLString v12 = new OCLString("Test");
	OCLString v11 = v12;
	OCLString v14 = new OCLString("1234");
	OCLString v13 = v14;
	OCLTuple v8 = new OCLTuple();
	v8.addItem("author", v9);
	v8.addItem("title", v11);
	v8.addItem("isbn", v13);
	Library_Book v6 = Library_Book.newInstance(this.context, v8);
	Library_Book v5 = v6;
	OCLSequence v4 = new OCLSequence();
	v4.add(v5);
	OCLSequence v3 = v4;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("Books", v3);
	Library_BookCollection v0 = Library_BookCollection.newInstance(this.context, v2);
	
		return v0;
	}

	public Library_BookCollection get_completeBookCollection(){
		if (this._completeBookCollection_isInitialized) {
			return _completeBookCollection;
		} else { 
			this.set_completeBookCollection(this.initial_completeBookCollection());
		}
		this._completeBookCollection_isInitialized = true;
		return this._completeBookCollection;
	}
	public Library_BookCollection initial_booksFound() {
		/* ==================================================
	 * null
	 * ================================================== */
	
	Library_BookCollection v0 = null;
	
		return v0;
	}

	public Library_BookCollection get_booksFound(){
		if (this._booksFound_isInitialized) {
			return _booksFound;
		} else { 
			this.set_booksFound(this.initial_booksFound());
		}
		this._booksFound_isInitialized = true;
		return this._booksFound;
	}
	public LibraryBrowserGUI_MainWindow initial_mainGUI() {
		/* ==================================================
	 * LibraryBrowserGUI::MainWindow::create()
	 * ================================================== */
	
	LibraryBrowserGUI_MainWindow v0 = LibraryBrowserGUI_MainWindow.newInstance(this.context);
	
		return v0;
	}

	public LibraryBrowserGUI_MainWindow get_mainGUI(){
		if (this._mainGUI_isInitialized) {
			return _mainGUI;
		} else { 
			this.set_mainGUI(this.initial_mainGUI());
		}
		this._mainGUI_isInitialized = true;
		return this._mainGUI;
	}
	public LibraryPersistenceHandler_LibraryLoader initial_libraryLoader() {
		/* ==================================================
	 * LibraryPersistenceHandler::LibraryLoader::create()
	 * ================================================== */
	
	LibraryPersistenceHandler_LibraryLoader v0 = LibraryPersistenceHandler_LibraryLoader.newInstance(this.context);
	
		return v0;
	}

	public LibraryPersistenceHandler_LibraryLoader get_libraryLoader(){
		if (this._libraryLoader_isInitialized) {
			return _libraryLoader;
		} else { 
			this.set_libraryLoader(this.initial_libraryLoader());
		}
		this._libraryLoader_isInitialized = true;
		return this._libraryLoader;
	}


	 


	public void set_completeBookCollection(Library_BookCollection value) {
		 	
		if (this._completeBookCollection!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._completeBookCollection.Application_Main_completeBookCollection_back;
			backpointers.removeElement(this);
		}
		this._completeBookCollection = value;
		if (this._completeBookCollection!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._completeBookCollection.Application_Main_completeBookCollection_back;
			backpointers.addElement(this);
		}
		this._completeBookCollection_isInitialized = true;

		this.onPropertyChange("completeBookCollection",value);
	}
	public void set_booksFound(Library_BookCollection value) {
		 	
		if (this._booksFound!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._booksFound.Application_Main_booksFound_back;
			backpointers.removeElement(this);
		}
		this._booksFound = value;
		if (this._booksFound!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._booksFound.Application_Main_booksFound_back;
			backpointers.addElement(this);
		}
		this._booksFound_isInitialized = true;

		this.onPropertyChange("booksFound",value);
	}
	public void set_mainGUI(LibraryBrowserGUI_MainWindow value) {
		 	
		if (this._mainGUI!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._mainGUI.Application_Main_mainGUI_back;
			backpointers.removeElement(this);
		}
		this._mainGUI = value;
		if (this._mainGUI!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._mainGUI.Application_Main_mainGUI_back;
			backpointers.addElement(this);
		}
		this._mainGUI_isInitialized = true;

		this.onPropertyChange("mainGUI",value);
	}
	public void set_libraryLoader(LibraryPersistenceHandler_LibraryLoader value) {
		 	
		if (this._libraryLoader!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._libraryLoader.Application_Main_libraryLoader_back;
			backpointers.removeElement(this);
		}
		this._libraryLoader = value;
		if (this._libraryLoader!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._libraryLoader.Application_Main_libraryLoader_back;
			backpointers.addElement(this);
		}
		this._libraryLoader_isInitialized = true;

		this.onPropertyChange("libraryLoader",value);
	}




	 
 	public void event_searchFinished_pushed (PropertyChangeList changes  , OCLAny p_booksFound ){
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			parameterTuple.addItem("booksFound", p_booksFound);
			this.onEvent("searchFinished", parameterTuple);
			 		
			// Trigger Push edges


			if (this._mainGUI != null) {
			 	
				Vector edge0_values = new Vector();
				edge0_values.addElement(this._mainGUI);
			 	Enumeration edge0_enum = edge0_values.elements();
				while (edge0_enum.hasMoreElements()) {
					LibraryBrowserGUI_MainWindow edge0_target = (LibraryBrowserGUI_MainWindow)edge0_enum.nextElement();
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * booksFound.oclAsType(Library::BookCollection).Books->collect(b:Library::Book | b.title)
				 * ================================================== */
				
				OCLAny v4 = p_booksFound;
				Library_BookCollection v3 = ((Library_BookCollection)v4);
				OCLSequence v2 = v3.get_Books();
				OCLSequence v1_nested = new OCLSequence();
				Iterator<OCLAny> v1_iter = v2.objectIterable().iterator();
				while (v1_iter.hasNext()) {
						Library_Book v6 = (Library_Book)v1_iter.next();
						Library_Book v8 = v6;
						OCLString v7 = v8.get_title();
						v1_nested.add(v7);
				}
				OCLSequence v1 = v1_nested.flatten();
				
						OCLSequence parameter_p_booksFound = v1;

						edge0_target.event_searchFinished_pushed(changes ,parameter_p_booksFound );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * booksFound.oclAsType(Library::BookCollection)
		 * ================================================== */
		
		OCLAny v1 = p_booksFound;
		Library_BookCollection v0 = ((Library_BookCollection)v1);
		
			Library_BookCollection _booksFound_newValue = v0;
			changes.addChange("_booksFound", this, _booksFound_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_searchBook_pushed (PropertyChangeList changes  , OCLString p_keyword , OCLString p_category ){
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			parameterTuple.addItem("keyword", p_keyword);parameterTuple.addItem("category", p_category);
			this.onEvent("searchBook", parameterTuple);
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {
				/* ==================================================
			 * Library::BookCollection::create(
			 * 	Tuple { Books =
			 * 			completeBookCollection.Books->select (
			 * 				b: Library::Book | ((category='Author') and (b.author=keyword)) or ((category = 'Title') and (b.title = keyword)) or ((category = 'ISBN') and (b.isbn = keyword))
			 * 				)
			 * 	})
			 * ================================================== */
			
			Library_BookCollection v7 = this.get_completeBookCollection();
			OCLSequence v6 = v7.get_Books();
			OCLSequence v5 = new OCLSequence();
			Iterator<OCLAny> v5_iter = v6.objectIterable().iterator();
			while (v5_iter.hasNext()) {
					Library_Book v8 = (Library_Book)v5_iter.next();
					OCLString v13 = p_category;
					OCLString v14 = new OCLString("Author");
					OCLBoolean v12 = v13.eq(v14);
					Library_Book v17 = v8;
					OCLString v16 = v17.get_author();
					OCLString v18 = p_keyword;
					OCLBoolean v15 = v16.eq(v18);
					OCLBoolean v11 = v12.and(v15);
					OCLString v21 = p_category;
					OCLString v22 = new OCLString("Title");
					OCLBoolean v20 = v21.eq(v22);
					Library_Book v25 = v8;
					OCLString v24 = v25.get_title();
					OCLString v26 = p_keyword;
					OCLBoolean v23 = v24.eq(v26);
					OCLBoolean v19 = v20.and(v23);
					OCLBoolean v10 = v11.or(v19);
					OCLString v29 = p_category;
					OCLString v30 = new OCLString("ISBN");
					OCLBoolean v28 = v29.eq(v30);
					Library_Book v33 = v8;
					OCLString v32 = v33.get_isbn();
					OCLString v34 = p_keyword;
					OCLBoolean v31 = v32.eq(v34);
					OCLBoolean v27 = v28.and(v31);
					OCLBoolean v9 = v10.or(v27);
					if (v9.value == true) { v5.add(v8); }
			}
			OCLSequence v4 = v5;
			OCLTuple v3 = new OCLTuple();
			v3.addItem("Books", v4);
			OCLAny v1 = Library_BookCollection.newInstance(this.context, v3);
			
				OCLAny parameter_p_booksFound = v1;

				this.event_searchFinished_pushed(changes , parameter_p_booksFound );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_searchBook_pulled_edge0(PropertyChangeList changes, LibraryBrowserGUI_MainWindow parentInstance ,OCLString p_keyword ,OCLString p_category  ) {
		System.out.println("event_searchBook_pulled in model Application_Main from event _searchBook in model LibraryBrowserGUI_MainWindow");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {
			/* ==================================================
		 * keyword
		 * ================================================== */
		
		OCLString v1 = p_keyword;
		
			OCLString parameter_p_keyword = v1;
			/* ==================================================
		 * category
		 * ================================================== */
		
		OCLString v2 = p_category;
		
			OCLString parameter_p_category = v2;

			this.event_searchBook_pushed(changes ,parameter_p_keyword ,parameter_p_category  );
		}
	}


 	public void event_bookSelected_pushed (PropertyChangeList changes  , OCLInteger p_id ){
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			parameterTuple.addItem("id", p_id);
			this.onEvent("bookSelected", parameterTuple);
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {
				/* ==================================================
			 * booksFound.Books->at(id).author
			 * ================================================== */
			
			Library_BookCollection v4 = this.get_booksFound();
			OCLSequence v3 = v4.get_Books();
			OCLInteger v5 = p_id;
			Library_Book v2 = ((Library_Book)v3.at(v5));
			OCLString v1 = v2.get_author();
			
				OCLString parameter_p_author = v1;
				/* ==================================================
			 * booksFound.Books->at(id).title
			 * ================================================== */
			
			Library_BookCollection v9 = this.get_booksFound();
			OCLSequence v8 = v9.get_Books();
			OCLInteger v10 = p_id;
			Library_Book v7 = ((Library_Book)v8.at(v10));
			OCLString v6 = v7.get_title();
			
				OCLString parameter_p_title = v6;
				/* ==================================================
			 * booksFound.Books->at(id).isbn
			 * ================================================== */
			
			Library_BookCollection v14 = this.get_booksFound();
			OCLSequence v13 = v14.get_Books();
			OCLInteger v15 = p_id;
			Library_Book v12 = ((Library_Book)v13.at(v15));
			OCLString v11 = v12.get_isbn();
			
				OCLString parameter_p_isbn = v11;

				this.event_selectedBookData_pushed(changes , parameter_p_author , parameter_p_title , parameter_p_isbn );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_bookSelected_pulled_edge0(PropertyChangeList changes, LibraryBrowserGUI_MainWindow parentInstance ,OCLInteger p_id  ) {
		System.out.println("event_bookSelected_pulled in model Application_Main from event _bookSelected in model LibraryBrowserGUI_MainWindow");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {
			/* ==================================================
		 * id
		 * ================================================== */
		
		OCLInteger v1 = p_id;
		
			OCLInteger parameter_p_id = v1;

			this.event_bookSelected_pushed(changes ,parameter_p_id  );
		}
	}


 	public void event_selectedBookData_pushed (PropertyChangeList changes  , OCLString p_author , OCLString p_title , OCLString p_isbn ){
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			parameterTuple.addItem("author", p_author);parameterTuple.addItem("title", p_title);parameterTuple.addItem("isbn", p_isbn);
			this.onEvent("selectedBookData", parameterTuple);
			 		
			// Trigger Push edges


			if (this._mainGUI != null) {
			 	
				Vector edge0_values = new Vector();
				edge0_values.addElement(this._mainGUI);
			 	Enumeration edge0_enum = edge0_values.elements();
				while (edge0_enum.hasMoreElements()) {
					LibraryBrowserGUI_MainWindow edge0_target = (LibraryBrowserGUI_MainWindow)edge0_enum.nextElement();
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * author
				 * ================================================== */
				
				OCLString v1 = p_author;
				
						OCLString parameter_p_author = v1;
						/* ==================================================
				 * title
				 * ================================================== */
				
				OCLString v2 = p_title;
				
						OCLString parameter_p_title = v2;
						/* ==================================================
				 * isbn
				 * ================================================== */
				
				OCLString v3 = p_isbn;
				
						OCLString parameter_p_isbn = v3;

						edge0_target.event_selectedBookData_pushed(changes ,parameter_p_author ,parameter_p_title ,parameter_p_isbn );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_libraryBooksLoaded_pushed (PropertyChangeList changes  , Library_BookCollection p_bookCollection ){
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			parameterTuple.addItem("bookCollection", p_bookCollection);
			this.onEvent("libraryBooksLoaded", parameterTuple);
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {
				/* ==================================================
			 * bookCollection
			 * ================================================== */
			
			Library_BookCollection v1 = p_bookCollection;
			
				Library_BookCollection parameter_p_completeBookCollection = v1;

				this.event_setCompleteBookCollection_pushed(changes , parameter_p_completeBookCollection );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_libraryBooksLoaded_pulled_edge0(PropertyChangeList changes, LibraryPersistenceHandler_LibraryLoader parentInstance  ) {
		System.out.println("event_libraryBooksLoaded_pulled in model Application_Main from event _libraryFileClosed in model LibraryPersistenceHandler_LibraryLoader");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {
			/* ==================================================
		 * libraryLoader.libraryBooks
		 * ================================================== */
		
		Application_Main v3 = this;
		LibraryPersistenceHandler_LibraryLoader v2 = v3.get_libraryLoader();
		Library_BookCollection v1 = v2.get_libraryBooks();
		
			Library_BookCollection parameter_p_bookCollection = v1;

			this.event_libraryBooksLoaded_pushed(changes ,parameter_p_bookCollection  );
		}
	}


 	public void event_setCompleteBookCollection_pushed (PropertyChangeList changes  , Library_BookCollection p_completeBookCollection ){
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			parameterTuple.addItem("completeBookCollection", p_completeBookCollection);
			this.onEvent("setCompleteBookCollection", parameterTuple);
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * -- Generated impacts relationship code:
		 * completeBookCollection
		 * ================================================== */
		
		Library_BookCollection v0 = p_completeBookCollection;
		
			Library_BookCollection _completeBookCollection_newValue = v0;
			changes.addChange("_completeBookCollection", this, _completeBookCollection_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_init_pushed (PropertyChangeList changes   ){
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			
			this.onEvent("init", parameterTuple);
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges
			/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean v0 = new OCLBoolean(true);
		
			if (v0.value == true) {

				this.event_loadLibrary_pushed(changes );
			}


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_loadLibrary_pushed (PropertyChangeList changes   ){
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			
			this.onEvent("loadLibrary", parameterTuple);
			 		
			// Trigger Push edges


			if (this._libraryLoader != null) {
			 	
				Vector edge0_values = new Vector();
				edge0_values.addElement(this._libraryLoader);
			 	Enumeration edge0_enum = edge0_values.elements();
				while (edge0_enum.hasMoreElements()) {
					LibraryPersistenceHandler_LibraryLoader edge0_target = (LibraryPersistenceHandler_LibraryLoader)edge0_enum.nextElement();
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {

						edge0_target.event_loadLibrary_pushed(changes );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 




	 


	 
	public void onPropertyChange(String propertyName, Object value) {
	}

	 
	public void onEvent(String eventName, OCLTuple parameters) {
	}

	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

