 
	  
package democles.generated;

import java.util.Vector;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
public class Library_BookCollection implements OCLAny {
	 
	private OCLSequence _Books;
	private boolean _Books_isInitialized;

	public Vector<OCLAny> LibraryPersistenceHandler_LibraryLoader_libraryBooks_back = new Vector<OCLAny>();
	public Vector<OCLAny> Application_Main_completeBookCollection_back = new Vector<OCLAny>();
	public Vector<OCLAny> Application_Main_booksFound_back = new Vector<OCLAny>();

	private Object context;

	 
	private Library_BookCollection(Object context) {
		super();
		this.context = context;
		 
		this.set_Books(this.initial_Books()); 


	}
	
	static public Library_BookCollection newInstance(Object context) {
		if (context == null) throw new NullPointerException();
		return new Library_BookCollection(context);
	}
 
	 
	private Library_BookCollection(Object context, OCLTuple values) {
		super();
		this.context = context;
		 
		this._Books_isInitialized = false; 

		if (values == null) values = new OCLTuple(); // Empty
		if (values.containsKey("Books")) {
			this.set_Books((OCLSequence)values.objectForKey("Books"));
		} else {
			this.set_Books(this.initial_Books());
		}


	}

	static public Library_BookCollection newInstance(Object context, OCLTuple values) {
		if (context == null) throw new NullPointerException();
		return new Library_BookCollection(context, values);
	}

	 
	public OCLSequence initial_Books() {
		/* ==================================================
	 * Sequence{}
	 * ================================================== */
	
	OCLSequence v0 = new OCLSequence();
	
		return v0;
	}

	public OCLSequence get_Books(){
		if (this._Books_isInitialized) {
			return _Books;
		} else { 
			this.set_Books(this.initial_Books());
		}
		this._Books_isInitialized = true;
		return this._Books;
	}


	 




 	public void set_Books(OCLSequence value) {
	 	
		if (this._Books!= null) {
			// Clear back pointer on old instance
			for (OCLAny object : this._Books.objectIterable()) {
				Library_Book o = (Library_Book)object;
				Vector<OCLAny> backpointers = o.Library_BookCollection_Books_back;
				backpointers.removeElement(this);
			}
		}
		this._Books = value;
		if (this._Books!= null) {
			// Add back pointer on new instance
			for (OCLAny object : this._Books.objectIterable()) {
				Library_Book o = (Library_Book)object;
				Vector<OCLAny> backpointers = o.Library_BookCollection_Books_back;
				backpointers.addElement(this);
			}
		}
		this._Books_isInitialized = true;

	}


	 


	 


	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

