 
	  
package democles.generated;

import java.util.Vector;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
public class LibraryBrowserGUI_MainWindow implements OCLAny {
	 
	private LibraryBrowserGUI_SearchView _searchView;
	private boolean _searchView_isInitialized;
	private LibraryBrowserGUI_HomeView _homeView;
	private boolean _homeView_isInitialized;
	private LibraryBrowserGUI_TabbedWindow _viewSelector;
	private boolean _viewSelector_isInitialized;

	public Vector<OCLAny> Application_Main_mainGUI_back = new Vector<OCLAny>();

	private Object context;

	 
	private LibraryBrowserGUI_MainWindow(Object context) {
		super();
		this.context = context;
		 
		this.set_searchView(this.initial_searchView()); 
		this.set_homeView(this.initial_homeView()); 
		this.set_viewSelector(this.initial_viewSelector()); 


	}
	
	static public LibraryBrowserGUI_MainWindow newInstance(Object context) {
		if (context == null) throw new NullPointerException();
		return new LibraryBrowserGUI_MainWindow(context);
	}
 
	 
	private LibraryBrowserGUI_MainWindow(Object context, OCLTuple values) {
		super();
		this.context = context;
		 
		this._searchView_isInitialized = false; 
		this._homeView_isInitialized = false; 
		this._viewSelector_isInitialized = false; 

		if (values == null) values = new OCLTuple(); // Empty
		if (values.containsKey("searchView")) {
			this.set_searchView((LibraryBrowserGUI_SearchView)values.objectForKey("searchView"));
		} else {
			this.set_searchView(this.initial_searchView());
		}
		if (values.containsKey("homeView")) {
			this.set_homeView((LibraryBrowserGUI_HomeView)values.objectForKey("homeView"));
		} else {
			this.set_homeView(this.initial_homeView());
		}
		if (values.containsKey("viewSelector")) {
			this.set_viewSelector((LibraryBrowserGUI_TabbedWindow)values.objectForKey("viewSelector"));
		} else {
			this.set_viewSelector(this.initial_viewSelector());
		}


	}

	static public LibraryBrowserGUI_MainWindow newInstance(Object context, OCLTuple values) {
		if (context == null) throw new NullPointerException();
		return new LibraryBrowserGUI_MainWindow(context, values);
	}

	 
	public LibraryBrowserGUI_SearchView initial_searchView() {
		/* ==================================================
	 * LibraryBrowserGUI::SearchView::create()
	 * ================================================== */
	
	LibraryBrowserGUI_SearchView v0 = LibraryBrowserGUI_SearchView.newInstance(this.context);
	
		return v0;
	}

	public LibraryBrowserGUI_SearchView get_searchView(){
		if (this._searchView_isInitialized) {
			return _searchView;
		} else { 
			this.set_searchView(this.initial_searchView());
		}
		this._searchView_isInitialized = true;
		return this._searchView;
	}
	public LibraryBrowserGUI_HomeView initial_homeView() {
		/* ==================================================
	 * HomeView::create()
	 * ================================================== */
	
	LibraryBrowserGUI_HomeView v0 = LibraryBrowserGUI_HomeView.newInstance(this.context);
	
		return v0;
	}

	public LibraryBrowserGUI_HomeView get_homeView(){
		if (this._homeView_isInitialized) {
			return _homeView;
		} else { 
			this.set_homeView(this.initial_homeView());
		}
		this._homeView_isInitialized = true;
		return this._homeView;
	}
	public LibraryBrowserGUI_TabbedWindow initial_viewSelector() {
		/* ==================================================
	 * TabbedWindow::create(
	 * 	Tuple { views = Sequence { homeView, searchView}}
	 * )
	 * ================================================== */
	
	LibraryBrowserGUI_MainWindow v7 = this;
	LibraryBrowserGUI_HomeView v6 = v7.get_homeView();
	LibraryBrowserGUI_HomeView v5 = v6;
	LibraryBrowserGUI_MainWindow v10 = this;
	LibraryBrowserGUI_SearchView v9 = v10.get_searchView();
	LibraryBrowserGUI_SearchView v8 = v9;
	OCLSequence v4 = new OCLSequence();
	v4.add(v5);
	v4.add(v8);
	OCLSequence v3 = v4;
	OCLTuple v2 = new OCLTuple();
	v2.addItem("views", v3);
	LibraryBrowserGUI_TabbedWindow v0 = LibraryBrowserGUI_TabbedWindow.newInstance(this.context, v2);
	
		return v0;
	}

	public LibraryBrowserGUI_TabbedWindow get_viewSelector(){
		if (this._viewSelector_isInitialized) {
			return _viewSelector;
		} else { 
			this.set_viewSelector(this.initial_viewSelector());
		}
		this._viewSelector_isInitialized = true;
		return this._viewSelector;
	}


	 


	public void set_searchView(LibraryBrowserGUI_SearchView value) {
	 	
		if (this._searchView!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._searchView.LibraryBrowserGUI_MainWindow_searchView_back;
			backpointers.removeElement(this);
		}
		this._searchView = value;
		if (this._searchView!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._searchView.LibraryBrowserGUI_MainWindow_searchView_back;
			backpointers.addElement(this);
		}
		this._searchView_isInitialized = true;

	}
	public void set_homeView(LibraryBrowserGUI_HomeView value) {
	 	
		if (this._homeView!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._homeView.LibraryBrowserGUI_MainWindow_homeView_back;
			backpointers.removeElement(this);
		}
		this._homeView = value;
		if (this._homeView!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._homeView.LibraryBrowserGUI_MainWindow_homeView_back;
			backpointers.addElement(this);
		}
		this._homeView_isInitialized = true;

	}
	public void set_viewSelector(LibraryBrowserGUI_TabbedWindow value) {
	 	
		if (this._viewSelector!= null) {
			// Clear back pointer on old instance
			Vector<OCLAny> backpointers = this._viewSelector.LibraryBrowserGUI_MainWindow_viewSelector_back;
			backpointers.removeElement(this);
		}
		this._viewSelector = value;
		if (this._viewSelector!= null) {
			// Add back pointer on new instance
		 	Vector<OCLAny> backpointers = this._viewSelector.LibraryBrowserGUI_MainWindow_viewSelector_back;
			backpointers.addElement(this);
		}
		this._viewSelector_isInitialized = true;

	}




	 
 	public void event_searchBook_pushed (PropertyChangeList changes  , OCLString p_keyword , OCLString p_category ){
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_searchBook_pushed in model LibraryBrowserGUI_MainWindow");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges
			Enumeration Application_Main_searchBook_edge0_enum = this.Application_Main_mainGUI_back.elements();
			while (Application_Main_searchBook_edge0_enum.hasMoreElements()) {
				Application_Main Application_Main_searchBook_edge0_target = (Application_Main)Application_Main_searchBook_edge0_enum.nextElement();
						Application_Main_searchBook_edge0_target.event_searchBook_pulled_edge0(changes, this , p_keyword , p_category  );
			}


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_searchBook_pulled_edge0(PropertyChangeList changes, LibraryBrowserGUI_SearchView parentInstance  ) {
		System.out.println("event_searchBook_pulled in model LibraryBrowserGUI_MainWindow from event _searchBook in model LibraryBrowserGUI_SearchView");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {
			/* ==================================================
		 * searchField.text
		 * ================================================== */
		
		LibraryBrowserGUI_Textfield v2 = parentInstance.get_searchField();
		OCLString v1 = v2.get_text();
		
			OCLString parameter_p_keyword = v1;
			/* ==================================================
		 * categorySelect.selectedChoice
		 * ================================================== */
		
		LibraryBrowserGUI_SelectionBox v4 = parentInstance.get_categorySelect();
		OCLString v3 = v4.get_selectedChoice();
		
			OCLString parameter_p_category = v3;

			this.event_searchBook_pushed(changes ,parameter_p_keyword ,parameter_p_category  );
		}
	}


 	public void event_searchFinished_pushed (PropertyChangeList changes  , OCLSequence p_booksFound ){
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_searchFinished_pushed in model LibraryBrowserGUI_MainWindow");
			 		
			// Trigger Push edges


			if (this._searchView != null) {
			 	
				Vector edge0_values = new Vector();
				edge0_values.addElement(this._searchView);
			 	Enumeration edge0_enum = edge0_values.elements();
				while (edge0_enum.hasMoreElements()) {
					LibraryBrowserGUI_SearchView edge0_target = (LibraryBrowserGUI_SearchView)edge0_enum.nextElement();
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * booksFound
				 * ================================================== */
				
				OCLSequence v1 = p_booksFound;
				
						OCLSequence parameter_p_booksFound = v1;

						edge0_target.event_searchFinished_pushed(changes ,parameter_p_booksFound );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 


 	public void event_bookSelected_pushed (PropertyChangeList changes  , OCLInteger p_id ){
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_bookSelected_pushed in model LibraryBrowserGUI_MainWindow");
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges
			Enumeration Application_Main_bookSelected_edge0_enum = this.Application_Main_mainGUI_back.elements();
			while (Application_Main_bookSelected_edge0_enum.hasMoreElements()) {
				Application_Main Application_Main_bookSelected_edge0_target = (Application_Main)Application_Main_bookSelected_edge0_enum.nextElement();
						Application_Main_bookSelected_edge0_target.event_bookSelected_pulled_edge0(changes, this , p_id  );
			}


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 
	public void event_bookSelected_pulled_edge0(PropertyChangeList changes, LibraryBrowserGUI_SearchView parentInstance ,OCLInteger p_id  ) {
		System.out.println("event_bookSelected_pulled in model LibraryBrowserGUI_MainWindow from event _bookSelected in model LibraryBrowserGUI_SearchView");
		/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean v0 = new OCLBoolean(true);
	
		if (v0.value == true) {
			/* ==================================================
		 * id
		 * ================================================== */
		
		OCLInteger v1 = p_id;
		
			OCLInteger parameter_p_id = v1;

			this.event_bookSelected_pushed(changes ,parameter_p_id  );
		}
	}


 	public void event_selectedBookData_pushed (PropertyChangeList changes  , OCLString p_author , OCLString p_title , OCLString p_isbn ){
		try {
			if (changes == null) changes = new PropertyChangeList();
			changes.enter();

			System.out.println("event_selectedBookData_pushed in model LibraryBrowserGUI_MainWindow");
			 		
			// Trigger Push edges


			if (this._searchView != null) {
			 	
				Vector edge0_values = new Vector();
				edge0_values.addElement(this._searchView);
			 	Enumeration edge0_enum = edge0_values.elements();
				while (edge0_enum.hasMoreElements()) {
					LibraryBrowserGUI_SearchView edge0_target = (LibraryBrowserGUI_SearchView)edge0_enum.nextElement();
					/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean v0 = new OCLBoolean(true);
			
					if (v0.value == true) {
						/* ==================================================
				 * author
				 * ================================================== */
				
				OCLString v1 = p_author;
				
						OCLString parameter_p_author = v1;
						/* ==================================================
				 * title
				 * ================================================== */
				
				OCLString v2 = p_title;
				
						OCLString parameter_p_title = v2;
						/* ==================================================
				 * isbn
				 * ================================================== */
				
				OCLString v3 = p_isbn;
				
						OCLString parameter_p_isbn = v3;

						edge0_target.event_selectedBookData_pushed(changes ,parameter_p_author ,parameter_p_title ,parameter_p_isbn );
					}
				}

			}


			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships


		}
		finally {
			changes.leave();
		}
	}
	
	 




	 


	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

