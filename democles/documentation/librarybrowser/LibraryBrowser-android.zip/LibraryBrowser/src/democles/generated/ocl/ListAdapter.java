package democles.generated.ocl;

import android.content.Context;
import android.database.DataSetObserver;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class ListAdapter<T> implements android.widget.ListAdapter {

    private final Context context;
    private final java.util.List<T> items;

    public ListAdapter(Context context, java.util.List<T> items) {
        this.context = context;
        this.items = items;
    }
    
    @Override
    public int getCount() {
        return this.items.size();
    }

    @Override
    public Object getItem(int position) {
        return this.items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return System.identityHashCode(this.getItem(position));
    }

    @Override
    public int getItemViewType(int position) {
        return IGNORE_ITEM_VIEW_TYPE;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        
        TextView view;
        
        if (convertView != null) {
            view = (TextView)convertView;
        } else {
            view = new TextView(this.context);
        }
        
        view.setText(this.getItem(position).toString());
        
        return view;
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public boolean isEmpty() {
        return this.items.isEmpty();
    }

    @Override
    public void registerDataSetObserver(DataSetObserver observer) {
    }

    @Override
    public void unregisterDataSetObserver(DataSetObserver observer) {
    }

    @Override
    public boolean areAllItemsEnabled() {
        return true;
    }

    @Override
    public boolean isEnabled(int position) {
        return true;
    }
}
