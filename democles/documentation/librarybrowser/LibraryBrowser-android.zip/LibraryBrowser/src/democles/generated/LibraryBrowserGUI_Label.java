 
	  
package democles.generated;

import java.util.Vector;
import java.util.Map;
import java.util.Enumeration;
import java.util.Iterator;
import democles.generated.ocl.*;

	 
import android.content.Context;
import android.view.View;

	 
import android.widget.TextView;

	 
public class LibraryBrowserGUI_Label implements IWidgetWrapper, OCLAny {
	 
	private OCLString _text;
	private boolean _text_isInitialized;

	public Vector<OCLAny> LibraryBrowserGUI_HomeView_titleLabel_back = new Vector<OCLAny>();
	public Vector<OCLAny> LibraryBrowserGUI_BookDetailView_bookTitleLabel_back = new Vector<OCLAny>();
	public Vector<OCLAny> LibraryBrowserGUI_BookDetailView_bookIsbnLabel_back = new Vector<OCLAny>();
	public Vector<OCLAny> LibraryBrowserGUI_BookDetailView_bookAuthorLabel_back = new Vector<OCLAny>();
	public Vector<OCLAny> LibraryBrowserGUI_SearchView_searchLabel_back = new Vector<OCLAny>();
	public Vector<OCLAny> LibraryBrowserGUI_BookDetailView_titleLabel_back = new Vector<OCLAny>();
	public Vector<OCLAny> LibraryBrowserGUI_BookDetailView_authorLabel_back = new Vector<OCLAny>();
	public Vector<OCLAny> LibraryBrowserGUI_BookDetailView_isbnLabel_back = new Vector<OCLAny>();

	private Object context;

	  
	private TextView textView;

	 
	private LibraryBrowserGUI_Label(Object context) {
		super();
		this.context = context;
		 
		this.set_text(this.initial_text()); 


	}
	
	static public LibraryBrowserGUI_Label newInstance(Object context) {
		if (context == null) throw new NullPointerException();
		return new LibraryBrowserGUI_Label(context);
	}
 
	 
	private LibraryBrowserGUI_Label(Object context, OCLTuple values) {
		super();
		this.context = context;
		 
		this._text_isInitialized = false; 

		if (values == null) values = new OCLTuple(); // Empty
		if (values.containsKey("text")) {
			this.set_text((OCLString)values.objectForKey("text"));
		} else {
			this.set_text(this.initial_text());
		}


	}

	static public LibraryBrowserGUI_Label newInstance(Object context, OCLTuple values) {
		if (context == null) throw new NullPointerException();
		return new LibraryBrowserGUI_Label(context, values);
	}

	 
	public OCLString initial_text() {
		/* ==================================================
	 * ''
	 * ================================================== */
	
	OCLString v0 = new OCLString("");
	
		return v0;
	}

	public OCLString get_text(){
		if (this._text_isInitialized) {
			return _text;
		} else { 
			this.set_text(this.initial_text());
		}
		this._text_isInitialized = true;
		return this._text;
	}


	 
	public void set_text(OCLString value) {
		 	
		this._text = value;
		this._text_isInitialized = true;

		this.onPropertyChange("text",value);
	}






	 
 	public void event_setText_pushed (PropertyChangeList changes  , OCLString p_text ){
		if (changes == null) changes = new PropertyChangeList();
		try {
			changes.enter();

			OCLTuple parameterTuple = new OCLTuple();
			parameterTuple.addItem("text", p_text);
			this.onEvent("setText", parameterTuple);
			 		
			// Trigger Push edges




			 		
			// Trigger Pull edges


			 		
		// Trigger local edges


			 		 
		// Process impacts relationships
			/* ==================================================
		 * -- Generated impacts relationship code:
		 * text
		 * ================================================== */
		
		OCLString v0 = p_text;
		
			OCLString _text_newValue = v0;
			changes.addChange("_text", this, _text_newValue);


		}
		finally {
			changes.leave();
		}
	}
	
	 




	 


	 
	public void onPropertyChange(String propertyName, Object value) {
		if (propertyName.equals("text")) {
			if (value != null) {
				updateTextView();
			}
		}
	}

	 
	public void onEvent(String eventName, OCLTuple parameters) {
	}

	  
	@Override
    public View createWidget(Context context) {
        this.textView = new TextView(context);
        this.updateTextView();
        return this.textView;
    }

    private void updateTextView() {
    	if (this.textView == null) return;
        this.textView.setText(this.get_text().string);
    }

	 
    private final OCLAny anyDelegate = new OCLAny.DefaultOCLAnyImpl(this);
    @Override public OCLBoolean eq(OCLAny other) { return this.anyDelegate.eq(other); }
    @Override public OCLBoolean neq(OCLAny other) {return this.anyDelegate.neq(other); }
    @Override public OCLBoolean oclIsTypeOf(Class<?> type) { return this.anyDelegate.oclIsTypeOf(type); }
    @Override public OCLBoolean oclIsKindOfClass(Class<?> type) { return this.anyDelegate.oclIsKindOfClass(type); }
    @Override public OCLBoolean oclIsKindOfInterface(String interfaceName) { return this.anyDelegate.oclIsKindOfInterface(interfaceName); }
    @Override public boolean isCompatibleType(OCLAny other) { return this.anyDelegate.isCompatibleType(other); }

}

