  
 
 
#import "LibraryBrowserGUI_SearchView.h"
#import "PropertyChangeList.h"
#import "LibraryBrowserGUI_Textfield.h"
#import "LibraryBrowserGUI_BookListView.h"
#import "LibraryBrowserGUI_Label.h"
#import "LibraryBrowserGUI_SearchView.h"
#import "LibraryBrowserGUI_Button.h"
#import "LibraryBrowserGUI_SelectionBox.h"
#import "LibraryBrowserGUI_MainWindow.h"


 
@implementation LibraryBrowserGUI_SearchView

 
- (id) init {
	self = [super init];
	 
	self->rootViewController = [[UIViewController alloc] init];

	 
	self->LibraryBrowserGUI_MainWindow_searchView_back = [[NSMutableArray alloc] init];

	[self set_searchLabel: [self _searchLabel]];
	[self set_searchField: [self _searchField]];
	[self set_categorySelect: [self _categorySelect]];
	[self set_searchButton: [self _searchButton]];
	[self set_resultView: [self _resultView]];
	[self set_viewTitle: [self _viewTitle]];
	[self set_seqGUIElements: [self _seqGUIElements]];


	 
	[self addWidgets: self->rootViewController.view];
	self->binding = [[UINavigationController alloc] initWithRootViewController: self->rootViewController ];
	self->binding.tabBarItem.image = [UIImage imageNamed: nil];
	self->navigationController = self->binding;

	return self;
}

 
- (id) initWithValues: (OCLTuple*) values {
	self = [super init];
	 
	self->rootViewController = [[UIViewController alloc] init];

	 
	self->_searchLabel_initialized = NO;
	self->_searchField_initialized = NO;
	self->_categorySelect_initialized = NO;
	self->_searchButton_initialized = NO;
	self->_resultView_initialized = NO;
	self->_viewTitle_initialized = NO;
	self->_seqGUIElements_initialized = NO;

	self->LibraryBrowserGUI_MainWindow_searchView_back = [[NSMutableArray alloc] init];

	LibraryBrowserGUI_Label* _searchLabel_initialValue = (LibraryBrowserGUI_Label*) [values objectForKey:@"searchLabel"];
	if (_searchLabel_initialValue == nil) {
		_searchLabel_initialValue = [self _searchLabel];
	}
	[self set_searchLabel:_searchLabel_initialValue];
	LibraryBrowserGUI_Textfield* _searchField_initialValue = (LibraryBrowserGUI_Textfield*) [values objectForKey:@"searchField"];
	if (_searchField_initialValue == nil) {
		_searchField_initialValue = [self _searchField];
	}
	[self set_searchField:_searchField_initialValue];
	LibraryBrowserGUI_SelectionBox* _categorySelect_initialValue = (LibraryBrowserGUI_SelectionBox*) [values objectForKey:@"categorySelect"];
	if (_categorySelect_initialValue == nil) {
		_categorySelect_initialValue = [self _categorySelect];
	}
	[self set_categorySelect:_categorySelect_initialValue];
	LibraryBrowserGUI_Button* _searchButton_initialValue = (LibraryBrowserGUI_Button*) [values objectForKey:@"searchButton"];
	if (_searchButton_initialValue == nil) {
		_searchButton_initialValue = [self _searchButton];
	}
	[self set_searchButton:_searchButton_initialValue];
	LibraryBrowserGUI_BookListView* _resultView_initialValue = (LibraryBrowserGUI_BookListView*) [values objectForKey:@"resultView"];
	if (_resultView_initialValue == nil) {
		_resultView_initialValue = [self _resultView];
	}
	[self set_resultView:_resultView_initialValue];
	OCLString* _viewTitle_initialValue = (OCLString*) [values objectForKey:@"viewTitle"];
	if (_viewTitle_initialValue == nil) {
		_viewTitle_initialValue = [self _viewTitle];
	}
	[self set_viewTitle:_viewTitle_initialValue];
	OCLSequence* _seqGUIElements_initialValue = (OCLSequence*) [values objectForKey:@"seqGUIElements"];
	if (_seqGUIElements_initialValue == nil) {
		_seqGUIElements_initialValue = [self _seqGUIElements];
	}
	[self set_seqGUIElements:_seqGUIElements_initialValue];


	 
	[self addWidgets: self->rootViewController.view];
	self->binding = [[UINavigationController alloc] initWithRootViewController: self->rootViewController ];
	self->binding.tabBarItem.image = [UIImage imageNamed: nil];
	self->navigationController = self->binding;

	return self;
}

 
- (void) dealloc {
	if (self->_searchLabel != nil && self->_searchLabel != (LibraryBrowserGUI_Label*) [NSNull null]) [self->_searchLabel release];
	if (self->_searchField != nil && self->_searchField != (LibraryBrowserGUI_Textfield*) [NSNull null]) [self->_searchField release];
	if (self->_categorySelect != nil && self->_categorySelect != (LibraryBrowserGUI_SelectionBox*) [NSNull null]) [self->_categorySelect release];
	if (self->_searchButton != nil && self->_searchButton != (LibraryBrowserGUI_Button*) [NSNull null]) [self->_searchButton release];
	if (self->_resultView != nil && self->_resultView != (LibraryBrowserGUI_BookListView*) [NSNull null]) [self->_resultView release];
	if (self->_viewTitle != nil && self->_viewTitle != (OCLString*) [NSNull null]) [self->_viewTitle release];
	if (self->_seqGUIElements != nil && self->_seqGUIElements != (OCLSequence*) [NSNull null]) [self->_seqGUIElements release];

	[self->LibraryBrowserGUI_MainWindow_searchView_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"LibraryBrowserGUI::SearchView\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"searchLabel\" type=\"LibraryBrowserGUI::Label\">\n"];
	[res appendFormat:@"%@\n", [self _searchLabel]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"searchField\" type=\"LibraryBrowserGUI::Textfield\">\n"];
	[res appendFormat:@"%@\n", [self _searchField]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"categorySelect\" type=\"LibraryBrowserGUI::SelectionBox\">\n"];
	[res appendFormat:@"%@\n", [self _categorySelect]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"searchButton\" type=\"LibraryBrowserGUI::Button\">\n"];
	[res appendFormat:@"%@\n", [self _searchButton]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"resultView\" type=\"LibraryBrowserGUI::BookListView\">\n"];
	[res appendFormat:@"%@\n", [self _resultView]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"viewTitle\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _viewTitle]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"seqGUIElements\" type=\"Sequence\">\n"];
	[res appendFormat:@"%@\n", [self _seqGUIElements]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
-(LibraryBrowserGUI_Label*) initial_searchLabel {
	/* ==================================================
	 * Label::create()
	 * ================================================== */
	
	LibraryBrowserGUI_Label* v0 = [(LibraryBrowserGUI_Label*)[LibraryBrowserGUI_Label alloc] init];
	
	return v0;
}

-(LibraryBrowserGUI_Label*) _searchLabel {
	if (self->_searchLabel_initialized == YES) {
		return _searchLabel;
	} else { 
		[self set_searchLabel:[self initial_searchLabel]];
	}

	self->_searchLabel_initialized = YES;
	return _searchLabel;
}
-(LibraryBrowserGUI_Textfield*) initial_searchField {
	/* ==================================================
	 * Textfield::create()
	 * ================================================== */
	
	LibraryBrowserGUI_Textfield* v0 = [(LibraryBrowserGUI_Textfield*)[LibraryBrowserGUI_Textfield alloc] init];
	
	return v0;
}

-(LibraryBrowserGUI_Textfield*) _searchField {
	if (self->_searchField_initialized == YES) {
		return _searchField;
	} else { 
		[self set_searchField:[self initial_searchField]];
	}

	self->_searchField_initialized = YES;
	return _searchField;
}
-(LibraryBrowserGUI_SelectionBox*) initial_categorySelect {
	/* ==================================================
	 * SelectionBox::create(Tuple { choices = Sequence { 'Author', 'Title', 'ISBN' }})
	 * ================================================== */
	
	OCLString* v6 = [(OCLString*)[OCLString alloc] initWithString:@"Author"];
	OCLString* v5 = v6;
	OCLString* v8 = [(OCLString*)[OCLString alloc] initWithString:@"Title"];
	OCLString* v7 = v8;
	OCLString* v10 = [(OCLString*)[OCLString alloc] initWithString:@"ISBN"];
	OCLString* v9 = v10;
	OCLSequence* v4 = [(OCLSequence*)[OCLSequence alloc] init];
	[v4 add:v5];
	[v4 add:v7];
	[v4 add:v9];
	OCLSequence* v3 = v4;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"choices" withValue:v3];
	LibraryBrowserGUI_SelectionBox* v0 = [(LibraryBrowserGUI_SelectionBox*)[LibraryBrowserGUI_SelectionBox alloc] initWithValues:v2];
	[v6 release];
	[v2 release];
	[v4 release];
	[v8 release];
	[v10 release];
	
	return v0;
}

-(LibraryBrowserGUI_SelectionBox*) _categorySelect {
	if (self->_categorySelect_initialized == YES) {
		return _categorySelect;
	} else { 
		[self set_categorySelect:[self initial_categorySelect]];
	}

	self->_categorySelect_initialized = YES;
	return _categorySelect;
}
-(LibraryBrowserGUI_Button*) initial_searchButton {
	/* ==================================================
	 * Button::create(Tuple { text = 'Search' })
	 * ================================================== */
	
	OCLString* v4 = [(OCLString*)[OCLString alloc] initWithString:@"Search"];
	OCLString* v3 = v4;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"text" withValue:v3];
	LibraryBrowserGUI_Button* v0 = [(LibraryBrowserGUI_Button*)[LibraryBrowserGUI_Button alloc] initWithValues:v2];
	[v4 release];
	[v2 release];
	
	return v0;
}

-(LibraryBrowserGUI_Button*) _searchButton {
	if (self->_searchButton_initialized == YES) {
		return _searchButton;
	} else { 
		[self set_searchButton:[self initial_searchButton]];
	}

	self->_searchButton_initialized = YES;
	return _searchButton;
}
-(LibraryBrowserGUI_BookListView*) initial_resultView {
	/* ==================================================
	 * null
	 * ================================================== */
	
	LibraryBrowserGUI_BookListView* v0 = [NSNull null];
	
	return v0;
}

-(LibraryBrowserGUI_BookListView*) _resultView {
	if (self->_resultView_initialized == YES) {
		return _resultView;
	} else { 
		[self set_resultView:[self initial_resultView]];
	}

	self->_resultView_initialized = YES;
	return _resultView;
}
-(OCLString*) initial_viewTitle {
	/* ==================================================
	 * 'Search'
	 * ================================================== */
	
	OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@"Search"];
	
	return v0;
}

-(OCLString*) _viewTitle {
	if (self->_viewTitle_initialized == YES) {
		return _viewTitle;
	} else { 
		[self set_viewTitle:[self initial_viewTitle]];
	}

	self->_viewTitle_initialized = YES;
	return _viewTitle;
}
-(OCLSequence*) initial_seqGUIElements {
	/* ==================================================
	 * Sequence {searchLabel, searchField, searchButton, categorySelect }
	 * ================================================== */
	
	LibraryBrowserGUI_SearchView* v3 = self;
	LibraryBrowserGUI_Label* v2 = [v3 _searchLabel];
	LibraryBrowserGUI_Label* v1 = v2;
	LibraryBrowserGUI_SearchView* v6 = self;
	LibraryBrowserGUI_Textfield* v5 = [v6 _searchField];
	LibraryBrowserGUI_Textfield* v4 = v5;
	LibraryBrowserGUI_SearchView* v9 = self;
	LibraryBrowserGUI_Button* v8 = [v9 _searchButton];
	LibraryBrowserGUI_Button* v7 = v8;
	LibraryBrowserGUI_SearchView* v12 = self;
	LibraryBrowserGUI_SelectionBox* v11 = [v12 _categorySelect];
	LibraryBrowserGUI_SelectionBox* v10 = v11;
	OCLSequence* v0 = [(OCLSequence*)[OCLSequence alloc] init];
	[v0 add:v1];
	[v0 add:v4];
	[v0 add:v7];
	[v0 add:v10];
	
	return v0;
}

-(OCLSequence*) _seqGUIElements {
	if (self->_seqGUIElements_initialized == YES) {
		return _seqGUIElements;
	} else { 
		[self set_seqGUIElements:[self initial_seqGUIElements]];
	}

	self->_seqGUIElements_initialized = YES;
	return _seqGUIElements;
}


 
-(void) set_viewTitle:(OCLString*) value {
	 	if (self->_viewTitle!= nil && self->_viewTitle!= (OCLString*) [NSNull null]) {
		[self->_viewTitle release];
	}
	self->_viewTitle = value;
	if (self->_viewTitle!= nil && self->_viewTitle!= (OCLString*) [NSNull null]) {
		[self->_viewTitle retain];
	}
	self->_viewTitle_initialized = YES;
	
	[self onPropertyChange:@"viewTitle" newValue:value];
}
-(void) set_seqGUIElements:(OCLSequence*) value {
	 	if (self->_seqGUIElements!= nil && self->_seqGUIElements!= (OCLSequence*) [NSNull null]) {
		[self->_seqGUIElements release];
	}
	self->_seqGUIElements = value;
	if (self->_seqGUIElements!= nil && self->_seqGUIElements!= (OCLSequence*) [NSNull null]) {
		[self->_seqGUIElements retain];
	}
	self->_seqGUIElements_initialized = YES;
	
	[self onPropertyChange:@"seqGUIElements" newValue:value];
}


-(void) set_searchLabel:(LibraryBrowserGUI_Label*) value {
	 
	if (self->_searchLabel!= nil && self->_searchLabel!= (LibraryBrowserGUI_Label*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_searchLabel valueForKey:@"LibraryBrowserGUI_SearchView_searchLabel_back"];
		[backpointers removeObject:self];
		[self->_searchLabel release];
	}
	self->_searchLabel = value;
	if (self->_searchLabel!= nil && self->_searchLabel!= (LibraryBrowserGUI_Label*) [NSNull null]) {
		[self->_searchLabel retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_searchLabel valueForKey:@"LibraryBrowserGUI_SearchView_searchLabel_back"];
		[backpointers addObject:self];
	}
	self->_searchLabel_initialized = YES;
	
	[self onPropertyChange:@"searchLabel" newValue:value];
}
-(void) set_searchField:(LibraryBrowserGUI_Textfield*) value {
	 
	if (self->_searchField!= nil && self->_searchField!= (LibraryBrowserGUI_Textfield*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_searchField valueForKey:@"LibraryBrowserGUI_SearchView_searchField_back"];
		[backpointers removeObject:self];
		[self->_searchField release];
	}
	self->_searchField = value;
	if (self->_searchField!= nil && self->_searchField!= (LibraryBrowserGUI_Textfield*) [NSNull null]) {
		[self->_searchField retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_searchField valueForKey:@"LibraryBrowserGUI_SearchView_searchField_back"];
		[backpointers addObject:self];
	}
	self->_searchField_initialized = YES;
	
	[self onPropertyChange:@"searchField" newValue:value];
}
-(void) set_categorySelect:(LibraryBrowserGUI_SelectionBox*) value {
	 
	if (self->_categorySelect!= nil && self->_categorySelect!= (LibraryBrowserGUI_SelectionBox*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_categorySelect valueForKey:@"LibraryBrowserGUI_SearchView_categorySelect_back"];
		[backpointers removeObject:self];
		[self->_categorySelect release];
	}
	self->_categorySelect = value;
	if (self->_categorySelect!= nil && self->_categorySelect!= (LibraryBrowserGUI_SelectionBox*) [NSNull null]) {
		[self->_categorySelect retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_categorySelect valueForKey:@"LibraryBrowserGUI_SearchView_categorySelect_back"];
		[backpointers addObject:self];
	}
	self->_categorySelect_initialized = YES;
	
	[self onPropertyChange:@"categorySelect" newValue:value];
}
-(void) set_searchButton:(LibraryBrowserGUI_Button*) value {
	 
	if (self->_searchButton!= nil && self->_searchButton!= (LibraryBrowserGUI_Button*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_searchButton valueForKey:@"LibraryBrowserGUI_SearchView_searchButton_back"];
		[backpointers removeObject:self];
		[self->_searchButton release];
	}
	self->_searchButton = value;
	if (self->_searchButton!= nil && self->_searchButton!= (LibraryBrowserGUI_Button*) [NSNull null]) {
		[self->_searchButton retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_searchButton valueForKey:@"LibraryBrowserGUI_SearchView_searchButton_back"];
		[backpointers addObject:self];
	}
	self->_searchButton_initialized = YES;
	
	[self onPropertyChange:@"searchButton" newValue:value];
}
-(void) set_resultView:(LibraryBrowserGUI_BookListView*) value {
	 
	if (self->_resultView!= nil && self->_resultView!= (LibraryBrowserGUI_BookListView*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_resultView valueForKey:@"LibraryBrowserGUI_SearchView_resultView_back"];
		[backpointers removeObject:self];
		[self->_resultView release];
	}
	self->_resultView = value;
	if (self->_resultView!= nil && self->_resultView!= (LibraryBrowserGUI_BookListView*) [NSNull null]) {
		[self->_resultView retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_resultView valueForKey:@"LibraryBrowserGUI_SearchView_resultView_back"];
		[backpointers addObject:self];
	}
	self->_resultView_initialized = YES;
	
	[self onPropertyChange:@"resultView" newValue:value];
}




 

 
-(void) event_searchButtonClicked_pushed:(PropertyChangeList*) changes  {
	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_searchButtonClicked", @"LibraryBrowserGUI_SearchView");

		OCLTuple* parameters = [[OCLTuple alloc] init];

		[self onEvent:@"searchButtonClicked" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {

			[self event_searchBook_pushed:changes ];
		}
		[v0 release];


		 
		 // Process impacts relationships


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_searchButtonClicked_pulled_edge0:(PropertyChangeList*)changes parentInstance:(LibraryBrowserGUI_Button*)parentInstance  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_searchButtonClicked", @"LibraryBrowserGUI_SearchView", @"_clicked", @"LibraryBrowserGUI_Button");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {

		[self event_searchButtonClicked_pushed:changes ];

	}
	[v0 release];
}


-(void) event_searchFinished_pushed:(PropertyChangeList*) changes  p_booksFound: (OCLSequence*) p_booksFound{
	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_searchFinished", @"LibraryBrowserGUI_SearchView");

		OCLTuple* parameters = [[OCLTuple alloc] init];
		[parameters addItemNamed:@"booksFound" withValue:p_booksFound]; 

		[self onEvent:@"searchFinished" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * BookListView::create(
		 * 	Tuple { 
		 * 		bookListTable = booksFound, 
		 * 		bookDetailView = null 
		 * 	})
		 * ================================================== */
		
		OCLSequence* v4 = p_booksFound;
		OCLSequence* v3 = v4;
		id v6 = [NSNull null];
		id v5 = v6;
		OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
		[v2 addItemNamed:@"bookListTable" withValue:v3];
		[v2 addItemNamed:@"bookDetailView" withValue:v5];
		LibraryBrowserGUI_BookListView* v0 = [(LibraryBrowserGUI_BookListView*)[LibraryBrowserGUI_BookListView alloc] initWithValues:v2];
		[v2 release];
		
		LibraryBrowserGUI_BookListView* _resultView_newValue = v0;
		[changes addChange:@selector(set_resultView:) instance:self value:_resultView_newValue];


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_selectedBookData_pushed:(PropertyChangeList*) changes  p_author: (OCLString*) p_author p_title: (OCLString*) p_title p_isbn: (OCLString*) p_isbn{
	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_selectedBookData", @"LibraryBrowserGUI_SearchView");

		OCLTuple* parameters = [[OCLTuple alloc] init];
		[parameters addItemNamed:@"author" withValue:p_author]; 
		[parameters addItemNamed:@"title" withValue:p_title]; 
		[parameters addItemNamed:@"isbn" withValue:p_isbn]; 

		[self onEvent:@"selectedBookData" withParameters:parameters];

		 
		// Trigger Push edges

		if (self->_resultView != nil && self->_resultView != (LibraryBrowserGUI_BookListView*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_resultView];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			LibraryBrowserGUI_BookListView* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * author
				 * ================================================== */
				
				OCLString* v1 = p_author;
				
					OCLString* parameter_p_author = v1;
					/* ==================================================
				 * title
				 * ================================================== */
				
				OCLString* v2 = p_title;
				
					OCLString* parameter_p_title = v2;
					/* ==================================================
				 * isbn
				 * ================================================== */
				
				OCLString* v3 = p_isbn;
				
					OCLString* parameter_p_isbn = v3;

					[edge0_target event_selectedBookData_pushed:changes p_author:parameter_p_author p_title:parameter_p_title p_isbn:parameter_p_isbn ];

				}
				[v0 release];
			}
			// Release targets collection
			[edge0_values release];

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_bookSelected_pushed:(PropertyChangeList*) changes  p_id: (OCLInteger*) p_id{
	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_bookSelected", @"LibraryBrowserGUI_SearchView");

		OCLTuple* parameters = [[OCLTuple alloc] init];
		[parameters addItemNamed:@"id" withValue:p_id]; 

		[self onEvent:@"bookSelected" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges
		NSEnumerator* LibraryBrowserGUI_MainWindow_bookSelected_edge0_enum = [self->LibraryBrowserGUI_MainWindow_searchView_back objectEnumerator];
		LibraryBrowserGUI_MainWindow* LibraryBrowserGUI_MainWindow_bookSelected_edge0_target;
		while ((LibraryBrowserGUI_MainWindow_bookSelected_edge0_target = [LibraryBrowserGUI_MainWindow_bookSelected_edge0_enum nextObject]) != nil) {
		    [LibraryBrowserGUI_MainWindow_bookSelected_edge0_target event_bookSelected_pulled_edge0:changes parentInstance:self p_id:p_id ];
		}



		 	
		// Trigger local edges


		 
		 // Process impacts relationships


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_bookSelected_pulled_edge0:(PropertyChangeList*)changes parentInstance:(LibraryBrowserGUI_BookListView*)parentInstance p_id:(OCLInteger*)p_id  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_bookSelected", @"LibraryBrowserGUI_SearchView", @"_bookSelected", @"LibraryBrowserGUI_BookListView");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {
		/* ==================================================
		 * id
		 * ================================================== */
		
		OCLInteger* v1 = p_id;
		
		OCLInteger* parameter_p_id = v1;

		[self event_bookSelected_pushed:changes p_id:parameter_p_id ];

	}
	[v0 release];
}


-(void) event_searchBook_pushed:(PropertyChangeList*) changes  {
	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_searchBook", @"LibraryBrowserGUI_SearchView");

		OCLTuple* parameters = [[OCLTuple alloc] init];

		[self onEvent:@"searchBook" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges
		NSEnumerator* LibraryBrowserGUI_MainWindow_searchBook_edge0_enum = [self->LibraryBrowserGUI_MainWindow_searchView_back objectEnumerator];
		LibraryBrowserGUI_MainWindow* LibraryBrowserGUI_MainWindow_searchBook_edge0_target;
		while ((LibraryBrowserGUI_MainWindow_searchBook_edge0_target = [LibraryBrowserGUI_MainWindow_searchBook_edge0_enum nextObject]) != nil) {
		    [LibraryBrowserGUI_MainWindow_searchBook_edge0_target event_searchBook_pulled_edge0:changes parentInstance:self ];
		}



		 	
		// Trigger local edges


		 
		 // Process impacts relationships


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 




 
- (void) addWidgets: (UIView *) view {
	OCLSequence* widgets = [self _seqGUIElements];
	int y_pos = 0;
	NSEnumerator* e = [widgets objectEnumerator];
	id object;
	while ((object = [e nextObject])) {
		if ([object conformsToProtocol:@protocol(IBinding)]) {
			id<IBinding> propBinding = [object getBinding];
			if (![propBinding isKindOfClass: [UIPickerView class]]){
				((UIView*) propBinding).frame = CGRectMake(20, y_pos + 10, 280, 30);
				y_pos += 40;
			} else {
				((UIView*) propBinding).frame  = CGRectMake(0,  y_pos + 10 , 320, 162);
				y_pos += 172;
			}
			[view addSubview: (UIView*) propBinding];
		}
	}
}

 
-(void)onPropertyChange:(NSString*)propertyName newValue:(id) value {
	if ([propertyName isEqual:@"viewTitle"]) {
		if (value != nil && value != [NSNull null]) 
			[self->rootViewController setTitle: ((OCLString *) value)->string ];
	}
	 
	if ([value conformsToProtocol:@protocol(IBinding)]) {
		id propBinding = [value getBinding];
		if ([propBinding isKindOfClass: [UIViewController class]] && self->navigationController != nil) {
			[self->navigationController pushViewController:(UIViewController *)propBinding animated: YES];
			[value setBindingAttribute: @"navigationController" newValue: self->navigationController];
		}
	}

}

 
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters{
}

 
-(id) getBinding {
	return self->binding;
}

 
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value {
}


@end 



