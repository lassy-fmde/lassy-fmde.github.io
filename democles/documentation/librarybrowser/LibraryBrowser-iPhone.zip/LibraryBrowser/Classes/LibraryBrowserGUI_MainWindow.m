  
 
 
#import "LibraryBrowserGUI_MainWindow.h"
#import "PropertyChangeList.h"
#import "LibraryBrowserGUI_SearchView.h"
#import "LibraryBrowserGUI_TabbedWindow.h"
#import "LibraryBrowserGUI_HomeView.h"
#import "Application_Main.h"


 
@implementation LibraryBrowserGUI_MainWindow

 
- (id) init {
	self = [super init];
	 	
	self->binding = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	self->binding.backgroundColor = [UIColor whiteColor];
	self->rootControllerAdded = NO;

	 
	self->Application_Main_mainGUI_back = [[NSMutableArray alloc] init];

	[self set_searchView: [self _searchView]];
	[self set_homeView: [self _homeView]];
	[self set_viewSelector: [self _viewSelector]];


	return self;
}

 - (id) initWithValues: (OCLTuple*) values {
	self = [super init];
	 	
	self->binding = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
	self->binding.backgroundColor = [UIColor whiteColor];
	self->rootControllerAdded = NO;

	 
	self->_searchView_initialized = NO;
	self->_homeView_initialized = NO;
	self->_viewSelector_initialized = NO;

	self->Application_Main_mainGUI_back = [[NSMutableArray alloc] init];

	LibraryBrowserGUI_SearchView* _searchView_initialValue = (LibraryBrowserGUI_SearchView*) [values objectForKey:@"searchView"];
	if (_searchView_initialValue == nil) {
		_searchView_initialValue = [self _searchView];
	}
	[self set_searchView:_searchView_initialValue];
	LibraryBrowserGUI_HomeView* _homeView_initialValue = (LibraryBrowserGUI_HomeView*) [values objectForKey:@"homeView"];
	if (_homeView_initialValue == nil) {
		_homeView_initialValue = [self _homeView];
	}
	[self set_homeView:_homeView_initialValue];
	LibraryBrowserGUI_TabbedWindow* _viewSelector_initialValue = (LibraryBrowserGUI_TabbedWindow*) [values objectForKey:@"viewSelector"];
	if (_viewSelector_initialValue == nil) {
		_viewSelector_initialValue = [self _viewSelector];
	}
	[self set_viewSelector:_viewSelector_initialValue];


	return self;
}

 
- (void) dealloc {
	if (self->_searchView != nil && self->_searchView != (LibraryBrowserGUI_SearchView*) [NSNull null]) [self->_searchView release];
	if (self->_homeView != nil && self->_homeView != (LibraryBrowserGUI_HomeView*) [NSNull null]) [self->_homeView release];
	if (self->_viewSelector != nil && self->_viewSelector != (LibraryBrowserGUI_TabbedWindow*) [NSNull null]) [self->_viewSelector release];

	[self->Application_Main_mainGUI_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"LibraryBrowserGUI::MainWindow\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"searchView\" type=\"LibraryBrowserGUI::SearchView\">\n"];
	[res appendFormat:@"%@\n", [self _searchView]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"homeView\" type=\"LibraryBrowserGUI::HomeView\">\n"];
	[res appendFormat:@"%@\n", [self _homeView]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"viewSelector\" type=\"LibraryBrowserGUI::TabbedWindow\">\n"];
	[res appendFormat:@"%@\n", [self _viewSelector]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
-(LibraryBrowserGUI_SearchView*) initial_searchView {
	/* ==================================================
	 * LibraryBrowserGUI::SearchView::create()
	 * ================================================== */
	
	LibraryBrowserGUI_SearchView* v0 = [(LibraryBrowserGUI_SearchView*)[LibraryBrowserGUI_SearchView alloc] init];
	
	return v0;
}

-(LibraryBrowserGUI_SearchView*) _searchView {
	if (self->_searchView_initialized == YES) {
		return _searchView;
	} else { 
		[self set_searchView:[self initial_searchView]];
	}

	self->_searchView_initialized = YES;
	return _searchView;
}
-(LibraryBrowserGUI_HomeView*) initial_homeView {
	/* ==================================================
	 * HomeView::create()
	 * ================================================== */
	
	LibraryBrowserGUI_HomeView* v0 = [(LibraryBrowserGUI_HomeView*)[LibraryBrowserGUI_HomeView alloc] init];
	
	return v0;
}

-(LibraryBrowserGUI_HomeView*) _homeView {
	if (self->_homeView_initialized == YES) {
		return _homeView;
	} else { 
		[self set_homeView:[self initial_homeView]];
	}

	self->_homeView_initialized = YES;
	return _homeView;
}
-(LibraryBrowserGUI_TabbedWindow*) initial_viewSelector {
	/* ==================================================
	 * TabbedWindow::create(
	 * 	Tuple { views = Sequence { homeView, searchView}}
	 * )
	 * ================================================== */
	
	LibraryBrowserGUI_MainWindow* v7 = self;
	LibraryBrowserGUI_HomeView* v6 = [v7 _homeView];
	LibraryBrowserGUI_HomeView* v5 = v6;
	LibraryBrowserGUI_MainWindow* v10 = self;
	LibraryBrowserGUI_SearchView* v9 = [v10 _searchView];
	LibraryBrowserGUI_SearchView* v8 = v9;
	OCLSequence* v4 = [(OCLSequence*)[OCLSequence alloc] init];
	[v4 add:v5];
	[v4 add:v8];
	OCLSequence* v3 = v4;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"views" withValue:v3];
	LibraryBrowserGUI_TabbedWindow* v0 = [(LibraryBrowserGUI_TabbedWindow*)[LibraryBrowserGUI_TabbedWindow alloc] initWithValues:v2];
	[v4 release];
	[v2 release];
	
	return v0;
}

-(LibraryBrowserGUI_TabbedWindow*) _viewSelector {
	if (self->_viewSelector_initialized == YES) {
		return _viewSelector;
	} else { 
		[self set_viewSelector:[self initial_viewSelector]];
	}

	self->_viewSelector_initialized = YES;
	return _viewSelector;
}


 


-(void) set_searchView:(LibraryBrowserGUI_SearchView*) value {
	 
	if (self->_searchView!= nil && self->_searchView!= (LibraryBrowserGUI_SearchView*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_searchView valueForKey:@"LibraryBrowserGUI_MainWindow_searchView_back"];
		[backpointers removeObject:self];
		[self->_searchView release];
	}
	self->_searchView = value;
	if (self->_searchView!= nil && self->_searchView!= (LibraryBrowserGUI_SearchView*) [NSNull null]) {
		[self->_searchView retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_searchView valueForKey:@"LibraryBrowserGUI_MainWindow_searchView_back"];
		[backpointers addObject:self];
	}
	self->_searchView_initialized = YES;
	
	[self onPropertyChange:@"searchView" newValue:value];
}
-(void) set_homeView:(LibraryBrowserGUI_HomeView*) value {
	 
	if (self->_homeView!= nil && self->_homeView!= (LibraryBrowserGUI_HomeView*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_homeView valueForKey:@"LibraryBrowserGUI_MainWindow_homeView_back"];
		[backpointers removeObject:self];
		[self->_homeView release];
	}
	self->_homeView = value;
	if (self->_homeView!= nil && self->_homeView!= (LibraryBrowserGUI_HomeView*) [NSNull null]) {
		[self->_homeView retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_homeView valueForKey:@"LibraryBrowserGUI_MainWindow_homeView_back"];
		[backpointers addObject:self];
	}
	self->_homeView_initialized = YES;
	
	[self onPropertyChange:@"homeView" newValue:value];
}
-(void) set_viewSelector:(LibraryBrowserGUI_TabbedWindow*) value {
	 
	if (self->_viewSelector!= nil && self->_viewSelector!= (LibraryBrowserGUI_TabbedWindow*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_viewSelector valueForKey:@"LibraryBrowserGUI_MainWindow_viewSelector_back"];
		[backpointers removeObject:self];
		[self->_viewSelector release];
	}
	self->_viewSelector = value;
	if (self->_viewSelector!= nil && self->_viewSelector!= (LibraryBrowserGUI_TabbedWindow*) [NSNull null]) {
		[self->_viewSelector retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_viewSelector valueForKey:@"LibraryBrowserGUI_MainWindow_viewSelector_back"];
		[backpointers addObject:self];
	}
	self->_viewSelector_initialized = YES;
	
	[self onPropertyChange:@"viewSelector" newValue:value];
}




 

 
-(void) event_searchBook_pushed:(PropertyChangeList*) changes  p_keyword: (OCLString*) p_keyword p_category: (OCLString*) p_category{
	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_searchBook", @"LibraryBrowserGUI_MainWindow");

		OCLTuple* parameters = [[OCLTuple alloc] init];
		[parameters addItemNamed:@"keyword" withValue:p_keyword]; 
		[parameters addItemNamed:@"category" withValue:p_category]; 

		[self onEvent:@"searchBook" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges
		NSEnumerator* Application_Main_searchBook_edge0_enum = [self->Application_Main_mainGUI_back objectEnumerator];
		Application_Main* Application_Main_searchBook_edge0_target;
		while ((Application_Main_searchBook_edge0_target = [Application_Main_searchBook_edge0_enum nextObject]) != nil) {
		    [Application_Main_searchBook_edge0_target event_searchBook_pulled_edge0:changes parentInstance:self p_keyword:p_keyword p_category:p_category ];
		}



		 	
		// Trigger local edges


		 
		 // Process impacts relationships


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_searchBook_pulled_edge0:(PropertyChangeList*)changes parentInstance:(LibraryBrowserGUI_SearchView*)parentInstance  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_searchBook", @"LibraryBrowserGUI_MainWindow", @"_searchBook", @"LibraryBrowserGUI_SearchView");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {
		/* ==================================================
		 * searchField.text
		 * ================================================== */
		
		LibraryBrowserGUI_Textfield* v2 = [parentInstance _searchField];
		OCLString* v1 = [v2 _text];
		
		OCLString* parameter_p_keyword = v1;
		/* ==================================================
		 * categorySelect.selectedChoice
		 * ================================================== */
		
		LibraryBrowserGUI_SelectionBox* v4 = [parentInstance _categorySelect];
		OCLString* v3 = [v4 _selectedChoice];
		
		OCLString* parameter_p_category = v3;

		[self event_searchBook_pushed:changes p_keyword:parameter_p_keyword p_category:parameter_p_category ];

	}
	[v0 release];
}


-(void) event_searchFinished_pushed:(PropertyChangeList*) changes  p_booksFound: (OCLSequence*) p_booksFound{
	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_searchFinished", @"LibraryBrowserGUI_MainWindow");

		OCLTuple* parameters = [[OCLTuple alloc] init];
		[parameters addItemNamed:@"booksFound" withValue:p_booksFound]; 

		[self onEvent:@"searchFinished" withParameters:parameters];

		 
		// Trigger Push edges

		if (self->_searchView != nil && self->_searchView != (LibraryBrowserGUI_SearchView*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_searchView];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			LibraryBrowserGUI_SearchView* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * booksFound
				 * ================================================== */
				
				OCLSequence* v1 = p_booksFound;
				
					OCLSequence* parameter_p_booksFound = v1;

					[edge0_target event_searchFinished_pushed:changes p_booksFound:parameter_p_booksFound ];

				}
				[v0 release];
			}
			// Release targets collection
			[edge0_values release];

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_bookSelected_pushed:(PropertyChangeList*) changes  p_id: (OCLInteger*) p_id{
	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_bookSelected", @"LibraryBrowserGUI_MainWindow");

		OCLTuple* parameters = [[OCLTuple alloc] init];
		[parameters addItemNamed:@"id" withValue:p_id]; 

		[self onEvent:@"bookSelected" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges
		NSEnumerator* Application_Main_bookSelected_edge0_enum = [self->Application_Main_mainGUI_back objectEnumerator];
		Application_Main* Application_Main_bookSelected_edge0_target;
		while ((Application_Main_bookSelected_edge0_target = [Application_Main_bookSelected_edge0_enum nextObject]) != nil) {
		    [Application_Main_bookSelected_edge0_target event_bookSelected_pulled_edge0:changes parentInstance:self p_id:p_id ];
		}



		 	
		// Trigger local edges


		 
		 // Process impacts relationships


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_bookSelected_pulled_edge0:(PropertyChangeList*)changes parentInstance:(LibraryBrowserGUI_SearchView*)parentInstance p_id:(OCLInteger*)p_id  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_bookSelected", @"LibraryBrowserGUI_MainWindow", @"_bookSelected", @"LibraryBrowserGUI_SearchView");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {
		/* ==================================================
		 * id
		 * ================================================== */
		
		OCLInteger* v1 = p_id;
		
		OCLInteger* parameter_p_id = v1;

		[self event_bookSelected_pushed:changes p_id:parameter_p_id ];

	}
	[v0 release];
}


-(void) event_selectedBookData_pushed:(PropertyChangeList*) changes  p_author: (OCLString*) p_author p_title: (OCLString*) p_title p_isbn: (OCLString*) p_isbn{
	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_selectedBookData", @"LibraryBrowserGUI_MainWindow");

		OCLTuple* parameters = [[OCLTuple alloc] init];
		[parameters addItemNamed:@"author" withValue:p_author]; 
		[parameters addItemNamed:@"title" withValue:p_title]; 
		[parameters addItemNamed:@"isbn" withValue:p_isbn]; 

		[self onEvent:@"selectedBookData" withParameters:parameters];

		 
		// Trigger Push edges

		if (self->_searchView != nil && self->_searchView != (LibraryBrowserGUI_SearchView*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_searchView];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			LibraryBrowserGUI_SearchView* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * author
				 * ================================================== */
				
				OCLString* v1 = p_author;
				
					OCLString* parameter_p_author = v1;
					/* ==================================================
				 * title
				 * ================================================== */
				
				OCLString* v2 = p_title;
				
					OCLString* parameter_p_title = v2;
					/* ==================================================
				 * isbn
				 * ================================================== */
				
				OCLString* v3 = p_isbn;
				
					OCLString* parameter_p_isbn = v3;

					[edge0_target event_selectedBookData_pushed:changes p_author:parameter_p_author p_title:parameter_p_title p_isbn:parameter_p_isbn ];

				}
				[v0 release];
			}
			// Release targets collection
			[edge0_values release];

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 




 
-(void)onPropertyChange:(NSString*)propertyName newValue:(id) value {
	if ([propertyName isEqual:@"viewSelector"]) {
		if ([value conformsToProtocol:@protocol(IBinding)]) {
			id<IBinding> propBinding = [value getBinding];
			if (self->rootControllerAdded == NO && [propBinding isKindOfClass: [UIViewController class]]) {
				[self->binding addSubview: ((UIViewController *)propBinding).view];
				[self->binding makeKeyAndVisible];
				self->rootControllerAdded = YES;
			}else{
				NSLog(@"Property change in model %@ NOT VALID:\n -%@ parameter binding is not of class UIViewController\n-Or view has already been added to Window",@"LibraryBrowserGUI_MainWindow", @"viewSelector");
			}
		}else{
			NSLog(@"Property change in model %@ NOT VALID:\n -%@ does not conform with protocol IBinding",@"LibraryBrowserGUI_MainWindow", @"viewSelector");
		}
	}
}

 
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters{
}

 
-(id) getBinding {
	return self->binding;
}

 
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value {
}


@end 



