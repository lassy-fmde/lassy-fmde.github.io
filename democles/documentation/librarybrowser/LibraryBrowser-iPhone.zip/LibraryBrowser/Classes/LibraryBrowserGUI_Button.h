  
 
 
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "OCLTypes.h"
#import "IBinding.h"

@class PropertyChangeList;
@class LibraryBrowserGUI_SearchView;


 
 
@interface LibraryBrowserGUI_Button : OCLAny <IBinding>
{
	 
	OCLString* _text;
	BOOL _text_initialized;


@public
	NSMutableArray *LibraryBrowserGUI_SearchView_searchButton_back;


	
	@protected
	UIButton* binding;
}

 
-(LibraryBrowserGUI_Button*)init;
-(LibraryBrowserGUI_Button*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(OCLString*) _text;
-(OCLString*) initial_text;
-(void) set_text:(OCLString*) value;

-(void) event_clicked_pushed:(PropertyChangeList*) changes ;

 
-(id) getBinding;
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value;
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters;
-(void) onPropertyChange: (NSString*)propertyName newValue:(id<OCLAny>)value;


@end



