  
 
 
#import "LibraryBrowserGUI_Button.h"
#import "PropertyChangeList.h"
#import "LibraryBrowserGUI_SearchView.h"


 
@implementation LibraryBrowserGUI_Button

 
- (id) init {
	self = [super init];
	 
	self->binding = [UIButton buttonWithType:UIButtonTypeRoundedRect];

	 
	self->LibraryBrowserGUI_SearchView_searchButton_back = [[NSMutableArray alloc] init];

	[self set_text: [self _text]];


	 
	[self->binding addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];

	return self;
}

 
- (id) initWithValues: (OCLTuple*) values {
	self = [super init];
	 
	self->binding = [UIButton buttonWithType:UIButtonTypeRoundedRect];

	 
	self->_text_initialized = NO;

	self->LibraryBrowserGUI_SearchView_searchButton_back = [[NSMutableArray alloc] init];

	OCLString* _text_initialValue = (OCLString*) [values objectForKey:@"text"];
	if (_text_initialValue == nil) {
		_text_initialValue = [self _text];
	}
	[self set_text:_text_initialValue];


	 
	[self->binding addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];

	return self;
}

 
- (void) dealloc {
	if (self->_text != nil && self->_text != (OCLString*) [NSNull null]) [self->_text release];

	[self->LibraryBrowserGUI_SearchView_searchButton_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"LibraryBrowserGUI::Button\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"text\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _text]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
- (id) buttonClicked: (id) sender {
	[self event_clicked_pushed:nil];
	return nil;
}

 
-(OCLString*) initial_text {
	/* ==================================================
	 * ''
	 * ================================================== */
	
	OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@""];
	
	return v0;
}

-(OCLString*) _text {
	if (self->_text_initialized == YES) {
		return _text;
	} else { 
		[self set_text:[self initial_text]];
	}

	self->_text_initialized = YES;
	return _text;
}


 
-(void) set_text:(OCLString*) value {
	 	if (self->_text!= nil && self->_text!= (OCLString*) [NSNull null]) {
		[self->_text release];
	}
	self->_text = value;
	if (self->_text!= nil && self->_text!= (OCLString*) [NSNull null]) {
		[self->_text retain];
	}
	self->_text_initialized = YES;
	
	[self onPropertyChange:@"text" newValue:value];
}






 

 
-(void) event_clicked_pushed:(PropertyChangeList*) changes  {
	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_clicked", @"LibraryBrowserGUI_Button");

		OCLTuple* parameters = [[OCLTuple alloc] init];

		[self onEvent:@"clicked" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges
		NSEnumerator* LibraryBrowserGUI_SearchView_searchButtonClicked_edge0_enum = [self->LibraryBrowserGUI_SearchView_searchButton_back objectEnumerator];
		LibraryBrowserGUI_SearchView* LibraryBrowserGUI_SearchView_searchButtonClicked_edge0_target;
		while ((LibraryBrowserGUI_SearchView_searchButtonClicked_edge0_target = [LibraryBrowserGUI_SearchView_searchButtonClicked_edge0_enum nextObject]) != nil) {
		    [LibraryBrowserGUI_SearchView_searchButtonClicked_edge0_target event_searchButtonClicked_pulled_edge0:changes parentInstance:self ];
		}



		 	
		// Trigger local edges


		 
		 // Process impacts relationships


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 




 
-(void)onPropertyChange:(NSString*)propertyName newValue:(id) value {
	if ([propertyName isEqual:@"text"]) {
		if (value != nil && value != [NSNull null]){
			OCLString *text = (OCLString *) value;
			[self->binding setTitle:text->string forState:UIControlStateNormal];
		}
	}
}

 
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters{
}

 
-(id) getBinding {
	return self->binding;
}

 
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value {
}


@end 



