  
 
 
#import "Persistence_FileHandler.h"
#import "PropertyChangeList.h"
#import "LibraryPersistenceHandler_LibraryLoader.h"


 
@implementation Persistence_FileHandler

 
- (Persistence_FileHandler*) init {
	self = [super init];
	 
	self->LibraryPersistenceHandler_LibraryLoader_fileHandler_back = [[NSMutableArray alloc] init];


	return self;
}

 
- (Persistence_FileHandler*) initWithValues: (OCLTuple*) values {
	self = [super init];
	 

	self->LibraryPersistenceHandler_LibraryLoader_fileHandler_back = [[NSMutableArray alloc] init];


	
	return self;
}

 
- (void) dealloc {

	[self->LibraryPersistenceHandler_LibraryLoader_fileHandler_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"Persistence::FileHandler\" retainCount=\"%i\">\n", self, [self retainCount]];
	
	[res appendString:@"</instance>\n"];
	return res;
}

 


 






 

 
-(void) event_openFile_pushed:(PropertyChangeList*) changes  p_filename: (OCLString*) p_filename{
	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_openFile", @"Persistence_FileHandler");

		OCLTuple* parameters = [[OCLTuple alloc] init];
		[parameters addItemNamed:@"filename" withValue:p_filename]; 

		[self onEvent:@"openFile" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_fileOpened_pushed:(PropertyChangeList*) changes  {
	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_fileOpened", @"Persistence_FileHandler");

		OCLTuple* parameters = [[OCLTuple alloc] init];

		[self onEvent:@"fileOpened" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges
		NSEnumerator* LibraryPersistenceHandler_LibraryLoader_libraryFileRead_edge0_enum = [self->LibraryPersistenceHandler_LibraryLoader_fileHandler_back objectEnumerator];
		LibraryPersistenceHandler_LibraryLoader* LibraryPersistenceHandler_LibraryLoader_libraryFileRead_edge0_target;
		while ((LibraryPersistenceHandler_LibraryLoader_libraryFileRead_edge0_target = [LibraryPersistenceHandler_LibraryLoader_libraryFileRead_edge0_enum nextObject]) != nil) {
		    [LibraryPersistenceHandler_LibraryLoader_libraryFileRead_edge0_target event_libraryFileRead_pulled_edge0:changes parentInstance:self ];
		}



		 	
		// Trigger local edges


		 
		 // Process impacts relationships


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_lineread_pushed:(PropertyChangeList*) changes  p_line: (OCLString*) p_line{
	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_lineread", @"Persistence_FileHandler");

		OCLTuple* parameters = [[OCLTuple alloc] init];
		[parameters addItemNamed:@"line" withValue:p_line]; 

		[self onEvent:@"lineread" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges
		NSEnumerator* LibraryPersistenceHandler_LibraryLoader_bookLineRead_edge0_enum = [self->LibraryPersistenceHandler_LibraryLoader_fileHandler_back objectEnumerator];
		LibraryPersistenceHandler_LibraryLoader* LibraryPersistenceHandler_LibraryLoader_bookLineRead_edge0_target;
		while ((LibraryPersistenceHandler_LibraryLoader_bookLineRead_edge0_target = [LibraryPersistenceHandler_LibraryLoader_bookLineRead_edge0_enum nextObject]) != nil) {
		    [LibraryPersistenceHandler_LibraryLoader_bookLineRead_edge0_target event_bookLineRead_pulled_edge0:changes parentInstance:self p_line:p_line ];
		}



		 	
		// Trigger local edges


		 
		 // Process impacts relationships


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_fileClosed_pushed:(PropertyChangeList*) changes  {
	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_fileClosed", @"Persistence_FileHandler");

		OCLTuple* parameters = [[OCLTuple alloc] init];

		[self onEvent:@"fileClosed" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges
		NSEnumerator* LibraryPersistenceHandler_LibraryLoader_libraryFileClosed_edge0_enum = [self->LibraryPersistenceHandler_LibraryLoader_fileHandler_back objectEnumerator];
		LibraryPersistenceHandler_LibraryLoader* LibraryPersistenceHandler_LibraryLoader_libraryFileClosed_edge0_target;
		while ((LibraryPersistenceHandler_LibraryLoader_libraryFileClosed_edge0_target = [LibraryPersistenceHandler_LibraryLoader_libraryFileClosed_edge0_enum nextObject]) != nil) {
		    [LibraryPersistenceHandler_LibraryLoader_libraryFileClosed_edge0_target event_libraryFileClosed_pulled_edge0:changes parentInstance:self ];
		}



		 	
		// Trigger local edges


		 
		 // Process impacts relationships


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 




 
-(void)onPropertyChange:(NSString*)propertyName newValue:(id) value {
}

 
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters{
	if ([eventName isEqual:@"openFile"]) {
		if (parameters != nil && parameters != [NSNull null]){
			OCLString* filename = (OCLString *) [parameters objectForKey:@"filename"];
			NSBundle *mainBundle = [NSBundle mainBundle];
			NSString *filePath = [mainBundle pathForResource:[filename->string stringByDeletingPathExtension] ofType:[filename->string pathExtension]];
			NSString *content = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error: nil];
			if (content != nil)
				[self event_fileOpened_pushed:nil];
			else
				return;
			
			NSArray *lines = [content componentsSeparatedByString: @"\n"];
			
			NSEnumerator *e = [lines objectEnumerator];
			id line;
			while (line = [e nextObject]){
				OCLString *oclLine = [[OCLString alloc] initWithString:(NSString *)line ];
				[self event_lineread_pushed:nil p_line: oclLine];
			}
			
			
			[self event_fileClosed_pushed:nil];
		}
	}
}

 
-(id) getBinding {
	return [NSNull null];
}

 
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value {
}


@end 



