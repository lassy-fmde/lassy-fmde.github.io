  
 
 
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "OCLTypes.h"
#import "IBinding.h"

@class PropertyChangeList;
@class LibraryBrowserGUI_MainWindow;


 
 
@interface LibraryBrowserGUI_TabbedWindow : OCLAny <IBinding>
{
	 
	OCLSequence* _views;
	BOOL _views_initialized;


@public
	NSMutableArray *LibraryBrowserGUI_MainWindow_viewSelector_back;


	
	@protected
	UITabBarController* binding;
	BOOL viewControllersAdded;
}

 
-(LibraryBrowserGUI_TabbedWindow*)init;
-(LibraryBrowserGUI_TabbedWindow*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(OCLSequence*) _views;
-(OCLSequence*) initial_views;
-(void) set_views:(OCLSequence*) value;


 
-(id) getBinding;
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value;
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters;
-(void) onPropertyChange: (NSString*)propertyName newValue:(id<OCLAny>)value;


@end



