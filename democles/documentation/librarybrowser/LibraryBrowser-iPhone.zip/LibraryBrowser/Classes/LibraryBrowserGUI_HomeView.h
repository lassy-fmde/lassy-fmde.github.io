  
 
 
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "OCLTypes.h"
#import "IBinding.h"

@class PropertyChangeList;
@class LibraryBrowserGUI_Label;
@class LibraryBrowserGUI_MainWindow;


 
 
@interface LibraryBrowserGUI_HomeView : OCLAny <IBinding>
{
	 
	LibraryBrowserGUI_Label* _titleLabel;
	BOOL _titleLabel_initialized;
	OCLString* _viewTitle;
	BOOL _viewTitle_initialized;
	OCLSequence* _seqGUIElements;
	BOOL _seqGUIElements_initialized;


@public
	NSMutableArray *LibraryBrowserGUI_MainWindow_homeView_back;


	
	@protected
	UIViewController* binding;
	UINavigationController* navigationController;
}

 
-(LibraryBrowserGUI_HomeView*)init;
-(LibraryBrowserGUI_HomeView*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(LibraryBrowserGUI_Label*) _titleLabel;
-(LibraryBrowserGUI_Label*) initial_titleLabel;
-(void) set_titleLabel:(LibraryBrowserGUI_Label*) value;
-(OCLString*) _viewTitle;
-(OCLString*) initial_viewTitle;
-(void) set_viewTitle:(OCLString*) value;
-(OCLSequence*) _seqGUIElements;
-(OCLSequence*) initial_seqGUIElements;
-(void) set_seqGUIElements:(OCLSequence*) value;


 
-(id) getBinding;
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value;
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters;
-(void) onPropertyChange: (NSString*)propertyName newValue:(id<OCLAny>)value;

 
-(void) addWidgets: (UIView *) view;


@end



