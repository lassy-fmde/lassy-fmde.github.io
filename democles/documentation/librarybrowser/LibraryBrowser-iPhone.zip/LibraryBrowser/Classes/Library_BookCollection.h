  
 
 
#import <Foundation/Foundation.h>
#import "OCLTypes.h"

@class PropertyChangeList;
@class Library_Book;
@class LibraryPersistenceHandler_LibraryLoader;
@class Application_Main;


 
 
@interface Library_BookCollection : OCLAny  
 {
	 
	OCLSequence* _Books;
	BOOL _Books_initialized;


@public
	NSMutableArray *LibraryPersistenceHandler_LibraryLoader_libraryBooks_back;
	NSMutableArray *Application_Main_completeBookCollection_back;
	NSMutableArray *Application_Main_booksFound_back;


}

 
-(Library_BookCollection*)init;
-(Library_BookCollection*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(OCLSequence*) _Books;
-(OCLSequence*) initial_Books;
-(void) set_Books:(OCLSequence*) value;



@end



