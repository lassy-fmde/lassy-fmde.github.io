  
 
 
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "OCLTypes.h"
#import "IBinding.h"

@class PropertyChangeList;
@class LibraryBrowserGUI_Textfield;
@class LibraryBrowserGUI_BookListView;
@class LibraryBrowserGUI_Label;
@class LibraryBrowserGUI_SearchView;
@class LibraryBrowserGUI_Button;
@class LibraryBrowserGUI_SelectionBox;
@class LibraryBrowserGUI_MainWindow;


 
 
@interface LibraryBrowserGUI_SearchView : OCLAny <IBinding>
{
	 
	LibraryBrowserGUI_Label* _searchLabel;
	BOOL _searchLabel_initialized;
	LibraryBrowserGUI_Textfield* _searchField;
	BOOL _searchField_initialized;
	LibraryBrowserGUI_SelectionBox* _categorySelect;
	BOOL _categorySelect_initialized;
	LibraryBrowserGUI_Button* _searchButton;
	BOOL _searchButton_initialized;
	LibraryBrowserGUI_BookListView* _resultView;
	BOOL _resultView_initialized;
	OCLString* _viewTitle;
	BOOL _viewTitle_initialized;
	OCLSequence* _seqGUIElements;
	BOOL _seqGUIElements_initialized;


@public
	NSMutableArray *LibraryBrowserGUI_MainWindow_searchView_back;


	
	@protected
	UINavigationController* binding;
	UINavigationController* navigationController;
	UIViewController* rootViewController;
}

 
-(LibraryBrowserGUI_SearchView*)init;
-(LibraryBrowserGUI_SearchView*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(LibraryBrowserGUI_Label*) _searchLabel;
-(LibraryBrowserGUI_Label*) initial_searchLabel;
-(void) set_searchLabel:(LibraryBrowserGUI_Label*) value;
-(LibraryBrowserGUI_Textfield*) _searchField;
-(LibraryBrowserGUI_Textfield*) initial_searchField;
-(void) set_searchField:(LibraryBrowserGUI_Textfield*) value;
-(LibraryBrowserGUI_SelectionBox*) _categorySelect;
-(LibraryBrowserGUI_SelectionBox*) initial_categorySelect;
-(void) set_categorySelect:(LibraryBrowserGUI_SelectionBox*) value;
-(LibraryBrowserGUI_Button*) _searchButton;
-(LibraryBrowserGUI_Button*) initial_searchButton;
-(void) set_searchButton:(LibraryBrowserGUI_Button*) value;
-(LibraryBrowserGUI_BookListView*) _resultView;
-(LibraryBrowserGUI_BookListView*) initial_resultView;
-(void) set_resultView:(LibraryBrowserGUI_BookListView*) value;
-(OCLString*) _viewTitle;
-(OCLString*) initial_viewTitle;
-(void) set_viewTitle:(OCLString*) value;
-(OCLSequence*) _seqGUIElements;
-(OCLSequence*) initial_seqGUIElements;
-(void) set_seqGUIElements:(OCLSequence*) value;

-(void) event_searchButtonClicked_pushed:(PropertyChangeList*) changes ;
-(void) event_searchButtonClicked_pulled_edge0:(PropertyChangeList*)changes parentInstance:(LibraryBrowserGUI_Button*)parentInstance ;
-(void) event_searchFinished_pushed:(PropertyChangeList*) changes p_booksFound: (OCLSequence*) p_booksFound;
-(void) event_selectedBookData_pushed:(PropertyChangeList*) changes p_author: (OCLString*) p_author p_title: (OCLString*) p_title p_isbn: (OCLString*) p_isbn;
-(void) event_bookSelected_pushed:(PropertyChangeList*) changes p_id: (OCLInteger*) p_id;
-(void) event_bookSelected_pulled_edge0:(PropertyChangeList*)changes parentInstance:(LibraryBrowserGUI_BookListView*)parentInstance p_id:(OCLInteger*)p_id ;
-(void) event_searchBook_pushed:(PropertyChangeList*) changes ;

 
-(id) getBinding;
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value;
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters;
-(void) onPropertyChange: (NSString*)propertyName newValue:(id<OCLAny>)value;

 
-(void) addWidgets: (UIView *) view;


@end



