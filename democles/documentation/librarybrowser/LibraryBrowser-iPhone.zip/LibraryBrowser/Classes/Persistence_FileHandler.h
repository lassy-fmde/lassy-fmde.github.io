  
 
 
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "OCLTypes.h"
#import "IBinding.h"

@class PropertyChangeList;
@class LibraryPersistenceHandler_LibraryLoader;


 
 
@interface Persistence_FileHandler : OCLAny <IBinding>
{
	 


@public
	NSMutableArray *LibraryPersistenceHandler_LibraryLoader_fileHandler_back;


}

 
-(Persistence_FileHandler*)init;
-(Persistence_FileHandler*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;


-(void) event_openFile_pushed:(PropertyChangeList*) changes p_filename: (OCLString*) p_filename;
-(void) event_fileOpened_pushed:(PropertyChangeList*) changes ;
-(void) event_lineread_pushed:(PropertyChangeList*) changes p_line: (OCLString*) p_line;
-(void) event_fileClosed_pushed:(PropertyChangeList*) changes ;

 
-(id) getBinding;
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value;
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters;
-(void) onPropertyChange: (NSString*)propertyName newValue:(id<OCLAny>)value;


@end



