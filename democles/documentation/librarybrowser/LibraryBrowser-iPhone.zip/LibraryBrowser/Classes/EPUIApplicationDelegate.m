#import "EPUIApplicationDelegate.h"
#import "Application_Main.h"

@implementation EPUIApplicationDelegate

-(EPUIApplicationDelegate*)init {
    self = [super init];

    //NSLog(@"init %@", self);
    
    return self;
}

-(void)applicationDidFinishLaunching:(UIApplication*)application {
    //NSLog(@"delegate %@ finished launching, app = %@\n", self, application);
    //NSLog(@"App. singleton = %@, with delegate %@", [UIApplication sharedApplication], [UIApplication sharedApplication].delegate);

    // 1) Async

    // t = Thread that instantiates Application::Main
    // t.start()

    // In constructor, UIApplicationBinding retrieves instance of this delegate
    // via [UIApplication sharedApplication].delegate, and calls method to register
    // itself. That method checks if another binding already registered, if so throws Exception.

    // t.join()

    // Check if any binding registered itself. If not, call system exit.


    // 2) Sync

    // Like 1 but synchronous? Should work...

    self->mainInstance = [[Application_Main alloc] init];
    
    if ([self->mainInstance respondsToSelector:@selector(event_init_pushed:)] == YES ) {
        [self->mainInstance event_init_pushed:nil];
    }
}

@end
