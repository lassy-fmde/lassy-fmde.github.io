#import <Foundation/Foundation.h>
#import "OCLCollection.h"

@class OCLInteger;
@class OCLBoolean;

@interface OCLSequence : OCLCollection {
	@public
	NSMutableArray* coll;
}

-(OCLSequence*)init;
-(void)dealloc;

// OCLCollection abstract methods
-(OCLSequence*)newCollection;
-(void)add:(OCLAny*)object;
-(NSEnumerator*)objectEnumerator;
-(OCLInteger*)size;
-(OCLBoolean*)includes:(OCLAny*)object;
-(NSString*)collectionName;

// Sequence methods
-(OCLSequence*)union:(OCLSequence*)other;
-(OCLSequence*)append:(OCLAny*)object;
-(OCLSequence*)prepend:(OCLAny*)object;
-(OCLSequence*)insertAt:(OCLInteger*)index object:(OCLAny*)object;
-(OCLSequence*)subSequence:(OCLInteger*)lower upper:(OCLInteger*)upper;
-(OCLAny*)at:(OCLInteger*)position;
-(OCLInteger*)indexOf:(OCLAny*)object;
-(OCLAny*)first;
-(OCLAny*)last;
-(OCLSequence*)including:(OCLAny*)object;
-(OCLSequence*)excluding:(OCLAny*)object;

-(OCLSequence*)flatten;

// internal methods
-(OCLSequence*)sortedByFirstSubElement;

// NSObject methods
-(BOOL)isEqual:(id)other;

@end
