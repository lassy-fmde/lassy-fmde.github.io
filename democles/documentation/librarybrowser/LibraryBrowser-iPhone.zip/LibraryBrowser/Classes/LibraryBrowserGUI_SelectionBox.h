  
 
 
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "OCLTypes.h"
#import "IBinding.h"

@class PropertyChangeList;
@class LibraryBrowserGUI_SearchView;


 
 
@interface LibraryBrowserGUI_SelectionBox : OCLAny <IBinding,UIPickerViewDelegate,UIPickerViewDataSource>
{
	 
	OCLSequence* _choices;
	BOOL _choices_initialized;
	OCLString* _selectedChoice;
	BOOL _selectedChoice_initialized;


@public
	NSMutableArray *LibraryBrowserGUI_SearchView_categorySelect_back;


	
	@protected
	UIPickerView* binding;
}

 
-(LibraryBrowserGUI_SelectionBox*)init;
-(LibraryBrowserGUI_SelectionBox*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(OCLSequence*) _choices;
-(OCLSequence*) initial_choices;
-(void) set_choices:(OCLSequence*) value;
-(OCLString*) _selectedChoice;
-(OCLString*) initial_selectedChoice;
-(void) set_selectedChoice:(OCLString*) value;

-(void) event_rowSelected_pushed:(PropertyChangeList*) changes p_id: (OCLInteger*) p_id;

 
-(id) getBinding;
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value;
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters;
-(void) onPropertyChange: (NSString*)propertyName newValue:(id<OCLAny>)value;


@end



