  
 
 
#import <Foundation/Foundation.h>
#import "OCLTypes.h"

@class PropertyChangeList;
@class Library_BookCollection;
@class LibraryPersistenceHandler_LibraryLoader;
@class LibraryBrowserGUI_MainWindow;
@class Application_Main;
@class Library_Book;


 
 
@interface Application_Main : OCLAny  
 {
	 
	Library_BookCollection* _completeBookCollection;
	BOOL _completeBookCollection_initialized;
	Library_BookCollection* _booksFound;
	BOOL _booksFound_initialized;
	LibraryBrowserGUI_MainWindow* _mainGUI;
	BOOL _mainGUI_initialized;
	LibraryPersistenceHandler_LibraryLoader* _libraryLoader;
	BOOL _libraryLoader_initialized;


@public


}

 
-(Application_Main*)init;
-(Application_Main*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(Library_BookCollection*) _completeBookCollection;
-(Library_BookCollection*) initial_completeBookCollection;
-(void) set_completeBookCollection:(Library_BookCollection*) value;
-(Library_BookCollection*) _booksFound;
-(Library_BookCollection*) initial_booksFound;
-(void) set_booksFound:(Library_BookCollection*) value;
-(LibraryBrowserGUI_MainWindow*) _mainGUI;
-(LibraryBrowserGUI_MainWindow*) initial_mainGUI;
-(void) set_mainGUI:(LibraryBrowserGUI_MainWindow*) value;
-(LibraryPersistenceHandler_LibraryLoader*) _libraryLoader;
-(LibraryPersistenceHandler_LibraryLoader*) initial_libraryLoader;
-(void) set_libraryLoader:(LibraryPersistenceHandler_LibraryLoader*) value;

-(void) event_searchFinished_pushed:(PropertyChangeList*) changes p_booksFound: (OCLAny*) p_booksFound;
-(void) event_searchBook_pushed:(PropertyChangeList*) changes p_keyword: (OCLString*) p_keyword p_category: (OCLString*) p_category;
-(void) event_searchBook_pulled_edge0:(PropertyChangeList*)changes parentInstance:(LibraryBrowserGUI_MainWindow*)parentInstance p_keyword:(OCLString*)p_keyword p_category:(OCLString*)p_category ;
-(void) event_bookSelected_pushed:(PropertyChangeList*) changes p_id: (OCLInteger*) p_id;
-(void) event_bookSelected_pulled_edge0:(PropertyChangeList*)changes parentInstance:(LibraryBrowserGUI_MainWindow*)parentInstance p_id:(OCLInteger*)p_id ;
-(void) event_selectedBookData_pushed:(PropertyChangeList*) changes p_author: (OCLString*) p_author p_title: (OCLString*) p_title p_isbn: (OCLString*) p_isbn;
-(void) event_libraryBooksLoaded_pushed:(PropertyChangeList*) changes p_bookCollection: (Library_BookCollection*) p_bookCollection;
-(void) event_libraryBooksLoaded_pulled_edge0:(PropertyChangeList*)changes parentInstance:(LibraryPersistenceHandler_LibraryLoader*)parentInstance ;
-(void) event_setCompleteBookCollection_pushed:(PropertyChangeList*) changes p_completeBookCollection: (Library_BookCollection*) p_completeBookCollection;
-(void) event_init_pushed:(PropertyChangeList*) changes ;
-(void) event_loadLibrary_pushed:(PropertyChangeList*) changes ;


@end



