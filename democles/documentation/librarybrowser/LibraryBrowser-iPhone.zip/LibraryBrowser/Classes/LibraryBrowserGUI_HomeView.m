  
 
 
#import "LibraryBrowserGUI_HomeView.h"
#import "PropertyChangeList.h"
#import "LibraryBrowserGUI_Label.h"
#import "LibraryBrowserGUI_MainWindow.h"


 
@implementation LibraryBrowserGUI_HomeView

 
- (id) init {
	self = [super init];
	 
	self->binding = [[UIViewController alloc] init];
	self->binding.tabBarItem.image = [UIImage imageNamed: nil];

	 
	self->LibraryBrowserGUI_MainWindow_homeView_back = [[NSMutableArray alloc] init];

	[self set_titleLabel: [self _titleLabel]];
	[self set_viewTitle: [self _viewTitle]];
	[self set_seqGUIElements: [self _seqGUIElements]];


	 
	[self addWidgets: self->binding.view];

	return self;
}

 
- (id) initWithValues: (OCLTuple*) values {
	self = [super init];
	 
	self->binding = [[UIViewController alloc] init];
	self->binding.tabBarItem.image = [UIImage imageNamed: nil];

	 
	self->_titleLabel_initialized = NO;
	self->_viewTitle_initialized = NO;
	self->_seqGUIElements_initialized = NO;

	self->LibraryBrowserGUI_MainWindow_homeView_back = [[NSMutableArray alloc] init];

	LibraryBrowserGUI_Label* _titleLabel_initialValue = (LibraryBrowserGUI_Label*) [values objectForKey:@"titleLabel"];
	if (_titleLabel_initialValue == nil) {
		_titleLabel_initialValue = [self _titleLabel];
	}
	[self set_titleLabel:_titleLabel_initialValue];
	OCLString* _viewTitle_initialValue = (OCLString*) [values objectForKey:@"viewTitle"];
	if (_viewTitle_initialValue == nil) {
		_viewTitle_initialValue = [self _viewTitle];
	}
	[self set_viewTitle:_viewTitle_initialValue];
	OCLSequence* _seqGUIElements_initialValue = (OCLSequence*) [values objectForKey:@"seqGUIElements"];
	if (_seqGUIElements_initialValue == nil) {
		_seqGUIElements_initialValue = [self _seqGUIElements];
	}
	[self set_seqGUIElements:_seqGUIElements_initialValue];


	 
	[self addWidgets: self->binding.view];

	return self;
}

 
- (void) dealloc {
	if (self->_titleLabel != nil && self->_titleLabel != (LibraryBrowserGUI_Label*) [NSNull null]) [self->_titleLabel release];
	if (self->_viewTitle != nil && self->_viewTitle != (OCLString*) [NSNull null]) [self->_viewTitle release];
	if (self->_seqGUIElements != nil && self->_seqGUIElements != (OCLSequence*) [NSNull null]) [self->_seqGUIElements release];

	[self->LibraryBrowserGUI_MainWindow_homeView_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"LibraryBrowserGUI::HomeView\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"titleLabel\" type=\"LibraryBrowserGUI::Label\">\n"];
	[res appendFormat:@"%@\n", [self _titleLabel]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"viewTitle\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _viewTitle]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"seqGUIElements\" type=\"Sequence\">\n"];
	[res appendFormat:@"%@\n", [self _seqGUIElements]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
-(LibraryBrowserGUI_Label*) initial_titleLabel {
	/* ==================================================
	 * Label::create(Tuple { text = 'Welcome to the Library Browser' })
	 * ================================================== */
	
	OCLString* v4 = [(OCLString*)[OCLString alloc] initWithString:@"Welcome to the Library Browser"];
	OCLString* v3 = v4;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"text" withValue:v3];
	LibraryBrowserGUI_Label* v0 = [(LibraryBrowserGUI_Label*)[LibraryBrowserGUI_Label alloc] initWithValues:v2];
	[v4 release];
	[v2 release];
	
	return v0;
}

-(LibraryBrowserGUI_Label*) _titleLabel {
	if (self->_titleLabel_initialized == YES) {
		return _titleLabel;
	} else { 
		[self set_titleLabel:[self initial_titleLabel]];
	}

	self->_titleLabel_initialized = YES;
	return _titleLabel;
}
-(OCLString*) initial_viewTitle {
	/* ==================================================
	 * 'Home'
	 * ================================================== */
	
	OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@"Home"];
	
	return v0;
}

-(OCLString*) _viewTitle {
	if (self->_viewTitle_initialized == YES) {
		return _viewTitle;
	} else { 
		[self set_viewTitle:[self initial_viewTitle]];
	}

	self->_viewTitle_initialized = YES;
	return _viewTitle;
}
-(OCLSequence*) initial_seqGUIElements {
	/* ==================================================
	 * Sequence {titleLabel}
	 * ================================================== */
	
	LibraryBrowserGUI_HomeView* v3 = self;
	LibraryBrowserGUI_Label* v2 = [v3 _titleLabel];
	LibraryBrowserGUI_Label* v1 = v2;
	OCLSequence* v0 = [(OCLSequence*)[OCLSequence alloc] init];
	[v0 add:v1];
	
	return v0;
}

-(OCLSequence*) _seqGUIElements {
	if (self->_seqGUIElements_initialized == YES) {
		return _seqGUIElements;
	} else { 
		[self set_seqGUIElements:[self initial_seqGUIElements]];
	}

	self->_seqGUIElements_initialized = YES;
	return _seqGUIElements;
}


 
-(void) set_viewTitle:(OCLString*) value {
	 	if (self->_viewTitle!= nil && self->_viewTitle!= (OCLString*) [NSNull null]) {
		[self->_viewTitle release];
	}
	self->_viewTitle = value;
	if (self->_viewTitle!= nil && self->_viewTitle!= (OCLString*) [NSNull null]) {
		[self->_viewTitle retain];
	}
	self->_viewTitle_initialized = YES;
	
	[self onPropertyChange:@"viewTitle" newValue:value];
}
-(void) set_seqGUIElements:(OCLSequence*) value {
	 	if (self->_seqGUIElements!= nil && self->_seqGUIElements!= (OCLSequence*) [NSNull null]) {
		[self->_seqGUIElements release];
	}
	self->_seqGUIElements = value;
	if (self->_seqGUIElements!= nil && self->_seqGUIElements!= (OCLSequence*) [NSNull null]) {
		[self->_seqGUIElements retain];
	}
	self->_seqGUIElements_initialized = YES;
	
	[self onPropertyChange:@"seqGUIElements" newValue:value];
}


-(void) set_titleLabel:(LibraryBrowserGUI_Label*) value {
	 
	if (self->_titleLabel!= nil && self->_titleLabel!= (LibraryBrowserGUI_Label*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_titleLabel valueForKey:@"LibraryBrowserGUI_HomeView_titleLabel_back"];
		[backpointers removeObject:self];
		[self->_titleLabel release];
	}
	self->_titleLabel = value;
	if (self->_titleLabel!= nil && self->_titleLabel!= (LibraryBrowserGUI_Label*) [NSNull null]) {
		[self->_titleLabel retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_titleLabel valueForKey:@"LibraryBrowserGUI_HomeView_titleLabel_back"];
		[backpointers addObject:self];
	}
	self->_titleLabel_initialized = YES;
	
	[self onPropertyChange:@"titleLabel" newValue:value];
}




 

 


 
-(void)onPropertyChange:(NSString*)propertyName newValue:(id) value {
	if ([propertyName isEqual:@"viewTitle"]) {
		if (value != nil && value != [NSNull null]) 
			[self->binding setTitle: ((OCLString *) value)->string ];
	}
	 
	if ([value conformsToProtocol:@protocol(IBinding)]) {
		id propBinding = [value getBinding];
		if ([propBinding isKindOfClass: [UIViewController class]] && self->navigationController != nil) {
			[self->navigationController pushViewController:(UIViewController *)propBinding animated: YES];
			[value setBindingAttribute: @"navigationController" newValue: self->navigationController];
		}
	}

}

 
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters{
}

 
-(id) getBinding {
	return self->binding;
}

 
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value {
	if ([propertyName isEqual:@"navigationController"]) {
		if (value != nil && value != [NSNull null] && [value isKindOfClass: [UINavigationController class]]) 
			self->navigationController = (UINavigationController *) value;
	}
}

 
- (void) addWidgets: (UIView *) view {
	OCLSequence* widgets = [self _seqGUIElements];
	int y_pos = 0;
	NSEnumerator* e = [widgets objectEnumerator];
	id object;
	while ((object = [e nextObject])) {
		if ([object conformsToProtocol:@protocol(IBinding)]) {
			id<IBinding> propBinding = [object getBinding];
			if (![propBinding isKindOfClass: [UIPickerView class]]){
				((UIView*) propBinding).frame = CGRectMake(20, y_pos + 10, 280, 30);
				y_pos += 40;
			} else {
				((UIView*) propBinding).frame  = CGRectMake(0,  y_pos + 10 , 320, 162);
				y_pos += 172;
			}
			[view addSubview: (UIView*) propBinding];
		}
	}
}


@end 



