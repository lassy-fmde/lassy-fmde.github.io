#import <Foundation/Foundation.h>
#import "OCLCollection.h"

@class OCLInteger;
@class OCLBoolean;
@class OCLOrderedSet;
@class OCLBag;
@class OCLSequence;

@interface OCLSet : OCLCollection {
	@public
	NSMutableSet* set;
}

-(OCLSet*)init;
-(void)dealloc;

// abstract Collection method implementations
-(OCLSet*)newCollection;
-(void)add:(OCLAny*)object;	
-(OCLInteger*)size;
-(OCLBoolean*)includes:(OCLAny*)object;
-(NSEnumerator*)objectEnumerator;
-(NSString*)collectionName;

// Set methods
-(OCLSet*)unionWithSet:(OCLSet*)other;
-(OCLBag*)unionWithBag:(OCLBag*)other;
-(OCLSet*)intersectionWithSet:(OCLSet*)other;
-(OCLSet*)intersectionWithBag:(OCLBag*)other;
-(OCLSet*)n:(OCLSet*)other;
-(OCLSet*)including:(OCLAny*)object;
-(OCLSet*)excluding:(OCLAny*)object;
-(OCLSet*)symmetricDifference:(OCLSet*)other;
-(OCLSet*)flatten;

// NSObject methods
-(BOOL)isEqual:(id)other;

@end
