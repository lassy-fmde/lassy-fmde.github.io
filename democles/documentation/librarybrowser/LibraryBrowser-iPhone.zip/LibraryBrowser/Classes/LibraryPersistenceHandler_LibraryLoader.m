  
 
 
#import "LibraryPersistenceHandler_LibraryLoader.h"
#import "PropertyChangeList.h"
#import "Library_BookCollection.h"
#import "Persistence_FileHandler.h"
#import "Library_Book.h"
#import "StringUtils_StringTokenizer.h"
#import "Application_Main.h"


 
@implementation LibraryPersistenceHandler_LibraryLoader

 
- (LibraryPersistenceHandler_LibraryLoader*) init {
	self = [super init];
	 
	self->Application_Main_libraryLoader_back = [[NSMutableArray alloc] init];

	[self set_libraryBooks: [self _libraryBooks]];
	[self set_fileHandler: [self _fileHandler]];
	[self set_bookLineTokenizer: [self _bookLineTokenizer]];

	return self;
}

 
- (LibraryPersistenceHandler_LibraryLoader*) initWithValues: (OCLTuple*) values {
	self = [super init];
	 
	self->_libraryBooks_initialized = NO;
	self->_fileHandler_initialized = NO;
	self->_bookLineTokenizer_initialized = NO;

	self->Application_Main_libraryLoader_back = [[NSMutableArray alloc] init];

	Library_BookCollection* _libraryBooks_initialValue = (Library_BookCollection*) [values objectForKey:@"libraryBooks"];
	if (_libraryBooks_initialValue == nil) {
		_libraryBooks_initialValue = [self _libraryBooks];
	}
	[self set_libraryBooks:_libraryBooks_initialValue];
	Persistence_FileHandler* _fileHandler_initialValue = (Persistence_FileHandler*) [values objectForKey:@"fileHandler"];
	if (_fileHandler_initialValue == nil) {
		_fileHandler_initialValue = [self _fileHandler];
	}
	[self set_fileHandler:_fileHandler_initialValue];
	StringUtils_StringTokenizer* _bookLineTokenizer_initialValue = (StringUtils_StringTokenizer*) [values objectForKey:@"bookLineTokenizer"];
	if (_bookLineTokenizer_initialValue == nil) {
		_bookLineTokenizer_initialValue = [self _bookLineTokenizer];
	}
	[self set_bookLineTokenizer:_bookLineTokenizer_initialValue];

	
	return self;
}

 
- (void) dealloc {
	if (self->_libraryBooks != nil && self->_libraryBooks != (Library_BookCollection*) [NSNull null]) [self->_libraryBooks release];
	if (self->_fileHandler != nil && self->_fileHandler != (Persistence_FileHandler*) [NSNull null]) [self->_fileHandler release];
	if (self->_bookLineTokenizer != nil && self->_bookLineTokenizer != (StringUtils_StringTokenizer*) [NSNull null]) [self->_bookLineTokenizer release];

	[self->Application_Main_libraryLoader_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"LibraryPersistenceHandler::LibraryLoader\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"libraryBooks\" type=\"Library::BookCollection\">\n"];
	[res appendFormat:@"%@\n", [self _libraryBooks]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"fileHandler\" type=\"Persistence::FileHandler\">\n"];
	[res appendFormat:@"%@\n", [self _fileHandler]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"bookLineTokenizer\" type=\"StringUtils::StringTokenizer\">\n"];
	[res appendFormat:@"%@\n", [self _bookLineTokenizer]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
-(Library_BookCollection*) initial_libraryBooks {
	/* ==================================================
	 * null
	 * ================================================== */
	
	Library_BookCollection* v0 = [NSNull null];
	
	return v0;
}

-(Library_BookCollection*) _libraryBooks {
	if (self->_libraryBooks_initialized == YES) {
		return _libraryBooks;
	} else { 
		[self set_libraryBooks:[self initial_libraryBooks]];
	}

	self->_libraryBooks_initialized = YES;
	return _libraryBooks;
}
-(Persistence_FileHandler*) initial_fileHandler {
	/* ==================================================
	 * Persistence::FileHandler::create()
	 * ================================================== */
	
	Persistence_FileHandler* v0 = [(Persistence_FileHandler*)[Persistence_FileHandler alloc] init];
	
	return v0;
}

-(Persistence_FileHandler*) _fileHandler {
	if (self->_fileHandler_initialized == YES) {
		return _fileHandler;
	} else { 
		[self set_fileHandler:[self initial_fileHandler]];
	}

	self->_fileHandler_initialized = YES;
	return _fileHandler;
}
-(StringUtils_StringTokenizer*) initial_bookLineTokenizer {
	/* ==================================================
	 * StringUtils::StringTokenizer::create()
	 * ================================================== */
	
	StringUtils_StringTokenizer* v0 = [(StringUtils_StringTokenizer*)[StringUtils_StringTokenizer alloc] init];
	
	return v0;
}

-(StringUtils_StringTokenizer*) _bookLineTokenizer {
	if (self->_bookLineTokenizer_initialized == YES) {
		return _bookLineTokenizer;
	} else { 
		[self set_bookLineTokenizer:[self initial_bookLineTokenizer]];
	}

	self->_bookLineTokenizer_initialized = YES;
	return _bookLineTokenizer;
}


 


-(void) set_libraryBooks:(Library_BookCollection*) value {
	 
	if (self->_libraryBooks!= nil && self->_libraryBooks!= (Library_BookCollection*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_libraryBooks valueForKey:@"LibraryPersistenceHandler_LibraryLoader_libraryBooks_back"];
		[backpointers removeObject:self];
		[self->_libraryBooks release];
	}
	self->_libraryBooks = value;
	if (self->_libraryBooks!= nil && self->_libraryBooks!= (Library_BookCollection*) [NSNull null]) {
		[self->_libraryBooks retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_libraryBooks valueForKey:@"LibraryPersistenceHandler_LibraryLoader_libraryBooks_back"];
		[backpointers addObject:self];
	}
	self->_libraryBooks_initialized = YES;

}
-(void) set_fileHandler:(Persistence_FileHandler*) value {
	 
	if (self->_fileHandler!= nil && self->_fileHandler!= (Persistence_FileHandler*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_fileHandler valueForKey:@"LibraryPersistenceHandler_LibraryLoader_fileHandler_back"];
		[backpointers removeObject:self];
		[self->_fileHandler release];
	}
	self->_fileHandler = value;
	if (self->_fileHandler!= nil && self->_fileHandler!= (Persistence_FileHandler*) [NSNull null]) {
		[self->_fileHandler retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_fileHandler valueForKey:@"LibraryPersistenceHandler_LibraryLoader_fileHandler_back"];
		[backpointers addObject:self];
	}
	self->_fileHandler_initialized = YES;

}
-(void) set_bookLineTokenizer:(StringUtils_StringTokenizer*) value {
	 
	if (self->_bookLineTokenizer!= nil && self->_bookLineTokenizer!= (StringUtils_StringTokenizer*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_bookLineTokenizer valueForKey:@"LibraryPersistenceHandler_LibraryLoader_bookLineTokenizer_back"];
		[backpointers removeObject:self];
		[self->_bookLineTokenizer release];
	}
	self->_bookLineTokenizer = value;
	if (self->_bookLineTokenizer!= nil && self->_bookLineTokenizer!= (StringUtils_StringTokenizer*) [NSNull null]) {
		[self->_bookLineTokenizer retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_bookLineTokenizer valueForKey:@"LibraryPersistenceHandler_LibraryLoader_bookLineTokenizer_back"];
		[backpointers addObject:self];
	}
	self->_bookLineTokenizer_initialized = YES;

}




 
-(void) event_loadLibrary_pushed:(PropertyChangeList*) changes  {
	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_loadLibrary", @"LibraryPersistenceHandler_LibraryLoader");

		 
		// Trigger Push edges

		if (self->_fileHandler != nil && self->_fileHandler != (Persistence_FileHandler*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_fileHandler];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			Persistence_FileHandler* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * 'libraryDataFile.dat'
				 * ================================================== */
				
				OCLString* v1 = [(OCLString*)[OCLString alloc] initWithString:@"libraryDataFile.dat"];
				
					OCLString* parameter_p_filename = v1;

					[edge0_target event_openFile_pushed:changes p_filename:parameter_p_filename ];
					[v1 release];

				}
				[v0 release];
			}
			// Release targets collection
			[edge0_values release];

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_bookLineRead_pushed:(PropertyChangeList*) changes  p_line: (OCLString*) p_line{
	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_bookLineRead", @"LibraryPersistenceHandler_LibraryLoader");

		 
		// Trigger Push edges

		if (self->_bookLineTokenizer != nil && self->_bookLineTokenizer != (StringUtils_StringTokenizer*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_bookLineTokenizer];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			StringUtils_StringTokenizer* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * line
				 * ================================================== */
				
				OCLString* v1 = p_line;
				
					OCLString* parameter_p_string = v1;
					/* ==================================================
				 * ';'
				 * ================================================== */
				
				OCLString* v2 = [(OCLString*)[OCLString alloc] initWithString:@";"];
				
					OCLString* parameter_p_separator = v2;

					[edge0_target event_tokenizeString_pushed:changes p_string:parameter_p_string p_separator:parameter_p_separator ];

				}
				[v0 release];
			}
			// Release targets collection
			[edge0_values release];

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_bookLineRead_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Persistence_FileHandler*)parentInstance p_line:(OCLString*)p_line  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_bookLineRead", @"LibraryPersistenceHandler_LibraryLoader", @"_lineread", @"Persistence_FileHandler");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {
		/* ==================================================
		 * line
		 * ================================================== */
		
		OCLString* v1 = p_line;
		
		OCLString* parameter_p_line = v1;

		[self event_bookLineRead_pushed:changes p_line:parameter_p_line ];

	}
	[v0 release];
}


-(void) event_libraryFileRead_pushed:(PropertyChangeList*) changes  {
	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_libraryFileRead", @"LibraryPersistenceHandler_LibraryLoader");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * Library::BookCollection::create(Tuple { Books = Sequence { } })
		 * ================================================== */
		
		OCLSequence* v4 = [(OCLSequence*)[OCLSequence alloc] init];
		OCLSequence* v3 = v4;
		OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
		[v2 addItemNamed:@"Books" withValue:v3];
		Library_BookCollection* v0 = [(Library_BookCollection*)[Library_BookCollection alloc] initWithValues:v2];
		[v4 release];
		[v2 release];
		
		Library_BookCollection* _libraryBooks_newValue = v0;
		[changes addChange:@selector(set_libraryBooks:) instance:self value:_libraryBooks_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_libraryFileRead_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Persistence_FileHandler*)parentInstance  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_libraryFileRead", @"LibraryPersistenceHandler_LibraryLoader", @"_fileOpened", @"Persistence_FileHandler");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {

		[self event_libraryFileRead_pushed:changes ];

	}
	[v0 release];
}


-(void) event_libraryFileClosed_pushed:(PropertyChangeList*) changes  {
	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_libraryFileClosed", @"LibraryPersistenceHandler_LibraryLoader");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges
		NSEnumerator* Application_Main_libraryBooksLoaded_edge0_enum = [self->Application_Main_libraryLoader_back objectEnumerator];
		Application_Main* Application_Main_libraryBooksLoaded_edge0_target;
		while ((Application_Main_libraryBooksLoaded_edge0_target = [Application_Main_libraryBooksLoaded_edge0_enum nextObject]) != nil) {
		    [Application_Main_libraryBooksLoaded_edge0_target event_libraryBooksLoaded_pulled_edge0:changes parentInstance:self ];
		}



		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_libraryFileClosed_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Persistence_FileHandler*)parentInstance  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_libraryFileClosed", @"LibraryPersistenceHandler_LibraryLoader", @"_fileClosed", @"Persistence_FileHandler");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {

		[self event_libraryFileClosed_pushed:changes ];

	}
	[v0 release];
}


-(void) event_bookLineTokenized_pushed:(PropertyChangeList*) changes  p_bookTokens: (OCLSequence*) p_bookTokens{
	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_bookLineTokenized", @"LibraryPersistenceHandler_LibraryLoader");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * if bookTokens->size() = 3 then 
		 * 	Library::BookCollection::create(Tuple { 
		 * 		Books = libraryBooks.Books->including(
		 * 					Library::Book::create(
		 * 					Tuple { author = bookTokens->at(1), 
		 * 							title =  bookTokens->at(2), 
		 * 							isbn =   bookTokens->at(3) 
		 * 					}
		 * 		))})
		 * else
		 * 	Library::BookCollection::create(Tuple { Books = libraryBooks.Books })
		 * endif
		 * 
		 * ================================================== */
		
		OCLSequence* v3 = p_bookTokens;
		OCLInteger* v2 = [v3 size];
		OCLInteger* v4 = [(OCLInteger*)[OCLInteger alloc] initWithValue:3];
		OCLBoolean* v1 = [v2 eq:v4];
		Library_BookCollection* v0;
		if (v1->value == YES) {
			LibraryPersistenceHandler_LibraryLoader* v12 = self;
			Library_BookCollection* v11 = [v12 _libraryBooks];
			OCLSequence* v10 = [v11 _Books];
			OCLSequence* v18 = p_bookTokens;
			OCLInteger* v19 = [(OCLInteger*)[OCLInteger alloc] initWithValue:1];
			OCLString* v17 = [v18 at:v19];
			OCLString* v16 = v17;
			OCLSequence* v22 = p_bookTokens;
			OCLInteger* v23 = [(OCLInteger*)[OCLInteger alloc] initWithValue:2];
			OCLString* v21 = [v22 at:v23];
			OCLString* v20 = v21;
			OCLSequence* v26 = p_bookTokens;
			OCLInteger* v27 = [(OCLInteger*)[OCLInteger alloc] initWithValue:3];
			OCLString* v25 = [v26 at:v27];
			OCLString* v24 = v25;
			OCLTuple* v15 = [(OCLTuple*)[OCLTuple alloc] init];
			[v15 addItemNamed:@"author" withValue:v16];
			[v15 addItemNamed:@"title" withValue:v20];
			[v15 addItemNamed:@"isbn" withValue:v24];
			Library_Book* v13 = [(Library_Book*)[Library_Book alloc] initWithValues:v15];
			OCLSequence* v9 = [v10 including:v13];
			OCLSequence* v8 = v9;
			OCLTuple* v7 = [(OCLTuple*)[OCLTuple alloc] init];
			[v7 addItemNamed:@"Books" withValue:v8];
			Library_BookCollection* v5 = [(Library_BookCollection*)[Library_BookCollection alloc] initWithValues:v7];
			v0 = v5;
			[v7 release];
			[v19 release];
			[v23 release];
			[v5 release];
			[v13 release];
			[v9 release];
			[v15 release];
			[v27 release];
		} else {
			LibraryPersistenceHandler_LibraryLoader* v34 = self;
			Library_BookCollection* v33 = [v34 _libraryBooks];
			OCLSequence* v32 = [v33 _Books];
			OCLSequence* v31 = v32;
			OCLTuple* v30 = [(OCLTuple*)[OCLTuple alloc] init];
			[v30 addItemNamed:@"Books" withValue:v31];
			Library_BookCollection* v28 = [(Library_BookCollection*)[Library_BookCollection alloc] initWithValues:v30];
			v0 = v28;
			[v30 release];
			[v28 release];
		}
		[v1 release];
		[v4 release];
		[v2 release];
		
		Library_BookCollection* _libraryBooks_newValue = v0;
		[changes addChange:@selector(set_libraryBooks:) instance:self value:_libraryBooks_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_bookLineTokenized_pulled_edge0:(PropertyChangeList*)changes parentInstance:(StringUtils_StringTokenizer*)parentInstance p_tokens:(OCLSequence*)p_tokens  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_bookLineTokenized", @"LibraryPersistenceHandler_LibraryLoader", @"_stringTokenized", @"StringUtils_StringTokenizer");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {
		/* ==================================================
		 * tokens
		 * ================================================== */
		
		OCLSequence* v1 = p_tokens;
		
		OCLSequence* parameter_p_bookTokens = v1;

		[self event_bookLineTokenized_pushed:changes p_bookTokens:parameter_p_bookTokens ];

	}
	[v0 release];
}




 


@end 



