  
 
 
#import "Library_Book.h"
#import "PropertyChangeList.h"
#import "Library_BookCollection.h"


 
@implementation Library_Book

 
- (Library_Book*) init {
	self = [super init];
	 
	self->Library_BookCollection_Books_back = [[NSMutableArray alloc] init];

	[self set_author: [self _author]];
	[self set_title: [self _title]];
	[self set_isbn: [self _isbn]];

	return self;
}

 
- (Library_Book*) initWithValues: (OCLTuple*) values {
	self = [super init];
	 
	self->_author_initialized = NO;
	self->_title_initialized = NO;
	self->_isbn_initialized = NO;

	self->Library_BookCollection_Books_back = [[NSMutableArray alloc] init];

	OCLString* _author_initialValue = (OCLString*) [values objectForKey:@"author"];
	if (_author_initialValue == nil) {
		_author_initialValue = [self _author];
	}
	[self set_author:_author_initialValue];
	OCLString* _title_initialValue = (OCLString*) [values objectForKey:@"title"];
	if (_title_initialValue == nil) {
		_title_initialValue = [self _title];
	}
	[self set_title:_title_initialValue];
	OCLString* _isbn_initialValue = (OCLString*) [values objectForKey:@"isbn"];
	if (_isbn_initialValue == nil) {
		_isbn_initialValue = [self _isbn];
	}
	[self set_isbn:_isbn_initialValue];

	
	return self;
}

 
- (void) dealloc {
	if (self->_author != nil && self->_author != (OCLString*) [NSNull null]) [self->_author release];
	if (self->_title != nil && self->_title != (OCLString*) [NSNull null]) [self->_title release];
	if (self->_isbn != nil && self->_isbn != (OCLString*) [NSNull null]) [self->_isbn release];

	[self->Library_BookCollection_Books_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"Library::Book\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"author\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _author]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"title\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _title]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"isbn\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _isbn]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
-(OCLString*) initial_author {
	/* ==================================================
	 * null
	 * ================================================== */
	
	OCLString* v0 = [NSNull null];
	
	return v0;
}

-(OCLString*) _author {
	if (self->_author_initialized == YES) {
		return _author;
	} else { 
		[self set_author:[self initial_author]];
	}

	self->_author_initialized = YES;
	return _author;
}
-(OCLString*) initial_title {
	/* ==================================================
	 * null
	 * ================================================== */
	
	OCLString* v0 = [NSNull null];
	
	return v0;
}

-(OCLString*) _title {
	if (self->_title_initialized == YES) {
		return _title;
	} else { 
		[self set_title:[self initial_title]];
	}

	self->_title_initialized = YES;
	return _title;
}
-(OCLString*) initial_isbn {
	/* ==================================================
	 * null
	 * ================================================== */
	
	OCLString* v0 = [NSNull null];
	
	return v0;
}

-(OCLString*) _isbn {
	if (self->_isbn_initialized == YES) {
		return _isbn;
	} else { 
		[self set_isbn:[self initial_isbn]];
	}

	self->_isbn_initialized = YES;
	return _isbn;
}


 
-(void) set_author:(OCLString*) value {
	 	if (self->_author!= nil && self->_author!= (OCLString*) [NSNull null]) {
		[self->_author release];
	}
	self->_author = value;
	if (self->_author!= nil && self->_author!= (OCLString*) [NSNull null]) {
		[self->_author retain];
	}
	self->_author_initialized = YES;

}
-(void) set_title:(OCLString*) value {
	 	if (self->_title!= nil && self->_title!= (OCLString*) [NSNull null]) {
		[self->_title release];
	}
	self->_title = value;
	if (self->_title!= nil && self->_title!= (OCLString*) [NSNull null]) {
		[self->_title retain];
	}
	self->_title_initialized = YES;

}
-(void) set_isbn:(OCLString*) value {
	 	if (self->_isbn!= nil && self->_isbn!= (OCLString*) [NSNull null]) {
		[self->_isbn release];
	}
	self->_isbn = value;
	if (self->_isbn!= nil && self->_isbn!= (OCLString*) [NSNull null]) {
		[self->_isbn retain];
	}
	self->_isbn_initialized = YES;

}






 


 


@end 



