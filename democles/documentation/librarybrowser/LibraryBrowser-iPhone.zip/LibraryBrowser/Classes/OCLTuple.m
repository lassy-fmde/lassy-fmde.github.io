#import "OCLTuple.h"
#import "OCLBoolean.h"

@implementation OCLTuple

-(OCLTuple*)init {
	self = [super init];
	dict = [[NSMutableDictionary alloc] init];
	return self;
}

-(void)dealloc {
	[dict release];
	[super dealloc];
}

-(BOOL)isEqual:(id)other {
	BOOL res;
	if ([self isCompatibleType:other]) {
		OCLTuple* otherTuple = (OCLTuple*)other;
		res = [self->dict isEqual:otherTuple->dict]; 
	} else {
		res = NO;
	}
	return res;
}

-(NSString*)description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<Tuple id=\"%p\" retainCount=\"%i\">\n", self, [self retainCount]];
	
	NSEnumerator* e = [self->dict keyEnumerator];
	NSString* key;
	while ((key = [e nextObject]) != nil) {
		id value = [dict objectForKey:key];
		[res appendFormat:@"<TupleEntry name=\"%@\">\n%@", key, value];
		[res appendString:@"</TupleEntry>\n"];
	}
	
	[res appendString:@"</Tuple>\n"];
	return res;
}

-(void)addItemNamed:(NSString*)name withValue:(OCLAny*)value {
	[dict setObject:value forKey:name];
}

-(OCLAny*)remove:(NSString*)name {
	id res = [dict objectForKey:name];
	[dict removeObjectForKey:name];
	return res;
}

-(NSEnumerator*)keyEnumerator {
	return [dict keyEnumerator];
}

-(OCLAny*)objectForKey:(NSString*)key {
	return [dict objectForKey:key];
}

@end
