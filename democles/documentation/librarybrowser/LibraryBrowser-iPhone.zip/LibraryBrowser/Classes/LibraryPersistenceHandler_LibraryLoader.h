  
 
 
#import <Foundation/Foundation.h>
#import "OCLTypes.h"

@class PropertyChangeList;
@class Library_BookCollection;
@class Persistence_FileHandler;
@class Library_Book;
@class StringUtils_StringTokenizer;
@class Application_Main;


 
 
@interface LibraryPersistenceHandler_LibraryLoader : OCLAny  
 {
	 
	Library_BookCollection* _libraryBooks;
	BOOL _libraryBooks_initialized;
	Persistence_FileHandler* _fileHandler;
	BOOL _fileHandler_initialized;
	StringUtils_StringTokenizer* _bookLineTokenizer;
	BOOL _bookLineTokenizer_initialized;


@public
	NSMutableArray *Application_Main_libraryLoader_back;


}

 
-(LibraryPersistenceHandler_LibraryLoader*)init;
-(LibraryPersistenceHandler_LibraryLoader*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(Library_BookCollection*) _libraryBooks;
-(Library_BookCollection*) initial_libraryBooks;
-(void) set_libraryBooks:(Library_BookCollection*) value;
-(Persistence_FileHandler*) _fileHandler;
-(Persistence_FileHandler*) initial_fileHandler;
-(void) set_fileHandler:(Persistence_FileHandler*) value;
-(StringUtils_StringTokenizer*) _bookLineTokenizer;
-(StringUtils_StringTokenizer*) initial_bookLineTokenizer;
-(void) set_bookLineTokenizer:(StringUtils_StringTokenizer*) value;

-(void) event_loadLibrary_pushed:(PropertyChangeList*) changes ;
-(void) event_bookLineRead_pushed:(PropertyChangeList*) changes p_line: (OCLString*) p_line;
-(void) event_bookLineRead_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Persistence_FileHandler*)parentInstance p_line:(OCLString*)p_line ;
-(void) event_libraryFileRead_pushed:(PropertyChangeList*) changes ;
-(void) event_libraryFileRead_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Persistence_FileHandler*)parentInstance ;
-(void) event_libraryFileClosed_pushed:(PropertyChangeList*) changes ;
-(void) event_libraryFileClosed_pulled_edge0:(PropertyChangeList*)changes parentInstance:(Persistence_FileHandler*)parentInstance ;
-(void) event_bookLineTokenized_pushed:(PropertyChangeList*) changes p_bookTokens: (OCLSequence*) p_bookTokens;
-(void) event_bookLineTokenized_pulled_edge0:(PropertyChangeList*)changes parentInstance:(StringUtils_StringTokenizer*)parentInstance p_tokens:(OCLSequence*)p_tokens ;


@end



