  
 
 
#import "LibraryBrowserGUI_BookDetailView.h"
#import "PropertyChangeList.h"
#import "LibraryBrowserGUI_Label.h"
#import "LibraryBrowserGUI_BookListView.h"


 
@implementation LibraryBrowserGUI_BookDetailView

 
- (id) init {
	self = [super init];
	 
	self->binding = [[UIViewController alloc] init];
	self->binding.tabBarItem.image = [UIImage imageNamed: nil];

	 
	self->LibraryBrowserGUI_BookListView_bookDetailView_back = [[NSMutableArray alloc] init];

	[self set_titleLabel: [self _titleLabel]];
	[self set_bookTitleLabel: [self _bookTitleLabel]];
	[self set_authorLabel: [self _authorLabel]];
	[self set_bookAuthorLabel: [self _bookAuthorLabel]];
	[self set_isbnLabel: [self _isbnLabel]];
	[self set_bookIsbnLabel: [self _bookIsbnLabel]];
	[self set_viewTitle: [self _viewTitle]];
	[self set_seqGUIElements: [self _seqGUIElements]];


	 
	[self addWidgets: self->binding.view];

	return self;
}

 
- (id) initWithValues: (OCLTuple*) values {
	self = [super init];
	 
	self->binding = [[UIViewController alloc] init];
	self->binding.tabBarItem.image = [UIImage imageNamed: nil];

	 
	self->_titleLabel_initialized = NO;
	self->_bookTitleLabel_initialized = NO;
	self->_authorLabel_initialized = NO;
	self->_bookAuthorLabel_initialized = NO;
	self->_isbnLabel_initialized = NO;
	self->_bookIsbnLabel_initialized = NO;
	self->_viewTitle_initialized = NO;
	self->_seqGUIElements_initialized = NO;

	self->LibraryBrowserGUI_BookListView_bookDetailView_back = [[NSMutableArray alloc] init];

	LibraryBrowserGUI_Label* _titleLabel_initialValue = (LibraryBrowserGUI_Label*) [values objectForKey:@"titleLabel"];
	if (_titleLabel_initialValue == nil) {
		_titleLabel_initialValue = [self _titleLabel];
	}
	[self set_titleLabel:_titleLabel_initialValue];
	LibraryBrowserGUI_Label* _bookTitleLabel_initialValue = (LibraryBrowserGUI_Label*) [values objectForKey:@"bookTitleLabel"];
	if (_bookTitleLabel_initialValue == nil) {
		_bookTitleLabel_initialValue = [self _bookTitleLabel];
	}
	[self set_bookTitleLabel:_bookTitleLabel_initialValue];
	LibraryBrowserGUI_Label* _authorLabel_initialValue = (LibraryBrowserGUI_Label*) [values objectForKey:@"authorLabel"];
	if (_authorLabel_initialValue == nil) {
		_authorLabel_initialValue = [self _authorLabel];
	}
	[self set_authorLabel:_authorLabel_initialValue];
	LibraryBrowserGUI_Label* _bookAuthorLabel_initialValue = (LibraryBrowserGUI_Label*) [values objectForKey:@"bookAuthorLabel"];
	if (_bookAuthorLabel_initialValue == nil) {
		_bookAuthorLabel_initialValue = [self _bookAuthorLabel];
	}
	[self set_bookAuthorLabel:_bookAuthorLabel_initialValue];
	LibraryBrowserGUI_Label* _isbnLabel_initialValue = (LibraryBrowserGUI_Label*) [values objectForKey:@"isbnLabel"];
	if (_isbnLabel_initialValue == nil) {
		_isbnLabel_initialValue = [self _isbnLabel];
	}
	[self set_isbnLabel:_isbnLabel_initialValue];
	LibraryBrowserGUI_Label* _bookIsbnLabel_initialValue = (LibraryBrowserGUI_Label*) [values objectForKey:@"bookIsbnLabel"];
	if (_bookIsbnLabel_initialValue == nil) {
		_bookIsbnLabel_initialValue = [self _bookIsbnLabel];
	}
	[self set_bookIsbnLabel:_bookIsbnLabel_initialValue];
	OCLString* _viewTitle_initialValue = (OCLString*) [values objectForKey:@"viewTitle"];
	if (_viewTitle_initialValue == nil) {
		_viewTitle_initialValue = [self _viewTitle];
	}
	[self set_viewTitle:_viewTitle_initialValue];
	OCLSequence* _seqGUIElements_initialValue = (OCLSequence*) [values objectForKey:@"seqGUIElements"];
	if (_seqGUIElements_initialValue == nil) {
		_seqGUIElements_initialValue = [self _seqGUIElements];
	}
	[self set_seqGUIElements:_seqGUIElements_initialValue];


	 
	[self addWidgets: self->binding.view];

	return self;
}

 
- (void) dealloc {
	if (self->_titleLabel != nil && self->_titleLabel != (LibraryBrowserGUI_Label*) [NSNull null]) [self->_titleLabel release];
	if (self->_bookTitleLabel != nil && self->_bookTitleLabel != (LibraryBrowserGUI_Label*) [NSNull null]) [self->_bookTitleLabel release];
	if (self->_authorLabel != nil && self->_authorLabel != (LibraryBrowserGUI_Label*) [NSNull null]) [self->_authorLabel release];
	if (self->_bookAuthorLabel != nil && self->_bookAuthorLabel != (LibraryBrowserGUI_Label*) [NSNull null]) [self->_bookAuthorLabel release];
	if (self->_isbnLabel != nil && self->_isbnLabel != (LibraryBrowserGUI_Label*) [NSNull null]) [self->_isbnLabel release];
	if (self->_bookIsbnLabel != nil && self->_bookIsbnLabel != (LibraryBrowserGUI_Label*) [NSNull null]) [self->_bookIsbnLabel release];
	if (self->_viewTitle != nil && self->_viewTitle != (OCLString*) [NSNull null]) [self->_viewTitle release];
	if (self->_seqGUIElements != nil && self->_seqGUIElements != (OCLSequence*) [NSNull null]) [self->_seqGUIElements release];

	[self->LibraryBrowserGUI_BookListView_bookDetailView_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"LibraryBrowserGUI::BookDetailView\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"titleLabel\" type=\"LibraryBrowserGUI::Label\">\n"];
	[res appendFormat:@"%@\n", [self _titleLabel]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"bookTitleLabel\" type=\"LibraryBrowserGUI::Label\">\n"];
	[res appendFormat:@"%@\n", [self _bookTitleLabel]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"authorLabel\" type=\"LibraryBrowserGUI::Label\">\n"];
	[res appendFormat:@"%@\n", [self _authorLabel]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"bookAuthorLabel\" type=\"LibraryBrowserGUI::Label\">\n"];
	[res appendFormat:@"%@\n", [self _bookAuthorLabel]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"isbnLabel\" type=\"LibraryBrowserGUI::Label\">\n"];
	[res appendFormat:@"%@\n", [self _isbnLabel]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"bookIsbnLabel\" type=\"LibraryBrowserGUI::Label\">\n"];
	[res appendFormat:@"%@\n", [self _bookIsbnLabel]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"viewTitle\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _viewTitle]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"seqGUIElements\" type=\"Sequence\">\n"];
	[res appendFormat:@"%@\n", [self _seqGUIElements]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
-(LibraryBrowserGUI_Label*) initial_titleLabel {
	/* ==================================================
	 * Label::create(Tuple { text = 'Title: ' })
	 * ================================================== */
	
	OCLString* v4 = [(OCLString*)[OCLString alloc] initWithString:@"Title: "];
	OCLString* v3 = v4;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"text" withValue:v3];
	LibraryBrowserGUI_Label* v0 = [(LibraryBrowserGUI_Label*)[LibraryBrowserGUI_Label alloc] initWithValues:v2];
	[v2 release];
	[v4 release];
	
	return v0;
}

-(LibraryBrowserGUI_Label*) _titleLabel {
	if (self->_titleLabel_initialized == YES) {
		return _titleLabel;
	} else { 
		[self set_titleLabel:[self initial_titleLabel]];
	}

	self->_titleLabel_initialized = YES;
	return _titleLabel;
}
-(LibraryBrowserGUI_Label*) initial_bookTitleLabel {
	/* ==================================================
	 * null
	 * ================================================== */
	
	LibraryBrowserGUI_Label* v0 = [NSNull null];
	
	return v0;
}

-(LibraryBrowserGUI_Label*) _bookTitleLabel {
	if (self->_bookTitleLabel_initialized == YES) {
		return _bookTitleLabel;
	} else { 
		[self set_bookTitleLabel:[self initial_bookTitleLabel]];
	}

	self->_bookTitleLabel_initialized = YES;
	return _bookTitleLabel;
}
-(LibraryBrowserGUI_Label*) initial_authorLabel {
	/* ==================================================
	 * Label::create(Tuple { text = 'Author: ' })
	 * ================================================== */
	
	OCLString* v4 = [(OCLString*)[OCLString alloc] initWithString:@"Author: "];
	OCLString* v3 = v4;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"text" withValue:v3];
	LibraryBrowserGUI_Label* v0 = [(LibraryBrowserGUI_Label*)[LibraryBrowserGUI_Label alloc] initWithValues:v2];
	[v2 release];
	[v4 release];
	
	return v0;
}

-(LibraryBrowserGUI_Label*) _authorLabel {
	if (self->_authorLabel_initialized == YES) {
		return _authorLabel;
	} else { 
		[self set_authorLabel:[self initial_authorLabel]];
	}

	self->_authorLabel_initialized = YES;
	return _authorLabel;
}
-(LibraryBrowserGUI_Label*) initial_bookAuthorLabel {
	/* ==================================================
	 * null
	 * ================================================== */
	
	LibraryBrowserGUI_Label* v0 = [NSNull null];
	
	return v0;
}

-(LibraryBrowserGUI_Label*) _bookAuthorLabel {
	if (self->_bookAuthorLabel_initialized == YES) {
		return _bookAuthorLabel;
	} else { 
		[self set_bookAuthorLabel:[self initial_bookAuthorLabel]];
	}

	self->_bookAuthorLabel_initialized = YES;
	return _bookAuthorLabel;
}
-(LibraryBrowserGUI_Label*) initial_isbnLabel {
	/* ==================================================
	 * Label::create(Tuple { text = 'ISBN: ' })
	 * ================================================== */
	
	OCLString* v4 = [(OCLString*)[OCLString alloc] initWithString:@"ISBN: "];
	OCLString* v3 = v4;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"text" withValue:v3];
	LibraryBrowserGUI_Label* v0 = [(LibraryBrowserGUI_Label*)[LibraryBrowserGUI_Label alloc] initWithValues:v2];
	[v2 release];
	[v4 release];
	
	return v0;
}

-(LibraryBrowserGUI_Label*) _isbnLabel {
	if (self->_isbnLabel_initialized == YES) {
		return _isbnLabel;
	} else { 
		[self set_isbnLabel:[self initial_isbnLabel]];
	}

	self->_isbnLabel_initialized = YES;
	return _isbnLabel;
}
-(LibraryBrowserGUI_Label*) initial_bookIsbnLabel {
	/* ==================================================
	 * null
	 * ================================================== */
	
	LibraryBrowserGUI_Label* v0 = [NSNull null];
	
	return v0;
}

-(LibraryBrowserGUI_Label*) _bookIsbnLabel {
	if (self->_bookIsbnLabel_initialized == YES) {
		return _bookIsbnLabel;
	} else { 
		[self set_bookIsbnLabel:[self initial_bookIsbnLabel]];
	}

	self->_bookIsbnLabel_initialized = YES;
	return _bookIsbnLabel;
}
-(OCLString*) initial_viewTitle {
	/* ==================================================
	 * 'Book Detail'
	 * ================================================== */
	
	OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@"Book Detail"];
	
	return v0;
}

-(OCLString*) _viewTitle {
	if (self->_viewTitle_initialized == YES) {
		return _viewTitle;
	} else { 
		[self set_viewTitle:[self initial_viewTitle]];
	}

	self->_viewTitle_initialized = YES;
	return _viewTitle;
}
-(OCLSequence*) initial_seqGUIElements {
	/* ==================================================
	 * Sequence { titleLabel, bookTitleLabel, authorLabel, bookAuthorLabel, isbnLabel, bookIsbnLabel }
	 * ================================================== */
	
	LibraryBrowserGUI_BookDetailView* v3 = self;
	LibraryBrowserGUI_Label* v2 = [v3 _titleLabel];
	LibraryBrowserGUI_Label* v1 = v2;
	LibraryBrowserGUI_BookDetailView* v6 = self;
	LibraryBrowserGUI_Label* v5 = [v6 _bookTitleLabel];
	LibraryBrowserGUI_Label* v4 = v5;
	LibraryBrowserGUI_BookDetailView* v9 = self;
	LibraryBrowserGUI_Label* v8 = [v9 _authorLabel];
	LibraryBrowserGUI_Label* v7 = v8;
	LibraryBrowserGUI_BookDetailView* v12 = self;
	LibraryBrowserGUI_Label* v11 = [v12 _bookAuthorLabel];
	LibraryBrowserGUI_Label* v10 = v11;
	LibraryBrowserGUI_BookDetailView* v15 = self;
	LibraryBrowserGUI_Label* v14 = [v15 _isbnLabel];
	LibraryBrowserGUI_Label* v13 = v14;
	LibraryBrowserGUI_BookDetailView* v18 = self;
	LibraryBrowserGUI_Label* v17 = [v18 _bookIsbnLabel];
	LibraryBrowserGUI_Label* v16 = v17;
	OCLSequence* v0 = [(OCLSequence*)[OCLSequence alloc] init];
	[v0 add:v1];
	[v0 add:v4];
	[v0 add:v7];
	[v0 add:v10];
	[v0 add:v13];
	[v0 add:v16];
	
	return v0;
}

-(OCLSequence*) _seqGUIElements {
	if (self->_seqGUIElements_initialized == YES) {
		return _seqGUIElements;
	} else { 
		[self set_seqGUIElements:[self initial_seqGUIElements]];
	}

	self->_seqGUIElements_initialized = YES;
	return _seqGUIElements;
}


 
-(void) set_viewTitle:(OCLString*) value {
	 	if (self->_viewTitle!= nil && self->_viewTitle!= (OCLString*) [NSNull null]) {
		[self->_viewTitle release];
	}
	self->_viewTitle = value;
	if (self->_viewTitle!= nil && self->_viewTitle!= (OCLString*) [NSNull null]) {
		[self->_viewTitle retain];
	}
	self->_viewTitle_initialized = YES;
	
	[self onPropertyChange:@"viewTitle" newValue:value];
}
-(void) set_seqGUIElements:(OCLSequence*) value {
	 	if (self->_seqGUIElements!= nil && self->_seqGUIElements!= (OCLSequence*) [NSNull null]) {
		[self->_seqGUIElements release];
	}
	self->_seqGUIElements = value;
	if (self->_seqGUIElements!= nil && self->_seqGUIElements!= (OCLSequence*) [NSNull null]) {
		[self->_seqGUIElements retain];
	}
	self->_seqGUIElements_initialized = YES;
	
	[self onPropertyChange:@"seqGUIElements" newValue:value];
}


-(void) set_titleLabel:(LibraryBrowserGUI_Label*) value {
	 
	if (self->_titleLabel!= nil && self->_titleLabel!= (LibraryBrowserGUI_Label*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_titleLabel valueForKey:@"LibraryBrowserGUI_BookDetailView_titleLabel_back"];
		[backpointers removeObject:self];
		[self->_titleLabel release];
	}
	self->_titleLabel = value;
	if (self->_titleLabel!= nil && self->_titleLabel!= (LibraryBrowserGUI_Label*) [NSNull null]) {
		[self->_titleLabel retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_titleLabel valueForKey:@"LibraryBrowserGUI_BookDetailView_titleLabel_back"];
		[backpointers addObject:self];
	}
	self->_titleLabel_initialized = YES;
	
	[self onPropertyChange:@"titleLabel" newValue:value];
}
-(void) set_bookTitleLabel:(LibraryBrowserGUI_Label*) value {
	 
	if (self->_bookTitleLabel!= nil && self->_bookTitleLabel!= (LibraryBrowserGUI_Label*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_bookTitleLabel valueForKey:@"LibraryBrowserGUI_BookDetailView_bookTitleLabel_back"];
		[backpointers removeObject:self];
		[self->_bookTitleLabel release];
	}
	self->_bookTitleLabel = value;
	if (self->_bookTitleLabel!= nil && self->_bookTitleLabel!= (LibraryBrowserGUI_Label*) [NSNull null]) {
		[self->_bookTitleLabel retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_bookTitleLabel valueForKey:@"LibraryBrowserGUI_BookDetailView_bookTitleLabel_back"];
		[backpointers addObject:self];
	}
	self->_bookTitleLabel_initialized = YES;
	
	[self onPropertyChange:@"bookTitleLabel" newValue:value];
}
-(void) set_authorLabel:(LibraryBrowserGUI_Label*) value {
	 
	if (self->_authorLabel!= nil && self->_authorLabel!= (LibraryBrowserGUI_Label*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_authorLabel valueForKey:@"LibraryBrowserGUI_BookDetailView_authorLabel_back"];
		[backpointers removeObject:self];
		[self->_authorLabel release];
	}
	self->_authorLabel = value;
	if (self->_authorLabel!= nil && self->_authorLabel!= (LibraryBrowserGUI_Label*) [NSNull null]) {
		[self->_authorLabel retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_authorLabel valueForKey:@"LibraryBrowserGUI_BookDetailView_authorLabel_back"];
		[backpointers addObject:self];
	}
	self->_authorLabel_initialized = YES;
	
	[self onPropertyChange:@"authorLabel" newValue:value];
}
-(void) set_bookAuthorLabel:(LibraryBrowserGUI_Label*) value {
	 
	if (self->_bookAuthorLabel!= nil && self->_bookAuthorLabel!= (LibraryBrowserGUI_Label*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_bookAuthorLabel valueForKey:@"LibraryBrowserGUI_BookDetailView_bookAuthorLabel_back"];
		[backpointers removeObject:self];
		[self->_bookAuthorLabel release];
	}
	self->_bookAuthorLabel = value;
	if (self->_bookAuthorLabel!= nil && self->_bookAuthorLabel!= (LibraryBrowserGUI_Label*) [NSNull null]) {
		[self->_bookAuthorLabel retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_bookAuthorLabel valueForKey:@"LibraryBrowserGUI_BookDetailView_bookAuthorLabel_back"];
		[backpointers addObject:self];
	}
	self->_bookAuthorLabel_initialized = YES;
	
	[self onPropertyChange:@"bookAuthorLabel" newValue:value];
}
-(void) set_isbnLabel:(LibraryBrowserGUI_Label*) value {
	 
	if (self->_isbnLabel!= nil && self->_isbnLabel!= (LibraryBrowserGUI_Label*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_isbnLabel valueForKey:@"LibraryBrowserGUI_BookDetailView_isbnLabel_back"];
		[backpointers removeObject:self];
		[self->_isbnLabel release];
	}
	self->_isbnLabel = value;
	if (self->_isbnLabel!= nil && self->_isbnLabel!= (LibraryBrowserGUI_Label*) [NSNull null]) {
		[self->_isbnLabel retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_isbnLabel valueForKey:@"LibraryBrowserGUI_BookDetailView_isbnLabel_back"];
		[backpointers addObject:self];
	}
	self->_isbnLabel_initialized = YES;
	
	[self onPropertyChange:@"isbnLabel" newValue:value];
}
-(void) set_bookIsbnLabel:(LibraryBrowserGUI_Label*) value {
	 
	if (self->_bookIsbnLabel!= nil && self->_bookIsbnLabel!= (LibraryBrowserGUI_Label*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_bookIsbnLabel valueForKey:@"LibraryBrowserGUI_BookDetailView_bookIsbnLabel_back"];
		[backpointers removeObject:self];
		[self->_bookIsbnLabel release];
	}
	self->_bookIsbnLabel = value;
	if (self->_bookIsbnLabel!= nil && self->_bookIsbnLabel!= (LibraryBrowserGUI_Label*) [NSNull null]) {
		[self->_bookIsbnLabel retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_bookIsbnLabel valueForKey:@"LibraryBrowserGUI_BookDetailView_bookIsbnLabel_back"];
		[backpointers addObject:self];
	}
	self->_bookIsbnLabel_initialized = YES;
	
	[self onPropertyChange:@"bookIsbnLabel" newValue:value];
}




 

 


 
-(void)onPropertyChange:(NSString*)propertyName newValue:(id) value {
	if ([propertyName isEqual:@"viewTitle"]) {
		if (value != nil && value != [NSNull null]) 
			[self->binding setTitle: ((OCLString *) value)->string ];
	}
	 
	if ([value conformsToProtocol:@protocol(IBinding)]) {
		id propBinding = [value getBinding];
		if ([propBinding isKindOfClass: [UIViewController class]] && self->navigationController != nil) {
			[self->navigationController pushViewController:(UIViewController *)propBinding animated: YES];
			[value setBindingAttribute: @"navigationController" newValue: self->navigationController];
		}
	}

}

 
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters{
}

 
-(id) getBinding {
	return self->binding;
}

 
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value {
	if ([propertyName isEqual:@"navigationController"]) {
		if (value != nil && value != [NSNull null] && [value isKindOfClass: [UINavigationController class]]) 
			self->navigationController = (UINavigationController *) value;
	}
}

 
- (void) addWidgets: (UIView *) view {
	OCLSequence* widgets = [self _seqGUIElements];
	int y_pos = 0;
	NSEnumerator* e = [widgets objectEnumerator];
	id object;
	while ((object = [e nextObject])) {
		if ([object conformsToProtocol:@protocol(IBinding)]) {
			id<IBinding> propBinding = [object getBinding];
			if (![propBinding isKindOfClass: [UIPickerView class]]){
				((UIView*) propBinding).frame = CGRectMake(20, y_pos + 10, 280, 30);
				y_pos += 40;
			} else {
				((UIView*) propBinding).frame  = CGRectMake(0,  y_pos + 10 , 320, 162);
				y_pos += 172;
			}
			[view addSubview: (UIView*) propBinding];
		}
	}
}


@end 



