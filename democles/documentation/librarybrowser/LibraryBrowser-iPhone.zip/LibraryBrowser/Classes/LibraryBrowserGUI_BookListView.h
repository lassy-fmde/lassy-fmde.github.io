  
 
 
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "OCLTypes.h"
#import "IBinding.h"

@class PropertyChangeList;
@class LibraryBrowserGUI_Label;
@class LibraryBrowserGUI_BookDetailView;
@class LibraryBrowserGUI_SearchView;


 
 
@interface LibraryBrowserGUI_BookListView : OCLAny <IBinding,UITableViewDelegate, UITableViewDataSource>
{
	 
	OCLSequence* _bookListTable;
	BOOL _bookListTable_initialized;
	LibraryBrowserGUI_BookDetailView* _bookDetailView;
	BOOL _bookDetailView_initialized;
	OCLString* _viewTitle;
	BOOL _viewTitle_initialized;


@public
	NSMutableArray *LibraryBrowserGUI_SearchView_resultView_back;


	
	@protected
	UITableViewController* binding;
	UINavigationController* navigationController;
}

 
-(LibraryBrowserGUI_BookListView*)init;
-(LibraryBrowserGUI_BookListView*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(OCLSequence*) _bookListTable;
-(OCLSequence*) initial_bookListTable;
-(void) set_bookListTable:(OCLSequence*) value;
-(LibraryBrowserGUI_BookDetailView*) _bookDetailView;
-(LibraryBrowserGUI_BookDetailView*) initial_bookDetailView;
-(void) set_bookDetailView:(LibraryBrowserGUI_BookDetailView*) value;
-(OCLString*) _viewTitle;
-(OCLString*) initial_viewTitle;
-(void) set_viewTitle:(OCLString*) value;

-(void) event_bookSelected_pushed:(PropertyChangeList*) changes p_id: (OCLInteger*) p_id;
-(void) event_selectedBookData_pushed:(PropertyChangeList*) changes p_author: (OCLString*) p_author p_title: (OCLString*) p_title p_isbn: (OCLString*) p_isbn;

 
-(id) getBinding;
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value;
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters;
-(void) onPropertyChange: (NSString*)propertyName newValue:(id<OCLAny>)value;


@end



