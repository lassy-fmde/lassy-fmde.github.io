#import <Foundation/Foundation.h>

@class OCLBoolean;
@class OCLAny;

@protocol OCLAny <NSObject>
-(OCLBoolean*)eq:(OCLAny*)other;
-(OCLBoolean*)neq:(OCLAny*)other;
//-(OCLBoolean*)oclIsUndefined;
//-(OCLBoolean*)oclIsInvalid;
//-(?)oclAsType:(Class)type; // implemented by AST visitor
-(OCLBoolean*)oclIsTypeOf:(Class)type;
-(OCLBoolean*)oclIsKindOfClass:(Class)type; 
-(OCLBoolean*)oclIsKindOfInterface:(NSString*)protocolName; 

// needed for ObjC compatibility (containers etc.):
-(BOOL)isEqual:(id)other;
// hash?

-(NSString*)description;

// utility methods
-(BOOL)isCompatibleType:(OCLAny*)other;
@end

@interface OCLAny : NSObject <OCLAny> {
}

@end

// Category to make NSNull output a description in XML
@interface NSNull (NullDescription)
-(NSString*)description;
@end
