  
 
 
#import "LibraryBrowserGUI_SelectionBox.h"
#import "PropertyChangeList.h"
#import "LibraryBrowserGUI_SearchView.h"


 
@implementation LibraryBrowserGUI_SelectionBox

 
- (id) init {
	self = [super init];
	 
	self->binding = [[UIPickerView alloc] init];
	self->binding.delegate = self;
	self->binding.dataSource = self;

	 
	self->LibraryBrowserGUI_SearchView_categorySelect_back = [[NSMutableArray alloc] init];

	[self set_choices: [self _choices]];
	[self set_selectedChoice: [self _selectedChoice]];


	 
	// Default row selected by picker
	OCLInteger* rowOCL = [[OCLInteger alloc] init];
	[rowOCL initWithValue:1];
	[self event_rowSelected_pushed: NULL p_id:rowOCL];

	return self;
}

 
- (id) initWithValues: (OCLTuple*) values {
	self = [super init];
	 
	self->binding = [[UIPickerView alloc] init];
	self->binding.delegate = self;
	self->binding.dataSource = self;

	 
	self->_choices_initialized = NO;
	self->_selectedChoice_initialized = NO;

	self->LibraryBrowserGUI_SearchView_categorySelect_back = [[NSMutableArray alloc] init];

	OCLSequence* _choices_initialValue = (OCLSequence*) [values objectForKey:@"choices"];
	if (_choices_initialValue == nil) {
		_choices_initialValue = [self _choices];
	}
	[self set_choices:_choices_initialValue];
	OCLString* _selectedChoice_initialValue = (OCLString*) [values objectForKey:@"selectedChoice"];
	if (_selectedChoice_initialValue == nil) {
		_selectedChoice_initialValue = [self _selectedChoice];
	}
	[self set_selectedChoice:_selectedChoice_initialValue];


	 
	// Default row selected by picker
	OCLInteger* rowOCL = [[OCLInteger alloc] init];
	[rowOCL initWithValue:1];
	[self event_rowSelected_pushed: NULL p_id:rowOCL];

	return self;
}

 
- (void) dealloc {
	if (self->_choices != nil && self->_choices != (OCLSequence*) [NSNull null]) [self->_choices release];
	if (self->_selectedChoice != nil && self->_selectedChoice != (OCLString*) [NSNull null]) [self->_selectedChoice release];

	[self->LibraryBrowserGUI_SearchView_categorySelect_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"LibraryBrowserGUI::SelectionBox\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"choices\" type=\"Sequence\">\n"];
	[res appendFormat:@"%@\n", [self _choices]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"selectedChoice\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _selectedChoice]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
-(OCLSequence*) initial_choices {
	/* ==================================================
	 * Sequence{}
	 * ================================================== */
	
	OCLSequence* v0 = [(OCLSequence*)[OCLSequence alloc] init];
	
	return v0;
}

-(OCLSequence*) _choices {
	if (self->_choices_initialized == YES) {
		return _choices;
	} else { 
		[self set_choices:[self initial_choices]];
	}

	self->_choices_initialized = YES;
	return _choices;
}
-(OCLString*) initial_selectedChoice {
	/* ==================================================
	 * ''
	 * ================================================== */
	
	OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@""];
	
	return v0;
}

-(OCLString*) _selectedChoice {
	if (self->_selectedChoice_initialized == YES) {
		return _selectedChoice;
	} else { 
		[self set_selectedChoice:[self initial_selectedChoice]];
	}

	self->_selectedChoice_initialized = YES;
	return _selectedChoice;
}


 
-(void) set_choices:(OCLSequence*) value {
	 	if (self->_choices!= nil && self->_choices!= (OCLSequence*) [NSNull null]) {
		[self->_choices release];
	}
	self->_choices = value;
	if (self->_choices!= nil && self->_choices!= (OCLSequence*) [NSNull null]) {
		[self->_choices retain];
	}
	self->_choices_initialized = YES;
	
	[self onPropertyChange:@"choices" newValue:value];
}
-(void) set_selectedChoice:(OCLString*) value {
	 	if (self->_selectedChoice!= nil && self->_selectedChoice!= (OCLString*) [NSNull null]) {
		[self->_selectedChoice release];
	}
	self->_selectedChoice = value;
	if (self->_selectedChoice!= nil && self->_selectedChoice!= (OCLString*) [NSNull null]) {
		[self->_selectedChoice retain];
	}
	self->_selectedChoice_initialized = YES;
	
	[self onPropertyChange:@"selectedChoice" newValue:value];
}






 

 
-(void) event_rowSelected_pushed:(PropertyChangeList*) changes  p_id: (OCLInteger*) p_id{
	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_rowSelected", @"LibraryBrowserGUI_SelectionBox");

		OCLTuple* parameters = [[OCLTuple alloc] init];
		[parameters addItemNamed:@"id" withValue:p_id]; 

		[self onEvent:@"rowSelected" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * choices->at(id)
		 * ================================================== */
		
		LibraryBrowserGUI_SelectionBox* v2 = self;
		OCLSequence* v1 = [v2 _choices];
		OCLInteger* v3 = p_id;
		OCLString* v0 = [v1 at:v3];
		
		OCLString* _selectedChoice_newValue = v0;
		[changes addChange:@selector(set_selectedChoice:) instance:self value:_selectedChoice_newValue];


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 




 
-(void)onPropertyChange:(NSString*)propertyName newValue:(id) value {
	if ([propertyName isEqual:@"choices"]){ 
		[self->binding reloadAllComponents];
	}
}

 
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters{
}

 
-(id) getBinding {
	return self->binding;
}

 
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value {
}

 
#pragma mark -
#pragma mark Picker Data Source Methods
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
	return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
	OCLInteger* size = [[self _choices] size];
	return size->value;
}

 
#pragma mark -
#pragma mark Picker Delegate Methods
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
	OCLInteger* rowOCL = [[OCLInteger alloc] init];
	[rowOCL initWithValue:row+1];
	OCLString* text = (OCLString*) [[self _choices] at: rowOCL];
	return text->string;
}
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
	OCLInteger* rowOCL = [[OCLInteger alloc] init];
	[rowOCL initWithValue:row+1];
	[self event_rowSelected_pushed: NULL p_id:rowOCL];
}


@end 



