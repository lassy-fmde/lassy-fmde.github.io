  
 
 
#import "Library_BookCollection.h"
#import "PropertyChangeList.h"
#import "Library_Book.h"
#import "LibraryPersistenceHandler_LibraryLoader.h"
#import "Application_Main.h"


 
@implementation Library_BookCollection

 
- (Library_BookCollection*) init {
	self = [super init];
	 
	self->LibraryPersistenceHandler_LibraryLoader_libraryBooks_back = [[NSMutableArray alloc] init];
	self->Application_Main_completeBookCollection_back = [[NSMutableArray alloc] init];
	self->Application_Main_booksFound_back = [[NSMutableArray alloc] init];

	[self set_Books: [self _Books]];

	return self;
}

 
- (Library_BookCollection*) initWithValues: (OCLTuple*) values {
	self = [super init];
	 
	self->_Books_initialized = NO;

	self->LibraryPersistenceHandler_LibraryLoader_libraryBooks_back = [[NSMutableArray alloc] init];
	self->Application_Main_completeBookCollection_back = [[NSMutableArray alloc] init];
	self->Application_Main_booksFound_back = [[NSMutableArray alloc] init];

	OCLSequence* _Books_initialValue = (OCLSequence*) [values objectForKey:@"Books"];
	if (_Books_initialValue == nil) {
		_Books_initialValue = [self _Books];
	}
	[self set_Books:_Books_initialValue];

	
	return self;
}

 
- (void) dealloc {
	if (self->_Books != nil && self->_Books != (OCLSequence*) [NSNull null]) [self->_Books release];

	[self->LibraryPersistenceHandler_LibraryLoader_libraryBooks_back release];
	[self->Application_Main_completeBookCollection_back release];
	[self->Application_Main_booksFound_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"Library::BookCollection\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"Books\" type=\"Sequence\">\n"];
	[res appendFormat:@"%@\n", [self _Books]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
-(OCLSequence*) initial_Books {
	/* ==================================================
	 * Sequence{}
	 * ================================================== */
	
	OCLSequence* v0 = [(OCLSequence*)[OCLSequence alloc] init];
	
	return v0;
}

-(OCLSequence*) _Books {
	if (self->_Books_initialized == YES) {
		return _Books;
	} else { 
		[self set_Books:[self initial_Books]];
	}

	self->_Books_initialized = YES;
	return _Books;
}


 




-(void) set_Books:(OCLSequence*) value {
	 
	if (self->_Books!= nil && self->_Books!= (OCLSequence*) [NSNull null]) {
		// Clear back pointer on old instance
		NSEnumerator* e = [self->_Books objectEnumerator];
		Library_Book* o;
		while ((o = [e nextObject]) != nil) {
			if (o != (Library_Book*)[NSNull null]) {
				NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)o valueForKey:@"Library_BookCollection_Books_back"];
				[backpointers removeObject:self];
			}
		}
		[self->_Books release];
	}
	self->_Books = value;
	if (self->_Books!= nil && self->_Books!= (OCLSequence*) [NSNull null]) {
		[self->_Books retain];
		// Add back pointer on new instance
		NSEnumerator* e = [self->_Books objectEnumerator];
		Library_Book* o;
		while ((o = [e nextObject]) != nil) {
			if (o != (Library_Book*)[NSNull null]) {
				NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)o valueForKey:@"Library_BookCollection_Books_back"];
				[backpointers addObject:self];
			}
		}
	}
	self->_Books_initialized = YES;

}


 


 


@end 



