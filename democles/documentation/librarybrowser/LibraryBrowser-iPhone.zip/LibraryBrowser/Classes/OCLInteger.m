#import "OCLInteger.h"
#import "OCLBoolean.h"
#import "OCLReal.h"
#import "OCLAny.h"
#import <math.h>

@implementation OCLInteger

-(int)value {
	return value;
}

-(OCLInteger*)initWithValue:(int)v {
	self = [super init];
	value = v;
	return self;
}

-(BOOL)isEqual:(id)other {
	BOOL res;
	if ([self isCompatibleType:other]) {
		OCLInteger* otherInt = (OCLInteger*)other;
		res = self->value == otherInt->value; 
	} else {
		res = NO;
	}
	return res;
}

-(NSUInteger)hash {
	return value;
}

-(NSString*)description {
	return [NSString stringWithFormat:@"<Integer id=\"%p\" retainCount=\"%i\" value=\"%i\"/>\n", self, [self retainCount], self->value];
}

-(OCLInteger*)plus:(OCLInteger*)other {
	return [(OCLInteger*)[OCLInteger alloc] initWithValue:value + other->value];
}

-(OCLInteger*)minus:(OCLInteger*)other {
	return [(OCLInteger*)[OCLInteger alloc] initWithValue:value - other->value];
}

-(OCLInteger*)mult:(OCLInteger*)other {
	return [(OCLInteger*)[OCLInteger alloc] initWithValue:value * other->value];
}

-(OCLInteger*)neg {
	return [(OCLInteger*)[OCLInteger alloc] initWithValue:-value];
}

-(OCLReal*)div:(OCLInteger*)other {
	if (other->value == 0) {
		return (OCLReal*)[NSNull null];
	}
	return [(OCLReal*)[OCLReal alloc] initWithValue:(double)value / (double)other->value];
}

-(OCLInteger*)idiv:(OCLInteger*)other {
	if (other->value == 0) {
		return (OCLInteger*)[NSNull null];
	}
	return [(OCLInteger*)[OCLInteger alloc] initWithValue:value / other->value];
}

-(OCLInteger*)mod:(OCLInteger*)other {
	return [(OCLInteger*)[OCLInteger alloc] initWithValue:value % other->value];
}

-(OCLInteger*)abs {
	return [(OCLInteger*)[OCLInteger alloc] initWithValue:abs(value)];
}

-(OCLInteger*)max:(OCLInteger*)other {
	return [(OCLInteger*)[OCLInteger alloc] initWithValue:value > other->value ? value : other->value];
}

-(OCLInteger*)min:(OCLInteger*)other {
	return [(OCLInteger*)[OCLInteger alloc] initWithValue:value < other->value ? value : other->value];
}

-(OCLBoolean*)lt:(OCLInteger*)other {
	return [(OCLBoolean*)[OCLBoolean alloc] initWithValue:value < other->value];
}

-(OCLBoolean*)gt:(OCLInteger*)other {
	return [(OCLBoolean*)[OCLBoolean alloc] initWithValue:value > other->value];
}

-(OCLBoolean*)lte:(OCLInteger*)other {
	return [(OCLBoolean*)[OCLBoolean alloc] initWithValue:value <= other->value];
}

-(OCLBoolean*)gte:(OCLInteger*)other {
	return [(OCLBoolean*)[OCLBoolean alloc] initWithValue:value >= other->value];
}


@end
