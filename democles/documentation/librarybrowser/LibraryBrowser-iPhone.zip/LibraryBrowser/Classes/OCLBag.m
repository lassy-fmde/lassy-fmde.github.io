#import <Foundation/Foundation.h>
#import "OCLBag.h"
#import "OCLSet.h"
#import "OCLAny.h"
#import "OCLInteger.h"
#import "OCLBoolean.h"

@implementation OCLBag

-(OCLBag*)init {
	self = [super init];
	self->bag = [[NSMutableArray alloc] init];
	return self;
}

-(void)dealloc {
	[self->bag release];
	[super dealloc];
}

-(OCLBag*)newCollection {
	return [[OCLBag alloc] init];
}

-(void)add:(OCLAny*)object {
	[self->bag addObject:object];
}

-(OCLInteger*)size {
	return [(OCLInteger*)[OCLInteger alloc] initWithValue:[self->bag count]];
}

-(OCLBoolean*)includes:(OCLAny*)object {
	return [(OCLBoolean*)[OCLBoolean alloc] initWithValue:[self->bag containsObject:object]];
}

-(NSEnumerator*)objectEnumerator {
	return [self->bag objectEnumerator];
}

-(NSString*)collectionName {
	return [NSString stringWithString:@"Bag"];
}

-(BOOL)isEqual:(id)other {
	BOOL res;
	if ([self isCompatibleType:other]) {
		OCLBag* otherBag = (OCLBag*)other;
		res = [self->bag isEqual:otherBag->bag]; 
	} else {
		res = NO;
	}
	return res;
}

-(OCLBag*)unionWithBag:(OCLBag*)other {
	OCLBag* res = [[OCLBag alloc] init];
	[res->bag setArray:self->bag];
	
	[res->bag addObjectsFromArray:other->bag];
	
	return res;
}

-(OCLBag*)unionWithSet:(OCLSet*)other {
	OCLBag* res = [[OCLBag alloc] init];
	[res->bag setArray:self->bag];
	
	NSArray* otherObjects = [other->set allObjects];
	[res->bag addObjectsFromArray:otherObjects];
	[otherObjects release];
	
	return res;
}

-(OCLBag*)intersectionWithBag:(OCLBag*)other {
	OCLBag* res = [[OCLBag alloc] init];

	NSEnumerator* e = [self objectEnumerator];
	OCLAny* o;
	while ((o = [e nextObject]) != nil) {
		if ([other->bag containsObject:o]) {
			[res add:o];
		}
	}

	return res;
}

-(OCLSet*)intersectionWithSet:(OCLSet*)other {
	OCLSet* res = [[OCLSet alloc] init];

	NSEnumerator* e = [self objectEnumerator];
	OCLAny* o;
	while ((o = [e nextObject]) != nil) {
		if ([other->set containsObject:o]) {
			[res add:o];
		}
	}

	return res;
}

-(OCLBag*)including:(OCLAny*)object {
	OCLBag* res = [[OCLBag alloc] init];
	[res->bag addObjectsFromArray:self->bag];
	[res->bag addObject:object];
	
	return res;
}

-(OCLBag*)excluding:(OCLAny*)object {
	OCLBag* res = [[OCLBag alloc] init];
	[res->bag addObjectsFromArray:self->bag];
	[res->bag removeObject:object];
	
	return res;
}

-(OCLInteger*)count:(OCLAny*)object {
	OCLInteger* res = [[OCLInteger alloc] init];
	NSEnumerator* e = [self objectEnumerator];
	OCLAny* o;
	while ((o = [e nextObject]) != nil) {
		if ([o isEqual:object]) {
			res->value++;
		}
	}
	
	return res;
}

-(OCLBag*)flatten {
	return (OCLBag*)[super flatten];
}

@end
