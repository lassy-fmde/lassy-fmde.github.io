#import <Foundation/Foundation.h>
#import "OCLAny.h"

@class OCLBoolean;
@class OCLInteger;

@interface OCLReal : OCLAny {
	@public
	double value;
}

-(double)value;

-(OCLReal*)initWithValue:(double)value;

// Real methods
-(OCLReal*)plus:(OCLReal*)other;
-(OCLReal*)minus:(OCLReal*)other;
-(OCLReal*)mult:(OCLReal*)other;
-(OCLReal*)neg;
-(OCLReal*)div:(OCLReal*)other;
-(OCLReal*)abs;
-(OCLInteger*)floor;
-(OCLInteger*)round;
-(OCLReal*)max:(OCLReal*)other;
-(OCLReal*)min:(OCLReal*)other;
-(OCLBoolean*)lt:(OCLReal*)other;
-(OCLBoolean*)gt:(OCLReal*)other;
-(OCLBoolean*)lte:(OCLReal*)other;
-(OCLBoolean*)gte:(OCLReal*)other;

// NSObject methods
-(NSUInteger)hash;
-(NSString*)description;
-(BOOL)isEqual:(id)other;

@end
