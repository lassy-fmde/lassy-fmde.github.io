  
 
 
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "OCLTypes.h"
#import "IBinding.h"

@class PropertyChangeList;
@class LibraryBrowserGUI_Label;
@class LibraryBrowserGUI_BookListView;


 
 
@interface LibraryBrowserGUI_BookDetailView : OCLAny <IBinding>
{
	 
	LibraryBrowserGUI_Label* _titleLabel;
	BOOL _titleLabel_initialized;
	LibraryBrowserGUI_Label* _bookTitleLabel;
	BOOL _bookTitleLabel_initialized;
	LibraryBrowserGUI_Label* _authorLabel;
	BOOL _authorLabel_initialized;
	LibraryBrowserGUI_Label* _bookAuthorLabel;
	BOOL _bookAuthorLabel_initialized;
	LibraryBrowserGUI_Label* _isbnLabel;
	BOOL _isbnLabel_initialized;
	LibraryBrowserGUI_Label* _bookIsbnLabel;
	BOOL _bookIsbnLabel_initialized;
	OCLString* _viewTitle;
	BOOL _viewTitle_initialized;
	OCLSequence* _seqGUIElements;
	BOOL _seqGUIElements_initialized;


@public
	NSMutableArray *LibraryBrowserGUI_BookListView_bookDetailView_back;


	
	@protected
	UIViewController* binding;
	UINavigationController* navigationController;
}

 
-(LibraryBrowserGUI_BookDetailView*)init;
-(LibraryBrowserGUI_BookDetailView*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(LibraryBrowserGUI_Label*) _titleLabel;
-(LibraryBrowserGUI_Label*) initial_titleLabel;
-(void) set_titleLabel:(LibraryBrowserGUI_Label*) value;
-(LibraryBrowserGUI_Label*) _bookTitleLabel;
-(LibraryBrowserGUI_Label*) initial_bookTitleLabel;
-(void) set_bookTitleLabel:(LibraryBrowserGUI_Label*) value;
-(LibraryBrowserGUI_Label*) _authorLabel;
-(LibraryBrowserGUI_Label*) initial_authorLabel;
-(void) set_authorLabel:(LibraryBrowserGUI_Label*) value;
-(LibraryBrowserGUI_Label*) _bookAuthorLabel;
-(LibraryBrowserGUI_Label*) initial_bookAuthorLabel;
-(void) set_bookAuthorLabel:(LibraryBrowserGUI_Label*) value;
-(LibraryBrowserGUI_Label*) _isbnLabel;
-(LibraryBrowserGUI_Label*) initial_isbnLabel;
-(void) set_isbnLabel:(LibraryBrowserGUI_Label*) value;
-(LibraryBrowserGUI_Label*) _bookIsbnLabel;
-(LibraryBrowserGUI_Label*) initial_bookIsbnLabel;
-(void) set_bookIsbnLabel:(LibraryBrowserGUI_Label*) value;
-(OCLString*) _viewTitle;
-(OCLString*) initial_viewTitle;
-(void) set_viewTitle:(OCLString*) value;
-(OCLSequence*) _seqGUIElements;
-(OCLSequence*) initial_seqGUIElements;
-(void) set_seqGUIElements:(OCLSequence*) value;


 
-(id) getBinding;
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value;
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters;
-(void) onPropertyChange: (NSString*)propertyName newValue:(id<OCLAny>)value;

 
-(void) addWidgets: (UIView *) view;


@end



