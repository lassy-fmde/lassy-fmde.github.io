  
 
 
#import "Application_Main.h"
#import "PropertyChangeList.h"
#import "Library_BookCollection.h"
#import "LibraryPersistenceHandler_LibraryLoader.h"
#import "LibraryBrowserGUI_MainWindow.h"
#import "Application_Main.h"
#import "Library_Book.h"


 
@implementation Application_Main

 
- (Application_Main*) init {
	self = [super init];
	 

	[self set_completeBookCollection: [self _completeBookCollection]];
	[self set_booksFound: [self _booksFound]];
	[self set_mainGUI: [self _mainGUI]];
	[self set_libraryLoader: [self _libraryLoader]];

	return self;
}

 
- (Application_Main*) initWithValues: (OCLTuple*) values {
	self = [super init];
	 
	self->_completeBookCollection_initialized = NO;
	self->_booksFound_initialized = NO;
	self->_mainGUI_initialized = NO;
	self->_libraryLoader_initialized = NO;


	Library_BookCollection* _completeBookCollection_initialValue = (Library_BookCollection*) [values objectForKey:@"completeBookCollection"];
	if (_completeBookCollection_initialValue == nil) {
		_completeBookCollection_initialValue = [self _completeBookCollection];
	}
	[self set_completeBookCollection:_completeBookCollection_initialValue];
	Library_BookCollection* _booksFound_initialValue = (Library_BookCollection*) [values objectForKey:@"booksFound"];
	if (_booksFound_initialValue == nil) {
		_booksFound_initialValue = [self _booksFound];
	}
	[self set_booksFound:_booksFound_initialValue];
	LibraryBrowserGUI_MainWindow* _mainGUI_initialValue = (LibraryBrowserGUI_MainWindow*) [values objectForKey:@"mainGUI"];
	if (_mainGUI_initialValue == nil) {
		_mainGUI_initialValue = [self _mainGUI];
	}
	[self set_mainGUI:_mainGUI_initialValue];
	LibraryPersistenceHandler_LibraryLoader* _libraryLoader_initialValue = (LibraryPersistenceHandler_LibraryLoader*) [values objectForKey:@"libraryLoader"];
	if (_libraryLoader_initialValue == nil) {
		_libraryLoader_initialValue = [self _libraryLoader];
	}
	[self set_libraryLoader:_libraryLoader_initialValue];

	
	return self;
}

 
- (void) dealloc {
	if (self->_completeBookCollection != nil && self->_completeBookCollection != (Library_BookCollection*) [NSNull null]) [self->_completeBookCollection release];
	if (self->_booksFound != nil && self->_booksFound != (Library_BookCollection*) [NSNull null]) [self->_booksFound release];
	if (self->_mainGUI != nil && self->_mainGUI != (LibraryBrowserGUI_MainWindow*) [NSNull null]) [self->_mainGUI release];
	if (self->_libraryLoader != nil && self->_libraryLoader != (LibraryPersistenceHandler_LibraryLoader*) [NSNull null]) [self->_libraryLoader release];

	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"Application::Main\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"completeBookCollection\" type=\"Library::BookCollection\">\n"];
	[res appendFormat:@"%@\n", [self _completeBookCollection]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"booksFound\" type=\"Library::BookCollection\">\n"];
	[res appendFormat:@"%@\n", [self _booksFound]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"mainGUI\" type=\"LibraryBrowserGUI::MainWindow\">\n"];
	[res appendFormat:@"%@\n", [self _mainGUI]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"libraryLoader\" type=\"LibraryPersistenceHandler::LibraryLoader\">\n"];
	[res appendFormat:@"%@\n", [self _libraryLoader]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
-(Library_BookCollection*) initial_completeBookCollection {
	/* ==================================================
	 * Library::BookCollection::create(
	 * 	Tuple { 
	 * 		Books = Sequence {
	 * 			Library::Book::create(Tuple { author = 'Author', title = 'Test', isbn = '1234' })
	 * 		} 
	 * 	})
	 * ================================================== */
	
	OCLString* v10 = [(OCLString*)[OCLString alloc] initWithString:@"Author"];
	OCLString* v9 = v10;
	OCLString* v12 = [(OCLString*)[OCLString alloc] initWithString:@"Test"];
	OCLString* v11 = v12;
	OCLString* v14 = [(OCLString*)[OCLString alloc] initWithString:@"1234"];
	OCLString* v13 = v14;
	OCLTuple* v8 = [(OCLTuple*)[OCLTuple alloc] init];
	[v8 addItemNamed:@"author" withValue:v9];
	[v8 addItemNamed:@"title" withValue:v11];
	[v8 addItemNamed:@"isbn" withValue:v13];
	Library_Book* v6 = [(Library_Book*)[Library_Book alloc] initWithValues:v8];
	Library_Book* v5 = v6;
	OCLSequence* v4 = [(OCLSequence*)[OCLSequence alloc] init];
	[v4 add:v5];
	OCLSequence* v3 = v4;
	OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
	[v2 addItemNamed:@"Books" withValue:v3];
	Library_BookCollection* v0 = [(Library_BookCollection*)[Library_BookCollection alloc] initWithValues:v2];
	[v2 release];
	[v10 release];
	[v4 release];
	[v8 release];
	[v14 release];
	[v6 release];
	[v12 release];
	
	return v0;
}

-(Library_BookCollection*) _completeBookCollection {
	if (self->_completeBookCollection_initialized == YES) {
		return _completeBookCollection;
	} else { 
		[self set_completeBookCollection:[self initial_completeBookCollection]];
	}

	self->_completeBookCollection_initialized = YES;
	return _completeBookCollection;
}
-(Library_BookCollection*) initial_booksFound {
	/* ==================================================
	 * null
	 * ================================================== */
	
	Library_BookCollection* v0 = [NSNull null];
	
	return v0;
}

-(Library_BookCollection*) _booksFound {
	if (self->_booksFound_initialized == YES) {
		return _booksFound;
	} else { 
		[self set_booksFound:[self initial_booksFound]];
	}

	self->_booksFound_initialized = YES;
	return _booksFound;
}
-(LibraryBrowserGUI_MainWindow*) initial_mainGUI {
	/* ==================================================
	 * LibraryBrowserGUI::MainWindow::create()
	 * ================================================== */
	
	LibraryBrowserGUI_MainWindow* v0 = [(LibraryBrowserGUI_MainWindow*)[LibraryBrowserGUI_MainWindow alloc] init];
	
	return v0;
}

-(LibraryBrowserGUI_MainWindow*) _mainGUI {
	if (self->_mainGUI_initialized == YES) {
		return _mainGUI;
	} else { 
		[self set_mainGUI:[self initial_mainGUI]];
	}

	self->_mainGUI_initialized = YES;
	return _mainGUI;
}
-(LibraryPersistenceHandler_LibraryLoader*) initial_libraryLoader {
	/* ==================================================
	 * LibraryPersistenceHandler::LibraryLoader::create()
	 * ================================================== */
	
	LibraryPersistenceHandler_LibraryLoader* v0 = [(LibraryPersistenceHandler_LibraryLoader*)[LibraryPersistenceHandler_LibraryLoader alloc] init];
	
	return v0;
}

-(LibraryPersistenceHandler_LibraryLoader*) _libraryLoader {
	if (self->_libraryLoader_initialized == YES) {
		return _libraryLoader;
	} else { 
		[self set_libraryLoader:[self initial_libraryLoader]];
	}

	self->_libraryLoader_initialized = YES;
	return _libraryLoader;
}


 


-(void) set_completeBookCollection:(Library_BookCollection*) value {
	 
	if (self->_completeBookCollection!= nil && self->_completeBookCollection!= (Library_BookCollection*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_completeBookCollection valueForKey:@"Application_Main_completeBookCollection_back"];
		[backpointers removeObject:self];
		[self->_completeBookCollection release];
	}
	self->_completeBookCollection = value;
	if (self->_completeBookCollection!= nil && self->_completeBookCollection!= (Library_BookCollection*) [NSNull null]) {
		[self->_completeBookCollection retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_completeBookCollection valueForKey:@"Application_Main_completeBookCollection_back"];
		[backpointers addObject:self];
	}
	self->_completeBookCollection_initialized = YES;

}
-(void) set_booksFound:(Library_BookCollection*) value {
	 
	if (self->_booksFound!= nil && self->_booksFound!= (Library_BookCollection*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_booksFound valueForKey:@"Application_Main_booksFound_back"];
		[backpointers removeObject:self];
		[self->_booksFound release];
	}
	self->_booksFound = value;
	if (self->_booksFound!= nil && self->_booksFound!= (Library_BookCollection*) [NSNull null]) {
		[self->_booksFound retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_booksFound valueForKey:@"Application_Main_booksFound_back"];
		[backpointers addObject:self];
	}
	self->_booksFound_initialized = YES;

}
-(void) set_mainGUI:(LibraryBrowserGUI_MainWindow*) value {
	 
	if (self->_mainGUI!= nil && self->_mainGUI!= (LibraryBrowserGUI_MainWindow*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_mainGUI valueForKey:@"Application_Main_mainGUI_back"];
		[backpointers removeObject:self];
		[self->_mainGUI release];
	}
	self->_mainGUI = value;
	if (self->_mainGUI!= nil && self->_mainGUI!= (LibraryBrowserGUI_MainWindow*) [NSNull null]) {
		[self->_mainGUI retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_mainGUI valueForKey:@"Application_Main_mainGUI_back"];
		[backpointers addObject:self];
	}
	self->_mainGUI_initialized = YES;

}
-(void) set_libraryLoader:(LibraryPersistenceHandler_LibraryLoader*) value {
	 
	if (self->_libraryLoader!= nil && self->_libraryLoader!= (LibraryPersistenceHandler_LibraryLoader*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_libraryLoader valueForKey:@"Application_Main_libraryLoader_back"];
		[backpointers removeObject:self];
		[self->_libraryLoader release];
	}
	self->_libraryLoader = value;
	if (self->_libraryLoader!= nil && self->_libraryLoader!= (LibraryPersistenceHandler_LibraryLoader*) [NSNull null]) {
		[self->_libraryLoader retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_libraryLoader valueForKey:@"Application_Main_libraryLoader_back"];
		[backpointers addObject:self];
	}
	self->_libraryLoader_initialized = YES;

}




 
-(void) event_searchFinished_pushed:(PropertyChangeList*) changes  p_booksFound: (OCLAny*) p_booksFound{
	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_searchFinished", @"Application_Main");

		 
		// Trigger Push edges

		if (self->_mainGUI != nil && self->_mainGUI != (LibraryBrowserGUI_MainWindow*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_mainGUI];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			LibraryBrowserGUI_MainWindow* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * booksFound.oclAsType(Library::BookCollection).Books->collect(b:Library::Book | b.title)
				 * ================================================== */
				
				OCLAny* v4 = p_booksFound;
				Library_BookCollection* v3 = ((Library_BookCollection*)v4);
				OCLSequence* v2 = [v3 _Books];
				OCLSequence* v1_nested = [(OCLSequence*)[OCLSequence alloc] init];
				NSEnumerator* v1_enum = [v2 objectEnumerator];
				Library_Book* v6;
				while ((v6 = [v1_enum nextObject]) != nil) {
					Library_Book* v8 = v6;
					OCLString* v7 = [v8 _title];
					[v1_nested add: v7];
				}
				OCLSequence* v1 = [v1_nested flatten];
				[v1_nested release];
				
					OCLSequence* parameter_p_booksFound = v1;

					[edge0_target event_searchFinished_pushed:changes p_booksFound:parameter_p_booksFound ];
					[v1 release];

				}
				[v0 release];
			}
			// Release targets collection
			[edge0_values release];

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * booksFound.oclAsType(Library::BookCollection)
		 * ================================================== */
		
		OCLAny* v1 = p_booksFound;
		Library_BookCollection* v0 = ((Library_BookCollection*)v1);
		
		Library_BookCollection* _booksFound_newValue = v0;
		[changes addChange:@selector(set_booksFound:) instance:self value:_booksFound_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_searchBook_pushed:(PropertyChangeList*) changes  p_keyword: (OCLString*) p_keyword p_category: (OCLString*) p_category{
	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_searchBook", @"Application_Main");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {
			/* ==================================================
			 * Library::BookCollection::create(
			 * 	Tuple { Books =
			 * 			completeBookCollection.Books->select (
			 * 				b: Library::Book | ((category='Author') and (b.author=keyword)) or ((category = 'Title') and (b.title = keyword)) or ((category = 'ISBN') and (b.isbn = keyword))
			 * 				)
			 * 	})
			 * ================================================== */
			
			Library_BookCollection* v7 = [self _completeBookCollection];
			OCLSequence* v6 = [v7 _Books];
			OCLSequence* v5 = [(OCLSequence*)[OCLSequence alloc] init];
			NSEnumerator* v5_enum = [v6 objectEnumerator];
			Library_Book* v8;
			while ((v8 = [v5_enum nextObject]) != nil) {
				OCLString* v13 = p_category;
				OCLString* v14 = [(OCLString*)[OCLString alloc] initWithString:@"Author"];
				OCLBoolean* v12 = [v13 eq:v14];
				Library_Book* v17 = v8;
				OCLString* v16 = [v17 _author];
				OCLString* v18 = p_keyword;
				OCLBoolean* v15 = [v16 eq:v18];
				OCLBoolean* v11 = [v12 and:v15];
				OCLString* v21 = p_category;
				OCLString* v22 = [(OCLString*)[OCLString alloc] initWithString:@"Title"];
				OCLBoolean* v20 = [v21 eq:v22];
				Library_Book* v25 = v8;
				OCLString* v24 = [v25 _title];
				OCLString* v26 = p_keyword;
				OCLBoolean* v23 = [v24 eq:v26];
				OCLBoolean* v19 = [v20 and:v23];
				OCLBoolean* v10 = [v11 or:v19];
				OCLString* v29 = p_category;
				OCLString* v30 = [(OCLString*)[OCLString alloc] initWithString:@"ISBN"];
				OCLBoolean* v28 = [v29 eq:v30];
				Library_Book* v33 = v8;
				OCLString* v32 = [v33 _isbn];
				OCLString* v34 = p_keyword;
				OCLBoolean* v31 = [v32 eq:v34];
				OCLBoolean* v27 = [v28 and:v31];
				OCLBoolean* v9 = [v10 or:v27];
				if (v9->value == YES) { [v5 add: v8]; }
				[v27 release];
				[v22 release];
				[v10 release];
				[v30 release];
				[v28 release];
				[v14 release];
				[v20 release];
				[v31 release];
				[v23 release];
				[v19 release];
				[v9 release];
				[v12 release];
				[v15 release];
				[v11 release];
			}
			OCLSequence* v4 = v5;
			OCLTuple* v3 = [(OCLTuple*)[OCLTuple alloc] init];
			[v3 addItemNamed:@"Books" withValue:v4];
			OCLAny* v1 = [(Library_BookCollection*)[Library_BookCollection alloc] initWithValues:v3];
			[v3 release];
			
			OCLAny* parameter_p_booksFound = v1;

			[self event_searchFinished_pushed:changes p_booksFound:parameter_p_booksFound ];
		}
		[v0 release];


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_searchBook_pulled_edge0:(PropertyChangeList*)changes parentInstance:(LibraryBrowserGUI_MainWindow*)parentInstance p_keyword:(OCLString*)p_keyword p_category:(OCLString*)p_category  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_searchBook", @"Application_Main", @"_searchBook", @"LibraryBrowserGUI_MainWindow");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {
		/* ==================================================
		 * keyword
		 * ================================================== */
		
		OCLString* v1 = p_keyword;
		
		OCLString* parameter_p_keyword = v1;
		/* ==================================================
		 * category
		 * ================================================== */
		
		OCLString* v2 = p_category;
		
		OCLString* parameter_p_category = v2;

		[self event_searchBook_pushed:changes p_keyword:parameter_p_keyword p_category:parameter_p_category ];

	}
	[v0 release];
}


-(void) event_bookSelected_pushed:(PropertyChangeList*) changes  p_id: (OCLInteger*) p_id{
	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_bookSelected", @"Application_Main");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {
			/* ==================================================
			 * booksFound.Books->at(id).author
			 * ================================================== */
			
			Library_BookCollection* v4 = [self _booksFound];
			OCLSequence* v3 = [v4 _Books];
			OCLInteger* v5 = p_id;
			Library_Book* v2 = [v3 at:v5];
			OCLString* v1 = [v2 _author];
			
			OCLString* parameter_p_author = v1;
			/* ==================================================
			 * booksFound.Books->at(id).title
			 * ================================================== */
			
			Library_BookCollection* v9 = [self _booksFound];
			OCLSequence* v8 = [v9 _Books];
			OCLInteger* v10 = p_id;
			Library_Book* v7 = [v8 at:v10];
			OCLString* v6 = [v7 _title];
			
			OCLString* parameter_p_title = v6;
			/* ==================================================
			 * booksFound.Books->at(id).isbn
			 * ================================================== */
			
			Library_BookCollection* v14 = [self _booksFound];
			OCLSequence* v13 = [v14 _Books];
			OCLInteger* v15 = p_id;
			Library_Book* v12 = [v13 at:v15];
			OCLString* v11 = [v12 _isbn];
			
			OCLString* parameter_p_isbn = v11;

			[self event_selectedBookData_pushed:changes p_author:parameter_p_author p_title:parameter_p_title p_isbn:parameter_p_isbn ];
		}
		[v0 release];


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_bookSelected_pulled_edge0:(PropertyChangeList*)changes parentInstance:(LibraryBrowserGUI_MainWindow*)parentInstance p_id:(OCLInteger*)p_id  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_bookSelected", @"Application_Main", @"_bookSelected", @"LibraryBrowserGUI_MainWindow");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {
		/* ==================================================
		 * id
		 * ================================================== */
		
		OCLInteger* v1 = p_id;
		
		OCLInteger* parameter_p_id = v1;

		[self event_bookSelected_pushed:changes p_id:parameter_p_id ];

	}
	[v0 release];
}


-(void) event_selectedBookData_pushed:(PropertyChangeList*) changes  p_author: (OCLString*) p_author p_title: (OCLString*) p_title p_isbn: (OCLString*) p_isbn{
	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_selectedBookData", @"Application_Main");

		 
		// Trigger Push edges

		if (self->_mainGUI != nil && self->_mainGUI != (LibraryBrowserGUI_MainWindow*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_mainGUI];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			LibraryBrowserGUI_MainWindow* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {
					/* ==================================================
				 * author
				 * ================================================== */
				
				OCLString* v1 = p_author;
				
					OCLString* parameter_p_author = v1;
					/* ==================================================
				 * title
				 * ================================================== */
				
				OCLString* v2 = p_title;
				
					OCLString* parameter_p_title = v2;
					/* ==================================================
				 * isbn
				 * ================================================== */
				
				OCLString* v3 = p_isbn;
				
					OCLString* parameter_p_isbn = v3;

					[edge0_target event_selectedBookData_pushed:changes p_author:parameter_p_author p_title:parameter_p_title p_isbn:parameter_p_isbn ];

				}
				[v0 release];
			}
			// Release targets collection
			[edge0_values release];

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_libraryBooksLoaded_pushed:(PropertyChangeList*) changes  p_bookCollection: (Library_BookCollection*) p_bookCollection{
	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_libraryBooksLoaded", @"Application_Main");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {
			/* ==================================================
			 * bookCollection
			 * ================================================== */
			
			Library_BookCollection* v1 = p_bookCollection;
			
			Library_BookCollection* parameter_p_completeBookCollection = v1;

			[self event_setCompleteBookCollection_pushed:changes p_completeBookCollection:parameter_p_completeBookCollection ];
		}
		[v0 release];


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 
-(void)event_libraryBooksLoaded_pulled_edge0:(PropertyChangeList*)changes parentInstance:(LibraryPersistenceHandler_LibraryLoader*)parentInstance  {
	NSLog(@"event%@_pulled in model %@ from event %@ in model %@\n", @"_libraryBooksLoaded", @"Application_Main", @"_libraryFileClosed", @"LibraryPersistenceHandler_LibraryLoader");

	/* ==================================================
	 * true
	 * ================================================== */
	
	OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
	
	if (v0->value == YES) {
		/* ==================================================
		 * libraryLoader.libraryBooks
		 * ================================================== */
		
		Application_Main* v3 = self;
		LibraryPersistenceHandler_LibraryLoader* v2 = [v3 _libraryLoader];
		Library_BookCollection* v1 = [v2 _libraryBooks];
		
		Library_BookCollection* parameter_p_bookCollection = v1;

		[self event_libraryBooksLoaded_pushed:changes p_bookCollection:parameter_p_bookCollection ];

	}
	[v0 release];
}


-(void) event_setCompleteBookCollection_pushed:(PropertyChangeList*) changes  p_completeBookCollection: (Library_BookCollection*) p_completeBookCollection{
	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_setCompleteBookCollection", @"Application_Main");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * -- Generated impacts relationship code:
		 * completeBookCollection
		 * ================================================== */
		
		Library_BookCollection* v0 = p_completeBookCollection;
		
		Library_BookCollection* _completeBookCollection_newValue = v0;
		[changes addChange:@selector(set_completeBookCollection:) instance:self value:_completeBookCollection_newValue];

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_init_pushed:(PropertyChangeList*) changes  {
	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_init", @"Application_Main");

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges
		/* ==================================================
		 * true
		 * ================================================== */
		
		OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
		
		if (v0->value == YES) {

			[self event_loadLibrary_pushed:changes ];
		}
		[v0 release];


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_loadLibrary_pushed:(PropertyChangeList*) changes  {
	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_loadLibrary", @"Application_Main");

		 
		// Trigger Push edges

		if (self->_libraryLoader != nil && self->_libraryLoader != (LibraryPersistenceHandler_LibraryLoader*)[NSNull null]) {
			 
			NSMutableArray* edge0_values = [[NSMutableArray alloc] init];
			[edge0_values addObject:self->_libraryLoader];
			NSEnumerator* edge0_enum = [edge0_values objectEnumerator];
			LibraryPersistenceHandler_LibraryLoader* edge0_target;
			while ((edge0_target = [edge0_enum nextObject]) != nil) {
				/* ==================================================
			 * true
			 * ================================================== */
			
			OCLBoolean* v0 = [(OCLBoolean*)[OCLBoolean alloc] initWithValue:YES];
			
				if (v0->value == YES) {

					[edge0_target event_loadLibrary_pushed:changes ];

				}
				[v0 release];
			}
			// Release targets collection
			[edge0_values release];

		}


		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships

	
	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 




 


@end 



