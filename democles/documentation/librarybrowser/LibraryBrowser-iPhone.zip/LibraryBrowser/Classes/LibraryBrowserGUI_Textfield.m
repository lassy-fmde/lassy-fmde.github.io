  
 
 
#import "LibraryBrowserGUI_Textfield.h"
#import "PropertyChangeList.h"
#import "LibraryBrowserGUI_SearchView.h"


 
@implementation LibraryBrowserGUI_Textfield

 
- (id) init {
	self = [super init];
	 
	self->binding = [[UITextField alloc] init];
	self->binding.borderStyle = UITextBorderStyleRoundedRect;

	 
	self->LibraryBrowserGUI_SearchView_searchField_back = [[NSMutableArray alloc] init];

	[self set_text: [self _text]];


	 
	self->binding.delegate = self;

	return self;
}

 
- (id) initWithValues: (OCLTuple*) values {
	self = [super init];
	 
	self->binding = [[UITextField alloc] init];
	self->binding.borderStyle = UITextBorderStyleRoundedRect;

	 
	self->_text_initialized = NO;

	self->LibraryBrowserGUI_SearchView_searchField_back = [[NSMutableArray alloc] init];

	OCLString* _text_initialValue = (OCLString*) [values objectForKey:@"text"];
	if (_text_initialValue == nil) {
		_text_initialValue = [self _text];
	}
	[self set_text:_text_initialValue];


	 
	self->binding.delegate = self;

	return self;
}

 
- (void) dealloc {
	if (self->_text != nil && self->_text != (OCLString*) [NSNull null]) [self->_text release];

	[self->LibraryBrowserGUI_SearchView_searchField_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"LibraryBrowserGUI::Textfield\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"text\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _text]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
-(OCLString*) initial_text {
	/* ==================================================
	 * ''
	 * ================================================== */
	
	OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@""];
	
	return v0;
}

-(OCLString*) _text {
	if (self->_text_initialized == YES) {
		return _text;
	} else { 
		[self set_text:[self initial_text]];
	}

	self->_text_initialized = YES;
	return _text;
}


 
-(void) set_text:(OCLString*) value {
	 	if (self->_text!= nil && self->_text!= (OCLString*) [NSNull null]) {
		[self->_text release];
	}
	self->_text = value;
	if (self->_text!= nil && self->_text!= (OCLString*) [NSNull null]) {
		[self->_text retain];
	}
	self->_text_initialized = YES;
	
	[self onPropertyChange:@"text" newValue:value];
}






 

 
-(void) event_setText_pushed:(PropertyChangeList*) changes  p_text: (OCLString*) p_text{
	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_setText", @"LibraryBrowserGUI_Textfield");

		OCLTuple* parameters = [[OCLTuple alloc] init];
		[parameters addItemNamed:@"text" withValue:p_text]; 

		[self onEvent:@"setText" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * -- Generated impacts relationship code:
		 * text
		 * ================================================== */
		
		OCLString* v0 = p_text;
		
		OCLString* _text_newValue = v0;
		[changes addChange:@selector(set_text:) instance:self value:_text_newValue];


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 




 
-(void)onPropertyChange:(NSString*)propertyName newValue:(id) value {
}

 
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters{
}

 
-(id) getBinding {
	return self->binding;
}

 
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value {
}

 
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
	OCLString* string = [[OCLString alloc] init];
	[string initWithString:binding.text];
	[self set_text:string]; 
	[textField resignFirstResponder];
	return NO;
}


@end 



