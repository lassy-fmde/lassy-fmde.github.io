#import "OCLSequence.h"
#import "OCLInteger.h"
#import "OCLReal.h"
#import "OCLBoolean.h"
#import "OCLString.h"
#import "OCLTuple.h"

@implementation OCLSequence

-(OCLSequence*)init {
	self = [super init];
	coll = [[NSMutableArray alloc] init];
	return self;
}

-(void)dealloc {
	[coll release];
	[super dealloc];
}

-(OCLSequence*)newCollection {
	return [(OCLSequence*)[OCLSequence alloc] init];
}

-(BOOL)isEqual:(id)other {
	BOOL res;
	if ([self isCompatibleType:other]) {
		OCLSequence* otherSequence = (OCLSequence*)other;
		res = [self->coll isEqual:otherSequence->coll]; 
	} else {
		res = NO;
	}
	return res;
}

-(void)add:(OCLAny*)object {
	[coll addObject:object];
}

-(OCLInteger*)size {
	return [(OCLInteger*)[OCLInteger alloc] initWithValue:[coll count]];
}

-(OCLBoolean*)includes:(OCLAny*)object {
	return [(OCLBoolean*)[OCLBoolean alloc] initWithValue:[coll containsObject:object]];
}

-(NSEnumerator*)objectEnumerator {
	return [coll objectEnumerator];
}

-(NSString*)collectionName {
	return [NSString stringWithString:@"Sequence"];
}

-(OCLSequence*)union:(OCLSequence*)other {
	OCLSequence* res = [[OCLSequence alloc] init];
	[res->coll setArray:self->coll];
	
	[res->coll addObjectsFromArray:other->coll];
	
	return res;
}

-(OCLSequence*)append:(OCLAny*)object {
	OCLSequence* res = [[OCLSequence alloc] init];
	[res->coll setArray:self->coll];
	[res->coll addObject:object];
	return res;
}

-(OCLSequence*)prepend:(OCLAny*)object {
	OCLSequence* res = [[OCLSequence alloc] init];
	[res->coll setArray:self->coll];
	[res->coll insertObject:object atIndex:0];
	return res;
}

-(OCLSequence*)insertAt:(OCLInteger*)index object:(OCLAny*)object {
	OCLSequence* res = [[OCLSequence alloc] init];
	[res->coll setArray:self->coll];
	[res->coll insertObject:object atIndex:(index->value - 1)];
	return res;
}

-(OCLSequence*)subSequence:(OCLInteger*)lower upper:(OCLInteger*)upper {
	OCLSequence* res = [[OCLSequence alloc] init];
	
	NSRange range;
	range.location = lower->value - 1;
	range.length = upper->value - lower->value;
	
	NSIndexSet* indexSet = [NSIndexSet indexSetWithIndexesInRange:range];
	
	[res->coll insertObjects:self->coll atIndexes:indexSet];

	[indexSet release];
	return res;	
}

-(OCLAny*)at:(OCLInteger*)position {
	return [coll objectAtIndex:[position value] - 1];
}

-(OCLInteger*)indexOf:(OCLAny*)object {
	NSUInteger index = [self->coll indexOfObject:object] + 1;
	return [(OCLInteger*)[OCLInteger alloc] initWithValue:index]; 
}

-(OCLAny*)first {
	return [self->coll objectAtIndex:0];
}

-(OCLAny*)last {
	return [self->coll lastObject];
}

-(OCLSequence*)including:(OCLAny*)object {
	OCLSequence* res = [[OCLSequence alloc] init];	
	[res->coll setArray:self->coll]; // Make copy of set
	[res add:object];
	
	return res;
}

-(OCLSequence*)excluding:(OCLAny*)object {
	OCLSequence* res = [[OCLSequence alloc] init];	
	[res->coll setArray:self->coll]; // Make copy of set
	[res->coll removeObject:object];
	
	return res;
}


-(OCLSequence*)flatten {
	return (OCLSequence*)[super flatten];
}

// internal methods

NSComparisonResult sortFunc(id s1, id s2, void* context) {
	NSObject* o1 = [((OCLSequence*)s1)->coll objectAtIndex:0];
	NSObject* o2 = [((OCLSequence*)s2)->coll objectAtIndex:0];
	
	if ([o1 isKindOfClass:[OCLInteger class]]) {
		OCLInteger* i1 = (OCLInteger*)o1;
		OCLInteger* i2 = (OCLInteger*)o2;
		
		if (i1->value < i2->value) {
			return NSOrderedAscending;
		} else if (i1->value == i2->value) {
			return NSOrderedSame;
		} else {
			return NSOrderedDescending;
		}
	}
	if ([o1 isKindOfClass:[OCLReal class]]) {
		OCLReal* r1 = (OCLReal*)o1;
		OCLReal* r2 = (OCLReal*)o2;
		
		if (r1->value < r2->value) {
			return NSOrderedAscending;
		} else if (r1->value == r2->value) {
			return NSOrderedSame;
		} else {
			return NSOrderedDescending;
		}
	}
	if ([o1 isKindOfClass:[OCLString class]]) {
		OCLString* s1 = (OCLString*)o1;
		OCLString* s2 = (OCLString*)o2;
		
		return [s1->string localizedCaseInsensitiveCompare:s2->string];		
	}
	
	return NSOrderedSame;
}

-(OCLSequence*)sortedByFirstSubElement {
	NSArray* a = [coll sortedArrayUsingFunction:sortFunc context:NULL];
	
	OCLSequence* res = [(OCLSequence*)[OCLSequence alloc] init];
	[res->coll addObjectsFromArray:a];
	
	// TODO the documentation for sortedArrayUsingFunction says:
	// http://developer.apple.com/mac/library/documentation/cocoa/reference/foundation/Classes/NSArray_Class/NSArray.html#//apple_ref/occ/instm/NSArray/sortedArrayUsingFunction:context:
	// "The new array contains references to the receiver's elements, not copies of them."
	// Does this mean that the sorted array does not retain the elements?
	// At the moment it looks like it since releasing the sorted array leads
	// to a segmentation fault when the NSAutoReleasePool is released later in the program.
	// How can we release the array then without releasing every single element?	
	
	// [a release];
	return res;
}

@end
