#import <Foundation/Foundation.h>
#import "OCLAny.h"

@class OCLInteger;
@class OCLBoolean;
@class OCLSet;
@class OCLOrderedSet;
@class OCLSequence;
@class OCLBag;

@interface OCLCollection : OCLAny {
}
-(OCLCollection*)newCollection;				// abstract
-(void)add:(OCLAny*)object;	  			// abstract	
-(OCLInteger*)size;							// abstract
-(OCLBoolean*)includes:(OCLAny*)object;	// abstract
-(NSEnumerator*)objectEnumerator; 			// abstract
-(OCLCollection*)flatten;					// child must override and cast
-(NSString*)collectionName;					// child must override (used by description)

-(OCLInteger*)count:(OCLAny*)object;
-(OCLBoolean*)excludes:(OCLAny*)object;
-(OCLBoolean*)includesAll:(OCLCollection*)collection;
-(OCLBoolean*)excludesAll:(OCLCollection*)collection;
-(OCLBoolean*)isEmpty;
-(OCLBoolean*)notEmpty;

-(OCLAny*)sum; // Returns all elements added with "+"
-(OCLSet*)product:(OCLCollection*)collection; // Returns Set(Tuple(first, second))

-(OCLSet*)asSet;
-(OCLOrderedSet*)asOrderedSet;
-(OCLSequence*)asSequence;
-(OCLBag*)asBag;

-(NSString*)description;

@end
