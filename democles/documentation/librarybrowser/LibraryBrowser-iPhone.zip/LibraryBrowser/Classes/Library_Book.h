  
 
 
#import <Foundation/Foundation.h>
#import "OCLTypes.h"

@class PropertyChangeList;
@class Library_BookCollection;


 
 
@interface Library_Book : OCLAny  
 {
	 
	OCLString* _author;
	BOOL _author_initialized;
	OCLString* _title;
	BOOL _title_initialized;
	OCLString* _isbn;
	BOOL _isbn_initialized;


@public
	NSMutableArray *Library_BookCollection_Books_back;


}

 
-(Library_Book*)init;
-(Library_Book*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(OCLString*) _author;
-(OCLString*) initial_author;
-(void) set_author:(OCLString*) value;
-(OCLString*) _title;
-(OCLString*) initial_title;
-(void) set_title:(OCLString*) value;
-(OCLString*) _isbn;
-(OCLString*) initial_isbn;
-(void) set_isbn:(OCLString*) value;



@end



