  
 
 
#import "LibraryBrowserGUI_BookListView.h"
#import "PropertyChangeList.h"
#import "LibraryBrowserGUI_Label.h"
#import "LibraryBrowserGUI_BookDetailView.h"
#import "LibraryBrowserGUI_SearchView.h"


 
@implementation LibraryBrowserGUI_BookListView

 
- (id) init {
	self = [super init];
	 
	self->binding = [[UITableViewController alloc] init];
	self->binding.tableView.delegate = self;
	self->binding.tableView.dataSource = self;
	self->binding.tabBarItem.image = [UIImage imageNamed:nil];

	 
	self->LibraryBrowserGUI_SearchView_resultView_back = [[NSMutableArray alloc] init];

	[self set_bookListTable: [self _bookListTable]];
	[self set_bookDetailView: [self _bookDetailView]];
	[self set_viewTitle: [self _viewTitle]];


	return self;
}

 
- (id) initWithValues: (OCLTuple*) values {
	self = [super init];
	 
	self->binding = [[UITableViewController alloc] init];
	self->binding.tableView.delegate = self;
	self->binding.tableView.dataSource = self;
	self->binding.tabBarItem.image = [UIImage imageNamed:nil];

	 
	self->_bookListTable_initialized = NO;
	self->_bookDetailView_initialized = NO;
	self->_viewTitle_initialized = NO;

	self->LibraryBrowserGUI_SearchView_resultView_back = [[NSMutableArray alloc] init];

	OCLSequence* _bookListTable_initialValue = (OCLSequence*) [values objectForKey:@"bookListTable"];
	if (_bookListTable_initialValue == nil) {
		_bookListTable_initialValue = [self _bookListTable];
	}
	[self set_bookListTable:_bookListTable_initialValue];
	LibraryBrowserGUI_BookDetailView* _bookDetailView_initialValue = (LibraryBrowserGUI_BookDetailView*) [values objectForKey:@"bookDetailView"];
	if (_bookDetailView_initialValue == nil) {
		_bookDetailView_initialValue = [self _bookDetailView];
	}
	[self set_bookDetailView:_bookDetailView_initialValue];
	OCLString* _viewTitle_initialValue = (OCLString*) [values objectForKey:@"viewTitle"];
	if (_viewTitle_initialValue == nil) {
		_viewTitle_initialValue = [self _viewTitle];
	}
	[self set_viewTitle:_viewTitle_initialValue];


	return self;
}

 
- (void) dealloc {
	if (self->_bookListTable != nil && self->_bookListTable != (OCLSequence*) [NSNull null]) [self->_bookListTable release];
	if (self->_bookDetailView != nil && self->_bookDetailView != (LibraryBrowserGUI_BookDetailView*) [NSNull null]) [self->_bookDetailView release];
	if (self->_viewTitle != nil && self->_viewTitle != (OCLString*) [NSNull null]) [self->_viewTitle release];

	[self->LibraryBrowserGUI_SearchView_resultView_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"LibraryBrowserGUI::BookListView\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"bookListTable\" type=\"Sequence\">\n"];
	[res appendFormat:@"%@\n", [self _bookListTable]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"bookDetailView\" type=\"LibraryBrowserGUI::BookDetailView\">\n"];
	[res appendFormat:@"%@\n", [self _bookDetailView]];;
	[res appendString:@"</property>\n"]; 
	[res appendString:@"<property Name=\"viewTitle\" type=\"String\">\n"];
	[res appendFormat:@"%@\n", [self _viewTitle]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
-(OCLSequence*) initial_bookListTable {
	/* ==================================================
	 * Sequence {}
	 * ================================================== */
	
	OCLSequence* v0 = [(OCLSequence*)[OCLSequence alloc] init];
	
	return v0;
}

-(OCLSequence*) _bookListTable {
	if (self->_bookListTable_initialized == YES) {
		return _bookListTable;
	} else { 
		[self set_bookListTable:[self initial_bookListTable]];
	}

	self->_bookListTable_initialized = YES;
	return _bookListTable;
}
-(LibraryBrowserGUI_BookDetailView*) initial_bookDetailView {
	/* ==================================================
	 * null
	 * ================================================== */
	
	LibraryBrowserGUI_BookDetailView* v0 = [NSNull null];
	
	return v0;
}

-(LibraryBrowserGUI_BookDetailView*) _bookDetailView {
	if (self->_bookDetailView_initialized == YES) {
		return _bookDetailView;
	} else { 
		[self set_bookDetailView:[self initial_bookDetailView]];
	}

	self->_bookDetailView_initialized = YES;
	return _bookDetailView;
}
-(OCLString*) initial_viewTitle {
	/* ==================================================
	 * 'Results'
	 * ================================================== */
	
	OCLString* v0 = [(OCLString*)[OCLString alloc] initWithString:@"Results"];
	
	return v0;
}

-(OCLString*) _viewTitle {
	if (self->_viewTitle_initialized == YES) {
		return _viewTitle;
	} else { 
		[self set_viewTitle:[self initial_viewTitle]];
	}

	self->_viewTitle_initialized = YES;
	return _viewTitle;
}


 
-(void) set_bookListTable:(OCLSequence*) value {
	 	if (self->_bookListTable!= nil && self->_bookListTable!= (OCLSequence*) [NSNull null]) {
		[self->_bookListTable release];
	}
	self->_bookListTable = value;
	if (self->_bookListTable!= nil && self->_bookListTable!= (OCLSequence*) [NSNull null]) {
		[self->_bookListTable retain];
	}
	self->_bookListTable_initialized = YES;
	
	[self onPropertyChange:@"bookListTable" newValue:value];
}
-(void) set_viewTitle:(OCLString*) value {
	 	if (self->_viewTitle!= nil && self->_viewTitle!= (OCLString*) [NSNull null]) {
		[self->_viewTitle release];
	}
	self->_viewTitle = value;
	if (self->_viewTitle!= nil && self->_viewTitle!= (OCLString*) [NSNull null]) {
		[self->_viewTitle retain];
	}
	self->_viewTitle_initialized = YES;
	
	[self onPropertyChange:@"viewTitle" newValue:value];
}


-(void) set_bookDetailView:(LibraryBrowserGUI_BookDetailView*) value {
	 
	if (self->_bookDetailView!= nil && self->_bookDetailView!= (LibraryBrowserGUI_BookDetailView*) [NSNull null]) {
		// Clear back pointer on old instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_bookDetailView valueForKey:@"LibraryBrowserGUI_BookListView_bookDetailView_back"];
		[backpointers removeObject:self];
		[self->_bookDetailView release];
	}
	self->_bookDetailView = value;
	if (self->_bookDetailView!= nil && self->_bookDetailView!= (LibraryBrowserGUI_BookDetailView*) [NSNull null]) {
		[self->_bookDetailView retain];
		// Add back pointer on new instance
		NSMutableArray* backpointers = (NSMutableArray*)[(OCLAny*)self->_bookDetailView valueForKey:@"LibraryBrowserGUI_BookListView_bookDetailView_back"];
		[backpointers addObject:self];
	}
	self->_bookDetailView_initialized = YES;
	
	[self onPropertyChange:@"bookDetailView" newValue:value];
}




 

 
-(void) event_bookSelected_pushed:(PropertyChangeList*) changes  p_id: (OCLInteger*) p_id{
	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_bookSelected", @"LibraryBrowserGUI_BookListView");

		OCLTuple* parameters = [[OCLTuple alloc] init];
		[parameters addItemNamed:@"id" withValue:p_id]; 

		[self onEvent:@"bookSelected" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges
		NSEnumerator* LibraryBrowserGUI_SearchView_bookSelected_edge0_enum = [self->LibraryBrowserGUI_SearchView_resultView_back objectEnumerator];
		LibraryBrowserGUI_SearchView* LibraryBrowserGUI_SearchView_bookSelected_edge0_target;
		while ((LibraryBrowserGUI_SearchView_bookSelected_edge0_target = [LibraryBrowserGUI_SearchView_bookSelected_edge0_enum nextObject]) != nil) {
		    [LibraryBrowserGUI_SearchView_bookSelected_edge0_target event_bookSelected_pulled_edge0:changes parentInstance:self p_id:p_id ];
		}



		 	
		// Trigger local edges


		 
		 // Process impacts relationships


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_selectedBookData_pushed:(PropertyChangeList*) changes  p_author: (OCLString*) p_author p_title: (OCLString*) p_title p_isbn: (OCLString*) p_isbn{
	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_selectedBookData", @"LibraryBrowserGUI_BookListView");

		OCLTuple* parameters = [[OCLTuple alloc] init];
		[parameters addItemNamed:@"author" withValue:p_author]; 
		[parameters addItemNamed:@"title" withValue:p_title]; 
		[parameters addItemNamed:@"isbn" withValue:p_isbn]; 

		[self onEvent:@"selectedBookData" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships
		/* ==================================================
		 * LibraryBrowserGUI::BookDetailView::create(
		 * Tuple { 
		 * 	bookTitleLabel = Label::create(Tuple { text = title }), 
		 * 	bookAuthorLabel = Label::create(Tuple { text = author }), 
		 * 	bookIsbnLabel = Label::create(Tuple { text = isbn })
		 * })
		 * ================================================== */
		
		OCLString* v8 = p_title;
		OCLString* v7 = v8;
		OCLTuple* v6 = [(OCLTuple*)[OCLTuple alloc] init];
		[v6 addItemNamed:@"text" withValue:v7];
		LibraryBrowserGUI_Label* v4 = [(LibraryBrowserGUI_Label*)[LibraryBrowserGUI_Label alloc] initWithValues:v6];
		LibraryBrowserGUI_Label* v3 = v4;
		OCLString* v14 = p_author;
		OCLString* v13 = v14;
		OCLTuple* v12 = [(OCLTuple*)[OCLTuple alloc] init];
		[v12 addItemNamed:@"text" withValue:v13];
		LibraryBrowserGUI_Label* v10 = [(LibraryBrowserGUI_Label*)[LibraryBrowserGUI_Label alloc] initWithValues:v12];
		LibraryBrowserGUI_Label* v9 = v10;
		OCLString* v20 = p_isbn;
		OCLString* v19 = v20;
		OCLTuple* v18 = [(OCLTuple*)[OCLTuple alloc] init];
		[v18 addItemNamed:@"text" withValue:v19];
		LibraryBrowserGUI_Label* v16 = [(LibraryBrowserGUI_Label*)[LibraryBrowserGUI_Label alloc] initWithValues:v18];
		LibraryBrowserGUI_Label* v15 = v16;
		OCLTuple* v2 = [(OCLTuple*)[OCLTuple alloc] init];
		[v2 addItemNamed:@"bookTitleLabel" withValue:v3];
		[v2 addItemNamed:@"bookAuthorLabel" withValue:v9];
		[v2 addItemNamed:@"bookIsbnLabel" withValue:v15];
		LibraryBrowserGUI_BookDetailView* v0 = [(LibraryBrowserGUI_BookDetailView*)[LibraryBrowserGUI_BookDetailView alloc] initWithValues:v2];
		[v18 release];
		[v6 release];
		[v4 release];
		[v10 release];
		[v12 release];
		[v2 release];
		[v16 release];
		
		LibraryBrowserGUI_BookDetailView* _bookDetailView_newValue = v0;
		[changes addChange:@selector(set_bookDetailView:) instance:self value:_bookDetailView_newValue];


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 




 
#pragma mark - 
#pragma mark Table Data Source Methods 
- (NSInteger) tableView:(UITableView *) tableView numberOfRowsInSection:(NSInteger)section 
{ 
	OCLInteger* size = [[ self _bookListTable] size];
	return size->value;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{
	static NSString *CellIdentifier = @"LibraryBrowserGUI_BookListViewCellIdentifier";
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier: CellIdentifier];
	if (cell == nil) { 
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero
				reuseIdentifier: CellIdentifier] autorelease];
		cell.accessoryType = UITableViewCellAccessoryDetailDisclosureButton;
	}
	NSUInteger row = [indexPath row];
	OCLInteger* rowOCL = [[OCLInteger alloc] init];
	[rowOCL initWithValue:row + 1];
	OCLString* text = (OCLString*) [[ self _bookListTable] at: rowOCL];
	[cell.textLabel setText:text->string]; 
	return cell;
}

 
#pragma mark - 
#pragma mark Table Delegate Methods
- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath
{
	NSUInteger row = [indexPath row];
	OCLInteger* rowOCL = [[OCLInteger alloc] init];
	[rowOCL initWithValue:row+1];
	[self event_bookSelected_pushed:NULL p_id:rowOCL];
}

 
-(void)onPropertyChange:(NSString*)propertyName newValue:(id) value {
	if ([propertyName isEqual:@"viewTitle"]) {
		if (value != nil && value != [NSNull null]) 
			[self->binding setTitle: ((OCLString *) value)->string ];
	}
	if ([propertyName isEqual:@"bookListTable"]){ 
		[self->binding.tableView reloadData];
	}
	 
	if ([value conformsToProtocol:@protocol(IBinding)]) {
		id propBinding = [value getBinding];
		if ([propBinding isKindOfClass: [UIViewController class]] && self->navigationController != nil) {
			[self->navigationController pushViewController:(UIViewController *)propBinding animated: YES];
			[value setBindingAttribute: @"navigationController" newValue: self->navigationController];
		}
	}

}

 
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters{
}

 
-(id) getBinding {
	return self->binding;
}

 
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value {
	if ([propertyName isEqual:@"navigationController"]) {
		if (value != nil && value != [NSNull null] && [value isKindOfClass: [UINavigationController class]]) 
			self->navigationController = (UINavigationController *) value;
	}
}


@end 



