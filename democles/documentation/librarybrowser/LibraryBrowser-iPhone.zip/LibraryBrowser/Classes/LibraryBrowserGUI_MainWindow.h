  
 
 
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "OCLTypes.h"
#import "IBinding.h"

@class PropertyChangeList;
@class LibraryBrowserGUI_SearchView;
@class LibraryBrowserGUI_TabbedWindow;
@class LibraryBrowserGUI_HomeView;
@class Application_Main;


 
 
@interface LibraryBrowserGUI_MainWindow : OCLAny <IBinding>
{
	 
	LibraryBrowserGUI_SearchView* _searchView;
	BOOL _searchView_initialized;
	LibraryBrowserGUI_HomeView* _homeView;
	BOOL _homeView_initialized;
	LibraryBrowserGUI_TabbedWindow* _viewSelector;
	BOOL _viewSelector_initialized;


@public
	NSMutableArray *Application_Main_mainGUI_back;


	
	@protected
	UIWindow *binding;
	BOOL rootControllerAdded;
}

 
-(LibraryBrowserGUI_MainWindow*)init;
-(LibraryBrowserGUI_MainWindow*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(LibraryBrowserGUI_SearchView*) _searchView;
-(LibraryBrowserGUI_SearchView*) initial_searchView;
-(void) set_searchView:(LibraryBrowserGUI_SearchView*) value;
-(LibraryBrowserGUI_HomeView*) _homeView;
-(LibraryBrowserGUI_HomeView*) initial_homeView;
-(void) set_homeView:(LibraryBrowserGUI_HomeView*) value;
-(LibraryBrowserGUI_TabbedWindow*) _viewSelector;
-(LibraryBrowserGUI_TabbedWindow*) initial_viewSelector;
-(void) set_viewSelector:(LibraryBrowserGUI_TabbedWindow*) value;

-(void) event_searchBook_pushed:(PropertyChangeList*) changes p_keyword: (OCLString*) p_keyword p_category: (OCLString*) p_category;
-(void) event_searchBook_pulled_edge0:(PropertyChangeList*)changes parentInstance:(LibraryBrowserGUI_SearchView*)parentInstance ;
-(void) event_searchFinished_pushed:(PropertyChangeList*) changes p_booksFound: (OCLSequence*) p_booksFound;
-(void) event_bookSelected_pushed:(PropertyChangeList*) changes p_id: (OCLInteger*) p_id;
-(void) event_bookSelected_pulled_edge0:(PropertyChangeList*)changes parentInstance:(LibraryBrowserGUI_SearchView*)parentInstance p_id:(OCLInteger*)p_id ;
-(void) event_selectedBookData_pushed:(PropertyChangeList*) changes p_author: (OCLString*) p_author p_title: (OCLString*) p_title p_isbn: (OCLString*) p_isbn;

 
-(id) getBinding;
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value;
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters;
-(void) onPropertyChange: (NSString*)propertyName newValue:(id<OCLAny>)value;


@end



