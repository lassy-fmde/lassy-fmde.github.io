  
 
 
#import "StringUtils_StringTokenizer.h"
#import "PropertyChangeList.h"
#import "LibraryPersistenceHandler_LibraryLoader.h"


 
@implementation StringUtils_StringTokenizer

 
- (StringUtils_StringTokenizer*) init {
	self = [super init];
	 
	self->LibraryPersistenceHandler_LibraryLoader_bookLineTokenizer_back = [[NSMutableArray alloc] init];


	return self;
}

 
- (StringUtils_StringTokenizer*) initWithValues: (OCLTuple*) values {
	self = [super init];
	 

	self->LibraryPersistenceHandler_LibraryLoader_bookLineTokenizer_back = [[NSMutableArray alloc] init];


	
	return self;
}

 
- (void) dealloc {

	[self->LibraryPersistenceHandler_LibraryLoader_bookLineTokenizer_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"StringUtils::StringTokenizer\" retainCount=\"%i\">\n", self, [self retainCount]];
	
	[res appendString:@"</instance>\n"];
	return res;
}

 


 






 

 
-(void) event_tokenizeString_pushed:(PropertyChangeList*) changes  p_string: (OCLString*) p_string p_separator: (OCLString*) p_separator{
	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_tokenizeString", @"StringUtils_StringTokenizer");

		OCLTuple* parameters = [[OCLTuple alloc] init];
		[parameters addItemNamed:@"string" withValue:p_string]; 
		[parameters addItemNamed:@"separator" withValue:p_separator]; 

		[self onEvent:@"tokenizeString" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges


		 	
		// Trigger local edges


		 
		 // Process impacts relationships


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 


-(void) event_stringTokenized_pushed:(PropertyChangeList*) changes  p_tokens: (OCLSequence*) p_tokens{
	@try {
		if (changes == nil) changes = [[PropertyChangeList alloc] init];
		else [changes retain];
		[changes enter];

		NSLog(@"event%@_pushed in model %@\n", @"_stringTokenized", @"StringUtils_StringTokenizer");

		OCLTuple* parameters = [[OCLTuple alloc] init];
		[parameters addItemNamed:@"tokens" withValue:p_tokens]; 

		[self onEvent:@"stringTokenized" withParameters:parameters];

		 
		// Trigger Push edges



		 
		// Trigger Pull edges
		NSEnumerator* LibraryPersistenceHandler_LibraryLoader_bookLineTokenized_edge0_enum = [self->LibraryPersistenceHandler_LibraryLoader_bookLineTokenizer_back objectEnumerator];
		LibraryPersistenceHandler_LibraryLoader* LibraryPersistenceHandler_LibraryLoader_bookLineTokenized_edge0_target;
		while ((LibraryPersistenceHandler_LibraryLoader_bookLineTokenized_edge0_target = [LibraryPersistenceHandler_LibraryLoader_bookLineTokenized_edge0_enum nextObject]) != nil) {
		    [LibraryPersistenceHandler_LibraryLoader_bookLineTokenized_edge0_target event_bookLineTokenized_pulled_edge0:changes parentInstance:self p_tokens:p_tokens ];
		}



		 	
		// Trigger local edges


		 
		 // Process impacts relationships


	}
	@finally {
		[changes leave];
		[changes release];
	}
}

 




 
-(void)onPropertyChange:(NSString*)propertyName newValue:(id) value {
}

 
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters{
	if ([eventName isEqual:@"tokenizeString"]) {
		if (parameters != nil && parameters != [NSNull null]){
			OCLString* line = (OCLString *) [parameters objectForKey:@"string"];
			OCLString* sep = (OCLString *) [parameters objectForKey:@"separator"];
			NSArray* tokens = [line->string componentsSeparatedByString:sep->string];
			
			NSEnumerator *e = [tokens objectEnumerator];
			id token;
			OCLSequence *oclTokens = [[OCLSequence alloc] init];
			while (token = [e nextObject])
				[oclTokens add: [[OCLString alloc] initWithString: (NSString *) token]];
			
			[self event_stringTokenized_pushed:nil p_tokens:oclTokens];
		}
	}
}

 
-(id) getBinding {
	return [NSNull null];
}

 
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value {
}



@end 



