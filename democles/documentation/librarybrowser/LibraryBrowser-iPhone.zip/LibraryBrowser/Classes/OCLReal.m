#import "OCLReal.h"
#import "OCLBoolean.h"
#import "OCLInteger.h"
#import <math.h>

@implementation OCLReal

-(OCLReal*)initWithValue:(double)v {
	self = [super init];
	value = v;
	return self;
}

-(BOOL)isEqual:(id)other {
	BOOL res;
	if ([self isCompatibleType:other]) {
		OCLReal* otherReal = (OCLReal*)other;
		res = self->value == otherReal->value; 
	} else {
		res = NO;
	}
	return res;
}

-(double)value {
	return value;
}

-(NSUInteger)hash {
	union {
		long l;
		double d;
	} u;
	
	u.d = value;
	return u.l;
}

-(NSString*)description {
	return [NSString stringWithFormat:@"<Real id=\"%p\" retainCount=\"%i\" value=\"%f\"/>\n", self, [self retainCount], self->value];
}

-(OCLReal*)plus:(OCLReal*)other {
	return [(OCLReal*)[OCLReal alloc] initWithValue:self->value + other->value];
}

-(OCLReal*)minus:(OCLReal*)other {
	return [(OCLReal*)[OCLReal alloc] initWithValue:self->value - other->value];
}

-(OCLReal*)mult:(OCLReal*)other {
	return [(OCLReal*)[OCLReal alloc] initWithValue:self->value * other->value];
}

-(OCLReal*)neg {
	return [(OCLReal*)[OCLReal alloc] initWithValue:-self->value];
}

-(OCLReal*)div:(OCLReal*)other {
	if (other->value == 0.0) {
		return (OCLReal*)[NSNull null];
	}
	return [(OCLReal*)[OCLReal alloc] initWithValue:self->value / other->value];
}

-(OCLReal*)abs {
	return [(OCLReal*)[OCLReal alloc] initWithValue:fabs(self->value)];
}

-(OCLInteger*)floor {
	return [(OCLInteger*)[OCLInteger alloc] initWithValue:(int)floor(self->value)];
}

-(OCLInteger*)round {
	return [(OCLInteger*)[OCLInteger alloc] initWithValue:(int)round(self->value)];
}

-(OCLReal*)max:(OCLReal*)other {
	return [(OCLReal*)[OCLReal alloc] initWithValue:self->value > other->value ? self->value : other->value];
}

-(OCLReal*)min:(OCLReal*)other {
	return [(OCLReal*)[OCLReal alloc] initWithValue:self->value < other->value ? self->value : other->value];
}

-(OCLBoolean*)lt:(OCLReal*)other {
	return [(OCLBoolean*)[OCLBoolean alloc] initWithValue:self->value < other->value];
}

-(OCLBoolean*)gt:(OCLReal*)other {
	return [(OCLBoolean*)[OCLBoolean alloc] initWithValue:self->value > other->value];
}

-(OCLBoolean*)lte:(OCLReal*)other {
	return [(OCLBoolean*)[OCLBoolean alloc] initWithValue:self->value <= other->value];
}

-(OCLBoolean*)gte:(OCLReal*)other {
	return [(OCLBoolean*)[OCLBoolean alloc] initWithValue:self->value >= other->value];
}

@end
