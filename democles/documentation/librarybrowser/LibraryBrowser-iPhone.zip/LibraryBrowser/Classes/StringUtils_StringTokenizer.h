  
 
 
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "OCLTypes.h"
#import "IBinding.h"

@class PropertyChangeList;
@class LibraryPersistenceHandler_LibraryLoader;


 
 
@interface StringUtils_StringTokenizer : OCLAny <IBinding>
{
	 


@public
	NSMutableArray *LibraryPersistenceHandler_LibraryLoader_bookLineTokenizer_back;


}

 
-(StringUtils_StringTokenizer*)init;
-(StringUtils_StringTokenizer*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;


-(void) event_tokenizeString_pushed:(PropertyChangeList*) changes p_string: (OCLString*) p_string p_separator: (OCLString*) p_separator;
-(void) event_stringTokenized_pushed:(PropertyChangeList*) changes p_tokens: (OCLSequence*) p_tokens;

 
-(id) getBinding;
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value;
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters;
-(void) onPropertyChange: (NSString*)propertyName newValue:(id<OCLAny>)value;


@end



