#include <Foundation/Foundation.h>
#import "OCLCollection.h"

@class OCLAny;
@class OCLInteger;
@class OCLBoolean;
@class OCLSet;

@interface OCLBag : OCLCollection {
	@public
	NSMutableArray* bag;
}

-(OCLBag*)init;
-(void)dealloc;

// OCLCollection abstract methods
-(OCLBag*)newCollection;
-(void)add:(OCLAny*)object;	
-(OCLInteger*)size;
-(OCLBoolean*)includes:(OCLAny*)object;
-(NSEnumerator*)objectEnumerator;
-(NSString*)collectionName;

// Bag methods
-(OCLBag*)unionWithBag:(OCLBag*)other;
-(OCLBag*)unionWithSet:(OCLSet*)other;
-(OCLBag*)intersectionWithBag:(OCLBag*)other;
-(OCLSet*)intersectionWithSet:(OCLSet*)other;
-(OCLBag*)including:(OCLAny*)object;
-(OCLBag*)excluding:(OCLAny*)object;
-(OCLInteger*)count:(OCLAny*)object;
-(OCLBag*)flatten;

// NSObject methods
-(BOOL)isEqual:(id)other;

@end
