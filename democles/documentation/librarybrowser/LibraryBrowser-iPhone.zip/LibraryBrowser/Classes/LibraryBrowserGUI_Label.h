  
 
 
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "OCLTypes.h"
#import "IBinding.h"

@class PropertyChangeList;
@class LibraryBrowserGUI_HomeView;
@class LibraryBrowserGUI_BookDetailView;
@class LibraryBrowserGUI_SearchView;


 
 
@interface LibraryBrowserGUI_Label : OCLAny <IBinding>
{
	 
	OCLString* _text;
	BOOL _text_initialized;


@public
	NSMutableArray *LibraryBrowserGUI_HomeView_titleLabel_back;
	NSMutableArray *LibraryBrowserGUI_BookDetailView_bookTitleLabel_back;
	NSMutableArray *LibraryBrowserGUI_BookDetailView_bookIsbnLabel_back;
	NSMutableArray *LibraryBrowserGUI_BookDetailView_bookAuthorLabel_back;
	NSMutableArray *LibraryBrowserGUI_SearchView_searchLabel_back;
	NSMutableArray *LibraryBrowserGUI_BookDetailView_titleLabel_back;
	NSMutableArray *LibraryBrowserGUI_BookDetailView_authorLabel_back;
	NSMutableArray *LibraryBrowserGUI_BookDetailView_isbnLabel_back;


	
	@protected
	UILabel* binding;
}

 
-(LibraryBrowserGUI_Label*)init;
-(LibraryBrowserGUI_Label*)initWithValues:(OCLTuple*)values;
-(void)dealloc;
-(NSString*)description;

-(OCLString*) _text;
-(OCLString*) initial_text;
-(void) set_text:(OCLString*) value;

-(void) event_setText_pushed:(PropertyChangeList*) changes p_text: (OCLString*) p_text;

 
-(id) getBinding;
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value;
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters;
-(void) onPropertyChange: (NSString*)propertyName newValue:(id<OCLAny>)value;


@end



