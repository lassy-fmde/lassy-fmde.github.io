  
 
 
#import "LibraryBrowserGUI_TabbedWindow.h"
#import "PropertyChangeList.h"
#import "LibraryBrowserGUI_MainWindow.h"


 
@implementation LibraryBrowserGUI_TabbedWindow

 
- (id) init {
	self = [super init];
	 
	self->binding = [[UITabBarController alloc] init];
	self->viewControllersAdded = NO;

	 
	self->LibraryBrowserGUI_MainWindow_viewSelector_back = [[NSMutableArray alloc] init];

	[self set_views: [self _views]];


	 

	return self;
}

 
- (id) initWithValues: (OCLTuple*) values {
	self = [super init];
	 
	self->binding = [[UITabBarController alloc] init];
	self->viewControllersAdded = NO;

	 
	self->_views_initialized = NO;

	self->LibraryBrowserGUI_MainWindow_viewSelector_back = [[NSMutableArray alloc] init];

	OCLSequence* _views_initialValue = (OCLSequence*) [values objectForKey:@"views"];
	if (_views_initialValue == nil) {
		_views_initialValue = [self _views];
	}
	[self set_views:_views_initialValue];


	 

	return self;
}

 
- (void) dealloc {
	if (self->_views != nil && self->_views != (OCLSequence*) [NSNull null]) [self->_views release];

	[self->LibraryBrowserGUI_MainWindow_viewSelector_back release];
	
	[super dealloc];
}

 
- (NSString*) description {
	NSMutableString* res = [[NSMutableString alloc] init];
	[res appendFormat:@"<instance id=\"%p\" type=\"LibraryBrowserGUI::TabbedWindow\" retainCount=\"%i\">\n", self, [self retainCount]];
	[res appendString:@"<property Name=\"views\" type=\"Sequence\">\n"];
	[res appendFormat:@"%@\n", [self _views]];;
	[res appendString:@"</property>\n"]; 
	
	[res appendString:@"</instance>\n"];
	return res;
}

 
-(OCLSequence*) initial_views {
	/* ==================================================
	 * Sequence {}
	 * ================================================== */
	
	OCLSequence* v0 = [(OCLSequence*)[OCLSequence alloc] init];
	
	return v0;
}

-(OCLSequence*) _views {
	if (self->_views_initialized == YES) {
		return _views;
	} else { 
		[self set_views:[self initial_views]];
	}

	self->_views_initialized = YES;
	return _views;
}


 
-(void) set_views:(OCLSequence*) value {
	 	if (self->_views!= nil && self->_views!= (OCLSequence*) [NSNull null]) {
		[self->_views release];
	}
	self->_views = value;
	if (self->_views!= nil && self->_views!= (OCLSequence*) [NSNull null]) {
		[self->_views retain];
	}
	self->_views_initialized = YES;
	
	[self onPropertyChange:@"views" newValue:value];
}






 

 


 
-(void)onPropertyChange:(NSString*)propertyName newValue:(id) value {
	if ([propertyName isEqual:@"views"]) {
		if (self->viewControllersAdded == NO && [value isKindOfClass: [OCLSequence class]]) {
			NSMutableArray* tabBarViews = [[NSMutableArray alloc] init]; 
			NSEnumerator* e = [((OCLSequence *) _views) objectEnumerator];
			id object;
			while ((object = [e nextObject])) {
				if ([object conformsToProtocol:@protocol(IBinding)]) {
					id<IBinding> propBinding = [object getBinding];
					if ([propBinding isKindOfClass: [UIViewController class]])
						[tabBarViews addObject: (UIViewController *) propBinding];
				}else{
					NSLog(@"Property change in model %@ NOT VALID:\n -Some item in %@ does not conform to IBinding \n",@"LibraryBrowserGUI_TabbedWindow", @"_views");

				}
			}
			if ([tabBarViews count] > 0) {
				[self->binding setViewControllers:tabBarViews animated:YES];
				self->viewControllersAdded = YES;
			}
		}else{
			NSLog(@"Property change in model %@ NOT VALID:\n -%@ property is not of class OCLSequence\n-Or Tabs have already been added to TabBar",@"LibraryBrowserGUI_TabbedWindow", @"_views");

		}
	}
}

 
-(void)onEvent:(NSString*)eventName withParameters:(OCLTuple*)parameters{
}

 
-(id) getBinding {
	return self->binding;
}

 
-(void) setBindingAttribute: (NSString*) propertyName newValue: (id) value {
}


@end 



