#import <Foundation/Foundation.h>
#import "OCLAny.h"

@interface OCLBoolean : OCLAny {
	@public
	BOOL value;
}
-(OCLBoolean*)initWithValue:(BOOL)value;

// Boolean methods
-(OCLBoolean*)or:(OCLBoolean*)other;
-(OCLBoolean*)xor:(OCLBoolean*)other;
-(OCLBoolean*)and:(OCLBoolean*)other;
-(OCLBoolean*)not;
-(OCLBoolean*)implies:(OCLBoolean*)other;

// NSObject methods
-(NSUInteger)hash;
-(NSString*)description;
-(BOOL)isEqual:(id)other;

@end
