package generated.BrowserGui;

public class BrowserWindow extends lu.uni.democles.runtime.Instance {
	private lu.uni.democles.runtime.Event _e_urlTextFieldActivated = new lu.uni.democles.runtime.Event(this, "urlTextFieldActivated", "BrowserWindow", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.Gui.TextField", "urlTextField", "activated", new java.lang.String[] {"url"}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.BrowserGui.BrowserWindow", "urlVisitRequested", new java.lang.String[] {"url"}) });
	private lu.uni.democles.runtime.Property _p_window = new lu.uni.democles.runtime.Property(this, "window", "BrowserWindow", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_urlVisitRequested = new lu.uni.democles.runtime.Event(this, "urlVisitRequested", "BrowserWindow", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_htmlViewer_linkClicked = new lu.uni.democles.runtime.Event(this, "htmlViewer_linkClicked", "BrowserWindow", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.Gui.HTMLViewer", "htmlViewer", "linkClicked", new java.lang.String[] {"url"}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.BrowserGui.BrowserWindow", "urlVisitRequested", new java.lang.String[] {"url"}) });
	private lu.uni.democles.runtime.Event _e_forwardButtonClicked = new lu.uni.democles.runtime.Event(this, "forwardButtonClicked", "BrowserWindow", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.Gui.Button", "forwardButton", "execute", new java.lang.String[] {"content"}) }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_htmlViewer_pageLoadFinished = new lu.uni.democles.runtime.Event(this, "htmlViewer_pageLoadFinished", "BrowserWindow", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.Gui.HTMLViewer", "htmlViewer", "pageLoadFinished", new java.lang.String[] {"url"}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "urlTextField", "generated.Gui.TextField", "setText", new java.lang.String[] {"s"}), new lu.uni.democles.runtime.ChildLink(false, "window", "generated.Gui.Window", "setStatusText", new java.lang.String[] {"statusText"}) });
	private lu.uni.democles.runtime.Event _e_setState = new lu.uni.democles.runtime.Event(this, "setState", "BrowserWindow", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "htmlViewer", "generated.Gui.HTMLViewer", "setCurrentUrl", new java.lang.String[] {"url"}), new lu.uni.democles.runtime.ChildLink(false, "window", "generated.Gui.Window", "setStatusText", new java.lang.String[] {"statusText"}), new lu.uni.democles.runtime.ChildLink(false, "forwardButton", "generated.Gui.Button", "setEnabled", new java.lang.String[] {"enabled"}), new lu.uni.democles.runtime.ChildLink(false, "backButton", "generated.Gui.Button", "setEnabled", new java.lang.String[] {"enabled"}), new lu.uni.democles.runtime.ChildLink(false, "window", "generated.Gui.Window", "setTitle", new java.lang.String[] {"title"}) });
	private lu.uni.democles.runtime.Property _p_urlTextField = new lu.uni.democles.runtime.Property(this, "urlTextField", "BrowserWindow", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_backButton = new lu.uni.democles.runtime.Property(this, "backButton", "BrowserWindow", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_htmlViewer_pageLoadError = new lu.uni.democles.runtime.Event(this, "htmlViewer_pageLoadError", "BrowserWindow", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.Gui.HTMLViewer", "htmlViewer", "pageLoadError", new java.lang.String[] {"url", "message"}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "htmlViewer", "generated.Gui.HTMLViewer", "showError", new java.lang.String[] {"url", "message"}) });
	private lu.uni.democles.runtime.Event _e_backbuttonClicked = new lu.uni.democles.runtime.Event(this, "backbuttonClicked", "BrowserWindow", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.Gui.Button", "backButton", "execute", new java.lang.String[] {"content"}) }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_htmlViewer_linkExited = new lu.uni.democles.runtime.Event(this, "htmlViewer_linkExited", "BrowserWindow", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.Gui.HTMLViewer", "htmlViewer", "linkExited", new java.lang.String[] {"url"}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "window", "generated.Gui.Window", "setStatusText", new java.lang.String[] {"statusText"}) });
	private lu.uni.democles.runtime.Event _e_htmlViewer_linkEntered = new lu.uni.democles.runtime.Event(this, "htmlViewer_linkEntered", "BrowserWindow", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.Gui.HTMLViewer", "htmlViewer", "linkEntered", new java.lang.String[] {"url"}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "window", "generated.Gui.Window", "setStatusText", new java.lang.String[] {"statusText"}) });
	private lu.uni.democles.runtime.Property _p_initialUrl = new lu.uni.democles.runtime.Property(this, "initialUrl", "BrowserWindow", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_forwardButton = new lu.uni.democles.runtime.Property(this, "forwardButton", "BrowserWindow", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_htmlViewer = new lu.uni.democles.runtime.Property(this, "htmlViewer", "BrowserWindow", "Local", false, false, null, "single");
	public BrowserWindow() {
		super("generated.BrowserGui.BrowserWindow", new java.lang.String[] {  });

	}
	protected void attachProperties(lu.uni.democles.runtime.Event e) {
		// Set Attached Properties:


	}
	protected java.lang.Object evalQuery(lu.uni.democles.runtime.Property p) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) return p.newVal;

if (p.isEvaluating()) throw new lu.uni.democles.runtime.ModificationCycleException();

p.setEvaluating(true);
java.lang.Object o = null;


		if ("initialUrl".equals(p.entityName)) {
	o = __initialUrl_eval();
	set(p, o);
}

		if ("htmlViewer".equals(p.entityName)) {
	o = __htmlViewer_eval();
	set(p, o);
}

		if ("forwardButton".equals(p.entityName)) {
	o = __forwardButton_eval();
	set(p, o);
}

		if ("window".equals(p.entityName)) {
	o = __window_eval();
	set(p, o);
}

		if ("urlTextField".equals(p.entityName)) {
	o = __urlTextField_eval();
	set(p, o);
}

		if ("backButton".equals(p.entityName)) {
	o = __backButton_eval();
	set(p, o);
}

		if (o instanceof lu.uni.democles.runtime.Instance) {
	((lu.uni.democles.runtime.Instance)o).initProps();
} else if (o instanceof lu.uni.democles.runtime.OCLCollection) {
	for (java.util.Iterator iter = ((lu.uni.democles.runtime.OCLCollection)o).getValues().iterator(); iter.hasNext();) {
		java.lang.Object entry = iter.next();
		if (entry instanceof lu.uni.democles.runtime.Instance) {
			((lu.uni.democles.runtime.Instance)entry).initProps();
		}
	}
}
p.setEvaluating(false);
return o;


	}
	public static void main(String[] args) {
	}
	public static BrowserWindow newWithValues(java.util.HashMap values) {
		BrowserWindow res = new BrowserWindow();
res.initialValues = new java.util.HashMap(values);
res.initProps();
return res;
	}
	protected java.lang.Object eval_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse, final java.lang.String _paramName) {
		if (_parent.entityName.equals("linkEntered") && _event.entityName.equals("htmlViewer_linkEntered") && _linkProperty.entityName.equals("htmlViewer") && _inverse == false && _paramName.equals("url")) {
try {
	return ((java.lang.String)_parent.getParameter("url"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PARAMETER_MAPPING|BrowserGui::BrowserWindow/Event/htmlViewer_linkEntered$eventParentLink,Forward,htmlViewer,Gui::HTMLViewer,linkEntered$url");
	try {
		_error.addVariable("url", _parent.getParameter("url"));
	} catch (Throwable _t) {
		_error.addVariable("url", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (_parent.entityName.equals("linkClicked") && _event.entityName.equals("htmlViewer_linkClicked") && _linkProperty.entityName.equals("htmlViewer") && _inverse == false && _paramName.equals("url")) {
try {
	return ((java.lang.String)_parent.getParameter("url"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PARAMETER_MAPPING|BrowserGui::BrowserWindow/Event/htmlViewer_linkClicked$eventParentLink,Forward,htmlViewer,Gui::HTMLViewer,linkClicked$url");
	try {
		_error.addVariable("url", _parent.getParameter("url"));
	} catch (Throwable _t) {
		_error.addVariable("url", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (_parent.entityName.equals("execute") && _event.entityName.equals("backbuttonClicked") && _linkProperty.entityName.equals("backButton") && _inverse == false && _paramName.equals("content")) {
try {
	return ((java.lang.Object)_parent.getParameter("content"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PARAMETER_MAPPING|BrowserGui::BrowserWindow/Event/backbuttonClicked$eventParentLink,Forward,backButton,Gui::Button,execute$content");
	try {
		_error.addVariable("content", _parent.getParameter("content"));
	} catch (Throwable _t) {
		_error.addVariable("content", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (_parent.entityName.equals("execute") && _event.entityName.equals("forwardButtonClicked") && _linkProperty.entityName.equals("forwardButton") && _inverse == false && _paramName.equals("content")) {
try {
	return ((java.lang.Object)_parent.getParameter("content"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PARAMETER_MAPPING|BrowserGui::BrowserWindow/Event/forwardButtonClicked$eventParentLink,Forward,forwardButton,Gui::Button,execute$content");
	try {
		_error.addVariable("content", _parent.getParameter("content"));
	} catch (Throwable _t) {
		_error.addVariable("content", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (_parent.entityName.equals("pageLoadFinished") && _event.entityName.equals("htmlViewer_pageLoadFinished") && _linkProperty.entityName.equals("htmlViewer") && _inverse == false && _paramName.equals("url")) {
try {
	return ((java.lang.String)_parent.getParameter("url"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PARAMETER_MAPPING|BrowserGui::BrowserWindow/Event/htmlViewer_pageLoadFinished$eventParentLink,Forward,htmlViewer,Gui::HTMLViewer,pageLoadFinished$url");
	try {
		_error.addVariable("url", _parent.getParameter("url"));
	} catch (Throwable _t) {
		_error.addVariable("url", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (_parent.entityName.equals("pageLoadError") && _event.entityName.equals("htmlViewer_pageLoadError") && _linkProperty.entityName.equals("htmlViewer") && _inverse == false && _paramName.equals("url")) {
try {
	return ((java.lang.String)_parent.getParameter("url"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PARAMETER_MAPPING|BrowserGui::BrowserWindow/Event/htmlViewer_pageLoadError$eventParentLink,Forward,htmlViewer,Gui::HTMLViewer,pageLoadError$url");
	try {
		_error.addVariable("url", _parent.getParameter("url"));
	} catch (Throwable _t) {
		_error.addVariable("url", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("message", _parent.getParameter("message"));
	} catch (Throwable _t) {
		_error.addVariable("message", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}
if (_parent.entityName.equals("pageLoadError") && _event.entityName.equals("htmlViewer_pageLoadError") && _linkProperty.entityName.equals("htmlViewer") && _inverse == false && _paramName.equals("message")) {
try {
	return ((java.lang.String)_parent.getParameter("message"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PARAMETER_MAPPING|BrowserGui::BrowserWindow/Event/htmlViewer_pageLoadError$eventParentLink,Forward,htmlViewer,Gui::HTMLViewer,pageLoadError$message");
	try {
		_error.addVariable("url", _parent.getParameter("url"));
	} catch (Throwable _t) {
		_error.addVariable("url", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("message", _parent.getParameter("message"));
	} catch (Throwable _t) {
		_error.addVariable("message", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (_parent.entityName.equals("activated") && _event.entityName.equals("urlTextFieldActivated") && _linkProperty.entityName.equals("urlTextField") && _inverse == false && _paramName.equals("url")) {
try {
	return ((java.lang.String)_parent.getParameter("currentText"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PARAMETER_MAPPING|BrowserGui::BrowserWindow/Event/urlTextFieldActivated$eventParentLink,Forward,urlTextField,Gui::TextField,activated$url");
	try {
		_error.addVariable("currentText", _parent.getParameter("currentText"));
	} catch (Throwable _t) {
		_error.addVariable("currentText", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (_parent.entityName.equals("linkExited") && _event.entityName.equals("htmlViewer_linkExited") && _linkProperty.entityName.equals("htmlViewer") && _inverse == false && _paramName.equals("url")) {
try {
	return ((java.lang.String)_parent.getParameter("url"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PARAMETER_MAPPING|BrowserGui::BrowserWindow/Event/htmlViewer_linkExited$eventParentLink,Forward,htmlViewer,Gui::HTMLViewer,linkExited$url");
	try {
		_error.addVariable("url", _parent.getParameter("url"));
	} catch (Throwable _t) {
		_error.addVariable("url", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		
		return null;

	}
	protected void resetNewVal() {
		this._p_initialUrl.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_htmlViewer.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_forwardButton.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_window.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_urlTextField.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_backButton.newVal = lu.uni.democles.runtime.Entity.nullObject;
	}
	private java.lang.Object __htmlViewer_eval() {
		try {
	return (generated.Gui.HTMLViewer.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "currentUrl", ((java.lang.String)((lu.uni.democles.runtime.Property)generated.BrowserGui.BrowserWindow.this.getEntity("initialUrl")).evalInContainer().getValues().iterator().next()) }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PROPERTY|BrowserGui::BrowserWindow/Property/htmlViewer");
	throw _error;
}

	}
	private java.lang.Object __initialUrl_eval() {
		try {
	return "http://www.uni.lu";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PROPERTY|BrowserGui::BrowserWindow/Property/initialUrl");
	throw _error;
}

	}
	protected void updateValues(lu.uni.democles.runtime.Event event) {
	}
	protected void set(lu.uni.democles.runtime.Property p, java.lang.Object v) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) {
	throw new lu.uni.democles.runtime.MultipleModificationException(p.toString());
}
p.newVal = v;
		super.set(p, v);
	}
	protected java.lang.Object eval_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final java.lang.String paramName, final int _link) {
		if (e1.entityName.equals("htmlViewer_linkEntered") && e2.entityName.equals("setStatusText") && linkProperty.entityName.equals("window") && paramName.equals("statusText")) {
try {
	return ((java.lang.String)e1.getParameter("url"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PARAMETER_MAPPING|BrowserGui::BrowserWindow/Event/htmlViewer_linkEntered$eventChildLink,Forward,window,Gui::Window,setStatusText$statusText");
	try {
		_error.addVariable("url", e1.getParameter("url"));
	} catch (Throwable _t) {
		_error.addVariable("url", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("htmlViewer_linkClicked") && e2.entityName.equals("urlVisitRequested") && linkProperty == null && paramName.equals("url")) {
try {
	return ((java.lang.String)e1.getParameter("url"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PARAMETER_MAPPING|BrowserGui::BrowserWindow/Event/htmlViewer_linkClicked$eventChildLink,Local,urlVisitRequested$url");
	try {
		_error.addVariable("url", e1.getParameter("url"));
	} catch (Throwable _t) {
		_error.addVariable("url", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		
		if (e1.entityName.equals("htmlViewer_pageLoadFinished") && e2.entityName.equals("setText") && linkProperty.entityName.equals("urlTextField") && paramName.equals("s")) {
try {
	return ((java.lang.String)e1.getParameter("url"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PARAMETER_MAPPING|BrowserGui::BrowserWindow/Event/htmlViewer_pageLoadFinished$eventChildLink,Forward,urlTextField,Gui::TextField,setText$s");
	try {
		_error.addVariable("url", e1.getParameter("url"));
	} catch (Throwable _t) {
		_error.addVariable("url", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}
if (e1.entityName.equals("htmlViewer_pageLoadFinished") && e2.entityName.equals("setStatusText") && linkProperty.entityName.equals("window") && paramName.equals("statusText")) {
try {
	return "Ready";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PARAMETER_MAPPING|BrowserGui::BrowserWindow/Event/htmlViewer_pageLoadFinished$eventChildLink,Forward,window,Gui::Window,setStatusText$statusText");
	try {
		_error.addVariable("url", e1.getParameter("url"));
	} catch (Throwable _t) {
		_error.addVariable("url", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("htmlViewer_pageLoadError") && e2.entityName.equals("showError") && linkProperty.entityName.equals("htmlViewer") && paramName.equals("url")) {
try {
	return ((java.lang.String)e1.getParameter("url"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PARAMETER_MAPPING|BrowserGui::BrowserWindow/Event/htmlViewer_pageLoadError$eventChildLink,Forward,htmlViewer,Gui::HTMLViewer,showError$url");
	try {
		_error.addVariable("url", e1.getParameter("url"));
	} catch (Throwable _t) {
		_error.addVariable("url", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("message", e1.getParameter("message"));
	} catch (Throwable _t) {
		_error.addVariable("message", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}
if (e1.entityName.equals("htmlViewer_pageLoadError") && e2.entityName.equals("showError") && linkProperty.entityName.equals("htmlViewer") && paramName.equals("message")) {
try {
	return ((java.lang.String)e1.getParameter("message"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PARAMETER_MAPPING|BrowserGui::BrowserWindow/Event/htmlViewer_pageLoadError$eventChildLink,Forward,htmlViewer,Gui::HTMLViewer,showError$message");
	try {
		_error.addVariable("url", e1.getParameter("url"));
	} catch (Throwable _t) {
		_error.addVariable("url", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("message", e1.getParameter("message"));
	} catch (Throwable _t) {
		_error.addVariable("message", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("urlTextFieldActivated") && e2.entityName.equals("urlVisitRequested") && linkProperty == null && paramName.equals("url")) {
try {
	return ((java.lang.String)e1.getParameter("url"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PARAMETER_MAPPING|BrowserGui::BrowserWindow/Event/urlTextFieldActivated$eventChildLink,Local,urlVisitRequested$url");
	try {
		_error.addVariable("url", e1.getParameter("url"));
	} catch (Throwable _t) {
		_error.addVariable("url", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("htmlViewer_linkExited") && e2.entityName.equals("setStatusText") && linkProperty.entityName.equals("window") && paramName.equals("statusText")) {
try {
	return "Ready";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PARAMETER_MAPPING|BrowserGui::BrowserWindow/Event/htmlViewer_linkExited$eventChildLink,Forward,window,Gui::Window,setStatusText$statusText");
	try {
		_error.addVariable("url", e1.getParameter("url"));
	} catch (Throwable _t) {
		_error.addVariable("url", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("setState") && e2.entityName.equals("setCurrentUrl") && linkProperty.entityName.equals("htmlViewer") && paramName.equals("url")) {
try {
	return ((java.lang.String)((lu.uni.democles.runtime.Property)((generated.BrowserGui.BrowserWindowState)e1.getParameter("windowState")).getEntity("currentUrl")).evalInContainer().getValues().iterator().next());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PARAMETER_MAPPING|BrowserGui::BrowserWindow/Event/setState$eventChildLink,Forward,htmlViewer,Gui::HTMLViewer,setCurrentUrl$url");
	try {
		_error.addVariable("windowState", e1.getParameter("windowState"));
	} catch (Throwable _t) {
		_error.addVariable("windowState", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}
if (e1.entityName.equals("setState") && e2.entityName.equals("setStatusText") && linkProperty.entityName.equals("window") && paramName.equals("statusText")) {
try {
	return (("Loading " + ((java.lang.String)((lu.uni.democles.runtime.Property)((generated.BrowserGui.BrowserWindowState)e1.getParameter("windowState")).getEntity("currentUrl")).evalInContainer().getValues().iterator().next())) + "...");

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PARAMETER_MAPPING|BrowserGui::BrowserWindow/Event/setState$eventChildLink,Forward,window,Gui::Window,setStatusText$statusText");
	try {
		_error.addVariable("windowState", e1.getParameter("windowState"));
	} catch (Throwable _t) {
		_error.addVariable("windowState", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}
if (e1.entityName.equals("setState") && e2.entityName.equals("setEnabled") && linkProperty.entityName.equals("forwardButton") && paramName.equals("enabled")) {
try {
	return new java.lang.Boolean(((boolean)((java.lang.Boolean)((lu.uni.democles.runtime.Property)((generated.BrowserGui.BrowserWindowState)e1.getParameter("windowState")).getEntity("canGoForward")).evalInContainer().getValues().iterator().next()).booleanValue()));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PARAMETER_MAPPING|BrowserGui::BrowserWindow/Event/setState$eventChildLink,Forward,forwardButton,Gui::Button,setEnabled$enabled");
	try {
		_error.addVariable("windowState", e1.getParameter("windowState"));
	} catch (Throwable _t) {
		_error.addVariable("windowState", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}
if (e1.entityName.equals("setState") && e2.entityName.equals("setEnabled") && linkProperty.entityName.equals("backButton") && paramName.equals("enabled")) {
try {
	return new java.lang.Boolean(((boolean)((java.lang.Boolean)((lu.uni.democles.runtime.Property)((generated.BrowserGui.BrowserWindowState)e1.getParameter("windowState")).getEntity("canGoBackward")).evalInContainer().getValues().iterator().next()).booleanValue()));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PARAMETER_MAPPING|BrowserGui::BrowserWindow/Event/setState$eventChildLink,Forward,backButton,Gui::Button,setEnabled$enabled");
	try {
		_error.addVariable("windowState", e1.getParameter("windowState"));
	} catch (Throwable _t) {
		_error.addVariable("windowState", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}
if (e1.entityName.equals("setState") && e2.entityName.equals("setTitle") && linkProperty.entityName.equals("window") && paramName.equals("title")) {
try {
	return ("Browser - " + ((java.lang.String)((lu.uni.democles.runtime.Property)((generated.BrowserGui.BrowserWindowState)e1.getParameter("windowState")).getEntity("currentUrl")).evalInContainer().getValues().iterator().next()));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PARAMETER_MAPPING|BrowserGui::BrowserWindow/Event/setState$eventChildLink,Forward,window,Gui::Window,setTitle$title");
	try {
		_error.addVariable("windowState", e1.getParameter("windowState"));
	} catch (Throwable _t) {
		_error.addVariable("windowState", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		return null;

	}
	private java.lang.Object __backButton_eval() {
		try {
	return (generated.Gui.Button.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "label", "Back", "enabled", new java.lang.Boolean(false) }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PROPERTY|BrowserGui::BrowserWindow/Property/backButton");
	throw _error;
}

	}
	private java.lang.Object __window_eval() {
		try {
	return (generated.Gui.Window.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "title", "Browser", "widgets", new lu.uni.democles.runtime.OCLSequence(new Object[] {((generated.Gui.HTMLViewer)((lu.uni.democles.runtime.Property)generated.BrowserGui.BrowserWindow.this.getEntity("htmlViewer")).evalInContainer().getValues().iterator().next())}), "toolbarWidgets", new lu.uni.democles.runtime.OCLSequence(new Object[] {((generated.Gui.Button)((lu.uni.democles.runtime.Property)generated.BrowserGui.BrowserWindow.this.getEntity("backButton")).evalInContainer().getValues().iterator().next()), ((generated.Gui.Button)((lu.uni.democles.runtime.Property)generated.BrowserGui.BrowserWindow.this.getEntity("forwardButton")).evalInContainer().getValues().iterator().next()), ((generated.Gui.TextField)((lu.uni.democles.runtime.Property)generated.BrowserGui.BrowserWindow.this.getEntity("urlTextField")).evalInContainer().getValues().iterator().next())}) }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PROPERTY|BrowserGui::BrowserWindow/Property/window");
	throw _error;
}

	}
	public void initProps() {
		if (this.isInitialized()) return;

		this._p_initialUrl.oldVal = this.initialValues.containsKey("initialUrl") ? this.initialValues.get("initialUrl") : eval_p(this._p_initialUrl).getValues().iterator().next();
this._p_initialUrl.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_initialUrl, this._p_initialUrl.oldVal);

		this._p_htmlViewer.oldVal = this.initialValues.containsKey("htmlViewer") ? this.initialValues.get("htmlViewer") : eval_p(this._p_htmlViewer).getValues().iterator().next();
this._p_htmlViewer.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_htmlViewer, this._p_htmlViewer.oldVal);

		this._p_forwardButton.oldVal = this.initialValues.containsKey("forwardButton") ? this.initialValues.get("forwardButton") : eval_p(this._p_forwardButton).getValues().iterator().next();
this._p_forwardButton.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_forwardButton, this._p_forwardButton.oldVal);

		this._p_window.oldVal = this.initialValues.containsKey("window") ? this.initialValues.get("window") : eval_p(this._p_window).getValues().iterator().next();
this._p_window.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_window, this._p_window.oldVal);

		this._p_urlTextField.oldVal = this.initialValues.containsKey("urlTextField") ? this.initialValues.get("urlTextField") : eval_p(this._p_urlTextField).getValues().iterator().next();
this._p_urlTextField.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_urlTextField, this._p_urlTextField.oldVal);

		this._p_backButton.oldVal = this.initialValues.containsKey("backButton") ? this.initialValues.get("backButton") : eval_p(this._p_backButton).getValues().iterator().next();
this._p_backButton.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_backButton, this._p_backButton.oldVal);

		this.setInitialized();
this.initialValues = new java.util.HashMap();


	}
	private java.lang.Object __forwardButton_eval() {
		try {
	return (generated.Gui.Button.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "label", "Forward", "enabled", new java.lang.Boolean(false) }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PROPERTY|BrowserGui::BrowserWindow/Property/forwardButton");
	throw _error;
}

	}
	protected void updateVal(lu.uni.democles.runtime.Property p) {
		if ("initialUrl".equals(p.entityName)) {
	if (this._p_initialUrl.newVal != lu.uni.democles.runtime.Entity.nullObject) {
		java.lang.Object previousOldVal = this._p_initialUrl.oldVal;
		this._p_initialUrl.oldVal = this._p_initialUrl.newVal;
		lu.uni.democles.runtime.Instance.epDebugPropertyValueChanged(this, this._p_initialUrl, previousOldVal, this._p_initialUrl.newVal);
		this.notifyPropertyChangeListeners(p);
	}
}
		if ("htmlViewer".equals(p.entityName)) {
	if (this._p_htmlViewer.newVal != lu.uni.democles.runtime.Entity.nullObject) {
		java.lang.Object previousOldVal = this._p_htmlViewer.oldVal;
		this._p_htmlViewer.oldVal = this._p_htmlViewer.newVal;
		lu.uni.democles.runtime.Instance.epDebugPropertyValueChanged(this, this._p_htmlViewer, previousOldVal, this._p_htmlViewer.newVal);
		this.notifyPropertyChangeListeners(p);
	}
}
		if ("forwardButton".equals(p.entityName)) {
	if (this._p_forwardButton.newVal != lu.uni.democles.runtime.Entity.nullObject) {
		java.lang.Object previousOldVal = this._p_forwardButton.oldVal;
		this._p_forwardButton.oldVal = this._p_forwardButton.newVal;
		lu.uni.democles.runtime.Instance.epDebugPropertyValueChanged(this, this._p_forwardButton, previousOldVal, this._p_forwardButton.newVal);
		this.notifyPropertyChangeListeners(p);
	}
}
		if ("window".equals(p.entityName)) {
	if (this._p_window.newVal != lu.uni.democles.runtime.Entity.nullObject) {
		java.lang.Object previousOldVal = this._p_window.oldVal;
		this._p_window.oldVal = this._p_window.newVal;
		lu.uni.democles.runtime.Instance.epDebugPropertyValueChanged(this, this._p_window, previousOldVal, this._p_window.newVal);
		this.notifyPropertyChangeListeners(p);
	}
}
		if ("urlTextField".equals(p.entityName)) {
	if (this._p_urlTextField.newVal != lu.uni.democles.runtime.Entity.nullObject) {
		java.lang.Object previousOldVal = this._p_urlTextField.oldVal;
		this._p_urlTextField.oldVal = this._p_urlTextField.newVal;
		lu.uni.democles.runtime.Instance.epDebugPropertyValueChanged(this, this._p_urlTextField, previousOldVal, this._p_urlTextField.newVal);
		this.notifyPropertyChangeListeners(p);
	}
}
		if ("backButton".equals(p.entityName)) {
	if (this._p_backButton.newVal != lu.uni.democles.runtime.Entity.nullObject) {
		java.lang.Object previousOldVal = this._p_backButton.oldVal;
		this._p_backButton.oldVal = this._p_backButton.newVal;
		lu.uni.democles.runtime.Instance.epDebugPropertyValueChanged(this, this._p_backButton, previousOldVal, this._p_backButton.newVal);
		this.notifyPropertyChangeListeners(p);
	}
}
	}
	private java.lang.Object __urlTextField_eval() {
		try {
	return (generated.Gui.TextField.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "text", ((java.lang.String)((lu.uni.democles.runtime.Property)generated.BrowserGui.BrowserWindow.this.getEntity("initialUrl")).evalInContainer().getValues().iterator().next()) }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PROPERTY|BrowserGui::BrowserWindow/Property/urlTextField");
	throw _error;
}

	}
}
