package generated.BrowserGui;

public class BrowserWindowState extends lu.uni.democles.runtime.Instance {
	private lu.uni.democles.runtime.Property _p_canGoBackward = new lu.uni.democles.runtime.Property(this, "canGoBackward", "BrowserWindowState", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_currentUrl = new lu.uni.democles.runtime.Property(this, "currentUrl", "BrowserWindowState", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_canGoForward = new lu.uni.democles.runtime.Property(this, "canGoForward", "BrowserWindowState", "Local", false, false, null, "single");
	public BrowserWindowState() {
		super("generated.BrowserGui.BrowserWindowState", new java.lang.String[] {  });

	}
	public void initProps() {
		if (this.isInitialized()) return;

		this._p_canGoForward.oldVal = this.initialValues.containsKey("canGoForward") ? this.initialValues.get("canGoForward") : eval_p(this._p_canGoForward).getValues().iterator().next();
this._p_canGoForward.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_canGoForward, this._p_canGoForward.oldVal);

		this._p_canGoBackward.oldVal = this.initialValues.containsKey("canGoBackward") ? this.initialValues.get("canGoBackward") : eval_p(this._p_canGoBackward).getValues().iterator().next();
this._p_canGoBackward.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_canGoBackward, this._p_canGoBackward.oldVal);

		this._p_currentUrl.oldVal = this.initialValues.containsKey("currentUrl") ? this.initialValues.get("currentUrl") : eval_p(this._p_currentUrl).getValues().iterator().next();
this._p_currentUrl.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_currentUrl, this._p_currentUrl.oldVal);

		this.setInitialized();
this.initialValues = new java.util.HashMap();


	}
	public static BrowserWindowState newWithValues(java.util.HashMap values) {
		BrowserWindowState res = new BrowserWindowState();
res.initialValues = new java.util.HashMap(values);
res.initProps();
return res;
	}
	private java.lang.Object __canGoForward_eval() {
		try {
	return new java.lang.Boolean(false);

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PROPERTY|BrowserGui::BrowserWindowState/Property/canGoForward");
	throw _error;
}

	}
	protected void set(lu.uni.democles.runtime.Property p, java.lang.Object v) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) {
	throw new lu.uni.democles.runtime.MultipleModificationException(p.toString());
}
p.newVal = v;
		super.set(p, v);
	}
	protected java.lang.Object evalQuery(lu.uni.democles.runtime.Property p) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) return p.newVal;

if (p.isEvaluating()) throw new lu.uni.democles.runtime.ModificationCycleException();

p.setEvaluating(true);
java.lang.Object o = null;


		if ("canGoForward".equals(p.entityName)) {
	o = __canGoForward_eval();
	set(p, o);
}

		if ("canGoBackward".equals(p.entityName)) {
	o = __canGoBackward_eval();
	set(p, o);
}

		if ("currentUrl".equals(p.entityName)) {
	o = __currentUrl_eval();
	set(p, o);
}

		if (o instanceof lu.uni.democles.runtime.Instance) {
	((lu.uni.democles.runtime.Instance)o).initProps();
} else if (o instanceof lu.uni.democles.runtime.OCLCollection) {
	for (java.util.Iterator iter = ((lu.uni.democles.runtime.OCLCollection)o).getValues().iterator(); iter.hasNext();) {
		java.lang.Object entry = iter.next();
		if (entry instanceof lu.uni.democles.runtime.Instance) {
			((lu.uni.democles.runtime.Instance)entry).initProps();
		}
	}
}
p.setEvaluating(false);
return o;


	}
	private java.lang.Object __currentUrl_eval() {
		try {
	return "";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PROPERTY|BrowserGui::BrowserWindowState/Property/currentUrl");
	throw _error;
}

	}
	private java.lang.Object __canGoBackward_eval() {
		try {
	return new java.lang.Boolean(false);

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PROPERTY|BrowserGui::BrowserWindowState/Property/canGoBackward");
	throw _error;
}

	}
	protected void updateVal(lu.uni.democles.runtime.Property p) {
		if ("canGoForward".equals(p.entityName)) {
	if (this._p_canGoForward.newVal != lu.uni.democles.runtime.Entity.nullObject) {
		java.lang.Object previousOldVal = this._p_canGoForward.oldVal;
		this._p_canGoForward.oldVal = this._p_canGoForward.newVal;
		lu.uni.democles.runtime.Instance.epDebugPropertyValueChanged(this, this._p_canGoForward, previousOldVal, this._p_canGoForward.newVal);
		this.notifyPropertyChangeListeners(p);
	}
}
		if ("canGoBackward".equals(p.entityName)) {
	if (this._p_canGoBackward.newVal != lu.uni.democles.runtime.Entity.nullObject) {
		java.lang.Object previousOldVal = this._p_canGoBackward.oldVal;
		this._p_canGoBackward.oldVal = this._p_canGoBackward.newVal;
		lu.uni.democles.runtime.Instance.epDebugPropertyValueChanged(this, this._p_canGoBackward, previousOldVal, this._p_canGoBackward.newVal);
		this.notifyPropertyChangeListeners(p);
	}
}
		if ("currentUrl".equals(p.entityName)) {
	if (this._p_currentUrl.newVal != lu.uni.democles.runtime.Entity.nullObject) {
		java.lang.Object previousOldVal = this._p_currentUrl.oldVal;
		this._p_currentUrl.oldVal = this._p_currentUrl.newVal;
		lu.uni.democles.runtime.Instance.epDebugPropertyValueChanged(this, this._p_currentUrl, previousOldVal, this._p_currentUrl.newVal);
		this.notifyPropertyChangeListeners(p);
	}
}
	}
	protected void resetNewVal() {
		this._p_canGoForward.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_canGoBackward.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_currentUrl.newVal = lu.uni.democles.runtime.Entity.nullObject;
	}
	public static void main(String[] args) {
	}
}
