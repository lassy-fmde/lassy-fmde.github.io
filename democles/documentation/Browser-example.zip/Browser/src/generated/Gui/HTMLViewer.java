package generated.Gui;

public class HTMLViewer extends lu.uni.democles.runtime.Instance {
	private lu.uni.democles.runtime.Event _e_showError = new lu.uni.democles.runtime.Event(this, "showError", "HTMLViewer", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_linkClicked = new lu.uni.democles.runtime.Event(this, "linkClicked", "HTMLViewer", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_pageLoadFinished = new lu.uni.democles.runtime.Event(this, "pageLoadFinished", "HTMLViewer", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Property _p_currentUrl = new lu.uni.democles.runtime.Property(this, "currentUrl", "HTMLViewer", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_linkExited = new lu.uni.democles.runtime.Event(this, "linkExited", "HTMLViewer", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_linkEntered = new lu.uni.democles.runtime.Event(this, "linkEntered", "HTMLViewer", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_setCurrentUrl = new lu.uni.democles.runtime.Event(this, "setCurrentUrl", "HTMLViewer", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_pageLoadError = new lu.uni.democles.runtime.Event(this, "pageLoadError", "HTMLViewer", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	public HTMLViewer() {
		super("generated.Gui.HTMLViewer", new java.lang.String[] { "generated.Gui.Widget" });

	}
	private java.lang.Object eval_ep(final lu.uni.democles.runtime.Event e, final lu.uni.democles.runtime.Property p) {
		if (p.entityName.equals(this._p_currentUrl.entityName) && e.entityName.equals(this._e_setCurrentUrl.entityName)) {
	return _setCurrentUrl_currentUrl_eval(e);
}
		return null;

	}
	protected java.lang.Object eval_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse, final java.lang.String _paramName) {
		
		return null;

	}
	protected void attachProperties(lu.uni.democles.runtime.Event e) {
		// Set Attached Properties:


	}
	protected void updateValues(lu.uni.democles.runtime.Event event) {
		if (event.entityName.equals("setCurrentUrl")) {
	updateVal(this._p_currentUrl);
}

	}
	public void initProps() {
		if (this.isInitialized()) return;

		this._p_currentUrl.oldVal = this.initialValues.containsKey("currentUrl") ? this.initialValues.get("currentUrl") : eval_p(this._p_currentUrl).getValues().iterator().next();
this._p_currentUrl.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_currentUrl, this._p_currentUrl.oldVal);

		this.setInitialized();
this.initialValues = new java.util.HashMap();


	}
	protected void doModify(lu.uni.democles.runtime.Event event) {
		if ("setCurrentUrl".equals(event.entityName)) {
	handleImpact(event, this._p_currentUrl);
}

	}
	public static HTMLViewer newWithValues(java.util.HashMap values) {
		HTMLViewer res = new HTMLViewer();
res.initialValues = new java.util.HashMap(values);
res.initProps();
return res;
	}
	private void handleImpact(lu.uni.democles.runtime.Event e, lu.uni.democles.runtime.Property p) {
		set(p, eval_ep(e, p));
	}
	protected java.lang.Object evalQuery(lu.uni.democles.runtime.Property p) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) return p.newVal;

if (p.isEvaluating()) throw new lu.uni.democles.runtime.ModificationCycleException();

p.setEvaluating(true);
java.lang.Object o = null;


		if ("currentUrl".equals(p.entityName)) {
	o = __currentUrl_eval();
	set(p, o);
}

		if (o instanceof lu.uni.democles.runtime.Instance) {
	((lu.uni.democles.runtime.Instance)o).initProps();
} else if (o instanceof lu.uni.democles.runtime.OCLCollection) {
	for (java.util.Iterator iter = ((lu.uni.democles.runtime.OCLCollection)o).getValues().iterator(); iter.hasNext();) {
		java.lang.Object entry = iter.next();
		if (entry instanceof lu.uni.democles.runtime.Instance) {
			((lu.uni.democles.runtime.Instance)entry).initProps();
		}
	}
}
p.setEvaluating(false);
return o;


	}
	protected void set(lu.uni.democles.runtime.Property p, java.lang.Object v) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) {
	throw new lu.uni.democles.runtime.MultipleModificationException(p.toString());
}
p.newVal = v;
		super.set(p, v);
	}
	protected void updateVal(lu.uni.democles.runtime.Property p) {
		if ("currentUrl".equals(p.entityName)) {
	if (this._p_currentUrl.newVal != lu.uni.democles.runtime.Entity.nullObject) {
		java.lang.Object previousOldVal = this._p_currentUrl.oldVal;
		this._p_currentUrl.oldVal = this._p_currentUrl.newVal;
		lu.uni.democles.runtime.Instance.epDebugPropertyValueChanged(this, this._p_currentUrl, previousOldVal, this._p_currentUrl.newVal);
		this.notifyPropertyChangeListeners(p);
	}
}
	}
	private java.lang.Object __currentUrl_eval() {
		try {
	return "";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PROPERTY|Gui::HTMLViewer/Property/currentUrl");
	throw _error;
}

	}
	private java.lang.Object _setCurrentUrl_currentUrl_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return ((java.lang.String)_event.getParameter("url"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("IMPACTS|Gui::HTMLViewer/Event/setCurrentUrl-impacts-Gui::HTMLViewer/Property/currentUrl");
	try {
		_error.addVariable("url", _event.getParameter("url"));
	} catch (Throwable _t) {
		_error.addVariable("url", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	protected java.lang.Object eval_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final java.lang.String paramName, final int _link) {
		
		return null;

	}
	protected void resetNewVal() {
		this._p_currentUrl.newVal = lu.uni.democles.runtime.Entity.nullObject;
	}
	public static void main(String[] args) {
	}
}
