package generated.Gui;

public class ItemList extends lu.uni.democles.runtime.Instance {
	private lu.uni.democles.runtime.Event _e_show = new lu.uni.democles.runtime.Event(this, "show", "ItemList", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_itemSelected = new lu.uni.democles.runtime.Event(this, "itemSelected", "ItemList", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Property _p_items = new lu.uni.democles.runtime.Property(this, "items", "ItemList", "Local", false, false, null, "sequence");
	private lu.uni.democles.runtime.Event _e_addItem = new lu.uni.democles.runtime.Event(this, "addItem", "ItemList", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_deleteSelectedItem = new lu.uni.democles.runtime.Event(this, "deleteSelectedItem", "ItemList", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_updateSelectedItem = new lu.uni.democles.runtime.Event(this, "updateSelectedItem", "ItemList", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_hide = new lu.uni.democles.runtime.Event(this, "hide", "ItemList", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_setItems = new lu.uni.democles.runtime.Event(this, "setItems", "ItemList", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Property _p_selectedItem = new lu.uni.democles.runtime.Property(this, "selectedItem", "ItemList", "Local", false, false, null, "single");
	protected void attachProperties(lu.uni.democles.runtime.Event e) {
		// Set Attached Properties:


		// Set Attached Properties:
if ("deleteSelectedItem".equals(e.entityName)) {
	e.attachProperty("ItemList_selectedItem", this._p_selectedItem.evalInContainer().getValues().iterator().next());
}


	}
	private java.lang.Object eval_ep(final lu.uni.democles.runtime.Event e, final lu.uni.democles.runtime.Property p) {
		if (p.entityName.equals(this._p_items.entityName) && e.entityName.equals(this._e_addItem.entityName)) {
	return _addItem_items_eval(e);
}
		if (p.entityName.equals(this._p_items.entityName) && e.entityName.equals(this._e_deleteSelectedItem.entityName)) {
	return _deleteSelectedItem_items_eval(e);
}
		if (p.entityName.equals(this._p_selectedItem.entityName) && e.entityName.equals(this._e_itemSelected.entityName)) {
	return _itemSelected_selectedItem_eval(e);
}
		if (p.entityName.equals(this._p_selectedItem.entityName) && e.entityName.equals(this._e_deleteSelectedItem.entityName)) {
	return _deleteSelectedItem_selectedItem_eval(e);
}
		if (p.entityName.equals(this._p_items.entityName) && e.entityName.equals(this._e_setItems.entityName)) {
	return _setItems_items_eval(e);
}
		return null;

	}
	public static ItemList newWithValues(java.util.HashMap values) {
		ItemList res = new ItemList();
res.initialValues = new java.util.HashMap(values);
res.initProps();
return res;
	}
	private java.lang.Object _itemSelected_selectedItem_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return ((lu.uni.democles.runtime.Instance)_event.getParameter("item"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("IMPACTS|Gui::ItemList/Event/itemSelected-impacts-Gui::ItemList/Property/selectedItem");
	try {
		_error.addVariable("item", _event.getParameter("item"));
	} catch (Throwable _t) {
		_error.addVariable("item", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	protected java.lang.Object evalQuery(lu.uni.democles.runtime.Property p) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) return p.newVal;

if (p.isEvaluating()) throw new lu.uni.democles.runtime.ModificationCycleException();

p.setEvaluating(true);
java.lang.Object o = null;


		if ("items".equals(p.entityName)) {
	o = __items_eval();
	set(p, o);
}

		if ("selectedItem".equals(p.entityName)) {
	o = __selectedItem_eval();
	set(p, o);
}

		if (o instanceof lu.uni.democles.runtime.Instance) {
	((lu.uni.democles.runtime.Instance)o).initProps();
} else if (o instanceof lu.uni.democles.runtime.OCLCollection) {
	for (java.util.Iterator iter = ((lu.uni.democles.runtime.OCLCollection)o).getValues().iterator(); iter.hasNext();) {
		java.lang.Object entry = iter.next();
		if (entry instanceof lu.uni.democles.runtime.Instance) {
			((lu.uni.democles.runtime.Instance)entry).initProps();
		}
	}
}
p.setEvaluating(false);
return o;


	}
	public static void main(String[] args) {
	}
	private java.lang.Object _setItems_items_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return ((lu.uni.democles.runtime.OCLSequence)_event.getParameter("newItems"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("IMPACTS|Gui::ItemList/Event/setItems-impacts-Gui::ItemList/Property/items");
	try {
		_error.addVariable("newItems", _event.getParameter("newItems"));
	} catch (Throwable _t) {
		_error.addVariable("newItems", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	protected java.lang.Object eval_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse, final java.lang.String _paramName) {
		
		return null;

	}
	private java.lang.Object __selectedItem_eval() {
		try {
	return null;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PROPERTY|Gui::ItemList/Property/selectedItem");
	throw _error;
}

	}
	protected void resetNewVal() {
		this._p_items.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_selectedItem.newVal = lu.uni.democles.runtime.Entity.nullObject;
	}
	private void handleImpact(lu.uni.democles.runtime.Event e, lu.uni.democles.runtime.Property p) {
		set(p, eval_ep(e, p));
	}
	private java.lang.Object __items_eval() {
		try {
	return new lu.uni.democles.runtime.OCLSequence(new Object[] {});

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PROPERTY|Gui::ItemList/Property/items");
	throw _error;
}

	}
	private java.lang.Object _addItem_items_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return (((lu.uni.democles.runtime.OCLSequence)((lu.uni.democles.runtime.Property)generated.Gui.ItemList.this.getEntity("items")).evalInContainer()).including(((lu.uni.democles.runtime.Instance)_event.getParameter("newItem"))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("IMPACTS|Gui::ItemList/Event/addItem-impacts-Gui::ItemList/Property/items");
	try {
		_error.addVariable("newItem", _event.getParameter("newItem"));
	} catch (Throwable _t) {
		_error.addVariable("newItem", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	protected void doModify(lu.uni.democles.runtime.Event event) {
		if ("setItems".equals(event.entityName)) {
	handleImpact(event, this._p_items);
}
if ("deleteSelectedItem".equals(event.entityName)) {
	handleImpact(event, this._p_items);
}
if ("itemSelected".equals(event.entityName)) {
	handleImpact(event, this._p_selectedItem);
}
if ("deleteSelectedItem".equals(event.entityName)) {
	handleImpact(event, this._p_selectedItem);
}
if ("addItem".equals(event.entityName)) {
	handleImpact(event, this._p_items);
}

	}
	protected void updateValues(lu.uni.democles.runtime.Event event) {
		if (event.entityName.equals("addItem")) {
	updateVal(this._p_items);
}

		if (event.entityName.equals("deleteSelectedItem")) {
	updateVal(this._p_items);
}

		if (event.entityName.equals("itemSelected")) {
	updateVal(this._p_selectedItem);
}

		if (event.entityName.equals("deleteSelectedItem")) {
	updateVal(this._p_selectedItem);
}

		if (event.entityName.equals("setItems")) {
	updateVal(this._p_items);
}

	}
	protected void set(lu.uni.democles.runtime.Property p, java.lang.Object v) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) {
	throw new lu.uni.democles.runtime.MultipleModificationException(p.toString());
}
p.newVal = v;
		super.set(p, v);
	}
	protected java.lang.Object eval_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final java.lang.String paramName, final int _link) {
		
		return null;

	}
	public void initProps() {
		if (this.isInitialized()) return;

		this._p_items.oldVal = this.initialValues.containsKey("items") ? this.initialValues.get("items") : eval_p(this._p_items);
this._p_items.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_items, this._p_items.oldVal);

		this._p_selectedItem.oldVal = this.initialValues.containsKey("selectedItem") ? this.initialValues.get("selectedItem") : eval_p(this._p_selectedItem).getValues().iterator().next();
this._p_selectedItem.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_selectedItem, this._p_selectedItem.oldVal);

		this.setInitialized();
this.initialValues = new java.util.HashMap();


	}
	protected void updateVal(lu.uni.democles.runtime.Property p) {
		if ("items".equals(p.entityName)) {
	if (this._p_items.newVal != lu.uni.democles.runtime.Entity.nullObject) {
		java.lang.Object previousOldVal = this._p_items.oldVal;
		this._p_items.oldVal = this._p_items.newVal;
		lu.uni.democles.runtime.Instance.epDebugPropertyValueChanged(this, this._p_items, previousOldVal, this._p_items.newVal);
		this.notifyPropertyChangeListeners(p);
	}
}
		if ("selectedItem".equals(p.entityName)) {
	if (this._p_selectedItem.newVal != lu.uni.democles.runtime.Entity.nullObject) {
		java.lang.Object previousOldVal = this._p_selectedItem.oldVal;
		this._p_selectedItem.oldVal = this._p_selectedItem.newVal;
		lu.uni.democles.runtime.Instance.epDebugPropertyValueChanged(this, this._p_selectedItem, previousOldVal, this._p_selectedItem.newVal);
		this.notifyPropertyChangeListeners(p);
	}
}
	}
	private java.lang.Object _deleteSelectedItem_selectedItem_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return null;

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("IMPACTS|Gui::ItemList/Event/deleteSelectedItem-impacts-Gui::ItemList/Property/selectedItem");
	try {
		_error.addVariable("selectedItem", _event.getAttachedProperty("ItemList_selectedItem"));
	} catch (Throwable _t) {
		_error.addVariable("selectedItem", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	public ItemList() {
		super("generated.Gui.ItemList", new java.lang.String[] { "generated.Gui.Widget" });

	}
	private java.lang.Object _deleteSelectedItem_items_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return ((lu.uni.democles.runtime.OCLSequence)new lu.uni.democles.runtime.Function() {
	public Object _result() {
if ((lu.uni.democles.runtime.Function._equals(((lu.uni.democles.runtime.Instance)_event.getAttachedProperty("ItemList_selectedItem")), null))) {
	return _asObject(((lu.uni.democles.runtime.OCLSequence)((lu.uni.democles.runtime.Property)generated.Gui.ItemList.this.getEntity("items")).evalInContainer()));
} else {
	return _asObject((((lu.uni.democles.runtime.OCLSequence)((lu.uni.democles.runtime.Property)generated.Gui.ItemList.this.getEntity("items")).evalInContainer()).excluding(((lu.uni.democles.runtime.Instance)_event.getAttachedProperty("ItemList_selectedItem")))));
}
}}._result());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("IMPACTS|Gui::ItemList/Event/deleteSelectedItem-impacts-Gui::ItemList/Property/items");
	try {
		_error.addVariable("selectedItem", _event.getAttachedProperty("ItemList_selectedItem"));
	} catch (Throwable _t) {
		_error.addVariable("selectedItem", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
}
