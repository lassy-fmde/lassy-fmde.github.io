package generated.Gui;

public class Action extends lu.uni.democles.runtime.Instance {
	private lu.uni.democles.runtime.Event _e_execute = new lu.uni.democles.runtime.Event(this, "execute", "Action", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	protected java.lang.Object eval_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final java.lang.String paramName, final int _link) {
		
		return null;

	}
	protected void resetNewVal() {
	}
	public static void main(String[] args) {
	}
	protected void updateValues(lu.uni.democles.runtime.Event event) {
	}
	public Action() {
		super("generated.Gui.Action", new java.lang.String[] {  });

	}
	protected java.lang.Object eval_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse, final java.lang.String _paramName) {
		
		return null;

	}
	protected void attachProperties(lu.uni.democles.runtime.Event e) {
		// Set Attached Properties:


	}
}
