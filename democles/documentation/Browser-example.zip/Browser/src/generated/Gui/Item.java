package generated.Gui;

public class Item extends lu.uni.democles.runtime.Instance {
	private lu.uni.democles.runtime.Property _p_value = new lu.uni.democles.runtime.Property(this, "value", "Item", "Query", false, false, null, "single");
	public void initProps() {
		if (this.isInitialized()) return;

		this.setInitialized();
this.initialValues = new java.util.HashMap();


	}
	public static Item newWithValues(java.util.HashMap values) {
		Item res = new Item();
res.initialValues = new java.util.HashMap(values);
res.initProps();
return res;
	}
	public Item() {
		super("generated.Gui.Item", new java.lang.String[] {  });

	}
	protected void set(lu.uni.democles.runtime.Property p, java.lang.Object v) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) {
	throw new lu.uni.democles.runtime.MultipleModificationException(p.toString());
}
p.newVal = v;
		super.set(p, v);
	}
	protected java.lang.Object evalQuery(lu.uni.democles.runtime.Property p) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) return p.newVal;

if (p.isEvaluating()) throw new lu.uni.democles.runtime.ModificationCycleException();

p.setEvaluating(true);
java.lang.Object o = null;


		if ("value".equals(p.entityName)) {
	o = __value_eval();
	set(p, o);
}

		if (o instanceof lu.uni.democles.runtime.Instance) {
	((lu.uni.democles.runtime.Instance)o).initProps();
} else if (o instanceof lu.uni.democles.runtime.OCLCollection) {
	for (java.util.Iterator iter = ((lu.uni.democles.runtime.OCLCollection)o).getValues().iterator(); iter.hasNext();) {
		java.lang.Object entry = iter.next();
		if (entry instanceof lu.uni.democles.runtime.Instance) {
			((lu.uni.democles.runtime.Instance)entry).initProps();
		}
	}
}
p.setEvaluating(false);
return o;


	}
	private java.lang.Object __value_eval() {
		/* Invalid OCL code omitted! */
	throw new RuntimeException("Execution reached invalid OCL code at Property value in Model Gui::Item: Incompatible expression of type Boolean, expected String or subtype");

	}
	protected void updateVal(lu.uni.democles.runtime.Property p) {
	}
	protected void resetNewVal() {
		this._p_value.newVal = lu.uni.democles.runtime.Entity.nullObject;
	}
	public static void main(String[] args) {
	}
}
