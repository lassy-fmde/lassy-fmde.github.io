package generated.Gui;

public class Widget extends lu.uni.democles.runtime.Instance {
	public Widget() {
		super("generated.Gui.Widget", new java.lang.String[] {  });

	}
}
