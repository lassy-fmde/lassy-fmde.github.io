package generated.Gui;

public class Window extends lu.uni.democles.runtime.Instance {
	private lu.uni.democles.runtime.Event _e_setStatusText = new lu.uni.democles.runtime.Event(this, "setStatusText", "Window", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_setWidgets = new lu.uni.democles.runtime.Event(this, "setWidgets", "Window", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Property _p_toolbarWidgets = new lu.uni.democles.runtime.Property(this, "toolbarWidgets", "Window", "Local", false, false, null, "sequence");
	private lu.uni.democles.runtime.Property _p_widgets = new lu.uni.democles.runtime.Property(this, "widgets", "Window", "Local", false, false, null, "sequence");
	private lu.uni.democles.runtime.Property _p_statusText = new lu.uni.democles.runtime.Property(this, "statusText", "Window", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_title = new lu.uni.democles.runtime.Property(this, "title", "Window", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_setToolbarWidgets = new lu.uni.democles.runtime.Event(this, "setToolbarWidgets", "Window", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_setTitle = new lu.uni.democles.runtime.Event(this, "setTitle", "Window", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_closed = new lu.uni.democles.runtime.Event(this, "closed", "Window", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private java.lang.Object _setTitle_title_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return ((java.lang.String)_event.getParameter("title"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("IMPACTS|Gui::Window/Event/setTitle-impacts-Gui::Window/Property/title");
	try {
		_error.addVariable("title", _event.getParameter("title"));
	} catch (Throwable _t) {
		_error.addVariable("title", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	public static Window newWithValues(java.util.HashMap values) {
		Window res = new Window();
res.initialValues = new java.util.HashMap(values);
res.initProps();
return res;
	}
	protected void attachProperties(lu.uni.democles.runtime.Event e) {
		// Set Attached Properties:


	}
	private java.lang.Object eval_ep(final lu.uni.democles.runtime.Event e, final lu.uni.democles.runtime.Property p) {
		if (p.entityName.equals(this._p_toolbarWidgets.entityName) && e.entityName.equals(this._e_setToolbarWidgets.entityName)) {
	return _setToolbarWidgets_toolbarWidgets_eval(e);
}
		if (p.entityName.equals(this._p_title.entityName) && e.entityName.equals(this._e_setTitle.entityName)) {
	return _setTitle_title_eval(e);
}
		if (p.entityName.equals(this._p_widgets.entityName) && e.entityName.equals(this._e_setWidgets.entityName)) {
	return _setWidgets_widgets_eval(e);
}
		if (p.entityName.equals(this._p_statusText.entityName) && e.entityName.equals(this._e_setStatusText.entityName)) {
	return _setStatusText_statusText_eval(e);
}
		return null;

	}
	private java.lang.Object _setStatusText_statusText_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return ((java.lang.String)_event.getParameter("statusText"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("IMPACTS|Gui::Window/Event/setStatusText-impacts-Gui::Window/Property/statusText");
	try {
		_error.addVariable("statusText", _event.getParameter("statusText"));
	} catch (Throwable _t) {
		_error.addVariable("statusText", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	private java.lang.Object _setToolbarWidgets_toolbarWidgets_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return ((lu.uni.democles.runtime.OCLSequence)_event.getParameter("toolbarWidgets"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("IMPACTS|Gui::Window/Event/setToolbarWidgets-impacts-Gui::Window/Property/toolbarWidgets");
	try {
		_error.addVariable("toolbarWidgets", _event.getParameter("toolbarWidgets"));
	} catch (Throwable _t) {
		_error.addVariable("toolbarWidgets", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	public Window() {
		super("generated.Gui.Window", new java.lang.String[] {  });

	}
	protected java.lang.Object evalQuery(lu.uni.democles.runtime.Property p) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) return p.newVal;

if (p.isEvaluating()) throw new lu.uni.democles.runtime.ModificationCycleException();

p.setEvaluating(true);
java.lang.Object o = null;


		if ("toolbarWidgets".equals(p.entityName)) {
	o = __toolbarWidgets_eval();
	set(p, o);
}

		if ("title".equals(p.entityName)) {
	o = __title_eval();
	set(p, o);
}

		if ("widgets".equals(p.entityName)) {
	o = __widgets_eval();
	set(p, o);
}

		if ("statusText".equals(p.entityName)) {
	o = __statusText_eval();
	set(p, o);
}

		if (o instanceof lu.uni.democles.runtime.Instance) {
	((lu.uni.democles.runtime.Instance)o).initProps();
} else if (o instanceof lu.uni.democles.runtime.OCLCollection) {
	for (java.util.Iterator iter = ((lu.uni.democles.runtime.OCLCollection)o).getValues().iterator(); iter.hasNext();) {
		java.lang.Object entry = iter.next();
		if (entry instanceof lu.uni.democles.runtime.Instance) {
			((lu.uni.democles.runtime.Instance)entry).initProps();
		}
	}
}
p.setEvaluating(false);
return o;


	}
	public static void main(String[] args) {
	}
	protected java.lang.Object eval_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse, final java.lang.String _paramName) {
		
		return null;

	}
	protected void resetNewVal() {
		this._p_toolbarWidgets.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_title.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_widgets.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_statusText.newVal = lu.uni.democles.runtime.Entity.nullObject;
	}
	private java.lang.Object __toolbarWidgets_eval() {
		try {
	return new lu.uni.democles.runtime.OCLSequence(new Object[] {});

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PROPERTY|Gui::Window/Property/toolbarWidgets");
	throw _error;
}

	}
	private void handleImpact(lu.uni.democles.runtime.Event e, lu.uni.democles.runtime.Property p) {
		set(p, eval_ep(e, p));
	}
	private java.lang.Object __title_eval() {
		try {
	return "";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PROPERTY|Gui::Window/Property/title");
	throw _error;
}

	}
	protected void doModify(lu.uni.democles.runtime.Event event) {
		if ("setToolbarWidgets".equals(event.entityName)) {
	handleImpact(event, this._p_toolbarWidgets);
}
if ("setStatusText".equals(event.entityName)) {
	handleImpact(event, this._p_statusText);
}
if ("setWidgets".equals(event.entityName)) {
	handleImpact(event, this._p_widgets);
}
if ("setTitle".equals(event.entityName)) {
	handleImpact(event, this._p_title);
}

	}
	protected void updateValues(lu.uni.democles.runtime.Event event) {
		if (event.entityName.equals("setToolbarWidgets")) {
	updateVal(this._p_toolbarWidgets);
}

		if (event.entityName.equals("setTitle")) {
	updateVal(this._p_title);
}

		if (event.entityName.equals("setWidgets")) {
	updateVal(this._p_widgets);
}

		if (event.entityName.equals("setStatusText")) {
	updateVal(this._p_statusText);
}

	}
	private java.lang.Object __widgets_eval() {
		try {
	return new lu.uni.democles.runtime.OCLSequence(new Object[] {});

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PROPERTY|Gui::Window/Property/widgets");
	throw _error;
}

	}
	private java.lang.Object _setWidgets_widgets_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return ((lu.uni.democles.runtime.OCLSequence)_event.getParameter("ws"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("IMPACTS|Gui::Window/Event/setWidgets-impacts-Gui::Window/Property/widgets");
	try {
		_error.addVariable("ws", _event.getParameter("ws"));
	} catch (Throwable _t) {
		_error.addVariable("ws", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	protected void set(lu.uni.democles.runtime.Property p, java.lang.Object v) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) {
	throw new lu.uni.democles.runtime.MultipleModificationException(p.toString());
}
p.newVal = v;
		super.set(p, v);
	}
	protected java.lang.Object eval_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final java.lang.String paramName, final int _link) {
		
		return null;

	}
	private java.lang.Object __statusText_eval() {
		try {
	return "";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PROPERTY|Gui::Window/Property/statusText");
	throw _error;
}

	}
	public void initProps() {
		if (this.isInitialized()) return;

		this._p_toolbarWidgets.oldVal = this.initialValues.containsKey("toolbarWidgets") ? this.initialValues.get("toolbarWidgets") : eval_p(this._p_toolbarWidgets);
this._p_toolbarWidgets.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_toolbarWidgets, this._p_toolbarWidgets.oldVal);

		this._p_title.oldVal = this.initialValues.containsKey("title") ? this.initialValues.get("title") : eval_p(this._p_title).getValues().iterator().next();
this._p_title.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_title, this._p_title.oldVal);

		this._p_widgets.oldVal = this.initialValues.containsKey("widgets") ? this.initialValues.get("widgets") : eval_p(this._p_widgets);
this._p_widgets.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_widgets, this._p_widgets.oldVal);

		this._p_statusText.oldVal = this.initialValues.containsKey("statusText") ? this.initialValues.get("statusText") : eval_p(this._p_statusText).getValues().iterator().next();
this._p_statusText.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_statusText, this._p_statusText.oldVal);

		this.setInitialized();
this.initialValues = new java.util.HashMap();


	}
	protected void updateVal(lu.uni.democles.runtime.Property p) {
		if ("toolbarWidgets".equals(p.entityName)) {
	if (this._p_toolbarWidgets.newVal != lu.uni.democles.runtime.Entity.nullObject) {
		java.lang.Object previousOldVal = this._p_toolbarWidgets.oldVal;
		this._p_toolbarWidgets.oldVal = this._p_toolbarWidgets.newVal;
		lu.uni.democles.runtime.Instance.epDebugPropertyValueChanged(this, this._p_toolbarWidgets, previousOldVal, this._p_toolbarWidgets.newVal);
		this.notifyPropertyChangeListeners(p);
	}
}
		if ("title".equals(p.entityName)) {
	if (this._p_title.newVal != lu.uni.democles.runtime.Entity.nullObject) {
		java.lang.Object previousOldVal = this._p_title.oldVal;
		this._p_title.oldVal = this._p_title.newVal;
		lu.uni.democles.runtime.Instance.epDebugPropertyValueChanged(this, this._p_title, previousOldVal, this._p_title.newVal);
		this.notifyPropertyChangeListeners(p);
	}
}
		if ("widgets".equals(p.entityName)) {
	if (this._p_widgets.newVal != lu.uni.democles.runtime.Entity.nullObject) {
		java.lang.Object previousOldVal = this._p_widgets.oldVal;
		this._p_widgets.oldVal = this._p_widgets.newVal;
		lu.uni.democles.runtime.Instance.epDebugPropertyValueChanged(this, this._p_widgets, previousOldVal, this._p_widgets.newVal);
		this.notifyPropertyChangeListeners(p);
	}
}
		if ("statusText".equals(p.entityName)) {
	if (this._p_statusText.newVal != lu.uni.democles.runtime.Entity.nullObject) {
		java.lang.Object previousOldVal = this._p_statusText.oldVal;
		this._p_statusText.oldVal = this._p_statusText.newVal;
		lu.uni.democles.runtime.Instance.epDebugPropertyValueChanged(this, this._p_statusText, previousOldVal, this._p_statusText.newVal);
		this.notifyPropertyChangeListeners(p);
	}
}
	}
}
