package generated.Gui;

public class Button extends lu.uni.democles.runtime.Instance {
	private lu.uni.democles.runtime.Event _e_setEnabled = new lu.uni.democles.runtime.Event(this, "setEnabled", "Button", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_execute = new lu.uni.democles.runtime.Event(this, "execute", "Button", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Property _p_enabled = new lu.uni.democles.runtime.Property(this, "enabled", "Button", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_label = new lu.uni.democles.runtime.Property(this, "label", "Button", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_setLabel = new lu.uni.democles.runtime.Event(this, "setLabel", "Button", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private java.lang.Object __enabled_eval() {
		try {
	return new java.lang.Boolean(true);

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PROPERTY|Gui::Button/Property/enabled");
	throw _error;
}

	}
	protected void attachProperties(lu.uni.democles.runtime.Event e) {
		// Set Attached Properties:


	}
	private java.lang.Object eval_ep(final lu.uni.democles.runtime.Event e, final lu.uni.democles.runtime.Property p) {
		if (p.entityName.equals(this._p_label.entityName) && e.entityName.equals(this._e_setLabel.entityName)) {
	return _setLabel_label_eval(e);
}
		if (p.entityName.equals(this._p_enabled.entityName) && e.entityName.equals(this._e_setEnabled.entityName)) {
	return _setEnabled_enabled_eval(e);
}
		return null;

	}
	protected java.lang.Object evalQuery(lu.uni.democles.runtime.Property p) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) return p.newVal;

if (p.isEvaluating()) throw new lu.uni.democles.runtime.ModificationCycleException();

p.setEvaluating(true);
java.lang.Object o = null;


		if ("enabled".equals(p.entityName)) {
	o = __enabled_eval();
	set(p, o);
}

		if ("label".equals(p.entityName)) {
	o = __label_eval();
	set(p, o);
}

		if (o instanceof lu.uni.democles.runtime.Instance) {
	((lu.uni.democles.runtime.Instance)o).initProps();
} else if (o instanceof lu.uni.democles.runtime.OCLCollection) {
	for (java.util.Iterator iter = ((lu.uni.democles.runtime.OCLCollection)o).getValues().iterator(); iter.hasNext();) {
		java.lang.Object entry = iter.next();
		if (entry instanceof lu.uni.democles.runtime.Instance) {
			((lu.uni.democles.runtime.Instance)entry).initProps();
		}
	}
}
p.setEvaluating(false);
return o;


	}
	private java.lang.Object _setLabel_label_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return ((java.lang.String)_event.getParameter("label"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("IMPACTS|Gui::Button/Event/setLabel-impacts-Gui::Button/Property/label");
	try {
		_error.addVariable("label", _event.getParameter("label"));
	} catch (Throwable _t) {
		_error.addVariable("label", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	public static void main(String[] args) {
	}
	protected java.lang.Object eval_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse, final java.lang.String _paramName) {
		
		return null;

	}
	public Button() {
		super("generated.Gui.Button", new java.lang.String[] { "generated.Gui.Action", "generated.Gui.Widget" });

	}
	protected void resetNewVal() {
		this._p_enabled.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_label.newVal = lu.uni.democles.runtime.Entity.nullObject;
	}
	private void handleImpact(lu.uni.democles.runtime.Event e, lu.uni.democles.runtime.Property p) {
		set(p, eval_ep(e, p));
	}
	protected void doModify(lu.uni.democles.runtime.Event event) {
		if ("setEnabled".equals(event.entityName)) {
	handleImpact(event, this._p_enabled);
}
if ("setLabel".equals(event.entityName)) {
	handleImpact(event, this._p_label);
}

	}
	private java.lang.Object __label_eval() {
		try {
	return "";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PROPERTY|Gui::Button/Property/label");
	throw _error;
}

	}
	protected void updateValues(lu.uni.democles.runtime.Event event) {
		if (event.entityName.equals("setLabel")) {
	updateVal(this._p_label);
}

		if (event.entityName.equals("setEnabled")) {
	updateVal(this._p_enabled);
}

	}
	private java.lang.Object _setEnabled_enabled_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return new java.lang.Boolean(((boolean)((java.lang.Boolean)_event.getParameter("enabled")).booleanValue()));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("IMPACTS|Gui::Button/Event/setEnabled-impacts-Gui::Button/Property/enabled");
	try {
		_error.addVariable("enabled", _event.getParameter("enabled"));
	} catch (Throwable _t) {
		_error.addVariable("enabled", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	protected void set(lu.uni.democles.runtime.Property p, java.lang.Object v) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) {
	throw new lu.uni.democles.runtime.MultipleModificationException(p.toString());
}
p.newVal = v;
		super.set(p, v);
	}
	protected java.lang.Object eval_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final java.lang.String paramName, final int _link) {
		
		return null;

	}
	public static Button newWithValues(java.util.HashMap values) {
		Button res = new Button();
res.initialValues = new java.util.HashMap(values);
res.initProps();
return res;
	}
	public void initProps() {
		if (this.isInitialized()) return;

		this._p_enabled.oldVal = this.initialValues.containsKey("enabled") ? this.initialValues.get("enabled") : eval_p(this._p_enabled).getValues().iterator().next();
this._p_enabled.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_enabled, this._p_enabled.oldVal);

		this._p_label.oldVal = this.initialValues.containsKey("label") ? this.initialValues.get("label") : eval_p(this._p_label).getValues().iterator().next();
this._p_label.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_label, this._p_label.oldVal);

		this.setInitialized();
this.initialValues = new java.util.HashMap();


	}
	protected void updateVal(lu.uni.democles.runtime.Property p) {
		if ("enabled".equals(p.entityName)) {
	if (this._p_enabled.newVal != lu.uni.democles.runtime.Entity.nullObject) {
		java.lang.Object previousOldVal = this._p_enabled.oldVal;
		this._p_enabled.oldVal = this._p_enabled.newVal;
		lu.uni.democles.runtime.Instance.epDebugPropertyValueChanged(this, this._p_enabled, previousOldVal, this._p_enabled.newVal);
		this.notifyPropertyChangeListeners(p);
	}
}
		if ("label".equals(p.entityName)) {
	if (this._p_label.newVal != lu.uni.democles.runtime.Entity.nullObject) {
		java.lang.Object previousOldVal = this._p_label.oldVal;
		this._p_label.oldVal = this._p_label.newVal;
		lu.uni.democles.runtime.Instance.epDebugPropertyValueChanged(this, this._p_label, previousOldVal, this._p_label.newVal);
		this.notifyPropertyChangeListeners(p);
	}
}
	}
}
