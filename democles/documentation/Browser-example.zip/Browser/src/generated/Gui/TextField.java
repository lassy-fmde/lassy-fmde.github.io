package generated.Gui;

public class TextField extends lu.uni.democles.runtime.Instance {
	private lu.uni.democles.runtime.Property _p_text = new lu.uni.democles.runtime.Property(this, "text", "TextField", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_activated = new lu.uni.democles.runtime.Event(this, "activated", "TextField", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_show = new lu.uni.democles.runtime.Event(this, "show", "TextField", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_hide = new lu.uni.democles.runtime.Event(this, "hide", "TextField", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_setText = new lu.uni.democles.runtime.Event(this, "setText", "TextField", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private java.lang.Object eval_ep(final lu.uni.democles.runtime.Event e, final lu.uni.democles.runtime.Property p) {
		if (p.entityName.equals(this._p_text.entityName) && e.entityName.equals(this._e_setText.entityName)) {
	return _setText_text_eval(e);
}
		return null;

	}
	protected java.lang.Object eval_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse, final java.lang.String _paramName) {
		
		return null;

	}
	private java.lang.Object __text_eval() {
		try {
	return "";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PROPERTY|Gui::TextField/Property/text");
	throw _error;
}

	}
	protected void attachProperties(lu.uni.democles.runtime.Event e) {
		// Set Attached Properties:


	}
	protected void updateValues(lu.uni.democles.runtime.Event event) {
		if (event.entityName.equals("setText")) {
	updateVal(this._p_text);
}

	}
	public void initProps() {
		if (this.isInitialized()) return;

		this._p_text.oldVal = this.initialValues.containsKey("text") ? this.initialValues.get("text") : eval_p(this._p_text).getValues().iterator().next();
this._p_text.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_text, this._p_text.oldVal);

		this.setInitialized();
this.initialValues = new java.util.HashMap();


	}
	protected void doModify(lu.uni.democles.runtime.Event event) {
		if ("setText".equals(event.entityName)) {
	handleImpact(event, this._p_text);
}

	}
	public TextField() {
		super("generated.Gui.TextField", new java.lang.String[] { "generated.Gui.Widget" });

	}
	private java.lang.Object _setText_text_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return ((java.lang.String)_event.getParameter("s"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("IMPACTS|Gui::TextField/Event/setText-impacts-Gui::TextField/Property/text");
	try {
		_error.addVariable("s", _event.getParameter("s"));
	} catch (Throwable _t) {
		_error.addVariable("s", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	private void handleImpact(lu.uni.democles.runtime.Event e, lu.uni.democles.runtime.Property p) {
		set(p, eval_ep(e, p));
	}
	protected java.lang.Object evalQuery(lu.uni.democles.runtime.Property p) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) return p.newVal;

if (p.isEvaluating()) throw new lu.uni.democles.runtime.ModificationCycleException();

p.setEvaluating(true);
java.lang.Object o = null;


		if ("text".equals(p.entityName)) {
	o = __text_eval();
	set(p, o);
}

		if (o instanceof lu.uni.democles.runtime.Instance) {
	((lu.uni.democles.runtime.Instance)o).initProps();
} else if (o instanceof lu.uni.democles.runtime.OCLCollection) {
	for (java.util.Iterator iter = ((lu.uni.democles.runtime.OCLCollection)o).getValues().iterator(); iter.hasNext();) {
		java.lang.Object entry = iter.next();
		if (entry instanceof lu.uni.democles.runtime.Instance) {
			((lu.uni.democles.runtime.Instance)entry).initProps();
		}
	}
}
p.setEvaluating(false);
return o;


	}
	protected void set(lu.uni.democles.runtime.Property p, java.lang.Object v) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) {
	throw new lu.uni.democles.runtime.MultipleModificationException(p.toString());
}
p.newVal = v;
		super.set(p, v);
	}
	protected void updateVal(lu.uni.democles.runtime.Property p) {
		if ("text".equals(p.entityName)) {
	if (this._p_text.newVal != lu.uni.democles.runtime.Entity.nullObject) {
		java.lang.Object previousOldVal = this._p_text.oldVal;
		this._p_text.oldVal = this._p_text.newVal;
		lu.uni.democles.runtime.Instance.epDebugPropertyValueChanged(this, this._p_text, previousOldVal, this._p_text.newVal);
		this.notifyPropertyChangeListeners(p);
	}
}
	}
	public static TextField newWithValues(java.util.HashMap values) {
		TextField res = new TextField();
res.initialValues = new java.util.HashMap(values);
res.initProps();
return res;
	}
	protected java.lang.Object eval_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final java.lang.String paramName, final int _link) {
		
		return null;

	}
	protected void resetNewVal() {
		this._p_text.newVal = lu.uni.democles.runtime.Entity.nullObject;
	}
	public static void main(String[] args) {
	}
}
