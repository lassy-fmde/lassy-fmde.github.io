package generated.BrowserModel;

public class History extends lu.uni.democles.runtime.Instance {
	private lu.uni.democles.runtime.Event _e_currentUrlChanged = new lu.uni.democles.runtime.Event(this, "currentUrlChanged", "History", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] {  });
	private lu.uni.democles.runtime.Event _e_back = new lu.uni.democles.runtime.Event(this, "back", "History", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.BrowserModel.History", "currentUrlChanged", new java.lang.String[] {"currentPosition"}) });
	private lu.uni.democles.runtime.Event _e_addUrl = new lu.uni.democles.runtime.Event(this, "addUrl", "History", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.BrowserModel.History", "currentUrlChanged", new java.lang.String[] {"currentPosition"}) });
	private lu.uni.democles.runtime.Property _p_currentUrlIndex = new lu.uni.democles.runtime.Property(this, "currentUrlIndex", "History", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_forward = new lu.uni.democles.runtime.Event(this, "forward", "History", new lu.uni.democles.runtime.ParentLink[] {  }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(true, "", "generated.BrowserModel.History", "currentUrlChanged", new java.lang.String[] {"currentPosition"}) });
	private lu.uni.democles.runtime.Property _p_urls = new lu.uni.democles.runtime.Property(this, "urls", "History", "Local", false, false, null, "orderedSet");
	protected void attachProperties(lu.uni.democles.runtime.Event e) {
		// Set Attached Properties:


		// Set Attached Properties:
if ("back".equals(e.entityName)) {
	e.attachProperty("History_urls", this._p_urls.evalInContainer());
	e.attachProperty("History_currentUrlIndex", this._p_currentUrlIndex.evalInContainer().getValues().iterator().next());
}


		// Set Attached Properties:
if ("forward".equals(e.entityName)) {
	e.attachProperty("History_currentUrlIndex", this._p_currentUrlIndex.evalInContainer().getValues().iterator().next());
	e.attachProperty("History_urls", this._p_urls.evalInContainer());
}


	}
	private java.lang.Object eval_ep(final lu.uni.democles.runtime.Event e, final lu.uni.democles.runtime.Property p) {
		if (p.entityName.equals(this._p_currentUrlIndex.entityName) && e.entityName.equals(this._e_forward.entityName)) {
	return _forward_currentUrlIndex_eval(e);
}
		if (p.entityName.equals(this._p_currentUrlIndex.entityName) && e.entityName.equals(this._e_back.entityName)) {
	return _back_currentUrlIndex_eval(e);
}
		if (p.entityName.equals(this._p_urls.entityName) && e.entityName.equals(this._e_addUrl.entityName)) {
	return _addUrl_urls_eval(e);
}
		if (p.entityName.equals(this._p_currentUrlIndex.entityName) && e.entityName.equals(this._e_addUrl.entityName)) {
	return _addUrl_currentUrlIndex_eval(e);
}
		return null;

	}
	private java.lang.Object _back_currentUrlIndex_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return new java.lang.Integer((((int)((java.lang.Integer)_event.getAttachedProperty("History_currentUrlIndex")).intValue()) - 1));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("IMPACTS|BrowserModel::History/Event/back-impacts-BrowserModel::History/Property/currentUrlIndex");
	try {
		_error.addVariable("urls", _event.getAttachedProperty("History_urls"));
	} catch (Throwable _t) {
		_error.addVariable("urls", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("currentUrlIndex", _event.getAttachedProperty("History_currentUrlIndex"));
	} catch (Throwable _t) {
		_error.addVariable("currentUrlIndex", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	public History() {
		super("generated.BrowserModel.History", new java.lang.String[] {  });

	}
	protected java.lang.Object evalQuery(lu.uni.democles.runtime.Property p) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) return p.newVal;

if (p.isEvaluating()) throw new lu.uni.democles.runtime.ModificationCycleException();

p.setEvaluating(true);
java.lang.Object o = null;


		if ("urls".equals(p.entityName)) {
	o = __urls_eval();
	set(p, o);
}

		if ("currentUrlIndex".equals(p.entityName)) {
	o = __currentUrlIndex_eval();
	set(p, o);
}

		if (o instanceof lu.uni.democles.runtime.Instance) {
	((lu.uni.democles.runtime.Instance)o).initProps();
} else if (o instanceof lu.uni.democles.runtime.OCLCollection) {
	for (java.util.Iterator iter = ((lu.uni.democles.runtime.OCLCollection)o).getValues().iterator(); iter.hasNext();) {
		java.lang.Object entry = iter.next();
		if (entry instanceof lu.uni.democles.runtime.Instance) {
			((lu.uni.democles.runtime.Instance)entry).initProps();
		}
	}
}
p.setEvaluating(false);
return o;


	}
	public static History newWithValues(java.util.HashMap values) {
		History res = new History();
res.initialValues = new java.util.HashMap(values);
res.initProps();
return res;
	}
	public static void main(String[] args) {
	}
	private java.lang.Object __currentUrlIndex_eval() {
		try {
	return new java.lang.Integer(1);

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PROPERTY|BrowserModel::History/Property/currentUrlIndex");
	throw _error;
}

	}
	protected java.lang.Object eval_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse, final java.lang.String _paramName) {
		
		return null;

	}
	protected void resetNewVal() {
		this._p_urls.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_currentUrlIndex.newVal = lu.uni.democles.runtime.Entity.nullObject;
	}
	private void handleImpact(lu.uni.democles.runtime.Event e, lu.uni.democles.runtime.Property p) {
		set(p, eval_ep(e, p));
	}
	private java.lang.Object _addUrl_currentUrlIndex_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return new java.lang.Integer((((int)((java.lang.Integer)((lu.uni.democles.runtime.Property)generated.BrowserModel.History.this.getEntity("currentUrlIndex")).evalInContainer().getValues().iterator().next()).intValue()) + 1));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("IMPACTS|BrowserModel::History/Event/addUrl-impacts-BrowserModel::History/Property/currentUrlIndex");
	try {
		_error.addVariable("url", _event.getParameter("url"));
	} catch (Throwable _t) {
		_error.addVariable("url", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	protected void doModify(lu.uni.democles.runtime.Event event) {
		if ("addUrl".equals(event.entityName)) {
	handleImpact(event, this._p_urls);
}
if ("back".equals(event.entityName)) {
	handleImpact(event, this._p_currentUrlIndex);
}
if ("forward".equals(event.entityName)) {
	handleImpact(event, this._p_currentUrlIndex);
}
if ("addUrl".equals(event.entityName)) {
	handleImpact(event, this._p_currentUrlIndex);
}

	}
	protected void updateValues(lu.uni.democles.runtime.Event event) {
		if (event.entityName.equals("forward")) {
	updateVal(this._p_currentUrlIndex);
}

		if (event.entityName.equals("back")) {
	updateVal(this._p_currentUrlIndex);
}

		if (event.entityName.equals("addUrl")) {
	updateVal(this._p_urls);
}

		if (event.entityName.equals("addUrl")) {
	updateVal(this._p_currentUrlIndex);
}

	}
	protected void set(lu.uni.democles.runtime.Property p, java.lang.Object v) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) {
	throw new lu.uni.democles.runtime.MultipleModificationException(p.toString());
}
p.newVal = v;
		super.set(p, v);
	}
	private java.lang.Object __urls_eval() {
		try {
	return new lu.uni.democles.runtime.OCLOrderedSet(new Object[] {});

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PROPERTY|BrowserModel::History/Property/urls");
	throw _error;
}

	}
	protected java.lang.Object eval_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final java.lang.String paramName, final int _link) {
		
		if (e1.entityName.equals("addUrl") && e2.entityName.equals("currentUrlChanged") && linkProperty == null && paramName.equals("currentPosition")) {
try {
	return (generated.BrowserModel.HistoryPosition.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "url", ((java.lang.String)e1.getParameter("url")), "isLastEntry", new java.lang.Boolean(true), "isFirstEntry", new java.lang.Boolean(false) }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PARAMETER_MAPPING|BrowserModel::History/Event/addUrl$eventChildLink,Local,currentUrlChanged$currentPosition");
	try {
		_error.addVariable("url", e1.getParameter("url"));
	} catch (Throwable _t) {
		_error.addVariable("url", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("back") && e2.entityName.equals("currentUrlChanged") && linkProperty == null && paramName.equals("currentPosition")) {
try {
	return ((generated.BrowserModel.HistoryPosition)new lu.uni.democles.runtime.Function() {
	public Object _result() {
		final int v_newIndex = (((int)((java.lang.Integer)e1.getAttachedProperty("History_currentUrlIndex")).intValue()) - 1);
		return _asObject((generated.BrowserModel.HistoryPosition.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "url", (((java.lang.String)((lu.uni.democles.runtime.OCLOrderedSet)e1.getAttachedProperty("History_urls")).at(v_newIndex))), "isLastEntry", new java.lang.Boolean(false), "isFirstEntry", new java.lang.Boolean((v_newIndex <= 1)) })))));
	}
}._result());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PARAMETER_MAPPING|BrowserModel::History/Event/back$eventChildLink,Local,currentUrlChanged$currentPosition");
	try {
		_error.addVariable("urls", e1.getAttachedProperty("History_urls"));
	} catch (Throwable _t) {
		_error.addVariable("urls", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("currentUrlIndex", e1.getAttachedProperty("History_currentUrlIndex"));
	} catch (Throwable _t) {
		_error.addVariable("currentUrlIndex", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (e1.entityName.equals("forward") && e2.entityName.equals("currentUrlChanged") && linkProperty == null && paramName.equals("currentPosition")) {
try {
	return ((generated.BrowserModel.HistoryPosition)new lu.uni.democles.runtime.Function() {
	public Object _result() {
		final int v_newIndex = (((int)((java.lang.Integer)e1.getAttachedProperty("History_currentUrlIndex")).intValue()) + 1);
		return _asObject((generated.BrowserModel.HistoryPosition.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "url", (((java.lang.String)((lu.uni.democles.runtime.OCLOrderedSet)e1.getAttachedProperty("History_urls")).at(v_newIndex))), "isLastEntry", new java.lang.Boolean((v_newIndex >= (((lu.uni.democles.runtime.OCLOrderedSet)e1.getAttachedProperty("History_urls")).size()))), "isFirstEntry", new java.lang.Boolean(false) })))));
	}
}._result());

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PARAMETER_MAPPING|BrowserModel::History/Event/forward$eventChildLink,Local,currentUrlChanged$currentPosition");
	try {
		_error.addVariable("currentUrlIndex", e1.getAttachedProperty("History_currentUrlIndex"));
	} catch (Throwable _t) {
		_error.addVariable("currentUrlIndex", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("urls", e1.getAttachedProperty("History_urls"));
	} catch (Throwable _t) {
		_error.addVariable("urls", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		return null;

	}
	private java.lang.Object _addUrl_urls_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return (((lu.uni.democles.runtime.OCLOrderedSet)((lu.uni.democles.runtime.Property)generated.BrowserModel.History.this.getEntity("urls")).evalInContainer()).append(((java.lang.String)_event.getParameter("url"))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("IMPACTS|BrowserModel::History/Event/addUrl-impacts-BrowserModel::History/Property/urls");
	try {
		_error.addVariable("url", _event.getParameter("url"));
	} catch (Throwable _t) {
		_error.addVariable("url", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	public void initProps() {
		if (this.isInitialized()) return;

		this._p_urls.oldVal = this.initialValues.containsKey("urls") ? this.initialValues.get("urls") : eval_p(this._p_urls);
this._p_urls.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_urls, this._p_urls.oldVal);

		this._p_currentUrlIndex.oldVal = this.initialValues.containsKey("currentUrlIndex") ? this.initialValues.get("currentUrlIndex") : eval_p(this._p_currentUrlIndex).getValues().iterator().next();
this._p_currentUrlIndex.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_currentUrlIndex, this._p_currentUrlIndex.oldVal);

		this.setInitialized();
this.initialValues = new java.util.HashMap();


	}
	private java.lang.Object _forward_currentUrlIndex_eval(final lu.uni.democles.runtime.Event _event) {
		try {
	return new java.lang.Integer((((int)((java.lang.Integer)_event.getAttachedProperty("History_currentUrlIndex")).intValue()) + 1));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("IMPACTS|BrowserModel::History/Event/forward-impacts-BrowserModel::History/Property/currentUrlIndex");
	try {
		_error.addVariable("currentUrlIndex", _event.getAttachedProperty("History_currentUrlIndex"));
	} catch (Throwable _t) {
		_error.addVariable("currentUrlIndex", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("urls", _event.getAttachedProperty("History_urls"));
	} catch (Throwable _t) {
		_error.addVariable("urls", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}


	}
	protected void updateVal(lu.uni.democles.runtime.Property p) {
		if ("urls".equals(p.entityName)) {
	if (this._p_urls.newVal != lu.uni.democles.runtime.Entity.nullObject) {
		java.lang.Object previousOldVal = this._p_urls.oldVal;
		this._p_urls.oldVal = this._p_urls.newVal;
		lu.uni.democles.runtime.Instance.epDebugPropertyValueChanged(this, this._p_urls, previousOldVal, this._p_urls.newVal);
		this.notifyPropertyChangeListeners(p);
	}
}
		if ("currentUrlIndex".equals(p.entityName)) {
	if (this._p_currentUrlIndex.newVal != lu.uni.democles.runtime.Entity.nullObject) {
		java.lang.Object previousOldVal = this._p_currentUrlIndex.oldVal;
		this._p_currentUrlIndex.oldVal = this._p_currentUrlIndex.newVal;
		lu.uni.democles.runtime.Instance.epDebugPropertyValueChanged(this, this._p_currentUrlIndex, previousOldVal, this._p_currentUrlIndex.newVal);
		this.notifyPropertyChangeListeners(p);
	}
}
	}
}
