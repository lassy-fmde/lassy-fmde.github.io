package generated.BrowserModel;

public class HistoryPosition extends lu.uni.democles.runtime.Instance {
	private lu.uni.democles.runtime.Property _p_url = new lu.uni.democles.runtime.Property(this, "url", "HistoryPosition", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_isFirstEntry = new lu.uni.democles.runtime.Property(this, "isFirstEntry", "HistoryPosition", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_isLastEntry = new lu.uni.democles.runtime.Property(this, "isLastEntry", "HistoryPosition", "Local", false, false, null, "single");
	private java.lang.Object __isFirstEntry_eval() {
		try {
	return new java.lang.Boolean(true);

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PROPERTY|BrowserModel::HistoryPosition/Property/isFirstEntry");
	throw _error;
}

	}
	public void initProps() {
		if (this.isInitialized()) return;

		this._p_isFirstEntry.oldVal = this.initialValues.containsKey("isFirstEntry") ? this.initialValues.get("isFirstEntry") : eval_p(this._p_isFirstEntry).getValues().iterator().next();
this._p_isFirstEntry.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_isFirstEntry, this._p_isFirstEntry.oldVal);

		this._p_isLastEntry.oldVal = this.initialValues.containsKey("isLastEntry") ? this.initialValues.get("isLastEntry") : eval_p(this._p_isLastEntry).getValues().iterator().next();
this._p_isLastEntry.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_isLastEntry, this._p_isLastEntry.oldVal);

		this._p_url.oldVal = this.initialValues.containsKey("url") ? this.initialValues.get("url") : eval_p(this._p_url).getValues().iterator().next();
this._p_url.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_url, this._p_url.oldVal);

		this.setInitialized();
this.initialValues = new java.util.HashMap();


	}
	private java.lang.Object __isLastEntry_eval() {
		try {
	return new java.lang.Boolean(true);

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PROPERTY|BrowserModel::HistoryPosition/Property/isLastEntry");
	throw _error;
}

	}
	protected void set(lu.uni.democles.runtime.Property p, java.lang.Object v) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) {
	throw new lu.uni.democles.runtime.MultipleModificationException(p.toString());
}
p.newVal = v;
		super.set(p, v);
	}
	protected java.lang.Object evalQuery(lu.uni.democles.runtime.Property p) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) return p.newVal;

if (p.isEvaluating()) throw new lu.uni.democles.runtime.ModificationCycleException();

p.setEvaluating(true);
java.lang.Object o = null;


		if ("isFirstEntry".equals(p.entityName)) {
	o = __isFirstEntry_eval();
	set(p, o);
}

		if ("isLastEntry".equals(p.entityName)) {
	o = __isLastEntry_eval();
	set(p, o);
}

		if ("url".equals(p.entityName)) {
	o = __url_eval();
	set(p, o);
}

		if (o instanceof lu.uni.democles.runtime.Instance) {
	((lu.uni.democles.runtime.Instance)o).initProps();
} else if (o instanceof lu.uni.democles.runtime.OCLCollection) {
	for (java.util.Iterator iter = ((lu.uni.democles.runtime.OCLCollection)o).getValues().iterator(); iter.hasNext();) {
		java.lang.Object entry = iter.next();
		if (entry instanceof lu.uni.democles.runtime.Instance) {
			((lu.uni.democles.runtime.Instance)entry).initProps();
		}
	}
}
p.setEvaluating(false);
return o;


	}
	protected void updateVal(lu.uni.democles.runtime.Property p) {
		if ("isFirstEntry".equals(p.entityName)) {
	if (this._p_isFirstEntry.newVal != lu.uni.democles.runtime.Entity.nullObject) {
		java.lang.Object previousOldVal = this._p_isFirstEntry.oldVal;
		this._p_isFirstEntry.oldVal = this._p_isFirstEntry.newVal;
		lu.uni.democles.runtime.Instance.epDebugPropertyValueChanged(this, this._p_isFirstEntry, previousOldVal, this._p_isFirstEntry.newVal);
		this.notifyPropertyChangeListeners(p);
	}
}
		if ("isLastEntry".equals(p.entityName)) {
	if (this._p_isLastEntry.newVal != lu.uni.democles.runtime.Entity.nullObject) {
		java.lang.Object previousOldVal = this._p_isLastEntry.oldVal;
		this._p_isLastEntry.oldVal = this._p_isLastEntry.newVal;
		lu.uni.democles.runtime.Instance.epDebugPropertyValueChanged(this, this._p_isLastEntry, previousOldVal, this._p_isLastEntry.newVal);
		this.notifyPropertyChangeListeners(p);
	}
}
		if ("url".equals(p.entityName)) {
	if (this._p_url.newVal != lu.uni.democles.runtime.Entity.nullObject) {
		java.lang.Object previousOldVal = this._p_url.oldVal;
		this._p_url.oldVal = this._p_url.newVal;
		lu.uni.democles.runtime.Instance.epDebugPropertyValueChanged(this, this._p_url, previousOldVal, this._p_url.newVal);
		this.notifyPropertyChangeListeners(p);
	}
}
	}
	private java.lang.Object __url_eval() {
		try {
	return "";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PROPERTY|BrowserModel::HistoryPosition/Property/url");
	throw _error;
}

	}
	public HistoryPosition() {
		super("generated.BrowserModel.HistoryPosition", new java.lang.String[] {  });

	}
	protected void resetNewVal() {
		this._p_isFirstEntry.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_isLastEntry.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_url.newVal = lu.uni.democles.runtime.Entity.nullObject;
	}
	public static void main(String[] args) {
	}
	public static HistoryPosition newWithValues(java.util.HashMap values) {
		HistoryPosition res = new HistoryPosition();
res.initialValues = new java.util.HashMap(values);
res.initProps();
return res;
	}
}
