package generated.Application;

public class Main extends lu.uni.democles.runtime.Instance {
	private lu.uni.democles.runtime.Event _e_urlVisitRequested = new lu.uni.democles.runtime.Event(this, "urlVisitRequested", "Main", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.BrowserGui.BrowserWindow", "browserWindow", "urlVisitRequested", new java.lang.String[] {"url"}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "history", "generated.BrowserModel.History", "addUrl", new java.lang.String[] {"url"}) });
	private lu.uni.democles.runtime.Property _p_history = new lu.uni.democles.runtime.Property(this, "history", "Main", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Property _p_browserWindow = new lu.uni.democles.runtime.Property(this, "browserWindow", "Main", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_forwardButtonClicked = new lu.uni.democles.runtime.Event(this, "forwardButtonClicked", "Main", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.BrowserGui.BrowserWindow", "browserWindow", "forwardButtonClicked", new java.lang.String[] {"content"}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "history", "generated.BrowserModel.History", "forward", new java.lang.String[] {}) });
	private lu.uni.democles.runtime.Event _e_history_currentUrlChanged = new lu.uni.democles.runtime.Event(this, "history_currentUrlChanged", "Main", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.BrowserModel.History", "history", "currentUrlChanged", new java.lang.String[] {"currentPosition"}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "browserWindow", "generated.BrowserGui.BrowserWindow", "setState", new java.lang.String[] {"windowState"}) });
	private lu.uni.democles.runtime.Property _p_initialUrl = new lu.uni.democles.runtime.Property(this, "initialUrl", "Main", "Local", false, false, null, "single");
	private lu.uni.democles.runtime.Event _e_backbuttonClicked = new lu.uni.democles.runtime.Event(this, "backbuttonClicked", "Main", new lu.uni.democles.runtime.ParentLink[] { new lu.uni.democles.runtime.ParentLink(false, "generated.BrowserGui.BrowserWindow", "browserWindow", "backbuttonClicked", new java.lang.String[] {"content"}) }, new lu.uni.democles.runtime.ChildLink[] { new lu.uni.democles.runtime.ChildLink(false, "history", "generated.BrowserModel.History", "back", new java.lang.String[] {}) });
	protected java.lang.Object eval_e2e1(final lu.uni.democles.runtime.Event _parent, final lu.uni.democles.runtime.Event _event, final lu.uni.democles.runtime.Property _linkProperty, final boolean _inverse, final java.lang.String _paramName) {
		if (_parent.entityName.equals("urlVisitRequested") && _event.entityName.equals("urlVisitRequested") && _linkProperty.entityName.equals("browserWindow") && _inverse == false && _paramName.equals("url")) {
try {
	return ((java.lang.String)_parent.getParameter("url"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PARAMETER_MAPPING|Application::Main/Event/urlVisitRequested$eventParentLink,Forward,browserWindow,BrowserGui::BrowserWindow,urlVisitRequested$url");
	try {
		_error.addVariable("url", _parent.getParameter("url"));
	} catch (Throwable _t) {
		_error.addVariable("url", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (_parent.entityName.equals("backbuttonClicked") && _event.entityName.equals("backbuttonClicked") && _linkProperty.entityName.equals("browserWindow") && _inverse == false && _paramName.equals("content")) {
try {
	return ((java.lang.Object)_parent.getParameter("content"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PARAMETER_MAPPING|Application::Main/Event/backbuttonClicked$eventParentLink,Forward,browserWindow,BrowserGui::BrowserWindow,backbuttonClicked$content");
	try {
		_error.addVariable("content", _parent.getParameter("content"));
	} catch (Throwable _t) {
		_error.addVariable("content", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (_parent.entityName.equals("forwardButtonClicked") && _event.entityName.equals("forwardButtonClicked") && _linkProperty.entityName.equals("browserWindow") && _inverse == false && _paramName.equals("content")) {
try {
	return ((java.lang.Object)_parent.getParameter("content"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PARAMETER_MAPPING|Application::Main/Event/forwardButtonClicked$eventParentLink,Forward,browserWindow,BrowserGui::BrowserWindow,forwardButtonClicked$content");
	try {
		_error.addVariable("content", _parent.getParameter("content"));
	} catch (Throwable _t) {
		_error.addVariable("content", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		if (_parent.entityName.equals("currentUrlChanged") && _event.entityName.equals("history_currentUrlChanged") && _linkProperty.entityName.equals("history") && _inverse == false && _paramName.equals("currentPosition")) {
try {
	return ((generated.BrowserModel.HistoryPosition)_parent.getParameter("currentPosition"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PARAMETER_MAPPING|Application::Main/Event/history_currentUrlChanged$eventParentLink,Forward,history,BrowserModel::History,currentUrlChanged$currentPosition");
	try {
		_error.addVariable("currentPosition", _parent.getParameter("currentPosition"));
	} catch (Throwable _t) {
		_error.addVariable("currentPosition", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		return null;

	}
	protected void attachProperties(lu.uni.democles.runtime.Event e) {
		// Set Attached Properties:


		// Set Attached Properties:
if ("history_currentUrlChanged".equals(e.entityName)) {
	e.attachProperty("Main_history", this._p_history.evalInContainer().getValues().iterator().next());
}


	}
	protected void updateValues(lu.uni.democles.runtime.Event event) {
	}
	public void initProps() {
		if (this.isInitialized()) return;

		this._p_browserWindow.oldVal = this.initialValues.containsKey("browserWindow") ? this.initialValues.get("browserWindow") : eval_p(this._p_browserWindow).getValues().iterator().next();
this._p_browserWindow.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_browserWindow, this._p_browserWindow.oldVal);

		this._p_history.oldVal = this.initialValues.containsKey("history") ? this.initialValues.get("history") : eval_p(this._p_history).getValues().iterator().next();
this._p_history.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_history, this._p_history.oldVal);

		this._p_initialUrl.oldVal = this.initialValues.containsKey("initialUrl") ? this.initialValues.get("initialUrl") : eval_p(this._p_initialUrl).getValues().iterator().next();
this._p_initialUrl.newVal = lu.uni.democles.runtime.Entity.nullObject;
lu.uni.democles.runtime.Instance.epDebugPropertyInitialized(this, this._p_initialUrl, this._p_initialUrl.oldVal);

		this.setInitialized();
this.initialValues = new java.util.HashMap();


	}
	protected java.lang.Object evalQuery(lu.uni.democles.runtime.Property p) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) return p.newVal;

if (p.isEvaluating()) throw new lu.uni.democles.runtime.ModificationCycleException();

p.setEvaluating(true);
java.lang.Object o = null;


		if ("browserWindow".equals(p.entityName)) {
	o = __browserWindow_eval();
	set(p, o);
}

		if ("history".equals(p.entityName)) {
	o = __history_eval();
	set(p, o);
}

		if ("initialUrl".equals(p.entityName)) {
	o = __initialUrl_eval();
	set(p, o);
}

		if (o instanceof lu.uni.democles.runtime.Instance) {
	((lu.uni.democles.runtime.Instance)o).initProps();
} else if (o instanceof lu.uni.democles.runtime.OCLCollection) {
	for (java.util.Iterator iter = ((lu.uni.democles.runtime.OCLCollection)o).getValues().iterator(); iter.hasNext();) {
		java.lang.Object entry = iter.next();
		if (entry instanceof lu.uni.democles.runtime.Instance) {
			((lu.uni.democles.runtime.Instance)entry).initProps();
		}
	}
}
p.setEvaluating(false);
return o;


	}
	protected void set(lu.uni.democles.runtime.Property p, java.lang.Object v) {
		if (p.newVal != lu.uni.democles.runtime.Entity.nullObject) {
	throw new lu.uni.democles.runtime.MultipleModificationException(p.toString());
}
p.newVal = v;
		super.set(p, v);
	}
	protected void updateVal(lu.uni.democles.runtime.Property p) {
		if ("browserWindow".equals(p.entityName)) {
	if (this._p_browserWindow.newVal != lu.uni.democles.runtime.Entity.nullObject) {
		java.lang.Object previousOldVal = this._p_browserWindow.oldVal;
		this._p_browserWindow.oldVal = this._p_browserWindow.newVal;
		lu.uni.democles.runtime.Instance.epDebugPropertyValueChanged(this, this._p_browserWindow, previousOldVal, this._p_browserWindow.newVal);
		this.notifyPropertyChangeListeners(p);
	}
}
		if ("history".equals(p.entityName)) {
	if (this._p_history.newVal != lu.uni.democles.runtime.Entity.nullObject) {
		java.lang.Object previousOldVal = this._p_history.oldVal;
		this._p_history.oldVal = this._p_history.newVal;
		lu.uni.democles.runtime.Instance.epDebugPropertyValueChanged(this, this._p_history, previousOldVal, this._p_history.newVal);
		this.notifyPropertyChangeListeners(p);
	}
}
		if ("initialUrl".equals(p.entityName)) {
	if (this._p_initialUrl.newVal != lu.uni.democles.runtime.Entity.nullObject) {
		java.lang.Object previousOldVal = this._p_initialUrl.oldVal;
		this._p_initialUrl.oldVal = this._p_initialUrl.newVal;
		lu.uni.democles.runtime.Instance.epDebugPropertyValueChanged(this, this._p_initialUrl, previousOldVal, this._p_initialUrl.newVal);
		this.notifyPropertyChangeListeners(p);
	}
}
	}
	private java.lang.Object __browserWindow_eval() {
		try {
	return (generated.BrowserGui.BrowserWindow.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "initialUrl", (((java.lang.String)((lu.uni.democles.runtime.OCLOrderedSet)((lu.uni.democles.runtime.Property)((generated.BrowserModel.History)((lu.uni.democles.runtime.Property)generated.Application.Main.this.getEntity("history")).evalInContainer().getValues().iterator().next()).getEntity("urls")).evalInContainer()).first())) }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PROPERTY|Application::Main/Property/browserWindow");
	throw _error;
}

	}
	private java.lang.Object __initialUrl_eval() {
		try {
	return "http://www.google.com";

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PROPERTY|Application::Main/Property/initialUrl");
	throw _error;
}

	}
	private java.lang.Object __history_eval() {
		try {
	return (generated.BrowserModel.History.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "urls", new lu.uni.democles.runtime.OCLOrderedSet(new Object[] {((java.lang.String)((lu.uni.democles.runtime.Property)generated.Application.Main.this.getEntity("initialUrl")).evalInContainer().getValues().iterator().next())}) }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PROPERTY|Application::Main/Property/history");
	throw _error;
}

	}
	public static Main newWithValues(java.util.HashMap values) {
		Main res = new Main();
res.initialValues = new java.util.HashMap(values);
res.initProps();
return res;
	}
	protected java.lang.Object eval_e1e2(final lu.uni.democles.runtime.Event e1, final lu.uni.democles.runtime.Event e2, final lu.uni.democles.runtime.Property linkProperty, final java.lang.String paramName, final int _link) {
		if (e1.entityName.equals("urlVisitRequested") && e2.entityName.equals("addUrl") && linkProperty.entityName.equals("history") && paramName.equals("url")) {
try {
	return ((java.lang.String)e1.getParameter("url"));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PARAMETER_MAPPING|Application::Main/Event/urlVisitRequested$eventChildLink,Forward,history,BrowserModel::History,addUrl$url");
	try {
		_error.addVariable("url", e1.getParameter("url"));
	} catch (Throwable _t) {
		_error.addVariable("url", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		
		if (e1.entityName.equals("history_currentUrlChanged") && e2.entityName.equals("setState") && linkProperty.entityName.equals("browserWindow") && paramName.equals("windowState")) {
try {
	return (generated.BrowserGui.BrowserWindowState.newWithValues(((java.util.HashMap)lu.uni.democles.runtime.Function._createMap(new Object[] { "canGoForward", new java.lang.Boolean((!((boolean)((java.lang.Boolean)((lu.uni.democles.runtime.Property)((generated.BrowserModel.HistoryPosition)e1.getParameter("currentPosition")).getEntity("isLastEntry")).evalInContainer().getValues().iterator().next()).booleanValue()))), "canGoBackward", new java.lang.Boolean((!((boolean)((java.lang.Boolean)((lu.uni.democles.runtime.Property)((generated.BrowserModel.HistoryPosition)e1.getParameter("currentPosition")).getEntity("isFirstEntry")).evalInContainer().getValues().iterator().next()).booleanValue()))), "currentUrl", ((java.lang.String)((lu.uni.democles.runtime.Property)((generated.BrowserModel.HistoryPosition)e1.getParameter("currentPosition")).getEntity("url")).evalInContainer().getValues().iterator().next()) }))));

} catch (java.lang.Exception _exception) {
	lu.uni.democles.runtime.OCLError _error = new lu.uni.democles.runtime.OCLError(_exception);
	_error.setContextId("PARAMETER_MAPPING|Application::Main/Event/history_currentUrlChanged$eventChildLink,Forward,browserWindow,BrowserGui::BrowserWindow,setState$windowState");
	try {
		_error.addVariable("history", e1.getAttachedProperty("Main_history"));
	} catch (Throwable _t) {
		_error.addVariable("history", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("currentPosition", e1.getParameter("currentPosition"));
	} catch (Throwable _t) {
		_error.addVariable("currentPosition", "<Error obtaining value: " + _t.getMessage() + ">");	}
	try {
		_error.addVariable("_linkNr", new java.lang.Integer(_link));
	} catch (Throwable _t) {
		_error.addVariable("_linkNr", "<Error obtaining value: " + _t.getMessage() + ">");	}
	throw _error;
}
}

		return null;

	}
	protected void resetNewVal() {
		this._p_browserWindow.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_history.newVal = lu.uni.democles.runtime.Entity.nullObject;
		this._p_initialUrl.newVal = lu.uni.democles.runtime.Entity.nullObject;
	}
	public static void main(String[] args) {
		Main initialMain = new Main();

		initialMain.initProps();
	}
	public Main() {
		super("generated.Application.Main", new java.lang.String[] {  });

	}
}
