package Gui;

import org.eclipse.swt.widgets.Composite;

/**
 * Implementors should realize widget on createControl, then
 * set widget attributes to those of instance and register listeners.
 * They should also register a DisposeListener to clear their widget
 * reference and unregister listeners.
 * @author cglodt
 *
 */
public interface IControlWrapper {

	/** Will be called within display thread */
	public void createControl(Composite parent);
}
