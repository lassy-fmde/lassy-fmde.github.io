package Gui;

import java.util.HashMap;
import java.util.Map;

import lu.uni.democles.runtime.BindingUtils;
import lu.uni.democles.runtime.Event;
import lu.uni.democles.runtime.IBinding;
import lu.uni.democles.runtime.IInstance;
import lu.uni.democles.runtime.Property;

import org.eclipse.swt.SWT;
import org.eclipse.swt.browser.Browser;
import org.eclipse.swt.browser.LocationAdapter;
import org.eclipse.swt.browser.LocationEvent;
import org.eclipse.swt.browser.ProgressAdapter;
import org.eclipse.swt.browser.ProgressEvent;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.widgets.Composite;

public class HTMLViewerBinding implements IBinding, IControlWrapper {

	private final IInstance instance;
	private Browser browser = null;

	public HTMLViewerBinding(final IInstance instance) {
		this.instance = instance;
		
		BindingUtils.initFromInstance(this, instance);
	}
	
	public IInstance getInstance() {
		return this.instance;
	}

	public void onEvent(Event e, int sequenceNr) {
		if ("showError".equals(e.entityName)) {
			String url = (String)e.getParameter("url");
			String message = (String)e.getParameter("message");
			
			final String html = "<html><body><h1>Error loading <a href=\"" + url + "\">" + url + "</a></h1>" + message + "</body></html>";
			if (this.browser != null) {
				this.browser.getDisplay().asyncExec(new Runnable() {
					public void run() {
						browser.setText(html);
					}
				});
			}
		}
	}

	public void onPropertyChange(Property property, Object value) {
/*		if ("currentUrl".equals(property.entityName)) {
			Map params = new HashMap();
			params.put("url", value);
			try {
				this.editorPane.setPage((String)value);
			} catch (IOException e) {
				params.put("message", e.getMessage());
				BindingUtils.triggerEvent(this.instance, "pageLoadError", params);
			}
		}
*/		this.syncWidgetState();
	}

	private boolean isSettingUrl = false;

	private void syncWidgetState() {
		if (this.browser != null) {
			this.browser.getDisplay().asyncExec(new Runnable() {
				public void run() {
					isSettingUrl = true;
					browser.setUrl((String)getInstance().getProperty("currentUrl").getValue());
					isSettingUrl = false;
				}
			});
		}
	}
	
	public void createControl(Composite parent) {
		this.browser = new Browser(parent, SWT.NONE);

/*				Map parameters = new HashMap();
				parameters.put("url", e.getURL().toString());
				if (e.getEventType().equals(HyperlinkEvent.EventType.ENTERED)) {
					BindingUtils.triggerEvent(instance, "linkEntered", parameters);
				} else if (e.getEventType().equals(HyperlinkEvent.EventType.EXITED)) {
					BindingUtils.triggerEvent(instance, "linkExited", parameters);
				}
*/		
		this.browser.addLocationListener(new LocationAdapter() {
			public void changing(LocationEvent event) {
				if (isSettingUrl) return;
				
				if (event.location.equals("about:blank")) {
					event.doit = false;
					return;
				}
				
				Map parameters = new HashMap();
				parameters.put("url", event.location);
				BindingUtils.triggerEvent(instance, "linkClicked", parameters);
				event.doit = false;
			}			
		});
		
		this.browser.addProgressListener(new ProgressAdapter() {
			public void completed(ProgressEvent event) {
				Map parameters = new HashMap();
				parameters.put("url", browser.getUrl());
				BindingUtils.triggerEvent(getInstance(), "pageLoadFinished", parameters);
			}
		});
		
		this.browser.addDisposeListener(new DisposeListener() {
			public void widgetDisposed(DisposeEvent arg0) {
				browser = null;
			}
		});
		
/*		this.browser.addStatusTextListener(new StatusTextListener() {
			public void changed(StatusTextEvent event) {
				//System.out.println(event);
			}			
		});
		
		this.browser.addOpenWindowListener(new OpenWindowListener() {
			public void open(WindowEvent event) {
				//System.out.println(event);
			}
		});
*/		
		this.syncWidgetState();
	}
}
