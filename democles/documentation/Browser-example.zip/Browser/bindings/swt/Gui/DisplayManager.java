package Gui;

import java.util.HashSet;
import java.util.Set;

import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class DisplayManager {

	static private Display display = null;
	
	static private DisplayThread displayThread = null;
	
	static private class DisplayThread extends Thread {

		private Display display = null;
		
		private boolean disposed = false;
		
		public synchronized Display getDisplay() {
			if (this.display == null) {
				try {
					this.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			return this.display;
		}
		
		public synchronized void start() {
			this.setDaemon(false);
			super.start();
		}

		public void dispose() {
			this.disposed = true;
		}
		
		public void run() {
			synchronized(this) {
				this.display = new Display();
				this.notify();
			}
			
			while (!this.disposed) {				
				if (!display.readAndDispatch()) {
					display.sleep();
				}
			}
			
			if (!display.isDisposed()) {
				display.dispose();
			}
		}
	};

	static private Set shells = new HashSet();
	
	static synchronized public Shell createShell() {
		final Display display = getDisplay();
		final Shell[] resArray = new Shell[1];
		
		display.syncExec(new Runnable() {
			public void run() {
				resArray[0] = new Shell(display);
				resArray[0].addDisposeListener(new DisposeListener() {
					public void widgetDisposed(DisposeEvent event) {
						shells.remove(event.getSource());
						if (shells.isEmpty()) {
							displayThread.dispose();
						}
					}
				});
			}
		});
		Shell res = resArray[0];
		shells.add(res);	
		
		return res;
	}
	
	synchronized static private Display getDisplay() {
		if (displayThread == null) {
			
			displayThread = new DisplayThread();
			displayThread.start();
		}
		return displayThread.getDisplay();
	}
}
