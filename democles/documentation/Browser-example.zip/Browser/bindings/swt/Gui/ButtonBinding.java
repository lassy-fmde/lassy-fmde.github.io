package Gui;

import lu.uni.democles.runtime.BindingUtils;
import lu.uni.democles.runtime.Event;
import lu.uni.democles.runtime.IBinding;
import lu.uni.democles.runtime.IInstance;
import lu.uni.democles.runtime.Property;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;

public class ButtonBinding implements IBinding, IControlWrapper {

	private final IInstance instance;
	private Button button = null;
	
	private String labelText = null;
	private boolean enabled = true;

	public ButtonBinding(final IInstance instance) {
		this.instance = instance;
				
		BindingUtils.initFromInstance(this, instance);
	}
	
	public IInstance getInstance() {
		return this.instance;
	}

	public void onEvent(Event e, int sequenceNr) {
	}

	public void onPropertyChange(Property property, Object value) {
		this.syncWidgetState();
	}

	private void syncWidgetState() {
		if (this.button != null) {
			this.button.getDisplay().asyncExec(new Runnable() {
				public void run() {
					button.setText((String)getInstance().getProperty("label").getValue());
					button.setEnabled(((Boolean)getInstance().getProperty("enabled").getValue()).booleanValue());
				}
			});
		}
	}
	
	public void createControl(Composite parent) {
		this.button = new Button(parent, SWT.NONE);
		this.button.addDisposeListener(new DisposeListener() {
			public void widgetDisposed(DisposeEvent event) {
				button = null;
			}
		});
		
		this.button.addSelectionListener(new SelectionAdapter() {
			
			public void widgetSelected(SelectionEvent e) {
				BindingUtils.triggerEvent(instance, "execute");
			}
		});
		
		this.syncWidgetState();
	}
}
