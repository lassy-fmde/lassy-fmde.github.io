package Gui;

import java.util.Iterator;

import lu.uni.democles.runtime.BindingUtils;
import lu.uni.democles.runtime.Entity;
import lu.uni.democles.runtime.Event;
import lu.uni.democles.runtime.IBinding;
import lu.uni.democles.runtime.IInstance;
import lu.uni.democles.runtime.OCLSequence;
import lu.uni.democles.runtime.Property;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

public class WindowBinding implements IBinding {

	protected final IInstance instance;

	protected Shell shell;
	
	protected Composite toolbar;

	protected Composite widgetPanel;
	
	protected Label statusLabel;
	
	public WindowBinding(final IInstance instance) {
		this.instance = instance;

		this.shell = DisplayManager.createShell();
		this.shell.getDisplay().syncExec(new Runnable() {
			public void run() {
				//this.frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
				shell.setSize(400, 300);
				int x = shell.getDisplay().getBounds().width / 2 - shell.getBounds().width / 2;
				int y = shell.getDisplay().getBounds().height / 2 - shell.getBounds().height / 2;
				shell.setLocation(x, y);
				
				shell.setLayout(new GridLayout(1, true));
				//this.frame.setLocationRelativeTo(null);
				
				toolbar = new Composite(shell, SWT.NONE);
				toolbar.setLayoutData(new GridData(GridData.BEGINNING, GridData.BEGINNING, true, false));
				toolbar.setLayout(new RowLayout(SWT.HORIZONTAL));
				toolbar.setVisible(false);
				
				widgetPanel = new Composite(shell, SWT.BORDER);
//				this.widgetPanel.setLayout(new BoxLayout(this.widgetPanel, BoxLayout.Y_AXIS));
//				this.widgetPanel.setBorder(BorderFactory.createLoweredBevelBorder());
				widgetPanel.setLayoutData(new GridData(GridData.FILL_BOTH));
				widgetPanel.setLayout(new FillLayout());
				widgetPanel.setVisible(true);
				
				statusLabel = new Label(shell, SWT.NONE);
				statusLabel.setVisible(false);
				statusLabel.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

				shell.setVisible(true);
			}
		});
		
/*		this.frame.getContentPane().setLayout(new BorderLayout());
		this.frame.getContentPane().add(this.toolbar, BorderLayout.PAGE_START);
		this.frame.getContentPane().add(this.widgetPanel, BorderLayout.CENTER);
		this.frame.getContentPane().add(this.statusLabel, BorderLayout.PAGE_END);
*/		
		BindingUtils.initFromInstance(this, instance);

//		this.shell.setVisible(true);
	}
	
	public IInstance getInstance() {
		return this.instance;
	}
	
	public void onEvent(Event event, int sequenceNr) {
		if ("closed".equals(event.entityName)) {
			this.shell.close();
			this.shell.dispose();
		}
	}

	public void onPropertyChange(Property property, final Object value) {
		if ("title".equals(property.entityName)) {
			this.shell.getDisplay().asyncExec(new Runnable() {
				public void run() {
					shell.setText((String)value);
				}
			});
		}
		if ("widgets".equals(property.entityName)) {
			this.shell.getDisplay().syncExec(new Runnable() {
				public void run() {
					Control[] children = widgetPanel.getChildren();
					for (int i = 0; i < children.length; i++) {
						children[i].dispose();
					}
					
					OCLSequence seq = (OCLSequence)value;
					
					for (Iterator iterator = seq.getValues().iterator(); iterator.hasNext();) {
						IInstance widgetInstance = (IInstance)iterator.next();
						IBinding widgetBinding = widgetInstance.getBinding();
						if (widgetBinding == null) {
							throw new RuntimeException("Missing binding for " + widgetInstance);
						}
						
						if (widgetBinding instanceof IControlWrapper) {
							IControlWrapper w = (IControlWrapper)widgetBinding;
							w.createControl(widgetPanel);
						} else {
							throw new RuntimeException("Binding for " + widgetInstance + " does not implement IControlWrapper");
						}
					}

					widgetPanel.layout(true);
					shell.layout(true);
				}
			});
			
		}
		if ("toolbarWidgets".equals(property.entityName)) {
			this.shell.getDisplay().syncExec(new Runnable() {
				public void run() {
					Control[] children = toolbar.getChildren();
					for (int i = 0; i < children.length; i++) {
						children[i].dispose();
					}
					
					OCLSequence seq = (OCLSequence)value;
					
					for (Iterator iterator = seq.getValues().iterator(); iterator.hasNext();) {
						IInstance widgetInstance = (IInstance)iterator.next();
						IBinding widgetBinding = widgetInstance.getBinding();
						if (widgetBinding == null) {
							throw new RuntimeException("Missing binding for " + widgetInstance);
						}
						
						if (widgetBinding instanceof IControlWrapper) {
							IControlWrapper w = (IControlWrapper)widgetBinding;
							w.createControl(toolbar);
						} else {
							throw new RuntimeException("Binding for " + widgetInstance + " does not implement IControlWrapper");
						}
					}

					toolbar.layout(true);
					shell.layout(true);
					toolbar.setVisible(!seq.isEmpty());
				}
			});
		}
		if ("statusText".equals(property.entityName)) {
			this.shell.getDisplay().asyncExec(new Runnable() {
				public void run() {
					if (value.equals(Entity.nullObject) || value == null || ((String)value).length() == 0) {
						statusLabel.setVisible(false);
					} else {
						statusLabel.setText((String)value);
						statusLabel.setVisible(true);
					}
				}				
			});
		}
	}
}
