package Gui;

import java.util.HashMap;
import java.util.Map;

import lu.uni.democles.runtime.BindingUtils;
import lu.uni.democles.runtime.Event;
import lu.uni.democles.runtime.IBinding;
import lu.uni.democles.runtime.IInstance;
import lu.uni.democles.runtime.Property;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.FocusAdapter;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Text;

public class TextFieldBinding implements IBinding, IControlWrapper {

	private final IInstance instance;
	private Text textField = null;

	boolean visible = true;
	
	public TextFieldBinding(final IInstance instance) {
		this.instance = instance;
		
		BindingUtils.initFromInstance(this, instance);
	}
	
	public IInstance getInstance() {
		return this.instance;
	}

	public void onEvent(Event e, int sequenceNr) {
		if ("show".equals(e.entityName)) {
			this.visible = true;
		}
		if ("hide".equals(e.entityName)) {
			this.visible = false;
		}
		
		this.syncWidgetState();
	}

	public void onPropertyChange(Property property, Object value) {
		this.syncWidgetState();
	}

	private void syncWidgetState() {
		if (this.textField != null) {
			this.textField.getDisplay().asyncExec(new Runnable() {
				public void run() {
					textField.setText((String)getInstance().getProperty("text").getValue());
					textField.setVisible(visible);
				}
			});
		}
	}

	public void createControl(Composite parent) {
		this.textField = new Text(parent, SWT.BORDER);
		
		this.textField.addFocusListener(new FocusAdapter() {
			public void focusLost(FocusEvent e) {				
				String newText = textField.getText();
				Map parameterMap = new HashMap();
				parameterMap.put("s", newText);
				BindingUtils.triggerEvent(instance, "setText", parameterMap);
			}
		});
		
		this.textField.addKeyListener(new KeyListener() {

			public void keyPressed(KeyEvent event) {
				if (event.keyCode == 13) {
					String newText = textField.getText();
					Map parameterMap = new HashMap();
					parameterMap.put("currentText", newText);
					BindingUtils.triggerEvent(instance, "activated", parameterMap);
				}
			}

			public void keyReleased(KeyEvent event) {}
		});
		
		this.textField.addDisposeListener(new DisposeListener() {
			public void widgetDisposed(DisposeEvent arg0) {
				textField = null;
			}
		});
		
		this.syncWidgetState();
	}
}
