package Gui;

import java.awt.Component;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JEditorPane;
import javax.swing.JScrollPane;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

import lu.uni.democles.runtime.BindingUtils;
import lu.uni.democles.runtime.Event;
import lu.uni.democles.runtime.IBinding;
import lu.uni.democles.runtime.IInstance;
import lu.uni.democles.runtime.Property;

public class HTMLViewerBinding implements IBinding, IWidgetWrapper {

	private final IInstance instance;
	private JEditorPane editorPane;
	private JScrollPane scrollPane;

	public HTMLViewerBinding(final IInstance instance) {
		this.instance = instance;
		
		this.editorPane = new JEditorPane();
		this.editorPane.setEditable(false);
		
		this.editorPane.addHyperlinkListener(new HyperlinkListener() {
			public void hyperlinkUpdate(HyperlinkEvent e) {
				Map parameters = new HashMap();
				parameters.put("url", e.getURL().toString());
				if (e.getEventType().equals(HyperlinkEvent.EventType.ACTIVATED)) {
					BindingUtils.triggerEvent(instance, "linkClicked", parameters);
				} else if (e.getEventType().equals(HyperlinkEvent.EventType.ENTERED)) {
					BindingUtils.triggerEvent(instance, "linkEntered", parameters);
				} else if (e.getEventType().equals(HyperlinkEvent.EventType.EXITED)) {
					BindingUtils.triggerEvent(instance, "linkExited", parameters);
				}
			}			
		});
		
		this.scrollPane = new JScrollPane(this.editorPane);
		
		BindingUtils.initFromInstance(this, instance);
	}
	
	public IInstance getInstance() {
		return this.instance;
	}

	public void onEvent(Event e, int sequenceNr) {
		if ("showError".equals(e.entityName)) {
			String url = (String)e.getParameter("url");
			String message = (String)e.getParameter("message");
			
			this.editorPane.setText("<html><body><h1>Error loading <a href=\"" + url + "\">" + url + "</a></h1>" + message + "</body></html>");
		}
	}

	public void onPropertyChange(Property property, Object value) {
		if ("currentUrl".equals(property.entityName)) {
			Map params = new HashMap();
			params.put("url", value);
			try {
				this.editorPane.setPage((String)value);
				params.put("url", this.editorPane.getPage().toString());
				BindingUtils.triggerEvent(this.instance, "pageLoadFinished", params);
			} catch (IOException e) {
				params.put("message", e.getMessage());
				BindingUtils.triggerEvent(this.instance, "pageLoadError", params);
			}
		}
	}

	public Component getWidget() {
		return this.scrollPane;
	}
}
