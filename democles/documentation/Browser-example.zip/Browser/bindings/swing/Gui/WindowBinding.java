package Gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.Iterator;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JToolBar;
import javax.swing.WindowConstants;

import lu.uni.democles.runtime.BindingUtils;
import lu.uni.democles.runtime.Entity;
import lu.uni.democles.runtime.Event;
import lu.uni.democles.runtime.EventQueue;
import lu.uni.democles.runtime.IBinding;
import lu.uni.democles.runtime.IInstance;
import lu.uni.democles.runtime.Instance;
import lu.uni.democles.runtime.OCLSequence;
import lu.uni.democles.runtime.Property;

public class WindowBinding implements IBinding {

	protected final IInstance instance;

	protected final JFrame frame;
	
	protected final JToolBar toolbar;

	protected final JPanel widgetPanel;
	
	protected final JLabel statusLabel;
	
	public WindowBinding(final IInstance instance) {
		this.instance = instance;

		this.frame = new JFrame();
		this.frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		this.frame.setSize(400, 300);
		this.frame.setLocationRelativeTo(null);
		
		this.toolbar = new JToolBar();
		this.toolbar.setVisible(false);
		this.toolbar.setFloatable(false);
		
		this.widgetPanel = new JPanel();
		this.widgetPanel.setLayout(new BoxLayout(this.widgetPanel, BoxLayout.Y_AXIS));
		this.widgetPanel.setBorder(BorderFactory.createLoweredBevelBorder());
		this.widgetPanel.setVisible(true);
		
		this.statusLabel = new JLabel();
		this.statusLabel.setVisible(false);
		
		this.frame.getContentPane().setLayout(new BorderLayout());
		this.frame.getContentPane().add(this.toolbar, BorderLayout.PAGE_START);
		this.frame.getContentPane().add(this.widgetPanel, BorderLayout.CENTER);
		this.frame.getContentPane().add(this.statusLabel, BorderLayout.PAGE_END);
		
		BindingUtils.initFromInstance(this, instance);

		this.frame.setVisible(true);
	}
	
	public IInstance getInstance() {
		return this.instance;
	}
	
	public void onEvent(Event event, int sequenceNr) {
		if ("closed".equals(event.entityName)) {
			this.frame.dispose();
		}
	}

	public void onPropertyChange(Property property, Object value) {
		if ("title".equals(property.entityName)) {
			this.frame.setTitle((String)value);
		}
		if ("widgets".equals(property.entityName)) {
			this.widgetPanel.removeAll();
			
			OCLSequence seq = (OCLSequence)value;
			
			for (Iterator iterator = seq.getValues().iterator(); iterator.hasNext();) {
				IInstance widgetInstance = (IInstance)iterator.next();
				IBinding widgetBinding = widgetInstance.getBinding();
				if (widgetBinding == null) {
					throw new RuntimeException("Missing binding for " + widgetInstance);
				}
				
				if (widgetBinding instanceof IWidgetWrapper) {
					IWidgetWrapper w = (IWidgetWrapper)widgetBinding;
					this.widgetPanel.add(w.getWidget());
				}
			}
			this.frame.pack();
		}
		if ("toolbarWidgets".equals(property.entityName)) {
			this.toolbar.removeAll();
			
			OCLSequence seq = (OCLSequence)value;
			
			for (Iterator iterator = seq.getValues().iterator(); iterator.hasNext();) {
				IInstance actionInstance = (IInstance)iterator.next();
				IBinding actionBinding = actionInstance.getBinding();
				if (actionBinding == null) {
					throw new RuntimeException("Missing binding for " + actionInstance);
				}
				
				if (actionBinding instanceof IWidgetWrapper) {
					IWidgetWrapper w = (IWidgetWrapper)actionBinding;
					this.toolbar.add(w.getWidget());
				}
			}
			this.toolbar.setVisible(!seq.isEmpty());
			this.frame.pack();
		}
		if ("statusText".equals(property.entityName)) {
			if (value.equals(Entity.nullObject) || value == null || ((String)value).length() == 0) {
				this.statusLabel.setVisible(false);
			} else {
				this.statusLabel.setText((String)value);
				this.statusLabel.setVisible(true);
			}
		}
	}
}
