package Gui;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

import lu.uni.democles.runtime.BindingUtils;
import lu.uni.democles.runtime.Event;
import lu.uni.democles.runtime.IBinding;
import lu.uni.democles.runtime.IInstance;
import lu.uni.democles.runtime.Property;

public class ButtonBinding implements IBinding, IWidgetWrapper {

	private final IInstance instance;
	private final JButton button;

	public ButtonBinding(final IInstance instance) {
		this.instance = instance;
		
		this.button = new JButton();
		
		this.button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BindingUtils.triggerEvent(instance, "execute");
			}
		});
		
		BindingUtils.initFromInstance(this, instance);
	}
	
	public IInstance getInstance() {
		return this.instance;
	}

	public void onEvent(Event e, int sequenceNr) {
	}

	public void onPropertyChange(Property property, Object value) {
		if ("label".equals(property.entityName)) {
			this.button.setText((String)value);
		}
		if ("enabled".equals(property.entityName)) {
			this.button.setEnabled(((Boolean)value).booleanValue());
		}
	}

	public Component getWidget() {
		return this.button;
	}
}
