package Gui;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JTextField;

import lu.uni.democles.runtime.BindingUtils;
import lu.uni.democles.runtime.Event;
import lu.uni.democles.runtime.IBinding;
import lu.uni.democles.runtime.IInstance;
import lu.uni.democles.runtime.Property;

public class TextFieldBinding implements IBinding, IWidgetWrapper {

	private final IInstance instance;
	private JTextField textField;

	public TextFieldBinding(final IInstance instance) {
		this.instance = instance;
		
		this.textField = new JTextField();
		
		this.textField.addFocusListener(new FocusAdapter() {
			public void focusLost(FocusEvent e) {
				String newText = textField.getText();
				Map parameterMap = new HashMap();
				parameterMap.put("s", newText);
				BindingUtils.triggerEvent(instance, "setText", parameterMap);
			}
		});
		
		this.textField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String newText = textField.getText();
				Map parameterMap = new HashMap();
				parameterMap.put("currentText", newText);
				BindingUtils.triggerEvent(instance, "activated", parameterMap);
			}
		});
		
		BindingUtils.initFromInstance(this, instance);
	}
	
	public IInstance getInstance() {
		return this.instance;
	}

	public void onEvent(Event e, int sequenceNr) {
		if ("show".equals(e.entityName)) {
			this.textField.setVisible(true);
		}
		if ("hide".equals(e.entityName)) {
			this.textField.setVisible(false);
		}
	}

	public void onPropertyChange(Property property, Object value) {
		if ("text".equals(property.entityName)) {
			this.textField.setText((String) value);
		}
	}

	public Component getWidget() {
		return this.textField;
	}
}
