package Gui;

import java.awt.Component;

public interface IWidgetWrapper {

	public Component getWidget();
}
