package Gui;

import java.awt.Component;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.swing.AbstractListModel;
import javax.swing.DefaultListSelectionModel;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListDataListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import com.sun.org.apache.xalan.internal.xsltc.runtime.Hashtable;

import lu.uni.democles.runtime.BindingUtils;
import lu.uni.democles.runtime.Entity;
import lu.uni.democles.runtime.Event;
import lu.uni.democles.runtime.IBinding;
import lu.uni.democles.runtime.IInstance;
import lu.uni.democles.runtime.OCLCollection;
import lu.uni.democles.runtime.OCLSequence;
import lu.uni.democles.runtime.Property;

public class ItemListBinding implements IBinding, IWidgetWrapper {

	protected final IInstance instance;
	protected final JScrollPane scrollPane;
	protected final JList list;
	
	private class PropertyLookupSequenceListModel extends AbstractListModel {

		private OCLSequence elements = new OCLSequence();
		private final String propertyName;
		
		public PropertyLookupSequenceListModel(String propertyName) {
			this.propertyName = propertyName;
		}
		
		public void setElements(OCLSequence sequence) {

			this.elements = sequence;
			
			this.fireContentsChanged(this, 0, getSize());
		}
		
		public void refreshItem(int index) {
			this.fireContentsChanged(this, index, index);
		}
		
		public Object getElementAt(int index) {
			IInstance itemInstance = (IInstance)this.elements.at(index + 1);
			Property property = itemInstance.getProperty(this.propertyName);
			OCLCollection value = property.evalInContainer();
			return value.getValues().iterator().next();
		}
		
		public OCLSequence getElements() {
			return this.elements;
		}

		public int getSize() {
			return this.elements.size();
		}		
	}
	
	protected final PropertyLookupSequenceListModel listModel;

	public ItemListBinding(final IInstance instance) {
		this.instance = instance;
	
		this.listModel = new PropertyLookupSequenceListModel("value");
		this.list = new JList(this.listModel);
		
		this.list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		
		this.scrollPane = new JScrollPane(this.list);

		this.list.addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent e) {
				if (e.getValueIsAdjusting()) return;

				int index = list.getSelectedIndex();
				triggerSelectionChanged(index);
			}			
		});
		
		BindingUtils.initFromInstance(this, instance);
	}

	protected void triggerSelectionChanged(int index) {
		this.list.setSelectedIndex(-1);
		Object selectedInstance = null;
		if (index != -1) {
			selectedInstance = this.listModel.getElements().at(index + 1);
		}
		
		Map parameters = new HashMap();
		parameters.put("item", selectedInstance);
		BindingUtils.triggerEvent(instance, "itemSelected", parameters);						
	}
	
	public IInstance getInstance() {
		return this.instance;
	}

	public void onEvent(Event e, int sequenceNr) {
		if ("updateSelectedItem".equals(e.entityName)) {
			int selectedIndex = this.list.getSelectedIndex();
			this.listModel.refreshItem(selectedIndex);
		}
	}

	public void onPropertyChange(Property property, Object value) {
		if ("items".equals(property.entityName)) {
			OCLSequence sequence = (OCLSequence)value;
			this.listModel.setElements(sequence);
			this.list.getSelectionModel().clearSelection();
		}
	}

	public Component getWidget() {
		return this.scrollPane;
	}
}
