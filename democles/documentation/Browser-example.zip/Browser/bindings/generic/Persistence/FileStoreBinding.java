package Persistence;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Hashtable;
import java.util.Map;

import lu.uni.democles.runtime.BindingUtils;
import lu.uni.democles.runtime.Event;
import lu.uni.democles.runtime.IBinding;
import lu.uni.democles.runtime.IInstance;
import lu.uni.democles.runtime.Property;

public class FileStoreBinding implements IBinding {

	private final IInstance instance;

	public FileStoreBinding(IInstance instance) {
		this.instance = instance;
	}
	
	public void onEvent(Event e, int sequenceNr) {
		if ("load".equals(e.entityName)) {
			String filename = (String)e.getParameter("filename");
			this.handleLoad(filename);
		}
		if ("save".equals(e.entityName)) {
			String filename = (String)e.getParameter("filename");
			Object object = e.getParameter("object");
			this.handleSave(filename, object);
		}
	}
	
	protected void handleLoad(String filename) {

		Object object = null;
		ObjectInputStream ois = null;
		try {
			FileInputStream fis = new FileInputStream(filename);
			ois = new ObjectInputStream(new BufferedInputStream(fis));
			object = ois.readObject();			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (ois != null) {
				try {
					ois.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
		Map parameters = new Hashtable();
		parameters.put("object", object);
		BindingUtils.triggerEvent(this.instance, "loaded", parameters);
	}
	
	protected void handleSave(String filename, Object object) {

		ObjectOutputStream oos = null;
		try {
			FileOutputStream fos = new FileOutputStream(filename);
			oos = new ObjectOutputStream(new BufferedOutputStream(fos));
			oos.writeObject(object);
			oos.close();
				
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (oos != null) {
				try {
					oos.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
		BindingUtils.triggerEvent(this.instance, "saved");
	}

	public void onPropertyChange(Property property, Object value) {
	}
	
	public IInstance getInstance() {
		return this.instance;
	}
}
