This is a simple example project demonstrating the use of
platform bindings with Democles (http://democles.lassy.uni.lu).

Documentation on how to run this example project can be found at:

http://democles.lassy.uni.lu/documentation/browserexample.html
